#### Dockerfile & Container Review Principles
> Focus on container security, multi-stage builds, rootless execution, layer caching, and image bloat.

#### Security & Least Privilege
- **Root User Execution**: Container running by default as `root` without specifying `USER <non-root-uid>` before the entrypoint/CMD.
- **Exposed Secrets & Tokens**: Hardcoded credentials, private keys, or build secrets injected via `ENV` or `ARG` without `--mount=type=secret`.
- **Insecure Base Images**: Using untrusted images or unpinned `:latest` tags in production stages instead of digest pins (`sha256:...`) or minimal secure bases (distroless, alpine, slim).

#### Optimization & Caching
- **Inefficient Layer Ordering**: Copying entire source code before installing dependencies (e.g. `COPY . .` before `npm install` or `pip install`), invalidating dependency build caches on every code change.
- **Unnecessary Packages & Cache Artifacts**: Package managers run without cleaning cache or temporary indices (e.g. missing `--no-cache` in alpine `apk`, missing `rm -rf /var/lib/apt/lists/*` in debian/ubuntu, or missing `--no-cache-dir` in `pip`).
- **Multi-Stage Build Missing**: Leaving build toolchains (compilers, devDependencies, git, headers) in final runtime image instead of separating build and release stages.

#### Process & Signal Handling
- **PID 1 / Zombie Processes**: Using shell form (`ENTRYPOINT command param`) instead of exec form (`ENTRYPOINT ["command", "param"]`), which prevents forwarding SIGTERM/SIGINT and causes unclean container terminations.
