#### Flutter & Dart Review Principles
> Favor precision over recall: report only defects that are likely real in the changed code and its reachable context. Focus on widget lifecycle bugs, state leaks, async race conditions, BuildContext misuse, and unhandled Streams.

#### Correctness & Concurrency
- **BuildContext across Async Gaps**: Using `BuildContext` (e.g. `Navigator.of(context)`, `Theme.of(context)`, `ScaffoldMessenger.of(context)`) after an `await` without verifying `if (!mounted) return` or `context.mounted`.
- **Stream/ChangeNotifier Subscription Leaks**: Controllers (`TextEditingController`, `AnimationController`, `ScrollController`), Streams, or ChangeNotifier listeners created in State without corresponding `.dispose()` or `.cancel()` in `dispose()`.
- **SetState in Build or Post-Frame Race**: Calling `setState()` synchronously inside `build()`, or calling it without checking `mounted` in async callbacks.
- **Unawaited Futures in UI Handlers**: Async onPressed/onTap handlers firing floating futures that can fail silently without try/catch or error feedback.

#### State Management & Reactivity
- **Direct Mutable State Overwrites**: Modifying collections directly without notifying listeners (e.g. `state.list.add(item)` in Riverpod/Bloc/Provider without emitting a new immutable state instance).
- **Infinite Build Re-trigger**: Triggering side effects (navigation, analytics, network calls) directly inside `build()` instead of lifecycle methods (`initState`, `didUpdateWidget`) or state listeners.

#### Performance
- **Heavy Computation in UI Thread**: Running JSON deserialization of large payloads or complex loops on the main isolate instead of `compute()` or `Isolate.run()`.
- **Unnecessary Widget Rebuilds**: Lack of `const` constructors where parameters are compile-time constants; rebuilding entire large subtrees instead of scoping down with `Consumer`, `Selector` or small widgets.
- **Image/List Memory Spikes**: `ListView` with many items instantiated via `children: [...]` instead of `ListView.builder` or `ListView.separated`.

#### Error Handling & Platform Interop
- **Platform Channel Exceptions**: MethodChannel invocations without handling `PlatformException` or timeouts.
- **Null Safety Assumptions**: Force-unwrapping (`!`) on nullable data coming from external APIs or storage without validation.
