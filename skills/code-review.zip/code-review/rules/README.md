# rules/ — Sistema Modular de Reglas por Path y Stack Tecnológico

Este directorio implementa el motor de reglas en dos capas:
1. **Reglas de Proyecto (`rules/rule.json`)**: Reglas de máxima prioridad específicas para la arquitectura de OpenHer (Zustand, Rust Tokio/Serde, React, Contratos y Shell).
2. **Catálogo Modular de Stacks (`rules/rule_map.json` y `rules/docs/`)**: Biblioteca completa con **más de 50 stacks tecnológicos modernos** (Rust, Go, Python, TypeScript, Java, C++, Kotlin, Swift, Dart/Flutter, Dockerfile, Terraform, etc.).

---

## 1. Jerarquía de Resolución

El orden de precedencia al resolver qué reglas aplican a un archivo es:
1. **Regla de Proyecto explícita** (`rules/rule.json` con `--rule`).
2. **Regla de Stack Tecnológico** (`rules/rule_map.json` apuntando a su documento en `rules/docs/<stack>.md`).
3. **Reglas de Sistema Upstream de OCR** (con `merge_system_rule: true`).
4. **Regla Global por Defecto** (`rules/docs/default.md` + 11 dimensiones).

---

## 2. Catálogo Modular de 50+ Stacks (`rules/docs/`)

- **Lenguajes Compilados y Sistemas:** `rust.md`, `go.md`, `c.md`, `cpp.md`, `zig.md`, `nim.md`, `ocaml.md`, `haskell.md`.
- **Plataformas Móvil y Frontend:** `dart_flutter.md`, `ts_js_tsx_jsx.md`, `swift.md`, `kotlin.md`, `astro.md`, `arkts.md`, `elm.md`, `pug.md`.
- **Backend, Enterprise y JVM:** `java.md`, `php.md`, `build_gradle.md`, `pom_xml.md`, `mapper_dao_xml.md`.
- **Scripting, Inteligencia Artificial y Datos:** `python.md`, `julia.md`, `r.md`, `matlab.md`.
- **Infraestructura, Nube y DevOps:** `dockerfile.md`, `terraform.md`, `bicep.md`, `nix.md`, `github_workflows.md`, `github_config.md`, `yaml.md`, `json.md`.
- **Contratos, RPCs y Schemas:** `protobuf.md`, `graphql.md`, `prisma.md`, `capnp.md`, `thrift.md`, `rego.md`.
- **Smart Contracts / Web3:** `solidity.md`, `vyper.md`.
- **Gestión de Paquetes:** `package_json.md`, `cargo_toml.md`, `composer_json.md`.

---

## 3. Comandos Rápidos

- Previsualizar reglas que aplican a un archivo:
  ```bash
  ocr rules check <archivo>
  # o vía delegate:
  npx -y @alibaba-group/open-code-review delegate rule <archivos...>
  ```
- Empaquetar y asignar reglas por archivo automáticamente:
  ```bash
  python scripts/bundle-changes.py --preview preview.json --rules rules/rule_map.json
  ```
- Añadir o modificar un stack: agrega o edita el archivo correspondiente en `rules/docs/<stack>.md` y su mapeo glob en `rules/rule_map.json`.
