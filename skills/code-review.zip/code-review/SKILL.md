---
name: code-review
description: Motor integral de auditoría de código, caza de bugs ocultos, análisis de flujos reales de usuario, desincronización full-stack, resiliencia Chaos Monkey (alta latencia, EPERM), invariantes de Zero Data Loss, observabilidad de logs, auto-fix supervisado y generación de tests de regresión. Protocolo cerrado delegate-first con cobertura 100%, catálogo de más de 50 reglas modulares por stack, suite de scripts deterministas (filter, bundle, repair, collector, diff, health) y scorecard JSON+markdown+SARIF.
---

# Code Review

## 1. Misión

Auditar flujos vivos de código (backend Rust/Go/Python/Java/C++, contratos, frontends React/Vue/Flutter, UI, Windows/Linux/macOS como entornos objetivo) para detectar errores que compilan y pasan tests aislados pero fallan en uso real: pantallas congeladas, pérdida de datos, fallos de concurrencia o red, desincronización de contratos serde/JSON y vulnerabilidades de inyección. El review es determinista y fail-closed: sin cobertura del 100% no hay veredicto.

## 2. Suite de Ingeniería Determinista (`scripts/`)

La skill cuenta con una suite completa de utilidades operativas en Python (sin dependencias externas):

- **`scripts/ocr-health.py`**: Diagnóstico previo de salud del entorno (CLI, Git, reglas, LLM).
- **`scripts/filter-scope.py`**: Filtrado determinista de scope, gitignore, archivos binarios y exclusiones.
- **`scripts/bundle-changes.py`**: Empaquetado automático por regla, dominio y cálculo de presupuestos de tokens.
- **`scripts/comment-repair.py`**: Reparador sintáctico de JSON, validador de categorías/severidad y anclaje real en disco (anti-alucinación de líneas y código).
- **`scripts/check-coverage.py`**: Puerta de enlace obligatoria de cobertura 100% (fail-closed).
- **`scripts/session-collector.py`**: Colector multiformato (Scorecard Markdown y OASIS SARIF v2.1.0 para CI/CD).
- **`scripts/session-diff.py`**: Comparador delta post-fix para cerrar la Fase 6 (`RESOLVED`, `PERSISTING`, `NEW`).

## 3. Protocolo cerrado en 8 fases

CLI (versión verificada v1.12.5, sin LLM propio en modo delegate):

```bash
npx -y @alibaba-group/open-code-review
```

Asumir el CLI instalado; no pre-chequear con `command -v ocr` ni `ocr --version`. Solo instalar si falla con `command not found`. Ejecutar las fases en orden. No saltar ninguna. Comportamiento por defecto read-only: no editar, no commitear, no pushear, no comentar en sistemas externos.

### F0 — Diagnóstico y Scope Determinista (qué se revisa)

Diagnóstico de salud opcional previo:
```bash
python scripts/ocr-health.py
```

Obtener el preview oficial:
```bash
npx -y @alibaba-group/open-code-review delegate preview --format json
```

O utilizar el filtro determinista local:
```bash
python scripts/filter-scope.py --repo . --output preview.json
```

Variantes:
```bash
npx -y @alibaba-group/open-code-review delegate preview --format json --from <ref> --to <ref>
npx -y @alibaba-group/open-code-review delegate preview --format json --commit <hash>
npx -y @alibaba-group/open-code-review delegate preview --format json --background "<contexto-negocio>"
npx -y @alibaba-group/open-code-review delegate preview --format json --exclude '<patterns>' --repo <path>
npx -y @alibaba-group/open-code-review delegate preview --format json --background-file <path>
```

Registrar `mode` (workspace / range / commit), `merge_base`, `from/to/commit`, lista `reviewable_files` (path + status + insertions/deleciones) y lista de excluidos con motivo. `--background` es obligatorio siempre que haya contexto de negocio (requisitos, constraints, criterios de aceptación); `--background-file` tiene precedencia sobre `-b`. Construir checklist con cada entrada `(path, status)` antes de revisar.

### F1 — Resolución de Reglas Modulares (con qué checklist se revisa)

La skill dispone de un catálogo de **más de 50 stacks tecnológicos** en `rules/docs/` y `rules/rule_map.json`:

```bash
npx -y @alibaba-group/open-code-review delegate rule --format json <paths>
npx -y @alibaba-group/open-code-review delegate rule --format json --rule rules/rule.json <paths>
```

Precedencia:
1. Reglas locales de proyecto (`rules/rule.json`).
2. Reglas del catálogo modular (`rules/rule_map.json` y `rules/docs/<stack>.md`).
3. Reglas del sistema upstream (`merge_system_rule: true`).
4. 11 Dimensiones universales.

Para previsualizar qué regla aplica a un archivo: `ocr rules check <file>`.

### F2 — Diffs por git (evidencia exacta)

Según `mode` de F0:

```bash
git diff <merge_base>..<to> -- <path>
git show <commit> -- <path>
git diff HEAD -- <path>
```

Archivos untracked en workspace: no tienen diff; leer el archivo completo directo. Inspeccionar diff más contexto circundante suficiente para validar cada hallazgo antes de reportarlo.

### F3 — Bundling Automático y Review con Contexto Aislado

Empaquetar archivos por afinidad de regla y dominio:
```bash
python scripts/bundle-changes.py --preview preview.json --output bundles.json
```

Revisar cada bundle como unidad con contexto aislado: cargar solo sus diffs + sus reglas + sus contratos; no mezclar hallazgos de otros bundles hasta la pasada de reflexión (F4b). Aplicar a cada bundle las 11 dimensiones como checklist obligatorio. Si un archivo ≥50 líneas cambiadas o el bundle suma ≥100 líneas en 2+ archivos, hacer primero un análisis de riesgo (plan phase) y luego el review principal. Cada archivo termina como `reviewed` o `skipped` con motivo concreto.

### F4 — Simulación chaos obligatoria por bundle

Para cada bundle, simular los tres casos y registrar el resultado (falla / resiste + línea o invariante afectado):

1. **Timeout 5s**: el backend o la dependencia tarda 5 segundos. Verificar `AbortSignal`/timeout, estado `isLoading` con salida en `catch`/`finally`, sin spinners infinitos.
2. **Fallo a mitad**: la petición, escritura en BD o disco falla a mitad de camino. Verificar transacción atómica, borrador local persistido, sin pérdida de trabajo.
3. **Cierre**: el usuario cierra la ventana o el proceso muere durante la operación. Verificar recuperación al reabrir, sin estado corrupto ni promesa colgada.

Si un caso no aplica al bundle, registrar `no-aplica` con una línea de justificación. Un bundle sin registro chaos se considera no revisado.

### F4b — Reparación Anti-Alucinación y Anclaje Real

Pasar los hallazgos preliminares por el reparador y validador:
```bash
python scripts/comment-repair.py --input findings.raw.json --repo . --output findings.clean.json
```

Este paso:
- Corrige JSONs mal serializados o con comillas rotas.
- Valida severidades (`critical`, `high`, `medium`, `low`) y categorías canónicas.
- Ancla líneas reales en disco si venían en `start=end=0` buscando el snippet de código.
- Comprueba que `existing_code` coincida literalmente con el disco, descartando citas falsas.

### F5 — Coverage Check + Scorecard + Exportación SARIF

1. Verificar cobertura cerrada obligatoria:
```bash
python scripts/check-coverage.py --preview preview.json --reviewed reviewed.txt
```
Fail-closed: si `coverage_rate < 100%` el review se considera INCOMPLETO y no se emite veredicto; se listan los archivos pendientes.

2. Consolidar el reporte y generar artefactos:
```bash
# Generar Scorecard Markdown
python scripts/session-collector.py --input findings.clean.json --preview preview.json --format markdown --output scorecard.md

# Generar OASIS SARIF v2.1.0 para GitHub Actions / CI
python scripts/session-collector.py --input findings.clean.json --format sarif --output review.sarif
```

### F6 — Verificación post-fix con Session Delta (si se aplican fixes)

Tras aplicar fixes a hallazgos Critical/High:
```bash
python scripts/session-diff.py --before before.json --after after.json --output session_delta.md
```
O nativamente con OCR si se utilizó modo review:
```bash
npx -y @alibaba-group/open-code-review session compare <before> <after>
```

Solo se cierra el review cuando no queden hallazgos `PERSISTING` en Critical/High y no aparezcan regresiones (`NEW`).

### F7 — Auditoría Estática sin Git (`scan`) y Modo LLM

Para auditar código desconocido o carpetas sin historial git:
```bash
npx -y @alibaba-group/open-code-review scan --path <dir> --audience agent --format json --output scan_result.json
```

Para review directo con LLM configurado:
```bash
npx -y @alibaba-group/open-code-review review --audience agent --format json --output result.json
npx -y @alibaba-group/open-code-review review --audience agent --format sarif --from main --to feature
```

## 4. Tabla de las 11 dimensiones resumida

Detalle operativo en `references/dimensiones.md`.

| # | Dimensión | Línea de control |
|---|-----------|------------------|
| 1 | Flujos rotos y máquinas de estado | `isLoading` sin salida en `catch`/`finally`, modales sin salida, promesas sin resolución. |
| 2 | Caos UX y concurrencia humana | Acción sin deshabilitar en vuelo, doble clic, respuestas desfasadas por lag. |
| 3 | Desincronización full-stack | `camelCase` TS frente a `snake_case` serde Rust, enums y tipos no sincronizados. |
| 4 | Mutaciones directas de estado | Mutación in-place en Zustand o React que impide re-render. |
| 5 | Fugas de memoria y deadlocks | Listeners, intervalos o sockets sin cleanup; I/O síncrono en Tokio. |
| 6 | Seguridad e inyección | Interpolación shell sin Base64, path traversal, input sin validar. |
| 7 | Ponytail / YAGNI | Duplicación de helper existente, abstracción sin uso real. |
| 8 | Dependencias fantasma | Símbolo o paquete ausente en la versión instalada real. |
| 9 | Chaos Monkey y entorno hostil | Sin timeout ni `AbortSignal`, sin manejo de `EPERM` Windows u offline. |
| 10 | Invariantes de Zero Data Loss | Formulario sin borrador local, mutación SQLite fuera de transacción atómica. |
| 11 | Observabilidad e higiene de logs | Error sin contexto (IDs, URLs), depuración residual en código. |

## 5. Formato de Salida

### JSON machine (un objeto por hallazgo)

```json
{
  "path": "path/to/file.ts",
  "content": "Descripción detallada del defecto",
  "start_line": 42,
  "end_line": 45,
  "category": "bug",
  "severity": "critical",
  "suggestion_code": "código propuesto",
  "existing_code": "código actual"
}
```

- `category`: `bug | security | performance | maintainability | test | style | documentation | other`.
- `severity`: `critical | high | medium | low`.

### Scorecard markdown

```markdown
## Scorecard
Files reviewed: <n>
Critical: <X> / High: <Y> / Medium: <Z> / Low: <W>
coverage_rate: <rate>%
```

## 6. Referencias

- `rules/rule_map.json` — mapeo modular de más de 50 stacks tecnológicos.
- `rules/docs/` — biblioteca de reglas especializadas por lenguaje.
- `rules/rule.json` — configuración canónica de reglas de proyecto.
- `scripts/` — suite completa de ingeniería determinista (filter, bundle, repair, collector, diff, health).
- `references/dimensiones.md` — detalle operativo de las 11 dimensiones con patrones y antipatrones.
- `references/chaos-casos.md` — guion de simulación chaos por bundle y por capa.
- `references/delegate-protocol.md` — protocolo delegate-first.
- `references/ci-sarif-sessions.md` — sesiones, SARIF, scan y CI.
