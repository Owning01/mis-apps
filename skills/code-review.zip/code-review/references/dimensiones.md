# Dimensiones de auditoría — OpenHer (11)

Mapeo de categorías OCR: `bug | security | performance | maintainability | test | style | documentation | other`.
Severidades: `critical | high | medium | low`. Regla: si congela UI, pierde datos o ejecuta comandos → `high` o `critical`.

---

## 1. Flujos Rotos & Máquinas de Estado

**Señal.** `isLoading = true` sin `finally`, modal sin salida, promesa que nunca resuelve, `await` sin `catch`.
```ts
// web/src/api.ts — ROTO: spinner infinito si fetch falla
store.setState({ isLoading: true });
const r = await fetch(url); // sin try/finally, sin AbortSignal
store.setState({ data: await r.json(), isLoading: true }); // nunca apaga
```
```ts
// CORRECTO
store.setState({ isLoading: true, error: null });
try { /* fetch con AbortSignal */ } catch (e) { store.setState({ error: msg(e) }); }
finally { store.setState({ isLoading: false }); }
```
**Impacto.** Pantalla congelada, spinner infinito, modal que atrapa al usuario.
**Checklist.**
1. ¿Todo `set isLoading(true)` tiene `finally` que lo apaga?
2. ¿Todo modal/diálogo tiene vía de cierre (Esc, backdrop, botón)?
3. ¿Toda promesa tiene `catch` o el llamador la observa (`JoinHandle` en Rust, `await` con timeout en TS)?
**OCR.** `category: bug` · `severity: high` (pantalla congelada) / `critical` (flujo principal bloqueado, ej. arranque).

## 2. Caos UX & Concurrencia Humana

**Señal.** Botón de acción sin `disabled={isLoading}`, doble submit, respuestas que llegan desfasadas (race: request vieja pisa a la nueva).
```ts
// ROTO: doble clic = doble POST /shell
<button onClick={runCommand}>Ejecutar</button>
// CORRECTO
<button onClick={runCommand} disabled={isLoading}>Ejecutar</button>
```
```ts
// ROTO: race — respuesta lenta pisa a la rápida. Usar AbortController o requestId.
```
**Impacto.** Peticiones duplicadas (doble comando shell, doble escritura), datos pisados.
**Checklist.**
1. ¿Los botones de acción se deshabilitan mientras hay petición en vuelo?
2. ¿Las respuestas tardías se descartan (`AbortController.abort()` en cambio de input, requestId/monotonic seq)?
3. ¿Doble clic / Enter repetido es idempotente o está bloqueado?
**OCR.** `category: bug` · `severity: high` (duplica efectos) / `medium` (solo visual).

## 3. Desincronización Full-Stack

**Señal.** `camelCase` TS vs `snake_case` Rust serde, enum que existe en un lado, campo renombrado sin migrar.
```rust
// desktop-app/src/http_server.rs
#[derive(Deserialize)] struct RunReq { command_id: String } // snake_case
```
```ts
// web/src/shell.ts — ROTO: manda commandId, Rust recibe undefined→"" y falla en silencio
fetch("/shell/run", { body: JSON.stringify({ commandId: id }) });
```
**Impacto.** Campos en `undefined`, deserialización parcial, errores silenciosos.
**Checklist.**
1. ¿Cada campo del contrato existe con el mismo nombre/caso en `web/src/types.ts` y el `struct` Rust (`serde(rename_all)` documentado)?
2. ¿Los enums están sincronizados valor por valor (incluido el default/`other`)?
3. ¿Hay test o type-check que rompa si un lado renombra un campo?
**OCR.** `category: bug` · `severity: high` (contrato roto) / `medium` (campo opcional).

## 4. Mutaciones Directas de Estado

**Señal.** Mutación in-place en Zustand/React: `push`, asignación directa, `sort()` sobre el array del store.
```ts
// ROTO: la UI no re-renderiza (misma referencia)
store.getState().items.push(newItem);
state.config.theme = "dark";
```
```ts
// CORRECTO: nueva referencia, update inmutable
set((s) => ({ items: [...s.items, newItem] }));
set((s) => ({ config: { ...s.config, theme: "dark" } }));
```
**Impacto.** UI desfasada del estado real; bugs "fantasma" que desaparecen al recargar.
**Checklist.**
1. ¿Todo update del store crea nueva referencia (spread / `map` / `filter`, nunca `push`/`splice`/`sort` in-place)?
2. ¿Los objetos anidados se clonan nivel por nivel hasta el campo tocado?
3. ¿Los `useEffect`/selectores dependen de referencias estables y no de mutaciones?
**OCR.** `category: bug` · `severity: medium` (alto si afecta datos visibles críticos).

## 5. Fugas de Memoria & Deadlocks

**Señal.** `useEffect` sin cleanup (listener, intervalo, WS, PTY), `Mutex`/`RwLock` cruzando `.await`, I/O bloqueante en Tokio.
```ts
// ROTO: listener duplicado en cada mount
useEffect(() => { window.addEventListener("resize", h); }, []);
```
```rust
// ROTO: lock cruzando await = deadlock potencial; además bloquea el runtime
let g = state.lock().unwrap();
tokio::fs::read_to_string(p).await; // + std::fs en async
```
```rust
// CORRECTO: clonar lo necesario, soltar el lock antes del await; usar tokio::fs
```
**Impacto.** RAM creciente, listeners duplicados, cuelgues del backend.
**Checklist.**
1. ¿Todo `useEffect` con subscribe/interval/WS retorna cleanup (`removeEventListener`, `clearInterval`, `ws.close()`)?
2. ¿Ningún guard de `Mutex`/`RwLock` vive a través de un `.await` o de I/O?
3. ¿Cero I/O bloqueante (`std::fs`, `std::process::Command`) en paths async (usar `tokio::fs`, `tokio::process`)?
**OCR.** `category: performance` (leak) o `bug` (deadlock) · `severity: high` (deadlock) / `medium` (leak lento).

## 6. Seguridad & Inyección

**Señal.** Concatenar input de usuario en shell/SQL/path, `innerHTML`/`dangerouslySetInnerHTML`, `eval`, path traversal.
```rust
// ROTO: inyección de comandos vía input del usuario
let cmd = format!("git log {}", user_input); // ¡arbitrario!
```
```ts
// ROTO
el.innerHTML = userInput; // XSS
```
Regla OpenHer: el input de usuario viaja a `/shell/*` solo como argumento estructurado o Base64, nunca interpolado; validar path dentro de la raíz permitida; nunca loguear tokens.
**Impacto.** Ejecución arbitraria de comandos, XSS, lectura fuera de la raíz.
**Checklist.**
1. ¿Algún input de usuario llega a shell/SQL/path sin allowlist ni encoding (Base64/argv)?
2. ¿Hay `innerHTML`, `eval`/`Function`, `document.write` o prototipos mutados?
3. ¿Se loguean secretos/tokens o se exponen API keys al cliente?
**OCR.** `category: security` · `severity: critical` (RCE/inyección real) / `high` (XSS/path traversal).

## 7. Ponytail / YAGNI

**Señal.** Helper duplicado que ya existe (`utils.ts`), abstracción para un solo uso, flag/config que nadie lee, dependencia para lo que hace el stdlib.
```ts
// ROTO: tercer formateador de fechas local; ya existe formatDate en utils.ts
```
**Impacto.** Código inflado, tres lugares donde arreglar el mismo bug.
**Checklist.**
1. ¿Esta lógica ya existe en `web/src/utils.ts`, `desktop-app/src/common.rs` u otro helper? (buscar antes de crear)
2. ¿La abstracción tiene ≥2 usos reales hoy (no hipotéticos)?
3. ¿Se resuelve con stdlib (`fetch`+`AbortSignal`, `std::fs`, `iterator`) sin nueva dependencia?
**OCR.** `category: maintainability` (o `style` si es trivial) · `severity: low` (subir a `medium` si el duplicado ya divergió).

## 8. Dependencias Fantasma

**Señal.** Import de API que no existe en la versión instalada (`package.json`/`Cargo.toml` vs código), método de Capacitor inexistente en la plataforma, `#[cfg]` que deja símbolo sin definir.
```ts
// ROTO: Filesystem.readFile con options de v6 en runtime v5 → throw en producción
```
```rust
// ROTO: crate actualizada en Cargo.toml pero código usa API eliminada
```
**Impacto.** Runtime crash solo en producción/APK, no en `pnpm dev`.
**Checklist.**
1. ¿Cada import existe en la versión instalada real (`pnpm ls`, `cargo tree`)?
2. ¿Las APIs de Capacitor/plataforma están guardadas por plataforma (`desktop.ts` vs móvil)?
3. ¿El lockfile (`pnpm-lock.yaml`, `Cargo.lock`) está sincronizado con el manifiesto?
**OCR.** `category: bug` (o `other` si es config) · `severity: high` (crash en runtime) / `medium` (solo build).

## 9. Chaos Monkey & Entorno Hostil

**Señal.** `fetch` sin timeout/`AbortSignal`, sin retry, sin manejo de `EPERM`/offline; Rust sin timeout en sockets/PTY.
Detalle operativo en `references/chaos-casos.md` (matriz obligatoria por capa).
```ts
// ROTO: cuelga para siempre si :4848 no responde
await fetch("http://127.0.0.1:4848/shell/run", { method: "POST", body });
```
**Impacto.** Cuelgues ante lag, disco bloqueado por antivirus (EPERM Windows), red caída.
**Checklist.**
1. ¿Toda petición tiene timeout + `AbortSignal` y mensaje de error accionable?
2. ¿Los fallos transitorios (red, EPERM, busy) reintentan con backoff acotado?
3. ¿El estado offline/lentitud tiene UI explícita (banner, reintento manual)?
**OCR.** `category: bug` (resiliencia) o `performance` (sin timeout en hot path) · `severity: medium` (alto si es ruta crítica).

## 10. Invariantes de Zero Data Loss

**Señal.** Formulario sin borrador autosalvado, escritura SQLite fuera de transacción, `localStorage` sin try/catch (cuota privada) ni schema-version.
```ts
// ROTO: se cierra la ventana = se pierde el prompt
const [draft, setDraft] = useState("");
```
```ts
// CORRECTO: autosave con debounce a persistentStorage + restore al montar
```
```sql
-- ROTO: dos INSERTs sin BEGIN/COMMIT → corte a mitad = DB a medias
```
**Impacto.** Pérdida de trabajo del usuario ante cierre, crash o fallo a mitad.
**Checklist.**
1. ¿Todo input no trivial autosalva borrador (debounce) y lo restaura al montar?
2. ¿Toda mutación multi-paso (SQLite, archivos) es atómica (tx `BEGIN/COMMIT`, write-tmp+rename)?
3. ¿La persistencia local tolera cuota/JSON corrupto/versionado sin borrar datos del usuario?
**OCR.** `category: bug` · `severity: critical` (pérdida de datos real) / `high` (riesgo sin caso confirmado).

## 11. Observabilidad & Higiene de Logs

**Señal.** `catch {}` silencioso, error sin IDs/URLs, `console.log`/`println!` de debug olvidados, niveles mezclados.
```ts
// ROTO: imposible diagnosticar
catch (e) { console.log("falló"); }
```
```ts
// CORRECTO: contexto estructurado + nivel error
catch (e) { console.error("[shell.run] cmd=%s failed: %s", cmdId, toMsg(e)); }
```
**Impacto.** Fallos irreproducibles, horas de diagnóstico, logs con ruido.
**Checklist.**
1. ¿Todo `catch` loguea con contexto (qué operación, qué ID/URL/path, qué error)?
2. ¿Cero `console.log`/`println!` de debug y cero secretos en logs?
3. ¿Los errores de usuario son accionables (qué pasó + qué hacer) y los técnicos llevan nivel correcto?
**OCR.** `category: documentation` (logs) o `maintainability` · `severity: low` (subir a `medium` si oculta fallos de las dims 1–10).
