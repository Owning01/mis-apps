# Review vs delegate · scan · sessions · SARIF · CI

## review (CON LLM) vs delegate (SIN LLM) vs scan

- `ocr review` usa LLM configurado: análisis profundo, caro. Úsalo para auditoría completa.
- `delegate` (ver `delegate-protocol.md`) es determinista y gratis: úsalo SIEMPRE primero
  (preview + rules + coverage 100%); el agente pone la inteligencia.
- `ocr scan` revisa archivos completos sin git (auditar código desconocido o dirs sin diff):
  `ocr scan`, `ocr scan --path internal/agent`, `ocr scan --resume <id>`.

## review esencial

```bash
ocr review --audience agent --format json
ocr review --audience agent --format sarif
ocr review --audience agent --format json --output result.json   # recomendado en runs grandes/agentes
ocr review --from main --to feature --audience agent --format json
ocr review -c abc123 --audience agent --format json
ocr review --resume <session-id> --from main --to feature   # retomar (solo range/commit; workspace NO soporta resume)
ocr review --preview                                        # qué entraría, sin LLM
```

`--audience agent` = solo resumen (progreso a stderr); nunca `--audience human`.
`--format text|json|sarif`. `--output` requiere ≥v1.10.0 (ver Gotchas SKILL.md).
Nunca pipear output a `tail/head`: usar `--output` + lectura completa.
Setup LLM: `ocr config provider`, `ocr config model`, verificar `ocr llm test`,
listar `ocr llm providers`; override por run `--provider/--model`.

## Background y budget en review

- `--background/-b` (o `--background-file/-B`, precede) con contexto de negocio.
- `--exclude '<pats>'`, `--max-tokens`, `--max-tokens-budget`, `--no-filter`,
  `--concurrency`, `--timeout` (ver delegate-protocol.md §4).
- `language` config controla idioma de comentarios (default English).

## Sessions (persistencia y diff)

```bash
ocr session list [--limit 20] [--json]
ocr session show <id> [--json]
ocr session comments <id> [--severity high,critical] [--category bug,security] [--json]
ocr session compare <before> <after> [--json]   # new / persisting / resolved / not-reviewed
ocr viewer                                      # WebUI historial (default localhost:5483)
```

Flujo post-fix obligatorio (F6): `session compare` antes/después para probar
`resolved`; cerrar solo sin `persisting` en Critical/High. El id de resume sale
como `retry with: --resume <id>` o en `session list`.

## SARIF levels (mapeo fijo)

`critical,high → error` · `medium → warning` · `low/unknown → note`.
`ruleId` = category (8 reglas: bug, security, performance, maintainability, test, style, documentation, other).

## CI (action.yml)

```yaml
- uses: alibaba/open-code-review@latest
  with:
    llm_url: ${{ secrets.LLM_URL }}
    llm_auth_token: ${{ secrets.LLM_TOKEN }}
    llm_model: my-model
    llm_use_anthropic: 'false'
    sticky_summary: 'true'     # un solo comentario resumen, actualizado in-place
    incremental: 'true'        # solo comentarios nuevos (no solapa historial)
    route_severity_below: medium   # medium+low van al summary, no inline (fail-open)
    route_categories: style,documentation
```

- `sticky + incremental` = PR limpio sin spam; `checkpoint_range` = solo el delta desde el último checkpoint.
- Routing nunca descarta: solo mueve hallazgos menores al summary.
- Subir `ocr-result.json` como artifact para `session compare` local.
- También GitLab CI / GitFlic / Gerrit soportados upstream.
