# Delegate-first (OCR sin LLM) — protocolo copiable

Modo delegación: OCR hace ingeniería determinista (selección de archivos,
bundling, reglas por path, posicionamiento); el agente revisa con su propia
inteligencia. No requiere endpoint LLM. Asumir CLI instalado; no pre-chequear.

## 1. Preview — qué entra al review

```bash
npx -y @alibaba-group/open-code-review delegate preview --format json
npx -y @alibaba-group/open-code-review delegate preview --format json --from main --to feature
npx -y @alibaba-group/open-code-review delegate preview --format json -c abc123
npx -y @alibaba-group/open-code-review delegate preview --format json --exclude '**/dist/**,**/*.lock' --repo /path/repo -b "contexto negocio"
npx -y @alibaba-group/open-code-review delegate preview --format json -B contexto.md
```

Devuelve `mode` (workspace/range/commit), `from/to/commit/merge_base`,
`reviewable_files[]` (path,status,+/-), `excluded_files[]` con motivo.
`--background/-b` obligatorio si hay contexto de negocio; `--background-file/-B`
tiene precedencia. `--exclude` (gitignore, coma) se fusiona con rule.json.

## 2. Reglas por path (agrupadas por contenido)

```bash
npx -y @alibaba-group/open-code-review delegate rule --format json <paths...>
npx -y @alibaba-group/open-code-review delegate rule --format json --rule rules/rule.json <paths...>
```

Archivos con la misma regla llegan en un grupo: pedir reglas por batch, no una
por archivo. Pre-chequeo puntual: `ocr rules check <file>`.

## 3. Diffs según mode (git directo, con preview.mode)

```bash
git diff <merge_base>..<to> -- <path>   # range
git show <commit> -- <path>              # commit
git diff HEAD -- <path>                  # workspace (tracked)
cat <path>                               # workspace (untracked = todo nuevo)
```

## 4. Bundling con contexto aislado + plan phase

- Bundle = regla compartida + diff acotado + archivos relacionados del mismo
  flujo (tipos + impl + test). Revisar cada bundle como unidad aislada.
- Plan phase extra si 1 archivo ≥50 líneas cambiadas o grupo ≥100 líneas en 2+
  archivos: primero riesgo (qué puede romper), luego review principal.
- Budget tokens: prompt grupo `MAX_TOKENS` 200k (scan 58888),
  salida `MAX_COMPLETION_TOKENS` 16384. Diff >~80% de `MAX_TOKENS` → `skipped`
  con motivo `over-budget`. Controles: `--max-tokens`, `--max-tokens-budget`
  (over-budget = 1 ronda final, resto `failed(budget)`), `--concurrency`
  (default 8; bajar ante rate-limit), `--timeout` (por ronda; efectivo =
  timeout × rounds low 1 / medium 2 / high 3), `--no-filter`, `--provider/--model`.

## 5. Checklist coverage (mandatory)

- Checklist con cada `(path, status)` de `reviewable_files` (puede repetirse path en workspace).
- Por bundle: diffs → grupo de reglas → review (11 dims + chaos) → reflexión
  anti-falsos-positivos → `reviewed` o `skipped` + motivo.
- Cierre: `total_files / reviewed / skipped / coverage_rate`. Prohibido omitir en silencio.
- No parar en el primer high.

## 6. Reflexión + formato de hallazgo

Segunda pasada por bundle: descartar en silencio lo que no ancle a evidencia
(diff, contrato, versión instalada). Formato:
`path* + content* [+ start_line/end_line, category (bug/security/performance/maintainability/test/style/documentation/other), severity (critical/high/medium/low), suggestion_code, existing_code, thinking?]`.
`start=end=0` = posicionamiento fallido: no inventar líneas, re-anclar manual.
Agrupar por severity.

## 7. Flags compartidos

`--from/--to`, `-c/--commit`, `--repo`, `--rule`, `--exclude`, `-b/--background`,
`-B/--background-file`, `-f/--format text|json`. Solo un modo por comando.

## Troubleshooting

- `unknown flag: --format` → rerun SIN el flag (CLI < v1.9.0), usar texto; no parsear texto como JSON.
- `unknown flag: --output` (≥v1.10.0) → no seguir por stdout; pedir upgrade, esperar, reintentar.
- `--background-file` límites: archivo ≤1MiB y contenido saneado ≤8000 chars. Si aborta: resumir (requisitos, constraints, criterios) y reintentar con `-b "<resumen>"` u otro archivo acotado; si no es resumible, omitir background y leer la fuente directo. Escape shell seguro para texto untrusted.
- Operar sobre el repo correcto: `--repo <path>` o cwd en la raíz git.
- Solo un modo: `--from/--to` o `-c`, nunca ambos.
- Nunca `tail/head` sobre código, diffs u output; usar `--output` + lectura completa.
- Windows PowerShell: `delegate preview` no tiene `--output`, y `> archivo.json` escribe UTF-16LE. `scripts/check-coverage.py` lo tolera (auto-detecta UTF-8/UTF-16); para otros consumidores preferir `| Out-File -Encoding utf8`.
