# Matriz Chaos — simulación obligatoria por capa (OpenHer)

Simular MENTALMENTE cada caso sobre el diff. Si el veredicto esperado no se cumple → hallazgo (`bug`, ≥medium).
Capas: C1 Rust (`desktop-app/src/`), C2 stores/hooks/servicios (`web/src/`), C3 contratos/SQLite (`types.ts`, esquemas), C4 UI (`components/`, `features/`, `pages/`).

## Capa 1 — Rust Tokio / HTTP / sockets (`http_server.rs`, `ptyx.rs`, `fswatch.rs`, `srvman.rs`)

| Caso | Qué simular | Veredicto esperado | Ejemplo de fallo real |
|---|---|---|---|
| Timeout 5s | El handler tarda 5s (disco lento, PTY sin salida) | Timeout por request, task cancelable, sin bloquear el runtime | `std::process::Command::output()` en handler async congela `:4848` para todos |
| Fallo a mitad | Cliente corta la conexión durante streaming/shell | Detecta disconnect, mata el child, libera el lock | Hijo huérfano consumiendo CPU tras cerrar la ventana |
| Cierre inesperado | Muere el proceso / se cae el socket WS | Sin `unwrap` en paths de shutdown; estado recuperable al reiniciar | `lock().unwrap()` poisoned tras panic → backend no arranca |
| EPERM Windows | Antivirus/bloqueo en `fswatch`/write | Error tipado + retry con backoff, nunca panic | `unwrap()` en watcher tumba `cargo run` en Windows |
| Offline | Puerto ocupado / loopback caído | Mensaje accionable (puerto en uso, reintento), no loop infinito | Reintento sin backoff satura CPU al 100% |

## Capa 2 — Stores / hooks / servicios (`web/src/api.ts`, `shell.ts`, `persistentStorage.ts`, `hooks/`, `features/`)

| Caso | Qué simular | Veredicto esperado | Ejemplo de fallo real |
|---|---|---|---|
| Timeout 5s | `:4848` tarda 5s | `AbortSignal` + timeout, `isLoading=false` en `finally`, error visible | Spinner infinito (dim 1) |
| Fallo a mitad | Respuesta truncada / JSON a medias | Valida schema antes de `set`; conserva estado anterior | `r.json()` lanza y deja store a medias |
| Cierre inesperado | Recarga / cierra pestaña con request en vuelo | `AbortController` en cleanup; borrador ya autosalvado (dim 10) | Prompt de 2h perdido al recargar |
| EPERM Windows | `localStorage` denegado (modo privado) / FS bloqueado | `try/catch` en persistencia, fallback en memoria, aviso | `setItem` lanza y rompe todo el store |
| Offline | Backend caído / sin red | Banner offline + reintento manual, cero requests en loop | Reintento automático infinito sin backoff |

## Capa 3 — Contratos / tipos / SQLite (`web/src/types.ts`, esquemas, migraciones)

| Caso | Qué simular | Veredicto esperado | Ejemplo de fallo real |
|---|---|---|---|
| Timeout 5s | Migración/seed tarda 5s | Migración idempotente y reejecutable, con lock | Migración a medias deja schema v3.5 inexistente |
| Fallo a mitad | Crash entre 2 escrituras | Transacción atómica (`BEGIN/COMMIT`) o write-tmp+rename | Kanban con tarjeta sin columna tras corte |
| Cierre inesperado | Kill durante `COMMIT` | WAL/journal + reintento al arrancar, sin corrupción | DB bloqueada (`SQLITE_BUSY`) sin recovery |
| EPERM Windows | DB/archivo bloqueado por otro proceso | Error tipado + reintento acotado, nunca pérdida | `SQLITE_LOCKED` propagado como crash |
| Offline | Shape del backend viejo (APK desactualizada) | Campos opcionales con default, `unknown`→descartar, aviso de update | `undefined` pisa UI tras update parcial (dim 3) |

## Capa 4 — UI (`components/`, `features/`, `pages/`, `App.tsx`)

| Caso | Qué simular | Veredicto esperado | Ejemplo de fallo real |
|---|---|---|---|
| Timeout 5s | Datos tardan 5s | Skeleton/spinner + timeout visible + reintentar | Pantalla en blanco sin feedback |
| Fallo a mitad | Lista llega parcial | Estado `error` con reintento, nunca lista a medias sin aviso | Chat muestra mitad de mensajes como si estuviera completo |
| Cierre inesperado | Cierra modal/ventana con edición abierta | Confirmación o borrador guardado (dim 10) | Formulario largo perdido por Esc accidental |
| EPERM Windows | Clipboard/notificación denegada | Degradación elegante (copiar manual), sin throw visible | `navigator.clipboard` denegado rompe el click |
| Offline | Acción sin backend | Botón deshabilitado o cola explícita, mensaje claro | Click que "no hace nada" sin explicación |

## Cómo reportar un fallo chaos

1. Nombra capa + caso (ej. `C2/timeout-5s`).
2. Describe la secuencia (qué tarda/falla/cierra).
3. Cita el veredicto esperado incumplido.
4. Clasifica: `category: bug`, severity `high` si congela/pierde/duplica, `medium` si degrada sin aviso.
