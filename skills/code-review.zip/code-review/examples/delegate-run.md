# Delegate run — ejemplo mínimo (`sess_9f31`, 2026-09-14)

```bash
$ ocr delegate preview --format json | head -c 300
{"reviewable_files":[{"path":"web/src/store/session.ts","status":"modified"},
{"path":"desktop-app/src/proto.rs","status":"modified"}, ...]}  # total: 4

$ ocr delegate run --task "review capa 2+3" --workers 2
[1/4] session.ts … 1 critical (mutación push l.88)
[2/4] proto.rs … 1 high (serde session_id l.41)
[3/4] SendBox.tsx … 1 medium (isLoading sin finally l.52)
[4/4] format.ts … 1 medium + 1 low descartado
saved: .code-review/bugs-and-flows-2026-09-14.md

$ python3 scripts/check-coverage.py --preview preview.json \
    --reviewed reviewed.txt --skipped skipped.txt
OK cobertura cerrada: 4/4 (100.0%) — reviewed=4 skipped=0
```

## Checklist final

- [x] preview.json con 4 reviewables; reviewed.txt con 4 líneas `path|status`
- [x] `check-coverage.py` exit 0, coverage_rate 100%
- [x] scorecard con severity + path:línea + suggestion_code + chaos
- [x] artefacto persistido en `.code-review/bugs-and-flows-<ts>.md`
- [x] veredicto NO MERGEAR hasta C1+H1 comunicado al autor
