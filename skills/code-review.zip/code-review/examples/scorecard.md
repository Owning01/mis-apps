# Scorecard — review delegate `sess_9f31` (2026-09-14)

Scope: 4 archivos · coverage_rate **100%** (4/4) · `check-coverage.py` exit 0.
Veredicto: **NO MERGEAR** hasta corregir C1 + H1.

## Hallazgos por severidad

| Sev | Ubicación | Categoría | Hallazgo + recomendación |
|-----|-----------|-----------|--------------------------|
| critical | `web/src/store/session.ts:88` [mutación-estado] | `push` in-place sobre `s.messages`; Zustand no re-renderiza y el usuario no ve su mensaje. Cambiar a copia inmutable. `suggestion_code`: `set({messages:[...s.messages,msg]})` |
| high | `desktop-app/src/proto.rs:41` [serde-desync] | Rust espera `session_id` (snake) pero TS envía `sessionId`; `serde` deja `None` y el bridge responde 422. Renombrar o `#[serde(alias="sessionId")]`. `suggestion_code`: `#[serde(alias = "sessionId")] pub session_id: String` |
| medium | `web/src/components/SendBox.tsx:52` [flujo-roto] | `setLoading(true)` sin `finally`; con error de red el botón queda congelado. Envolver en try/finally. `suggestion_code`: `finally { setLoading(false) }` |
| medium | `web/src/lib/format.ts:17` [ponytail] | `truncate()` duplica `sliceText()` existente; borrar y reutilizar. `suggestion_code`: `export { sliceText as truncate } from "./slice"` |
| low (descartado) | `web/src/lib/format.ts:3` [logs] | `console.debug` residual. Se descarta: solo existe en build dev, `vite build` lo elimina (verificado en `dist/`). Sin acción. |

## Simulación chaos (qué se simuló y veredicto)

| Escenario | Resultado |
|-----------|-----------|
| POST `/shell` con latencia 5 s + doble click en Enviar | FAIL: sin `finally` ni botón deshabilitado → 2 sesiones creadas (ligado a H-medium SendBox) |
| Respuesta Rust 422 por `sessionId` vs `session_id` | FAIL: UI muestra spinner infinito, sin mensaje de error (ligado a H-high proto.rs) |
| `EPERM` escribiendo borrador local (Win32) | PASS: borrador en memoria + reintento; cero pérdida de datos |
| Reload a mitad de stream | PASS: rehidrata desde store inmutable tras fix C1 (verificado con parche local) |

## Tests de regresión propuestos

1. `store.test.ts`: dispatch 2 mensajes seguidos, assert `messages.length===2` y referencia nueva.
2. `proto.test.rs`: deserializar payload TS real con `sessionId`, assert `session_id=="abc"`.
3. `SendBox.test.tsx`: mock fetch reject, assert botón habilitado tras error.

Artefacto: `.code-review/bugs-and-flows-2026-09-14.md` · Score robustez: **42/100**.
