#!/usr/bin/env python3
"""check-coverage.py — verifica cobertura cerrada del protocolo delegate.

Todo archivo reviewable debe estar en reviewed o skipped (con razon no vacia).

Identidad: tupla (path,status). Soporta duplicados porque un workspace puede
tener staged-deletion + untracked recreation del mismo path con distinto status;
cada combinacion (path,status) cuenta como item independiente.

Formatos:
  preview.json : salida de `ocr delegate preview --format json`, objeto con
                 clave "reviewable_files": [{path, status}, ...]
  reviewed.txt : una linea por archivo revisado: `path|status`
  skipped.txt  : opcional, una linea por archivo omitido: `path|reason`
                 (matchea por path, la razon no puede ser vacia)

Exit codes:
  0 = cobertura 100% (cerrada)
  1 = error de uso / IO / formato
  2 = cobertura incompleta (lista faltantes en stdout)

Solo stdlib. Uso:
  python3 check-coverage.py --preview preview.json --reviewed reviewed.txt [--skipped skipped.txt]
"""

import argparse
import json
import sys


def parse_args(argv=None):
    p = argparse.ArgumentParser(
        description="Verifica cobertura cerrada del protocolo delegate: "
                    "todo reviewable debe estar en reviewed o skipped con razon.",
        epilog="Exit 0 = 100%% cerrada. Exit 2 = incompleta (lista faltantes). "
               "Identidad: tupla (path,status).",
    )
    p.add_argument("--preview", required=True,
                   help="preview.json de `ocr delegate preview --format json`")
    p.add_argument("--reviewed", required=True,
                   help="reviewed.txt con lineas `path|status`")
    p.add_argument("--skipped", default=None,
                   help="skipped.txt opcional con lineas `path|reason`")
    return p.parse_args(argv)


def read_text_auto(path):
    """Lee texto tolerando UTF-8(-SIG) y UTF-16 (redireccion `>` de PowerShell)."""
    for enc in ("utf-8-sig", "utf-16"):
        try:
            with open(path, encoding=enc) as f:
                return f.readlines()
        except UnicodeDecodeError:
            continue
    with open(path, encoding="utf-8-sig") as f:
        return f.readlines()


def load_preview(path):
    try:
        lines = read_text_auto(path)
        data = json.loads("".join(lines))
    except FileNotFoundError:
        print(f"ERROR: no existe --preview: {path}", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"ERROR: preview JSON invalido ({path}): {e}", file=sys.stderr)
        sys.exit(1)
    files = data.get("reviewable_files", data) if isinstance(data, dict) else data
    if not isinstance(files, list):
        print("ERROR: preview debe contener reviewable_files: [...]",
              file=sys.stderr)
        sys.exit(1)
    items = set()
    for i, entry in enumerate(files):
        if not isinstance(entry, dict) or "path" not in entry or "status" not in entry:
            print(f"ERROR: entrada #{i} sin path/status: {entry!r}",
                  file=sys.stderr)
            sys.exit(1)
        items.add((str(entry["path"]).strip(), str(entry["status"]).strip()))
    return items


def load_reviewed(path):
    reviewed = set()
    try:
        lines = read_text_auto(path)
    except FileNotFoundError:
        print(f"ERROR: no existe --reviewed: {path}", file=sys.stderr)
        sys.exit(1)
    for n, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line:
            continue
        if "|" not in line:
            print(f"ERROR: {path}:{n} sin formato path|status: {line!r}",
                  file=sys.stderr)
            sys.exit(1)
        p, s = line.split("|", 1)
        p, s = p.strip(), s.strip()
        if not p or not s:
            print(f"ERROR: {path}:{n} path/status vacio: {line!r}",
                  file=sys.stderr)
            sys.exit(1)
        reviewed.add((p, s))
    return reviewed


def load_skipped(path):
    """Devuelve (paths_cubiertos:set[str], errores:list[str])."""
    if path is None:
        return set(), []
    covered, errors = set(), []
    try:
        lines = read_text_auto(path)
    except FileNotFoundError:
        print(f"ERROR: no existe --skipped: {path}", file=sys.stderr)
        sys.exit(1)
    for n, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line:
            continue
        if "|" not in line:
            errors.append(f"{path}:{n} sin formato path|reason: {line!r}")
            continue
        p, reason = line.split("|", 1)
        p, reason = p.strip(), reason.strip()
        if not p:
            errors.append(f"{path}:{n} path vacio")
            continue
        if not reason:
            errors.append(f"{p} skipped sin razon (linea {n})")
            continue
        covered.add(p)
    return covered, errors


def main(argv=None):
    args = parse_args(argv)
    reviewable = load_preview(args.preview)
    reviewed = load_reviewed(args.reviewed)
    skipped_paths, skip_errors = load_skipped(args.skipped)

    total = len(reviewable)
    if total == 0:
        print("coverage_rate: 100.0% (0/0, nada que revisar)")
        return 0

    covered = {item for item in reviewable
               if item in reviewed or item[0] in skipped_paths}
    missing = sorted(reviewable - covered)
    rate = len(covered) / total * 100

    if skip_errors:
        print("SKIPPED con formato invalido:")
        for e in skip_errors:
            print(f"  - {e}")

    if not missing and not skip_errors:
        print(f"OK cobertura cerrada: {len(covered)}/{total} "
              f"({rate:.1f}%) — reviewed={len(reviewable & reviewed)} "
              f"skipped={len(covered - reviewed)}")
        return 0

    print(f"INCOMPLETO coverage_rate: {len(covered)}/{total} ({rate:.1f}%)")
    for path, status in missing:
        print(f"  FALTA {path}|{status}")
    return 2


if __name__ == "__main__":
    sys.exit(main())
