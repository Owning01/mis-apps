#!/usr/bin/env python3
"""session-diff.py — Comparador delta de sesiones post-fix para cerrar la Fase 6 (F6).

Compara los hallazgos antes de aplicar fixes (before.json) contra los hallazgos
obtenidos después de aplicar fixes (after.json).

Clasificación por hallazgo:
- RESOLVED: Estaba en before y ya no existe en after.
- PERSISTING: Sigue presente en after.
- REGRESSION / NEW: Apareció como un defecto nuevo en after.

Exit codes:
  0 = Todos los Critical/High están RESOLVED, sin nuevas regresiones.
  1 = Error de lectura / formato.
  2 = Quedan defectos PERSISTING o NEW en Critical/High (no se puede cerrar el review).

Uso:
  python3 session-diff.py --before before.json --after after.json [--output delta.md]
"""

import argparse
import json
import os
import re
import sys


def safe_int(val, default=0):
    if val is None:
        return default
    if isinstance(val, int):
        return val
    try:
        s = str(val).strip()
        s = re.sub(r"^[L:]+", "", s).strip()
        return int(s)
    except (ValueError, TypeError):
        return default


def load_findings(path):
    if not os.path.exists(path):
        print(f"Error: no existe {path}", file=sys.stderr)
        sys.exit(1)
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            data = json.load(f)
            return data.get("comments", data) if isinstance(data, dict) else data
    except Exception as e:
        print(f"Error cargando {path}: {e}", file=sys.stderr)
        sys.exit(1)


def is_same_finding(a, b):
    pa = str(a.get("path", "")).strip().replace("\\", "/")
    pb = str(b.get("path", "")).strip().replace("\\", "/")
    if pa != pb:
        return False

    cata = str(a.get("category", "")).lower().strip()
    catb = str(b.get("category", "")).lower().strip()
    if cata != catb:
        return False

    ca = str(a.get("content", "")).strip().lower()
    cb = str(b.get("content", "")).strip().lower()
    la = safe_int(a.get("start_line"), 0)
    lb = safe_int(b.get("start_line"), 0)

    # 1. Si el contenido es idéntico, tolerar desplazamiento de hasta 15 líneas
    if ca and cb and ca == cb:
        return abs(la - lb) <= 15

    # 2. Si la línea es idéntica
    if la > 0 and lb > 0 and la == lb:
        return True

    # 3. Si el código existente coincide
    sa = str(a.get("existing_code", "")).strip()
    sb = str(b.get("existing_code", "")).strip()
    if sa and sb and sa == sb:
        return True

    return False


def main():
    parser = argparse.ArgumentParser(description="Comparador delta post-fix de sesiones.")
    parser.add_argument("--before", required=True, help="Archivo JSON de hallazgos iniciales")
    parser.add_argument("--after", required=True, help="Archivo JSON de hallazgos post-fix")
    parser.add_argument("--output", help="Archivo de salida markdown para el reporte delta")
    args = parser.parse_args()

    before_list = list(load_findings(args.before))
    after_list = list(load_findings(args.after))

    matched_after_indices = set()
    resolved = []
    persisting = []

    for b_item in before_list:
        match_idx = None
        for i, a_item in enumerate(after_list):
            if i not in matched_after_indices and is_same_finding(b_item, a_item):
                match_idx = i
                break

        if match_idx is not None:
            matched_after_indices.add(match_idx)
            persisting.append(b_item)
        else:
            resolved.append(b_item)

    new_regressions = [a_item for i, a_item in enumerate(after_list) if i not in matched_after_indices]

    # Check blockers (Critical or High)
    blockers_persisting = [c for c in persisting if str(c.get("severity", "")).lower() in ("critical", "high")]
    blockers_new = [c for c in new_regressions if str(c.get("severity", "")).lower() in ("critical", "high")]

    lines = [
        "## Verificación Post-Fix (Session Delta)",
        "",
        f"- **Resolved (corregidos)**: {len(resolved)}",
        f"- **Persisting (pendientes)**: {len(persisting)}",
        f"- **New / Regressions (nuevos)**: {len(new_regressions)}",
        ""
    ]

    if resolved:
        lines.append(f"### Resolved ({len(resolved)})")
        for c in resolved:
            lines.append(f"- [x] `{c.get('path')}:{safe_int(c.get('start_line'), 0)}` [{str(c.get('severity', '')).upper()}] — {c.get('content')}")
        lines.append("")

    if persisting:
        lines.append(f"### Persisting ({len(persisting)})")
        for c in persisting:
            lines.append(f"- [ ] `{c.get('path')}:{safe_int(c.get('start_line'), 0)}` [{str(c.get('severity', '')).upper()}] — {c.get('content')}")
        lines.append("")

    if new_regressions:
        lines.append(f"### New / Regressions ({len(new_regressions)})")
        for c in new_regressions:
            lines.append(f"- [!] `{c.get('path')}:{safe_int(c.get('start_line'), 0)}` [{str(c.get('severity', '')).upper()}] — {c.get('content')}")
        lines.append("")

    can_close = (len(blockers_persisting) == 0 and len(blockers_new) == 0)
    verdict = "VERIFICACIÓN EXITOSA: No quedan defectos Critical/High abiertos." if can_close else "VERIFICACIÓN FALLIDA: Existen defectos Critical/High que persisten o regresiones."
    lines.append(f"**Veredicto**: {verdict}")

    report = "\n".join(lines)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(report)
        print(f"Reporte delta guardado en {args.output}")
    else:
        print(report)

    if not can_close:
        print(f"\n[FAIL-CLOSED] Bloqueado: {len(blockers_persisting)} persistentes, {len(blockers_new)} regresiones en Critical/High.", file=sys.stderr)
        sys.exit(2)

    return 0


if __name__ == "__main__":
    main()
