#!/usr/bin/env python3
"""filter-scope.py — Módulo de filtrado determinista de scope para code review.

Inspecciona el espacio de trabajo Git (workspace, commits o range) y aplica
filtros deterministas: detección de binarios, exclusión de lockfiles, artefactos
generados, minificados y patrones configurables. Soporta renames (R100) y ramas recién iniciadas.

Uso:
  python3 filter-scope.py [--repo <path>] [--from <ref> --to <ref>] [-c <commit>]
                          [--exclude '<pat1>,<pat2>'] [--output <path>]
"""

import argparse
import fnmatch
import json
import os
import subprocess
import sys

DEFAULT_EXCLUDES = [
    "**/.git/**",
    "**/node_modules/**",
    "**/dist/**",
    "**/build/**",
    "**/.dart_tool/**",
    "**/target/**",
    "**/vendor/**",
    "**/*.lock",
    "**/package-lock.json",
    "**/pnpm-lock.yaml",
    "**/yarn.lock",
    "**/Cargo.lock",
    "**/pubspec.lock",
    "**/*.min.js",
    "**/*.min.css",
    "**/*.map",
    "**/*.svg",
    "**/*.png",
    "**/*.jpg",
    "**/*.jpeg",
    "**/*.gif",
    "**/*.ico",
    "**/*.wasm",
    "**/*.exe",
    "**/*.dll",
    "**/*.so",
    "**/*.dylib",
    "**/*.g.dart",
    "**/*.freezed.dart",
    "**/*.pb.go",
]


def run_git(cmd, repo_dir):
    try:
        p = subprocess.run(
            cmd,
            cwd=repo_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        if p.returncode == 0:
            return p.stdout.strip()
        return None
    except Exception as e:
        print(f"Git execution error: {e}", file=sys.stderr)
        return None


def parse_name_status_line(line):
    line = line.strip()
    if not line:
        return None
    parts = line.split("\t")
    if len(parts) == 1:
        parts = line.split(maxsplit=1)

    if len(parts) >= 3:
        # Renamed: R100 \t old_path \t new_path -> evaluamos new_path
        status = parts[0]
        path = parts[2]
        return {"status": status, "path": path}
    elif len(parts) == 2:
        return {"status": parts[0], "path": parts[1]}
    return None


def is_binary_file(filepath):
    if not os.path.exists(filepath):
        return False
    try:
        with open(filepath, "rb") as f:
            chunk = f.read(1024)
            return b"\x00" in chunk
    except Exception:
        return False


def matches_any(path, patterns):
    norm_path = path.replace("\\", "/")
    for pat in patterns:
        pat = pat.strip().replace("\\", "/")
        if not pat:
            continue
        if fnmatch.fnmatch(norm_path, pat) or fnmatch.fnmatch(os.path.basename(norm_path), pat):
            return True
        if pat.startswith("**/") and fnmatch.fnmatch(norm_path, pat[3:]):
            return True
    return False


def parse_args():
    p = argparse.ArgumentParser(description="Filtrado determinista de scope para code review.")
    p.add_argument("--repo", default=".", help="Ruta del repositorio git")
    p.add_argument("--from", dest="from_ref", help="Ref base para modo range")
    p.add_argument("--to", dest="to_ref", help="Ref destino para modo range")
    p.add_argument("-c", "--commit", help="Hash del commit para modo commit")
    p.add_argument("--exclude", default="", help="Patrones de exclusión separados por coma")
    p.add_argument("--max-size-kb", type=int, default=500, help="Límite máximo de tamaño en KB (default: 500)")
    p.add_argument("--output", help="Archivo de salida JSON (stdout si se omite)")
    return p.parse_args()


def main():
    args = parse_args()
    repo_dir = os.path.abspath(args.repo)
    if not os.path.exists(os.path.join(repo_dir, ".git")):
        print(f"Error: {repo_dir} no es la raíz de un repositorio Git.", file=sys.stderr)
        sys.exit(1)

    custom_excludes = [x.strip() for x in args.exclude.split(",") if x.strip()]
    all_excludes = DEFAULT_EXCLUDES + custom_excludes

    mode = "workspace"
    merge_base = ""
    raw_files = []

    if args.commit:
        mode = "commit"
        status_out = run_git(["show", "--name-status", "--pretty=format:", args.commit], repo_dir)
        if status_out:
            for line in status_out.splitlines():
                parsed = parse_name_status_line(line)
                if parsed:
                    raw_files.append(parsed)
    elif args.from_ref and args.to_ref:
        mode = "range"
        mb = run_git(["merge-base", args.from_ref, args.to_ref], repo_dir)
        merge_base = mb if mb else args.from_ref
        status_out = run_git(["diff", "--name-status", f"{merge_base}..{args.to_ref}"], repo_dir)
        if status_out:
            for line in status_out.splitlines():
                parsed = parse_name_status_line(line)
                if parsed:
                    raw_files.append(parsed)
    else:
        mode = "workspace"
        # Tracked changes (staged + unstaged contra HEAD si existe)
        status_out = run_git(["diff", "--name-status", "HEAD"], repo_dir)
        if status_out is None:
            # Fallback si HEAD aún no existe (repo vacío o primer commit)
            status_out = run_git(["diff", "--name-status", "--cached"], repo_dir)

        if status_out:
            for line in status_out.splitlines():
                parsed = parse_name_status_line(line)
                if parsed:
                    raw_files.append(parsed)

        # Untracked files
        untracked = run_git(["ls-files", "--others", "--exclude-standard"], repo_dir)
        if untracked:
            for line in untracked.splitlines():
                p = line.strip()
                if p:
                    raw_files.append({"status": "?", "path": p})

    reviewable = []
    excluded = []

    max_bytes = args.max_size_kb * 1024

    for item in raw_files:
        p = item["path"]
        st = item["status"]
        full_p = os.path.join(repo_dir, p)

        if matches_any(p, all_excludes):
            excluded.append({"path": p, "reason": "pattern-exclude"})
            continue

        if st != "D" and os.path.exists(full_p):
            if is_binary_file(full_p):
                excluded.append({"path": p, "reason": "binary-file"})
                continue
            size = os.path.getsize(full_p)
            if size > max_bytes:
                excluded.append({"path": p, "reason": f"over-size-limit ({size // 1024}KB > {args.max_size_kb}KB)"})
                continue
            item["size_bytes"] = size
        else:
            item["size_bytes"] = 0

        reviewable.append(item)

    result = {
        "mode": mode,
        "repo": repo_dir,
        "from": args.from_ref or "",
        "to": args.to_ref or "",
        "commit": args.commit or "",
        "merge_base": merge_base,
        "total_files": len(reviewable) + len(excluded),
        "reviewable_count": len(reviewable),
        "excluded_count": len(excluded),
        "reviewable_files": reviewable,
        "excluded_files": excluded,
    }

    out_json = json.dumps(result, indent=2, ensure_ascii=False)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(out_json)
        print(f"Scope guardado en {args.output} ({len(reviewable)} reviewable, {len(excluded)} excluidos).")
    else:
        print(out_json)


if __name__ == "__main__":
    main()
