#!/usr/bin/env python3
"""session-collector.py — Colector y exportador multiformato de sesiones de code review.

Agrega comentarios de hallazgos, calcula estadísticas de severidad y cobertura,
y exporta a:
1. Scorecard Markdown estándar.
2. JSON Machine consolidado.
3. OASIS SARIF v2.1.0 (para GitHub Code Scanning / CI).

Uso:
  python3 session-collector.py --input findings.json [--preview preview.json] [--reviewed reviewed.txt]
                               [--format markdown|sarif|json] [--output report.md]
"""

import argparse
import json
import os
import re
import sys

SARIF_SEVERITY_MAP = {
    "critical": "error",
    "high": "error",
    "medium": "warning",
    "low": "note"
}


def safe_int(val, default=1):
    if val is None:
        return default
    if isinstance(val, int):
        return val
    try:
        s = str(val).strip()
        s = re.sub(r"^[L:]+", "", s).strip()
        return int(s)
    except (ValueError, TypeError):
        return default


def load_json(path):
    if not path or not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return json.load(f)
    except Exception as e:
        print(f"Aviso: error leyendo {path}: {e}", file=sys.stderr)
        return None


def load_reviewed_txt(path):
    if not path or not os.path.exists(path):
        return set()
    reviewed = set()
    try:
        for enc in ("utf-8-sig", "utf-8", "utf-16"):
            try:
                with open(path, "r", encoding=enc) as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        p = line.split("|")[0].strip()
                        if p:
                            reviewed.add(p)
                break
            except UnicodeDecodeError:
                continue
    except Exception as e:
        print(f"Aviso: error leyendo reviewed.txt ({e})", file=sys.stderr)
    return reviewed


def generate_sarif(comments, repo_root=""):
    rules = {}
    results = []

    for c in comments:
        category = c.get("category", "other")
        severity = str(c.get("severity", "medium")).lower()
        rule_id = f"OCR-{category.upper()}"

        if rule_id not in rules:
            rules[rule_id] = {
                "id": rule_id,
                "name": category.capitalize(),
                "shortDescription": {"text": f"Defect in category {category}"},
                "defaultConfiguration": {
                    "level": SARIF_SEVERITY_MAP.get(severity, "warning")
                }
            }

        file_path = str(c.get("path", "")).replace("\\", "/")
        start_line = max(1, safe_int(c.get("start_line"), 1))
        end_line = max(start_line, safe_int(c.get("end_line"), start_line))

        result = {
            "ruleId": rule_id,
            "level": SARIF_SEVERITY_MAP.get(severity, "warning"),
            "message": {"text": str(c.get("content", ""))},
            "locations": [
                {
                    "physicalLocation": {
                        "artifactLocation": {"uri": file_path},
                        "region": {
                            "startLine": start_line,
                            "endLine": end_line
                        }
                    }
                }
            ]
        }

        sug = c.get("suggestion_code")
        if sug:
            result["fixes"] = [
                {
                    "description": {"text": "Suggested fix"},
                    "fileChanges": [
                        {
                            "artifactLocation": {"uri": file_path},
                            "replacements": [
                                {
                                    "deletedRegion": {"startLine": start_line, "endLine": end_line},
                                    "insertedContent": {"text": str(sug)}
                                }
                            ]
                        }
                    ]
                }
            ]

        results.append(result)

    sarif = {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "OpenCodeReview-Delegate",
                        "informationUri": "https://github.com/alibaba/open-code-review",
                        "rules": list(rules.values())
                    }
                },
                "results": results
            }
        ]
    }
    return sarif


def generate_markdown(comments, preview_data=None, reviewed_txt_path=None):
    total_files = 0
    reviewed_files = set()
    skipped_files = []

    # 1. Determinar reviewed files
    if reviewed_txt_path and os.path.exists(reviewed_txt_path):
        reviewed_files = load_reviewed_txt(reviewed_txt_path)
    else:
        # Extraer de los comentarios y de preview si no se especificó archivo
        for c in comments:
            p = c.get("path")
            if p:
                reviewed_files.add(p)

    # 2. Determinar total files a revisar y skipped files
    if preview_data:
        rev_list = preview_data.get("reviewable_files", [])
        total_files = len(rev_list)
        skipped_files = preview_data.get("excluded_files", [])
        # Si no hubo reviewed.txt y no hay comments, pero hay reviewable_files
        if not reviewed_files and not comments:
            reviewed_files = set()
    else:
        total_files = len(reviewed_files)

    by_sev = {"critical": [], "high": [], "medium": [], "low": []}
    for c in comments:
        sev = str(c.get("severity", "medium")).lower()
        if sev in by_sev:
            by_sev[sev].append(c)
        else:
            by_sev["medium"].append(c)

    coverage_rate = 100.0 if total_files == 0 else (len(reviewed_files) / total_files) * 100
    if coverage_rate > 100.0:
        coverage_rate = 100.0

    lines = [
        "## Scorecard",
        f"Files reviewed: {len(reviewed_files)}",
        f"Critical: {len(by_sev['critical'])} / High: {len(by_sev['high'])} / Medium: {len(by_sev['medium'])} / Low: {len(by_sev['low'])}",
        f"coverage_rate: {coverage_rate:.1f}%",
        ""
    ]

    for sev in ["critical", "high", "medium", "low"]:
        items = by_sev[sev]
        if not items:
            continue
        lines.append(f"### {sev.capitalize()} ({len(items)})")
        lines.append("")
        for item in items:
            p = item.get("path", "")
            s_l = safe_int(item.get("start_line"), 0)
            loc = f"`{p}:{s_l}`" if s_l > 0 else f"`{p}`"
            cat = item.get("category", "other")
            lines.append(f"- **{loc}** [{cat}] — {item.get('content', '')}")
            if item.get("suggestion_code"):
                lines.append("  ```suggestion")
                lines.append(f"  {str(item.get('suggestion_code')).strip()}")
                lines.append("  ```")
        lines.append("")

    if skipped_files:
        lines.append(f"### Skipped Files ({len(skipped_files)})")
        lines.append("")
        for sk in skipped_files:
            lines.append(f"- `{sk.get('path', '')}`: {sk.get('reason', 'no-reason')}")
        lines.append("")

    return "\n".join(lines)


def parse_args():
    p = argparse.ArgumentParser(description="Colector y exportador de sesiones de code review.")
    p.add_argument("--input", required=True, help="Archivo JSON con comentarios")
    p.add_argument("--preview", help="Archivo preview.json opcional para calcular métricas de cobertura")
    p.add_argument("--reviewed", help="Archivo reviewed.txt opcional para verificar cobertura real")
    p.add_argument("--format", choices=["markdown", "sarif", "json"], default="markdown", help="Formato de salida")
    p.add_argument("--output", help="Archivo de salida (stdout si se omite)")
    return p.parse_args()


def main():
    args = parse_args()
    raw_data = load_json(args.input)
    if raw_data is None:
        print(f"Error: no se pudo cargar {args.input}", file=sys.stderr)
        sys.exit(1)

    comments = raw_data.get("comments", raw_data) if isinstance(raw_data, dict) else raw_data
    if not isinstance(comments, list):
        print("Error: formato de comentarios inválido", file=sys.stderr)
        sys.exit(1)

    preview_data = load_json(args.preview) if args.preview else None

    if args.format == "sarif":
        sarif_obj = generate_sarif(comments)
        out_content = json.dumps(sarif_obj, indent=2, ensure_ascii=False)
    elif args.format == "json":
        out_content = json.dumps({"total_comments": len(comments), "comments": comments}, indent=2, ensure_ascii=False)
    else:
        out_content = generate_markdown(comments, preview_data, args.reviewed)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(out_content)
        print(f"Reporte exportado a {args.output} (formato {args.format})")
    else:
        print(out_content)


if __name__ == "__main__":
    main()
