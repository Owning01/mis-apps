#!/usr/bin/env python3
"""bundle-changes.py — Módulo de empaquetado de archivos en bundles con contexto aislado.

Agrupa los archivos a revisar según:
1. Jerarquía de reglas: regla local de proyecto (rule.json) > regla modular de stack (rule_map.json) > default.
2. Afinidad funcional de subdirectorio/módulo.
3. Estimación de presupuesto de tokens/líneas para activar 'plan phase' (≥50 líneas/archivo o ≥100 líneas/grupo).

Uso:
  python3 bundle-changes.py --preview preview.json [--rules rules/rule_map.json] [--output bundles.json]
"""

import argparse
import fnmatch
import json
import os
import sys


def load_rules_hierarchy(custom_rules_path=None):
    """Carga reglas en cascada: rule.json (proyecto) > rule_map.json (stacks) > default."""
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    project_rule_path = os.path.join(base_dir, "rules", "rule.json")
    stack_rule_path = custom_rules_path or os.path.join(base_dir, "rules", "rule_map.json")

    project_rules = {}
    stack_rules = {}
    default_rule = "rules/docs/default.md"

    # 1. Cargar stack rules
    if os.path.exists(stack_rule_path):
        try:
            with open(stack_rule_path, "r", encoding="utf-8") as f:
                d = json.load(f)
                stack_rules = d.get("path_rule_map", {})
                default_rule = d.get("default_rule", default_rule)
        except Exception as e:
            print(f"Aviso: error leyendo stack rules ({e})", file=sys.stderr)

    # 2. Cargar project rules (tienen precedencia)
    if os.path.exists(project_rule_path):
        try:
            with open(project_rule_path, "r", encoding="utf-8") as f:
                d = json.load(f)
                for r in d.get("rules", []):
                    project_rules[r["path"]] = r.get("rule", "")
        except Exception as e:
            print(f"Aviso: error leyendo project rules ({e})", file=sys.stderr)

    return project_rules, stack_rules, default_rule


def resolve_rule_for_path(filepath, project_rules, stack_rules, default_rule):
    norm_path = filepath.replace("\\", "/")

    # Precedencia 1: Reglas de proyecto
    for pattern, rule in project_rules.items():
        pattern = pattern.replace("\\", "/")
        if fnmatch.fnmatch(norm_path, pattern) or fnmatch.fnmatch(os.path.basename(norm_path), pattern):
            return f"[PROJECT] {rule[:40]}..." if len(rule) > 40 else f"[PROJECT] {rule}"
        if pattern.startswith("**/") and fnmatch.fnmatch(norm_path, pattern[3:]):
            return f"[PROJECT] {rule[:40]}..." if len(rule) > 40 else f"[PROJECT] {rule}"

    # Precedencia 2: Reglas modulares de stack
    for pattern, rule in stack_rules.items():
        pattern = pattern.replace("\\", "/")
        if fnmatch.fnmatch(norm_path, pattern) or fnmatch.fnmatch(os.path.basename(norm_path), pattern):
            return rule
        if pattern.startswith("**/") and fnmatch.fnmatch(norm_path, pattern[3:]):
            return rule

    return default_rule


def get_directory_group(filepath):
    parts = filepath.replace("\\", "/").split("/")
    if len(parts) <= 1:
        return "root"
    if len(parts) == 2:
        return parts[0]
    return f"{parts[0]}/{parts[1]}"


def parse_args():
    p = argparse.ArgumentParser(description="Empaquetado inteligente de cambios en bundles.")
    p.add_argument("--preview", required=True, help="Archivo JSON de preview de archivos")
    p.add_argument("--rules", default=None, help="Ruta opcional al archivo rule_map.json")
    p.add_argument("--output", help="Ruta para guardar el plan de bundles en JSON")
    return p.parse_args()


def main():
    args = parse_args()
    if not os.path.exists(args.preview):
        print(f"Error: no existe {args.preview}", file=sys.stderr)
        sys.exit(1)

    try:
        with open(args.preview, "r", encoding="utf-8") as f:
            preview_data = json.load(f)
    except Exception as e:
        print(f"Error parseando preview JSON: {e}", file=sys.stderr)
        sys.exit(1)

    files = preview_data.get("reviewable_files", preview_data)
    if not isinstance(files, list):
        print("Error: formato inválido en preview.json (se esperaba lista de reviewable_files)", file=sys.stderr)
        sys.exit(1)

    proj_rules, stack_rules, default_rule = load_rules_hierarchy(args.rules)

    bundles_map = {}
    for entry in files:
        if isinstance(entry, str):
            entry = {"path": entry, "status": "M"}
        path = entry.get("path", "")
        if not path:
            continue

        rule = resolve_rule_for_path(path, proj_rules, stack_rules, default_rule)
        rule_key = os.path.basename(rule) if "/" in rule or "\\" in rule else rule
        dir_key = get_directory_group(path)
        bundle_id = f"{dir_key}::{rule_key}"

        if bundle_id not in bundles_map:
            bundles_map[bundle_id] = {
                "bundle_id": bundle_id,
                "directory_scope": dir_key,
                "rule": rule,
                "files": [],
                "plan_phase_required": False,
            }

        bundles_map[bundle_id]["files"].append(entry)

    bundles_list = list(bundles_map.values())
    for b in bundles_list:
        if len(b["files"]) >= 3:
            b["plan_phase_required"] = True

    output_data = {
        "total_bundles": len(bundles_list),
        "total_files": len(files),
        "bundles": bundles_list
    }

    out_json = json.dumps(output_data, indent=2, ensure_ascii=False)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(out_json)
        print(f"Plan de bundles generado en {args.output} ({len(bundles_list)} bundles)")
    else:
        print(out_json)


if __name__ == "__main__":
    main()
