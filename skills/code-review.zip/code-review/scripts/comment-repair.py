#!/usr/bin/env python3
"""comment-repair.py — Validador y reparador de hallazgos anti-alucinaciones.

Inspirado en comment_args_repair.go y comment_collector.go de OpenCodeReview:
1. Repara JSONs con comillas mal escapadas en prosa y parsea bloques markdown.
2. Valida estrictamente severidad y categoría.
3. Conversión segura de líneas numéricas (safe_int) tolerando cadenas o formatos tipo 'L12'.
4. Verifica la existencia del archivo en disco.
5. Ancla líneas reales si start_line=0 mediante búsqueda difusa de existing_code.
6. Comprueba que existing_code coincida con el contenido del archivo real para erradicar citas falsas.

Uso:
  python3 comment-repair.py --input findings.raw.json [--repo .] [--output findings.clean.json]
"""

import argparse
import json
import os
import re
import sys

VALID_CATEGORIES = {
    "bug", "security", "performance", "maintainability",
    "test", "style", "documentation", "other"
}

VALID_SEVERITIES = {
    "critical", "high", "medium", "low"
}


def safe_int(val, default=0):
    if val is None:
        return default
    if isinstance(val, int):
        return val
    try:
        s = str(val).strip()
        # Si viene en formato "L42" o ":42"
        s = re.sub(r"^[L:]+", "", s).strip()
        return int(s)
    except (ValueError, TypeError):
        return default


def repair_json_string(raw_str):
    raw = raw_str.strip()
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass

    # Intento 1: extraer bloque delimitado por ```json ... ```
    m = re.search(r"```(?:json)?\s*([\[{].*?[\]}])\s*```", raw, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except json.JSONDecodeError:
            raw = m.group(1)

    # Intento 2: reparar comillas no escapadas comunes
    cleaned = re.sub(r'(?<!\\)"(?=(?:[^"]*"[^"]*")*[^"]*$)', r'\"', raw)
    try:
        return json.loads(cleaned)
    except Exception:
        pass

    return None


def read_file_lines(filepath):
    if not os.path.exists(filepath):
        return []
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            with open(filepath, "r", encoding=enc) as f:
                return [line.replace("\r\n", "\n") for line in f]
        except Exception:
            continue
    return []


def locate_snippet(lines, snippet):
    if not snippet or not lines:
        return 0, 0
    clean_snippet = snippet.replace("\r\n", "\n").strip()
    if not clean_snippet:
        return 0, 0

    snip_lines = [l.strip() for l in clean_snippet.splitlines() if l.strip()]
    if not snip_lines:
        return 0, 0

    first_line = snip_lines[0]
    for idx, line in enumerate(lines):
        if first_line in line:
            match = True
            for offset, snip_l in enumerate(snip_lines):
                if idx + offset >= len(lines) or snip_l not in lines[idx + offset]:
                    match = False
                    break
            if match:
                start = idx + 1
                end = idx + len(snip_lines)
                return start, end
    return 0, 0


def validate_and_repair_comment(c, repo_dir):
    repaired = dict(c)
    warnings = []

    # Path
    raw_path = repaired.get("path", "")
    if not raw_path:
        return None, ["Comment sin path descartado"]
    raw_path = str(raw_path).strip().replace("\\", "/")
    repaired["path"] = raw_path

    full_path = os.path.join(repo_dir, raw_path)
    file_exists = os.path.exists(full_path)

    # Category
    cat = str(repaired.get("category", "other")).lower().strip()
    if cat not in VALID_CATEGORIES:
        warnings.append(f"Categoría inválida '{cat}' corregida a 'other'")
        cat = "other"
    repaired["category"] = cat

    # Severity
    sev = str(repaired.get("severity", "medium")).lower().strip()
    if sev not in VALID_SEVERITIES:
        warnings.append(f"Severidad inválida '{sev}' corregida a 'medium'")
        sev = "medium"
    repaired["severity"] = sev

    # Lines & Code verification (con safe_int)
    start_line = safe_int(repaired.get("start_line"), 0)
    end_line = safe_int(repaired.get("end_line"), 0)
    if end_line < start_line and end_line > 0:
        end_line = start_line

    existing_code = str(repaired.get("existing_code", "") or "").replace("\r\n", "\n")

    if file_exists:
        lines = read_file_lines(full_path)
        total_l = len(lines)

        # Si no tiene líneas o están en 0 pero tiene snippet, intentar anclarlo
        if (start_line <= 0 or end_line <= 0) and existing_code:
            s, e = locate_snippet(lines, existing_code)
            if s > 0:
                warnings.append(f"Líneas re-ancladas de 0 a {s}-{e} vía existing_code en {raw_path}")
                start_line, end_line = s, e

        # Normalizar si start_line > 0 pero end_line es 0
        if start_line > 0 and end_line == 0:
            end_line = start_line

        # Verificar si las líneas exceden el archivo
        if total_l > 0 and (start_line > total_l or end_line > total_l):
            warnings.append(f"Línea fuera de rango ({start_line}-{end_line} > {total_l}) en {raw_path}")

        # Verificar concordancia de existing_code si start/end son válidas
        if existing_code and start_line > 0 and end_line >= start_line and end_line <= total_l:
            file_slice = "".join(lines[start_line - 1:end_line]).strip()
            clean_snip = existing_code.strip()
            if clean_snip not in file_slice and file_slice not in clean_snip:
                warnings.append(f"Discrepancia en existing_code contra disco L{start_line}-L{end_line}")

    repaired["start_line"] = start_line
    repaired["end_line"] = end_line
    repaired["content"] = str(repaired.get("content", "") or "").strip()
    repaired["suggestion_code"] = str(repaired.get("suggestion_code", "") or "").replace("\r\n", "\n").strip()

    return repaired, warnings


def parse_args():
    p = argparse.ArgumentParser(description="Validador y reparador de comentarios de code review.")
    p.add_argument("--input", required=True, help="Archivo JSON de entrada con comentarios")
    p.add_argument("--repo", default=".", help="Ruta del repositorio para validar anclaje")
    p.add_argument("--output", help="Archivo de salida JSON reparado")
    return p.parse_args()


def main():
    args = parse_args()
    if not os.path.exists(args.input):
        print(f"Error: no existe {args.input}", file=sys.stderr)
        sys.exit(1)

    try:
        with open(args.input, "r", encoding="utf-8", errors="replace") as f:
            raw_text = f.read()
    except Exception as e:
        print(f"Error leyendo archivo de entrada: {e}", file=sys.stderr)
        sys.exit(1)

    data = repair_json_string(raw_text)
    if data is None:
        print(f"Error: No se pudo deserializar JSON desde {args.input}", file=sys.stderr)
        sys.exit(1)

    comments = data.get("comments", data) if isinstance(data, dict) else data
    if not isinstance(comments, list):
        print(f"Error: Estructura no es lista de comentarios en {args.input}", file=sys.stderr)
        sys.exit(1)

    cleaned_comments = []
    total_warnings = 0

    repo_dir = os.path.abspath(args.repo)
    for i, c in enumerate(comments):
        if not isinstance(c, dict):
            continue
        rep, warns = validate_and_repair_comment(c, repo_dir)
        if rep:
            cleaned_comments.append(rep)
        if warns:
            total_warnings += len(warns)
            for w in warns:
                print(f"[REPAIR] Item #{i+1}: {w}", file=sys.stderr)

    output_data = {
        "total_comments": len(cleaned_comments),
        "comments": cleaned_comments
    }

    out_json = json.dumps(output_data, indent=2, ensure_ascii=False)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(out_json)
        print(f"Comentarios validados guardados en {args.output} ({len(cleaned_comments)} hallazgos, {total_warnings} reparaciones/avisos)")
    else:
        print(out_json)


if __name__ == "__main__":
    main()
