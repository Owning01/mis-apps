#!/usr/bin/env python3
"""ocr-health.py — Verificador de salud del entorno de Open Code Review.

Inspecciona:
1. Disponibilidad y versión del CLI `ocr` o `npx @alibaba-group/open-code-review`.
2. Estado del repositorio Git actual.
3. Integridad sintáctica de rule.json y rule_map.json.
4. Conectividad con el proveedor LLM configurado (si aplica).

Uso:
  python3 ocr-health.py [--repo .]
"""

import argparse
import json
import os
import shutil
import subprocess
import sys


def check_git(repo_dir):
    try:
        p = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            cwd=repo_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True
        )
        branch = subprocess.run(
            ["git", "branch", "--show-current"],
            cwd=repo_dir,
            stdout=subprocess.PIPE,
            text=True
        ).stdout.strip()
        return True, f"Repositorio Git activo (rama: {branch or 'detached HEAD'})"
    except Exception as e:
        return False, f"No es un repositorio Git válido ({e})"


def check_cli():
    # 1. Chequear si 'ocr' está en PATH
    ocr_path = shutil.which("ocr")
    if ocr_path:
        try:
            out = subprocess.run(["ocr", "version"], stdout=subprocess.PIPE, text=True, timeout=10).stdout.strip()
            return True, f"CLI ocr nativo detectado ({out})"
        except Exception:
            return True, f"CLI ocr detectado en {ocr_path}"

    # 2. Chequear si npm / npx está disponible
    npx_path = shutil.which("npx")
    if npx_path:
        return True, "CLI accesible vía 'npx -y @alibaba-group/open-code-review' (Node.js disponible)"

    return False, "Ni 'ocr' ni 'npx' están instalados en PATH."


def check_rules():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    rule_map_path = os.path.join(base_dir, "rules", "rule_map.json")
    rule_json_path = os.path.join(base_dir, "rules", "rule.json")

    results = []
    if os.path.exists(rule_map_path):
        try:
            with open(rule_map_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                count = len(data.get("path_rule_map", {}))
                results.append(f"rule_map.json válido ({count} mapeos de stacks)")
        except Exception as e:
            results.append(f"rule_map.json inválido: {e}")
    else:
        results.append("rule_map.json no encontrado")

    if os.path.exists(rule_json_path):
        try:
            with open(rule_json_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                count = len(data.get("rules", []))
                results.append(f"rule.json local válido ({count} reglas de proyecto)")
        except Exception as e:
            results.append(f"rule.json inválido: {e}")
    else:
        results.append("rule.json no encontrado")

    return results


def check_llm():
    ocr_path = shutil.which("ocr")
    cmd = ["ocr", "llm", "test"] if ocr_path else ["npx", "-y", "@alibaba-group/open-code-review", "llm", "test"]
    use_shell = (sys.platform == "win32")
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=20, shell=use_shell)
        if p.returncode == 0:
            return True, f"Endpoint LLM respondiendo: {p.stdout.strip()}"
        else:
            return False, f"LLM no configurado o inalcanzable (opcional para modo delegate): {p.stderr.strip()}"
    except Exception as e:
        return False, f"No se pudo chequear LLM: {e}"


def main():
    parser = argparse.ArgumentParser(description="Verificador de salud de Open Code Review.")
    parser.add_argument("--repo", default=".", help="Ruta del repositorio a inspeccionar")
    args = parser.parse_args()

    repo_dir = os.path.abspath(args.repo)
    print("=== Diagnóstico de Salud @codereview ===")

    # Git
    git_ok, git_msg = check_git(repo_dir)
    print(f"[{'OK' if git_ok else 'WARN'}] Git: {git_msg}")

    # CLI
    cli_ok, cli_msg = check_cli()
    print(f"[{'OK' if cli_ok else 'WARN'}] OCR CLI: {cli_msg}")

    # Rules
    rule_msgs = check_rules()
    for rm in rule_msgs:
        status = "OK" if "válido" in rm else "WARN"
        print(f"[{status}] Reglas: {rm}")

    # LLM (informativo)
    llm_ok, llm_msg = check_llm()
    print(f"[{'OK' if llm_ok else 'INFO'}] Conexión LLM: {llm_msg}")

    print("========================================")
    sys.exit(0)


if __name__ == "__main__":
    main()
