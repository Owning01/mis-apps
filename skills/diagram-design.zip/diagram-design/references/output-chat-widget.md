# Output mode: in-chat relational diagram (bt-flowchart)

> Folded in from the former `diagrama-relacional` skill (archived at
> `C:/Users/perca/.agents/backupo/diagram-merge-2026-09-25/`). Content preserved;
> only the routing was rewritten to English to match this skill's references.

Use this only when the deliverable is **a message, not a file**: the user asks for a
relational / ER / tables-and-foreign-keys diagram to see in the chat. Every other
case goes through §12 and produces a self-contained `.html` file.

In-chat output bypasses the standalone HTML pipeline (style guide, SVG primitives,
templates, export) on purpose: the host renders the block itself.

## What renders it

OpenHer renders a fenced code block with language `flowchart` (catalog id
`bt-flowchart`; source BeautifulUI, https://beautifului.dev/, MIT) as a **live
canvas** instead of plain text: draggable nodes, measured bezier connectors, dotted
canvas background.

Triggers: "diagrama relacional", "esquema ER", "entidad-relación", "tablas y claves
foráneas", "modelá la base de datos", "diagrama de tablas", "cómo se relacionan X e
Y", "agregá una columna FK", "para verlo en el chat".

Plain flowcharts with decisions also work (the widget supports `condition`), but
for **relational** schemas use the table recipe below.

## Format

JSON inside the `flowchart` block:

    ```flowchart
    {
      "steps": [
        { "id": "users", "row": 0, "x": 0.5, "w": 320,
          "kind": { "label": "Tabla", "hue": "#9a5cff" },
          "title": "users", "caption": "id PK · name · email" }
      ],
      "edges": [ { "from": "users", "to": "orders" } ]
    }
    ```

### `steps[]` fields (at least 1 required)

| Field | Type | What it is |
|---|---|---|
| `id` | string | Unique identifier; `edges` reference it. |
| `row` | number | Vertical row (0 = top). Parallel tables share a `row`. |
| `x` | 0–1 | Horizontal center of the card (0.5 centered; 0.2 / 0.8 for two columns). |
| `w` | number | Card width (260–360 recommended). |
| `kind` | `{label, hue}` | Pill on the card: `label` = "Tabla" / "Vista" / "Relación"; `hue` = hex color. |
| `title` | string | Table or entity name. |
| `caption` | string | Columns: `id PK · user_id FK · total` (separator `·`). |
| `condition` | boolean | If/Else card from the original widget. **Do not** use in relational diagrams. |

### `edges[]` (optional)

Pairs of `{ "from", "to" }` with existing ids. Edges to unknown ids are dropped; with
no valid edges there is no connector. Cardinality (1:N) goes in the child table's
`caption` (`user_id FK → users`), never in an edge label.

## Rules

1. **No emojis** in `title`, `caption` or `kind.label` (repo rule: zero emojis in the
   UI, SVG only).
2. **Strict types**: `title` / `caption` / `kind.label` / `kind.hue` are strings
   (≤300 / ≤1000 / ≤60 / ≤64), `condition` boolean, `id` unique string ≤200.
   Anything else renders the block as plain code.
3. **Ceilings**: max **100 `steps`** and **200 `edges`**; unique ids; edges only
   between existing ids; no self-edges (`from` = `to`) and no duplicates (repeated
   and orphan edges are dropped, the rest of the diagram still renders).
4. **Valid JSON, no prose** inside the block, no typographic quotes: bad JSON falls
   back to plain code (the chat survives, the canvas is lost).
5. `hue` from a bounded palette: `#9a5cff` (violet), `#f09a2f` (amber), `#2f8ff0`
   (blue), `#3bb273` (green). One color per entity type.
6. Answer with a line of text too; the block goes in **your** message.

## Example: ER users → orders → order_items

````markdown
Listo, este es el esquema:

```flowchart
{
  "steps": [
    { "id": "users", "row": 0, "x": 0.5, "w": 320, "kind": { "label": "Tabla", "hue": "#9a5cff" }, "title": "users", "caption": "id PK · name · email" },
    { "id": "orders", "row": 1, "x": 0.5, "w": 320, "kind": { "label": "Tabla", "hue": "#f09a2f" }, "title": "orders", "caption": "id PK · user_id FK → users · total" },
    { "id": "items", "row": 2, "x": 0.5, "w": 320, "kind": { "label": "Tabla", "hue": "#3bb273" }, "title": "order_items", "caption": "id PK · order_id FK → orders · sku · qty" }
  ],
  "edges": [
    { "from": "users", "to": "orders" },
    { "from": "orders", "to": "items" }
  ]
}
```
````

## Where the widget lives

The widget is at `web/src/vendor/bt-flowchart/` (fork of the vendor
`G:\Proyectos\anim-lab\src\vendor\beautiful\flowchart\Flowchart.tsx`; catalog id in
`G:\Proyectos\anim-lab\src\catalog\beautiful.ts` → `bt-flowchart`) and the render
hook is in `web/src/components/Markdown.tsx`, where `parseFlowchartSpec` validates
the JSON. Read those files before changing the format; this reference documents the
contract, not the implementation.
