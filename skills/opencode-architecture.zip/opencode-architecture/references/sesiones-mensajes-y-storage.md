# Sesiones, mensajes y storage del server v2 (medido)

Forma real de los datos del daemon de OpenCode v2: **dónde guarda**, **qué emite** y las trampas
que ya costaron un bug. No es teoría del monorepo: está medido sobre una instalación real
(`packages/opencode` `1.18.x`, Windows) el **2026-09-21**, consultando la DB del server. Los conteos
son de esa máquina y ese proyecto: sirven como orden de magnitud, no como contrato.

Si algo no se pudo verificar, está en §9.

---

## 1. Dónde vive la verdad

| Ruta (bajo `%USERPROFILE%\.local\share\opencode\`) | Qué es |
|---|---|
| **`opencode.db`** | **La fuente real**: SQLite (en la medición: 6,2 GB) con los **dos dialectos** (v1 y v2). |
| `shell/<hash>/sh_<id>.out` | Salida cruda de cada comando en segundo plano (el mensaje sintético trae el path). |
| `log/opencode.log`, `snapshot/`, `tool-output/`, `team/`, `plans/`, `repos/` | Logs, snapshots de revert, salidas grandes de tools, tablero/equipo, planes. |
| `storage/**/*.json` | **Remanente** del layout viejo en archivos: no es la fuente; buscar acá hace perder tiempo. |

## 2. Esquema relevante de `opencode.db`

| Tabla | Columnas clave | Dialecto |
|---|---|---|
| `message` | `id, session_id, time_created, time_updated, data` (JSON) | **v1** |
| `part` | `id, message_id, session_id, time_created, time_updated, data` (JSON) | **v1** |
| `session_message` | `id, session_id, **type**, **seq**, time_created, time_updated, data` (JSON) | **v2** |
| `session` / `session_v2` | `id, project_id, parent_id, slug, directory, title, version, …` | v1 / v2 |
| `session_inbox` / `session_pending` | `id, session_id, type, payload\|data, delivery, enqueued_seq\|admitted_seq` | v2 |
| `project`, `todo`, `event`, `event_sequence`, `kv`, `permission`, `worktree`, `workspace`, `instruction_*` | — | compartidas |

**El mismo id de sesión existe en `session` y en `session_v2`, y sus mensajes viven en las dos
familias de tablas a la vez** (en la medición: 7133 filas en `message` + 28567 en `part`, y 14200 en
`session_message`): no hay migración, los dialectos conviven.

`session_inbox` es la puerta de entrada de prompts "por atrás" (otro agente o la PC): filas tipo
`steer` con `payload = {"text","files","agents"}`.

## 3. Cómo consultarlo (receta)

Node 24 trae `node:sqlite`; no hace falta `sqlite3` ni credenciales:

```js
import { DatabaseSync } from "node:sqlite"
const db = new DatabaseSync(process.env.USERPROFILE + "\\.local\\share\\opencode\\opencode.db", { readOnly: true })
const rows = db.prepare("select id, type, data from session_message where session_id = ? order by seq desc limit 50").all(SID)
```

**Trampas medidas**: (a) siempre `readOnly` (el server tiene la DB abierta con WAL); (b) filtrar
siempre por `session_id` — un `LIKE '%…%'` suelto recorre gigabytes; (c) `JSON.parse` después de
bajar la fila; (d) el mismo string puede estar en `message`/`part` **y** en `session_message`.

## 4. `session_message.type` (v2)

Medido sobre una ventana de 4000 filas: `assistant` 3564 · `idle` 143 · `user` 118 · `synthetic` 75 ·
`agent-switched` 49 · `system` 32 · `model-switched` 10 · `compaction` 9.

> `type` **es el rol** del mensaje: un cliente no debe asumir solo `user`/`assistant`.

## 5. `assistant`: `content[]`

Cada item es `reasoning` | `text` | `tool`:

```jsonc
// reasoning
{ "type": "reasoning", "text": "…", "state": { "reasoningField": "reasoning_content" }, "time": {…} }
// tool (vistos: read, write, edit, shell, execute, question, task…)
{ "type": "tool", "id": "call_…", "name": "shell", "executed": false,
  "time": { "created": …, "ran": …, "completed": … },
  "state": { "status": "completed", "input": { … }, "metadata": { … },
             "content": [ { "type": "text", "text": "SALIDA REAL" } ] } }
```

- **La salida del tool vive en `state.content[0].text`** en v2. El dialecto **v1** (`part.data`) usaba
  `state.output` (+ `state.metadata.exit`, `state.metadata.output`): si se leen las dos tablas, hay que
  tolerar las dos formas.
- Estados vistos: `running`, `pending`, `completed`, `error` (el error va en `state.error`).
- Los items nuevos agregan `providerState` (id de respuesta del proveedor).

## 6. `synthetic`: lo que el server inyecta solo

Forma base: `{ time: { created }, text, description?, metadata: { source?, … } }`.
`metadata.source` medido: **`shell`**, **`subagent`** y **sin source** (textos de sistema:
"Continue if you have next steps…", "Summarize the task tool output above…", "The following tool was
executed by the user", `<system-reminder>…</system-reminder>` de Plan mode, "The server restarted
while you were working. Continue from where you left off…").

### 6.1 `metadata.source === "shell"` (comando en segundo plano)

```jsonc
{ "metadata": { "source": "shell", "shellID": "sh_0a54…", "jobID": "sh_0a54…",
                "state": "completed", "truncated": false, "exit": 1 },
  "description": "node scripts/…",
  "text": "<shell id=\"sh_0a54…\" state=\"completed\" command=\"node scripts/…\">\nSALIDA\n\n\nCommand exited with code 1.\n</shell>" }
```

**Medido sobre 66 casos: `jobID === shellID` en los 66** → el resultado **no se puede acoplar por id**
al tool call que lo lanzó; el acople es por posición/turno (o por `shellID` si el cliente lo guardó
cuando el tool arrancó).

**Trampa de parseo**: el `command="…"` puede traer **comillas adentro**, **`>` de redirección** y
**saltos de línea reales**. Un `[^"]*` / `[^>]*` corta el comando y ensucia la salida: hay que tomar
el comando hasta el `">` de cierre del tag (o usar los atributos `id`/`state` como ancla).

### 6.2 `metadata.source === "subagent"`

`{ metadata: { source: "subagent", agent: "worker", childID: "ses_…" } }` con el texto envuelto en
`<subagent sessionID="…" state="…" description="…">…</subagent>`. Mismo riesgo que shell: sin trato
propio los tags crudos quedan a la vista del usuario.

## 7. Cadena completa de un comando en segundo plano

1. El agente llama al tool **`shell`** con `input.background: true`; el item queda `status: completed`
   y su `state.content[0].text` dice: `Command moved to the background (shell ID: sh_…).` +
   `Output is streaming to: …\opencode\shell\<hash>\sh_….out` (medido).
2. El server escribe la salida en vivo en ese `.out`.
3. Al terminar inyecta el `synthetic` de §6.1 con el **mismo** `shellID` y `state`
   (`completed` | `error` | `cancelled`) + `exit`.
4. El cliente debería mostrarlo como **comando + salida** (tool), no como texto con tags.

## 8. Eventos SSE (muestra, no exhaustiva)

Envelope: `{ id, created, type, location: { directory }, data: { sessionID, … }, durable: { aggregateID, seq, version } }`.

Tipos vistos: `server.connected` · `session.step.started|streamed|ended` ·
`session.reasoning.started|ended` · `session.text.started|delta|ended` · `session.tool.input.started|ended` ·
`session.tool.called|progress|success` · `session.execution.started|succeeded` · `session.usage.updated` ·
`session.inbox.enqueued|delivered` · `session.instructions.updated` · `shell.created` · `shell.exited` ·
`catalog.updated`.

## 9. Lo que **no** está verificado

- La **respuesta HTTP cruda** de `/api/session/:id/message` (v2): el probe local devolvió **401** sin
  credenciales. El storage (§5) guarda la salida en `state.content[0].text`; si un cliente lee
  `part.text` / `state.output` y una tool aparece "sin salida", el sospechoso es ese aplanado.
- Los conteos de §4 y §6 son de **una ventana** de filas y de una sola máquina.
