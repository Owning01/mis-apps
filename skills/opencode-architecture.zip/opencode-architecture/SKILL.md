﻿---
name: opencode-architecture
description: Guía canónica de arquitectura interna de OpenCode (V1/V2), ciclo de vida de sesiones, Effect-TS runtime, contratos de plugins, hooks, tools y diseño de extensiones de alto rendimiento sin invalidación de caché.
argument-hint: "[plugins|sessions|context|tools] <consulta>"
version: "2.0.0-opencode"
license: MIT
---

# 🏛️ Arquitectura Interna de OpenCode & Manual de Creación de Plugins

> Esta skill compila la anatomía interna de OpenCode (basada en el monorepo `packages/`), su runtime basado en **Effect-TS / Drizzle / Bun**, el ciclo de vida de **Session Runtime & System Context**, y el manual de referencia para construir **Plugins oficiales de alto rendimiento**.

---

## 📑 1. MAPA DEL MONOREPO (PACKAGES)

| Paquete | Responsabilidad Central | Tecnologías Clave |
| :--- | :--- | :--- |
| `packages/core` | Núcleo del servidor: sesiones, agentes, catálogos de modelos, git, filesystem, permisos, snapshot y runtime. | `effect`, `drizzle-orm`, `better-sqlite3`, `zod` |
| `packages/plugin` | Definición de contratos, tipos e interfaces para plugins (`PluginInput`, `Hooks`, `tool()`). | `zod`, `bun-shell` |
| `packages/client` | SDK y cliente HTTP/Effect autogenerado para interactuar con la API del daemon de OpenCode. | TypeScript, Effect HTTP |
| `packages/server` | Servidor HTTP / API Daemon (`/api/session`, `/api/provider`, `/api/event` SSE). | Effect HTTP Server |
| `packages/ui` | Sistema de diseño, componentes base, temas e iconos. | `solid-js`, Tailwind, Storybook |
| `packages/session-ui` | Renderizado de conversaciones, mensajes de asistente, diffs de código y ejecución de tools. | `solid-js`, Pierre diffs, WebWorkers |
| `packages/cli` | Binario de consola (`opencode`, daemon service, runner de comandos). | Effect CLI, Node/Bun |

---

## 🔄 2. SESSION RUNTIME & GESTIÓN DE CONTEXTO (PREFIJOS Y CACHÉ)

OpenCode gestiona el contexto del modelo a través de **Context Epochs** y **System Context Registry**:

```
 ┌─────────────────────────────────────────────────────────────────────────────┐
 │                         ESTRUCTURA DE UN PROMPT TURN                        │
 ├─────────────────────────────────────────────────────────────────────────────┤
 │  [1. Baseline System Context] (Inmutable durante el Context Epoch)          │
 │      • Instrucciones globales (`AGENTS.md`)                                 │
 │      • Definición del agente activo                                         │
 │      • Registro de tools habilitadas                                        │
 ├─────────────────────────────────────────────────────────────────────────────┤
 │  [2. Session History] (Append-Only)                                         │
 │      • Mensajes de usuario (`user`)                                         │
 │      • Respuestas del asistente (`assistant`)                               │
 │      • Salidas de herramientas (`tool_result`)                              │
 │      • Mensajes de sistema a mitad de conversación (Mid-Conv System Msg)    │
 └─────────────────────────────────────────────────────────────────────────────┘
```

### ⚠️ Reglas de Oro del Prompt Caching en OpenCode:
1. **El prefijo idéntico es ley:** Los proveedores (Anthropic, Gemini, OpenAI) solo cachean tokens si el inicio exacto del prompt coincide byte por byte.
2. **Cambiar de agente invalida el prefijo:** Si cambias de agente a mitad de sesión, el `System Context` cambia y el proveedor sufre un **Cache Miss** total.
3. **Crear sub-sesiones bifurca el prefijo:** Cada nueva sesión empieza en frío.
4. **Append-Only = 100% Cache Hit:** La forma óptima de encadenar tareas o debates es agregar mensajes al final del mismo hilo sin mutar el Baseline inicial.

---

## 🧩 3. CONTRATO OFICIAL DE PLUGINS (V2)

Un plugin en OpenCode es un módulo exportado como función asíncrona:

```typescript
import type { Plugin } from "@opencode-ai/plugin"
import { tool } from "@opencode-ai/plugin"
import { z } from "zod"

export const MyPlugin: Plugin = async (input, options) => {
  // input contiene:
  // - input.client: SDK cliente tipado de OpenCode (sesiones, modelos, providers)
  // - input.project: Metadatos del proyecto actual
  // - input.directory: Directorio raíz de trabajo
  // - input.worktree: Raíz del repositorio git
  // - input.$: BunShell para ejecutar comandos del sistema
  // - input.serverUrl: URL del servidor OpenCode activo

  return {
    // 1. Registro de herramientas personalizadas (Tools)
    tool: {
      my_custom_tool: tool({
        description: "Descripción clara para que el LLM sepa cuándo invocarla",
        args: {
          param1: z.string().describe("Parámetro de ejemplo"),
          optionalParam: z.number().optional()
        },
        async execute(args, toolCtx) {
          // toolCtx contiene: sessionID, messageID, directory, abort (signal)
          // toolCtx.metadata({ title: "Ejecutando..." })
          
          return {
            output: "Resultado en texto para el modelo",
            metadata: { customData: true }
          }
        }
      })
    },

    // 2. Interceptores de ciclo de vida (Hooks)
    "tool.execute.before": async (input, output) => {
      // Intercepta antes de ejecutar cualquier herramienta
    },
    "tool.execute.after": async (input, output) => {
      // Modifica o audita la salida de una herramienta
    },
    "chat.message": async (input, output) => {
      // Intercepta mensajes entrantes de chat
    },
    "chat.params": async (input, output) => {
      // Modifica temperature, topP o parámetros del LLM
    }
  }
}

export default MyPlugin
```

---

## 🛠️ 4. CÓMO REGISTRAR PLUGINS EN TU ENTORNO

En el archivo de configuración global: `~/.config/opencode/opencode.json` (o local en `.opencode/config.json`):

```json
{
  "plugin": [
    "opencode-mem",
    "./plugins/mi-plugin.ts",
    "C:/Users/perca/.config/opencode/plugins/debate-room.ts"
  ]
}
```

---

## 💡 5. PATRONES Y ANTI-PATRONES EN EXTENSIONES OPENCODE

| Patrón Recomendado | Anti-Patrón Prohibido |
| :--- | :--- |
| **Sesión Única Temporal + Limpieza (`finally`)**: Para tareas multi-turno, usar una sola sesión efímera y compactarla al cerrar. | **Sub-sesiones Huérfanas**: Crear 4 o 5 sesiones con `session.create` sin borrarlas (llena la DB y destruye la UI). |
| **Uso de `tool()` con esquemas `zod`**: Validación tipada en tiempo de ejecución. | **JSON Schema crudo o argumentos sin tipar**. |
| **Lectura segura con presupuestos (`maxChars`)**: Delimitar archivos como bloques de datos. | **Inyección ciega de archivos enteros** que desbordan la ventana de contexto. |
| **`input.$` (BunShell) para procesos del SO**: Manejo seguro y asíncrono de comandos. | **`execSync` bloqueante** que congela el bucle de eventos de Node/Bun. |

---

## 🗄️ 6. FORMA DE LOS DATOS: SESIONES, MENSAJES Y STORAGE

Cómo guarda y emite **realmente** el daemon v2 (storage SQLite, tipos de `session_message`, mensajes
`synthetic` que inyecta por su cuenta, cadena completa de un comando en segundo plano y eventos SSE):
medido sobre una instalación real en
[`references/sesiones-mensajes-y-storage.md`](references/sesiones-mensajes-y-storage.md).

Lo que más se rompe al integrar un cliente:

- **La salida de un tool vive en `state.content[0].text`** (v2); el dialecto v1 usaba `state.output`.
- **`synthetic` con `metadata.source`** (`shell`, `subagent`) trae el payload envuelto en tags
  (`<shell id="…" state="…" command="…">…</shell>`): parsearlo con `[^"]*`/`[^>]*` corta el comando
  (adentro tiene comillas, `>` de redirección y saltos de línea reales).
- **`opencode.db` mantiene los dos dialectos** (`message`+`part` y `session_message`) para el mismo id
  de sesión: al leer mensajes hay que saber cuál se está leyendo.
- **`session_message.type` es el rol** (`synthetic`, `compaction`, `idle`, `agent-switched`…), no solo
  `user`/`assistant`.
