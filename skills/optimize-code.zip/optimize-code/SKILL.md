---
name: optimize-code
description: General-purpose code optimization for any language. Audits and fixes performance issues across algorithms, data structures, I/O, memory, concurrency, databases, networking, caching, and build pipelines. Use when asked to "optimize", "improve performance", "make it faster", "reduce latency", or "refactor for speed". If no specific file or snippet is provided, automatically audits the entire repository.
metadata:
  model: models/gemini-3.1-pro-preview
  last_modified: Sat, 05 Sep 2026 20:05:00 GMT
---

# Code Optimization (General Purpose)

## Usage Rules & Execution Priority

1.  **ENVIRONMENT TRIAGE**: Before auditing, instantly identify the language, framework, and execution environment. Suppress checklists that are physically impossible or idiomatic anti-patterns for that environment (e.g., do not suggest manual memory management in JavaScript, or async/await in pure standard C).
2.  **MACRO OVER MICRO**: Always prioritize Macro-optimizations (Algorithm complexity, I/O bottlenecks, N+1 queries) over Micro-optimizations (Loop unrolling, bit-shifting, inlining) unless explicitly told that macro-architecture is locked.
3.  **CONTEXTUAL PRUNING**: Do not display the entire checklist. Only reason about and output sections relevant to the user's snippet.
4.  **ZERO SEMANTIC REGRESSION**: Optimizations must strictly preserve exact business logic, numerical precision contracts (beware IEEE 754 float reordering and fast-math side effects), and thread-safety invariants.
5.  **CANCELLATION & LIFECYCLE AWARENESS**: Never optimize CPU or memory while allowing zombie operations. Propagate task cancellation signals (`AbortController`, `context.Context`, `CancellationToken`) so aborted client requests instantly abort server computations.
6.  **FULL-REPO DISCOVERY (WHEN NO TARGET FILE IS GIVEN)**: If the user asks to optimize, audit, or speed up the codebase without specifying a target file or snippet, NEVER halt or ask for a file. Automatically initiate a full-repository performance audit: scan project configuration, dependency graphs, entry points, critical hot paths, data pipelines, database queries, and architectural bottlenecks across the entire repository.

---

## 1. Algorithms & Data Structures

### 1.1 Time complexity
- Identify O(n²) or worse loops and reduce them
- Nested loops over the same data → hash maps or sets for O(1) lookups
- Sorting: avoid custom comparators that recompute values each comparison (precompute once)
- Two-pointer and sliding window techniques over brute force

### 1.2 Data structure selection
- Hash map / set for lookups instead of linear search
- Priority queue / heap for top-k or scheduling problems
- Stack / queue for sequential processing (avoid repeated list operations)
- Tree / trie for prefix searches and range queries
- Bloom filter for probabilistic membership checks (memory-constrained)

### 1.3 Space complexity
- Mutate in-place instead of creating copies
- Stream / lazy evaluation over loading everything into memory
- Bit manipulation over boolean arrays (flagsets)
- Reuse buffers instead of allocating per iteration

### 1.4 Recursion
- Tail recursion optimization where supported
- Convert deep recursion to iterative (stack overflow prevention)
- Memoization for overlapping subproblems (DP)

### 1.5 Amortized analysis & Capacity pre-allocation
- Pre-allocate collection capacities upfront (`std::vector::reserve`, `ArrayList(capacity)`, `make([]T, 0, cap)`) to avoid geometric reallocation and copying overhead
- Ring buffers / circular arrays over frequent shifting or dynamic queues
- Fast-path for common small capacities (small vector optimization / inline storage)

### 1.6 Branchless algorithms & SIMD readiness
- Replace unpredictable branches in tight inner loops with bitwise operations, arithmetic masks, or conditional moves (`cmov`)
- Organize data sequentially for compiler auto-vectorization (avoid loop-carried dependencies)

---

## 2. I/O Optimization

### 2.1 File I/O
- Buffered reads/writes instead of byte-by-byte
- Memory-map files for random access patterns (mmap)
- Batch writes instead of per-record flushing
- Use binary formats over text when parsing overhead is high
- Asynchronous / non-blocking I/O for concurrent operations

### 2.2 Serialization
- Binary serialization (protobuf, msgpack, bson) over JSON/XML for large payloads
- Zero-copy deserialization (flatbuffers, cap'n proto)
- Schema-aware parsing over generic DOM parsing (e.g., SAX over DOM for XML)

### 2.3 Compression
- Compress large payloads before network transfer or disk write
- Choose codec by use case: gzip (speed), zstd (ratio), lz4 (ultra-fast)
- Pre-compress static assets at build time

### 2.4 Modern OS & Kernel I/O primitives
- Zero-copy I/O using `sendfile`, `splice`, or DMA (Direct Memory Access) transfers
- Modern async kernel I/O: `io_uring` (Linux) / I/O Completion Ports (IOCP on Windows)
- Direct I/O (`O_DIRECT` / `FILE_FLAG_NO_BUFFERING`) when bypassing OS page cache for custom storage engines
- Memory mapping flags: `madvise` with `MADV_SEQUENTIAL`, `MADV_WILLNEED`, or `MADV_DONTNEED` to guide OS page fetching

---

## 3. Memory Management

### 3.1 Allocation
- Pool / reuse objects instead of allocating in hot paths
- Arena allocators for sequential short-lived objects
- Stack allocation over heap where possible
- Avoid boxing/unboxing of primitives in hot paths

### 3.2 Leaks
- Unregister event listeners / callbacks on teardown
- Clear circular references (use WeakRef / weak pointers)
- Close file handles, network sockets, database connections
- Limit closure captures that keep large objects alive

### 3.3 Cache locality
- Arrays of structs (AoS) → structs of arrays (SoA) for hot loops
- Contiguous memory (vectors, arrays) over linked structures
- Align data structures to cache line boundaries
- Prefetch hints for predictable access patterns

### 3.4 Garbage collection
- Reduce allocation rate in hot paths (fewer GC pauses)
- Pool / reuse objects to avoid GC pressure
- Tune GC parameters (heap size, generational thresholds)
- Use value types / structs over reference types for small data

### 3.5 Struct layout & Alignment padding
- Order struct/class fields by decreasing size to eliminate silent alignment padding holes
- Bitfields and packed structs for cold data or network transfer structures
- Value types and inline arrays over reference indirection

### 3.6 Virtual memory & Hardware TLB
- HugePages / Transparent Huge Pages (THP) for multi-gigabyte working sets to eliminate Translation Lookaside Buffer (TLB) misses
- NUMA-aware allocations: allocate memory on the local NUMA node executing the thread, pin high-throughput threads (CPU affinity)

---

## 4. Concurrency & Parallelism

### 4.1 Multi-threading
- Thread pool over creating threads per task
- Work-stealing schedulers for load balancing
- Lock-free data structures (atomic operations) over mutex
- Read-write locks for read-heavy workloads
- Sharding / partitioning to reduce contention

### 4.2 Async / non-blocking
- Event loop / async-await over blocking threads (I/O-bound workloads)
- Coroutines / fibers for cooperative multitasking
- Batch async operations with fan-out (Promise.all, WaitGroup)
- Backpressure and flow control to prevent resource exhaustion

### 4.3 Synchronization
- Minimize critical section size
- Lock-free / wait-free algorithms for high-contention paths
- Optimistic concurrency (retry on conflict) over pessimistic locking
- Reduce false sharing by padding hot fields to cache line boundaries

### 4.4 Parallel patterns
- Map-reduce for data-parallel workloads
- Pipeline / producer-consumer for stream processing
- Fork-join for divide-and-conquer algorithms
- Actor model for isolated mutable state

### 4.5 Task cancellation & Structured concurrency
- Propagate cancellation tokens (`context.Context`, `CancellationToken`, `AbortSignal`) to abort downstream compute and database queries on disconnect
- Worker pools with graceful drain and worker reuse instead of uncontrolled unbounded spawning
- Prevent unhandled async rejection / orphaned background tasks

### 4.6 Lock-free queues & High-throughput primitives
- Disruptor pattern: bounded lock-free ring buffers with sequence barriers over mutex-guarded queues
- Cache-line padding (`@Contended` in Java, `alignas(64)` in C++/Rust) to prevent false sharing between hot adjacent variables

---

## 5. Database Optimization

### 5.1 Query optimization
- Index columns used in WHERE, JOIN, ORDER BY, GROUP BY
- Composite indexes for multi-column queries (column order matters)
- Covering indexes to avoid table lookups
- Avoid SELECT * — fetch only needed columns
- Use EXPLAIN / query plan analysis to find bottlenecks

### 5.2 Connection management
- Connection pooling (avoid open/close per request)
- Batch inserts/updates in transactions
- Read replicas for read-heavy workloads
- Connection timeout and retry with backoff

### 5.3 Schema design
- Denormalization for read-heavy workloads (fewer joins)
- Partitioning / sharding for large tables
- Materialized views for expensive aggregations
- Avoid N+1 queries — use JOIN or batch loading

### 5.4 Caching
- Query result cache (Redis, Memcached)
- Application-level cache with TTL and invalidation
- Database buffer pool tuning
- Prepared statement caching

### 5.5 Bulk operations & Pagination
- Keyset / cursor-based pagination (`WHERE id > ? LIMIT N`) over `OFFSET` for deep pagination
- Streaming cursors / batch fetches to process millions of rows without loading all rows into RAM
- Bulk inserts/upserts with parameterized chunks instead of one-by-one transactions

### 5.6 Storage engine & Transaction design
- Minimize transaction boundary duration to avoid lock contention on high-concurrency tables
- Awareness of storage engine write amplification: LSM-trees (RocksDB/Cassandra) vs B+ Trees (PostgreSQL/MySQL/InnoDB)
- Read uncommitted / snapshot isolation tradeoffs where strict serializability is not needed

---

## 6. Network Optimization

### 6.1 Protocol
- HTTP/2 multiplexing over HTTP/1.1 pipelining
- gRPC / protocol buffers over REST+JSON for internal services
- Keep-alive / connection reuse instead of per-request connections
- Compression (gzip, brotli) for responses
- Binary protocols over text for high-throughput paths

### 6.2 Latency
- CDN for static assets and edge caching
- Connection pooling and pre-warming
- DNS caching and pre-resolution
- TCP tuning (window size, congestion control)
- Batching requests instead of individual calls

### 6.3 Payload
- Pagination over unbounded result sets
- Field selection / sparse fieldsets
- Incremental / delta updates instead of full payloads
- Server-sent events (SSE) or WebSockets over polling

### 6.4 Modern transport & Protocol enhancements
- HTTP/3 (QUIC) to prevent head-of-line blocking over lossy wireless/mobile connections and leverage 0-RTT handshakes
- TLS session resumption and modern cipher suites with hardware AES-NI acceleration
- Multiplexed persistent connections with health-check heartbeats over frequent reconnect handshakes

---

## 7. Caching Strategies

### 7.1 Layers
- Browser / client cache (Cache-Control headers, ETags)
- CDN cache (edge caching)
- Reverse proxy cache (Varnish, Nginx)
- Application cache (in-memory, Redis)
- Database query cache

### 7.2 Policies
- LRU (Least Recently Used) for general-purpose
- LFU (Least Frequently Used) for skewed access patterns
- TTL-based expiration for time-sensitive data
- Write-through vs write-behind (lazy write)
- Cache invalidation: event-driven over time-based

### 7.3 Prefetching
- Pre-load data likely to be requested soon
- Speculative execution for predictable paths
- Warm caches on deployment (avoid cold start)

### 7.4 Stampede prevention & Resilience
- Cache stampede / dogpile mitigation: probabilistic early expiration (XFetch algorithm) or mutex/singleflight lock on cache refill
- Negative caching with short TTL for non-existent entities to thwart cache penetration attacks
- Soft TTL vs hard TTL: serve stale data immediately in background while asynchronously revalidating

---

## 8. Code Quality & Maintainability (Performance-Related)

### 8.1 Hot paths
- Profile first, optimize second (never guess)
- Identify 80/20 bottlenecks (Pareto principle)
- Inline small hot functions (compiler hints: `inline`, `@pragma`)
- Branch prediction: most likely branch first

### 8.2 Conditionals
- Reduce branching in hot paths (lookup tables, branchless programming)
- Simplify boolean expressions (early returns, guard clauses)
- Switch over if-else chains for multi-way branches (compiler optimizes better)

### 8.3 Loop optimizations
- Loop unrolling for small fixed-size loops
- Hoist invariant calculations outside loops
- Strength reduction (multiply → shift, divide → multiply by reciprocal)
- Vectorization hints (SIMD annotations)

### 8.4 Avoid premature optimization
- Do not optimize cold paths — measure first
- Keep code readable unless the hot path proves it needs tuning
- Document why an optimization exists (avoid future refactor that removes it)

### 8.5 Modern CPU instruction pipeline
- Instruction cache (I-cache) awareness: excessive loop unrolling or inlining bloats binary size and triggers I-cache misses
- Restrict pointers (`restrict` / `__restrict__`) in C/C++ to guarantee no pointer aliasing, enabling aggressive compiler auto-vectorization
- Branch probabilities: use compiler hints (`[[likely]]`/`[[unlikely]]`, `__builtin_expect`) for critical hot-path branch steering

---

## 9. Build & Deployment

### 9.1 Build time
- Incremental compilation / caching
- Parallel build tasks
- Module federation / code splitting for large projects
- Avoid recompilation of unchanged dependencies

### 9.2 Artifact size
- Tree shaking / dead code elimination
- Minification (JS, CSS, HTML)
- Code splitting (lazy load modules)
- Dependency audit: remove unused libraries
- Binary stripping for compiled languages

### 9.3 Startup time
- Lazy initialization over eager loading
- Preload only critical resources
- Async initialization of non-critical services
- Profile application startup (Flame graph)

### 9.4 Ahead-of-time (AOT) & Runtime engines
- Ahead-Of-Time (AOT) compilation (GraalVM Native Image, .NET Native AOT, Go/Rust native binaries) to eliminate JIT warm-up and slash memory footprint for serverless/containers
- Profile-Guided Optimization (PGO) during build time using production traffic traces

---

## 10. Security (Performance-Aware)

- Rate limiting to prevent resource exhaustion
- Connection limits per client
- Timeouts for all external calls
- Payload size limits (prevent OOM attacks)
- Circuit breakers for downstream failures
- ReDoS mitigation: use linear-time regex engines (RE2, Rust regex) or bounded finite automata to avoid catastrophic backtracking
- Constant-time algorithms for cryptographic/hash comparisons (`crypto.timingSafeEqual`) without introducing branch-based timing side channels
- Backpressure-driven load shedding: drop low-priority requests with HTTP 503 before server resources saturate

---

## 11. Profiling & Benchmarking

### 11.1 Profiling tools by language
| Language        | CPU Profiler        | Memory Profiler  | Tracing          |
|-----------------|---------------------|------------------|------------------|
| Dart/Flutter    | DevTools CPU        | DevTools Memory  | DevTools Timeline|
| JavaScript/Node | Chrome DevTools     | Chrome Memory    | perf / tracing   |
| Python          | cProfile / py-spy   | memory_profiler  | viztracer        |
| Rust            | perf / flamegraph    | heaptrack        | tracing crate    |
| Go              | pprof               | pprof (heap)     | trace / fgprof   |
| Java            | Async Profiler      | JFR / JMC        | JFR              |
| C++             | perf / VerySleepy   | Valgrind / ASan  | perf / ETW       |
| C# / .NET       | dotTrace / dotnet-trace | dotMemory / dotnet-dump | PerfView / EventPipe |
| Swift           | Instruments (Time Profiler) | Instruments (Allocations) | OSLog / Signposts |
| Kotlin / Android| Android Studio Profiler | Android Memory Profiler | Perfetto / Systrace |

### 11.2 Methodology
- Establish a baseline before optimizing
- Measure wall-clock time, CPU time, memory, I/O, network
- Run multiple samples (warm-up + steady-state)
- Statistical significance (not single-run flukes)
- Compare before/after with the same environment and inputs

### 11.3 What to measure
- Latency (p50, p95, p99, p999)
- Throughput (requests/sec, ops/sec)
- Memory: allocated bytes, GC pauses, resident set size
- CPU: user vs sys, idle, iowait
- I/O: read/write ops, disk utilization

### 11.4 Micro-benchmarking traps & Rigor
- Prevent compiler dead-code elimination: consume return values with `black_box` / `benchmark::DoNotOptimize`
- Measure after JIT warmup: ignore initial interpretation and tiered compilation runs in managed runtimes
- Beware Coordinated Omission: measure true client response times inclusive of queue waiting time, not just internal processing latency

---

## 12. Language-Specific Patterns

### 12.1 Interpreted languages (Python, Ruby, JS)
- Avoid dynamic dispatch in hot paths
- Use native/C extensions for CPU-bound code
- Prefer standard library functions (C-optimized) over manual loops
- JIT warm-up: profile-guided optimization (PGO)

### 12.2 Compiled languages (C++, Rust, Go, Java)
- Compiler optimization flags: `-O2`/`-O3`, LTO, PGO
- Link-time optimization (LTO) across translation units
- Profile-guided optimization (PGO) for branch prediction
- Intrinsics / SIMD for data-parallel operations

### 12.3 JIT languages (Java, C#, JS V8)
- Warm-up loops (tiered compilation)
- Avoid megamorphic call sites (inline caches)
- Reduce allocation pressure (GC tuning)
- Escape analysis for stack allocation

---

## 13. Modern Runtime Idioms

### 13.1 JavaScript / TypeScript & Browser Runtimes
- Avoid hidden class / shape transitions in V8 (initialize all properties in constructor in the same order)
- Maintain monomorphic call sites; avoid polymorphic (>4 shapes) and megamorphic lookups in hot functions
- Never use `delete obj.key` (deoptimizes V8 hidden classes into hash maps); set to `undefined` or use `Map`
- Off-main-thread compute: delegate CPU-heavy parsing, crypto, or image manipulation to Web Workers
- Prevent DOM thrashing: batch DOM reads and writes (use `requestAnimationFrame`, CSS `content-visibility: auto`, `contain: strict`)
- Use TypedArrays (`Uint8Array`, `Float64Array`) with `ArrayBuffer.transfer()` for zero-copy binary manipulations

### 13.2 Python Performance Engineering
- `__slots__` on data classes/models to eliminate per-instance `__dict__` overhead and reduce memory consumption by up to 50%
- Local variable caching: assign global/module-level functions to local variables inside hot loops to bypass global dictionary lookup
- Vectorized operations: NumPy/Polars/Arrow over Python loops for array transformations
- Accelerated runtimes & compilers: PyPy, Mypyc, Cython, or Rust bindings (PyO3) for CPU-bound hot spots

### 13.3 C# & .NET High-Performance Patterns
- `Span<T>` and `ReadOnlySpan<T>` for zero-allocation slicing over arrays, strings, and native memory
- `stackalloc` for small, short-lived buffers to completely avoid heap allocation
- `ValueTask<T>` over `Task<T>` for asynchronous methods that frequently complete synchronously
- `ref struct` and in-parameters (`in T`) to pass large structs by readonly reference without copying
- ArrayPool (`ArrayPool<T>.Shared`) to rent and return large arrays in high-throughput network/IO paths

### 13.4 Go High-Throughput Patterns
- Zero-copy string/slice conversions using `unsafe.String` and `unsafe.Slice` in verified hot paths
- `sync.Pool` for reusing frequently allocated short-lived structs/buffers to reduce GC pressure
- Escape analysis verification (`go build -gcflags="-m"`) to keep variables on the stack instead of escaping to the heap
- Pre-sized channels and non-blocking channel selects with `default:` to prevent goroutine leaks

### 13.5 Rust Zero-Cost Patterns
- Avoid unnecessary cloning: use borrowed slices (`&[T]`, `&str`) and `Cow<'a, T>` (Clone-on-Write)
- Small vector optimization: use `smallvec` or `arrayvec` to store small collections on the stack without heap allocation
- Iterator chaining: leverage LLVM auto-vectorization across chained iterator combinators (`map`, `filter`, `fold`) over manual indexing
- `Box<[T]>` instead of `Vec<T>` for fixed-size read-only collections to eliminate capacity pointer overhead

### 13.6 Dart & Flutter Performance Patterns
- Use `const` constructors aggressively to prevent unnecessary widget rebuilds in the element tree
- Offload expensive computations from the UI thread to background isolates via `Isolate.run()` or `compute()`
- Use `RepaintBoundary` around frequently repainting widgets (animations, spinners) to isolate render object painting
- Avoid work inside `Widget.build()`: no HTTP calls, heavy parsing, or database queries; compute once in state/controllers
- Use `ListView.builder` / `CustomScrollView` with slivers for lazy element layout instead of rendering unbounded lists

---

## 14. AI, LLM & Machine Learning Inference Optimization

### 14.1 Quantization & Precision Scaling
- Downscale model precision: FP32 → FP16 / BF16 → INT8 / INT4 (GGUF, AWQ, GPTQ) to minimize VRAM bandwidth bottlenecks
- Mixed precision compute: perform critical accumulator math in FP32 while storing weights and activations in FP16/BF16

### 14.2 Inference Serving & Memory Optimization
- KV-Cache management: PagedAttention (vLLM architecture) to eliminate memory fragmentation and enable high concurrency
- Dynamic continuous batching: batch requests at the iteration level rather than request level to maximize GPU tensor core utilization
- Speculative decoding: use a small draft model to generate candidate tokens verified in parallel by the target model

### 14.3 Vector Search & Embeddings
- Approximate Nearest Neighbor (ANN) index tuning: HNSW (`M` connections, `efConstruction`, `efSearch`) tradeoff between recall and search latency
- Product Quantization (PQ) and Scalar Quantization (SQ) on vector indexes to fit millions of embeddings into RAM
- Batch embedding generation: utilize SIMD/GPU tensor pipelines for batch vectorization instead of single-vector calls

---

## 15. Mobile & Embedded Performance

- 60/120 FPS jank budget: ensure per-frame main thread compute never exceeds 16.6ms (60Hz) or 8.3ms (120Hz)
- Battery & thermal throttling: throttle background polling, release wakelocks immediately, debounce sensor updates
- Memory limits & OOM kills: cache images in downscaled decode dimensions matching display size rather than raw file resolution
- Cold-start optimization: defer secondary plugin/SDK initializations until after the first frame has rendered

---

## 16. Distributed Systems & Cloud-Scale Architecture

### 16.1 Tail-at-scale & Latency Hedging
- Hedged requests / speculative retries (Jeff Dean principle): send duplicate parallel requests to alternative replicas if the initial request crosses the P95 latency mark, taking whichever completes first (slashes P99/P99.9 tail latency by up to 80%)
- Deadlines and propagation: attach strict distributed timeouts/budgets across all RPC hops so downstream workers instantly abort work for expired requests

### 16.2 Adaptive Concurrency Limits
- Replace rigid static thread/connection pool limits with dynamic algorithms (Little's Law, TCP Vegas, Gradient, AIMD) that track real-time RTT variance and throttle traffic before queue buildup
- Bulkheads & isolate thread pools: segregate resource pools per tenant or critical service to prevent a failing dependency from consuming 100% of thread capacity

### 16.3 Cell-Based Architecture & Shuffle Sharding
- Partition large clusters into isolated autonomous "cells" to bound the blast radius of outages
- Shuffle sharding: assign each tenant or customer deterministically to a small virtual combination of cells (e.g. 2 of 8 cells), guaranteeing that any toxic payload or noisy neighbor can affect at most a tiny fraction of other customers

### 16.4 CQRS & Asynchronous Read Projections
- Decouple write-heavy normalized transactional stores (OLTP) from read-optimized analytical/view stores (Elasticsearch, Redis, Read Replicas) via event streams
- Eliminate multi-table relational joins from critical consumer read paths by pre-materializing denormalized views

### 16.5 BGP Anycast & Edge Data Locality
- Utilize BGP Anycast routing to direct traffic automatically to the geographically closest point-of-presence (PoP)
- Edge computing (Cloudflare Workers, V8 isolates at edge): evaluate authorization, caching, and simple aggregations near the user to avoid cross-ocean roundtrips

---

## 17. Analytical Engines, Columnar Formats & Stream Pipelines

### 17.1 In-Memory Columnar Processing
- Column-oriented memory representations (Apache Arrow, Parquet, DuckDB, ClickHouse) over row-oriented (AoS) collections for aggregations, analytical scans, and filtering
- Vectorized execution: process batches of column arrays in tight CPU loops, enabling automatic SIMD pipelining and maximizing memory bus bandwidth

### 17.2 Stream Processing & Batching Trade-offs
- Micro-batching vs stream-at-a-time: tune batching parameters (`linger.ms`, `batch.size`, buffer timeouts) to balance throughput against per-event latency in Kafka/RabbitMQ/SQS
- Compression at the batch level: compress entire message batches (zstd/lz4) rather than individual records to exploit cross-record redundancy

### 17.3 Reactive Streams & Cascading Backpressure
- Enforce pull-based reactive stream protocols across pipeline boundaries to avoid memory exhaustion (OOM cascades) when downstream sinks slow down
- Dynamic watermarking: manage late-arriving data in streaming windows without blocking real-time emission

---

## 18. Kernel-Bypass & Ultra-Low-Latency Networking

### 18.1 Kernel-Bypass & Packet Filtering
- eBPF (extended Berkeley Packet Filter) & XDP (eXpress Data Path): inspect, modify, and drop or redirect network packets at the device driver layer before allocating OS socket buffers (`sk_buff`)
- DPDK (Data Plane Development Kit): bypass the Linux kernel network stack entirely, polling network cards directly from user space for millions of packets per second

### 18.2 Congestion Control Tuning
- TCP BBR (Bottleneck Bandwidth and RTT) over traditional loss-based algorithms (CUBIC) on high-bandwidth, high-latency links to prevent throughput collapse from bufferbloat
- Tune socket buffers (`SO_RCVBUF`, `SO_SNDBUF`) and enable TCP Fast Open (TFO) to eliminate the initial handshake roundtrip

### 18.3 Zero-Downtime State Handoff
- Leverage `SO_REUSEPORT` to allow multiple processes to bind to the exact same listening port, enabling kernel-level load balancing
- Pass listening socket file descriptors across process restarts (socket takeover / graceful reload) to achieve zero dropped packets during hot deployments

---

## 19. Mechanical Sympathy & Hardware Architecture

### 19.1 Memory Ordering & Hardware Fences
- Use explicit memory models for lock-free concurrency: prefer relaxed (`memory_order_relaxed`) for independent counters, acquire-release (`memory_order_acquire`/`memory_order_release`) for synchronization handoffs, avoiding expensive sequentially consistent (`memory_order_seq_cst`) CPU memory barriers (`MFENCE`) unless strictly necessary
- Cache coherence traffic reduction: prevent cache-line bouncing across multi-socket CPUs by segregating write-heavy shared states to distinct CPU cores

### 19.2 Zero-Copy In-Memory Serialization
- Serialization frameworks that operate directly on mapped memory without object allocation or decoding: FlatBuffers, Cap'n Proto, and rkyv (Rust)
- Direct memory-mapped access (`mmap`) allowing instant lookups with zero heap allocation and zero parse time

### 19.3 Branch Target Buffer (BTB) & Virtual Dispatch
- Avoid deep polymorphic hierarchies and megamorphic vtable lookups in tight loops to prevent thrashing the CPU's Branch Target Buffer (BTB)
- Prefer static polymorphism (templates in C++, generics with monomorphization in Rust, CRTP) over dynamic interface dispatch in hot paths

---

## 20. Heterogeneous & Hardware-Accelerated Computing (GPU/WebGPU)

### 20.1 GPGPU & Compute Shaders
- Offload massive data-parallel loops (matrix operations, image/audio transforms, cryptography, physics simulations) to GPU compute shaders via WebGPU (WGSL), CUDA, or Metal
- Design algorithms for high thread divergence tolerance and coalesced memory access patterns

### 20.2 Host-to-Device Memory Transfer Optimization
- Use page-locked / pinned host memory (`cudaHostAlloc`, WebGPU mapped buffers) to enable asynchronous DMA transfers
- Overlap memory transfers with kernel execution using concurrent hardware streams

---

## 21. Serverless & Cloud-Native Execution Optimization

### 21.1 MicroVM Snapshot Restoration (Cold Start Mitigation)
- Utilize snapshot-based memory restores (Firecracker, AWS SnapStart, JVM CRaC) to resume pre-initialized execution heaps in sub-millisecond windows
- Pre-warm connection handshakes and initialize dependency graphs at build/snapshot time rather than runtime

### 21.2 Extreme Container Trimming
- Build minimal execution images (`scratch`, Google Distroless, Alpine) stripping package managers, shells, and debug utilities, reducing container sizes from >1GB to <30MB for rapid node pulls and decompression

### 21.3 Serverless Connection Proxying
- Employ managed connection pooling proxies (PgBouncer, AWS RDS Proxy, Prisma Accelerate) to multiplex ephemeral function connections over a small set of persistent database sessions

---

## 22. Performance Engineering in the Agentic & AI Era

### 22.1 Context Engineering & Token Latency
- Optimize Time-To-First-Token (TTFT): structure prompts with static prefixes to maximize LLM provider KV-cache hit rates (Prefix Caching)
- Semantic prompt compaction: eliminate repetitive formatting and conversational fluff before LLM ingestion to reduce input token overhead and latency
- Token budget enforcement: truncate dynamic histories with sliding window embeddings instead of unbounded context growth

### 22.2 Hybrid Deterministic Orchestration
- Wrap non-deterministic LLM calls within fast, deterministic rule engines and classification trees; use LLMs only when heuristic classifiers cannot resolve intent
- Parallel speculative agent dispatch: invoke fast speculative models for simple subtasks while dispatching complex reasoning models only for ambiguous paths

---

## 23. Continuous Performance Validation & Chaos Invariants

### 23.1 Shift-Left Performance Gates in CI/CD
- Establish automated performance regression budgets in CI: fail builds if pull requests increase memory allocation per request, CPU instruction counts, or P95 latency beyond defined thresholds
- Run reproducible micro-benchmarks with fixed CPU clock frequency pinning to eliminate thermal throttling noise in CI environments

### 23.2 Telemetry Correlation & RUM Observability
- Correlate Real User Monitoring (RUM) frontend telemetry directly with distributed OpenTelemetry backend traces
- Focus alerting strictly on high tail percentiles (P95, P99, P99.9) and SLO burn rates rather than arithmetic averages (mean)

### 23.3 Chaos Engineering under Performance Stress
- Invalidate performance assumptions by injecting controlled latency, packet jitter, and downstream node evictions during load tests
- Validate that circuit breakers open cleanly, bulkheads protect healthy paths, and fallback degradation routes execute without cascading collapse

---

## Workflow: Systematic Execution & Output Format

### Mode A: Full-Repository Audit (When no file or snippet is specified)

When the user asks to optimize, audit, or speed up the project without specifying a target file or snippet, execute the following repository-wide protocol:

1. **Topological Reconnaissance & Hotspot Mapping**:
   - Inspect build & dependency manifests (`package.json`, `Cargo.toml`, `go.mod`, `pubspec.yaml`, `pom.xml`, `requirements.txt`, etc.) to identify stack, frameworks, and database drivers.
   - Trace execution entry points (HTTP servers, CLI entrypoints, background daemons, message queue consumers).
   - Identify critical hot paths: heavy data transformations, database access layers (ORMs/queries), serialization loops, event routers, and network callouts.
   - Scan for repository-wide performance anti-patterns:
     * N+1 query patterns, unindexed filters, missing cursor pagination.
     * Unbounded concurrency / unbounded worker spawning without backpressure.
     * Blocking sync operations inside async event loops.
     * Heavy memory allocations in hot paths (boxing, unneeded copies, missing capacity pre-allocations).
     * Missing caching layers, uncompressed payload transfers, or missing task cancellation signals (`AbortController`, `context.Context`).

2. **Ranked Bottlenecks Inventory**:
   - Synthesize the top 3-7 most impactful performance bottlenecks found across the repository.
   - Group by severity (Critical / High / Medium) with exact file paths (`file:///path/to/file.ext#L10-L40`) and root cause explanations.

3. **Targeted Code Refactors & Architectural Fixes**:
   - For each prioritized hotspot, deliver production-ready refactored code or architectural modifications with precise diffs.
   - Respect idiomatic patterns for each language and guarantee Zero Semantic Regression.

4. **Repository-Wide Verification & Profiling Playbook**:
   - Provide the exact profiling commands, benchmark scripts, or load testing tooling applicable to the project to validate the improvements across the entire codebase.

---

### Mode B: Targeted Snippet / File Optimization (When code or a file is provided)

When code or a specific file is provided, respond strictly using the following 4-Phase structure:

#### Phase 1: Diagnosis & Constraints
* State identified language/runtime environment.
* List the top 1-3 bottlenecks found (categorized by High/Medium/Low impact).

#### Phase 2: The Big-O / Architectural Shift (If applicable)
* If an algorithmic change is needed, explicitly contrast the current vs. proposed complexity (e.g., O(N^2) -> O(N log N)).

#### Phase 3: Optimized Implementation
* Provide the fully refactored, production-ready code.
* Use clean, idiomatic syntax for the target language.
* Add minimal, high-value comments directly inside the code explaining *why* a complex optimization was made.

#### Phase 4: Verification & Benchmarking Advice
* Provide the exact specific tool/standard library module the user should run to verify this specific change (e.g., `timeit` for Python, `go test -bench` for Go, `BenchmarkDotNet` for C#). Do not just list a generic table.
