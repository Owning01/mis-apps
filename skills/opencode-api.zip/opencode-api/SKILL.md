---
name: opencode-api
description: >-
  Guía completa para consumir la API de OpenCode por HTTP directo desde cualquier lenguaje o backend:
  OpenCode Go (suscripción) y OpenCode Zen (pay-as-you-go). Cubre base URLs, autenticación, qué endpoint
  usar por modelo (/responses, /chat/completions, /messages), el header obligatorio x-opencode-session,
  function/tool calling con loop de agente, replay de razonamiento (encrypted_content), streaming, parámetros,
  precios, límites y privacidad. Usá esta skill SIEMPRE que haya que integrar, configurar, migrar o
  debuggear una app/agente/chat para que use la API de OpenCode, Zen o Go; cuando aparezcan errores del
  gateway (invalid_request_error, MissingSessionID, "Upstream request failed", "Internal server error",
  model not found); o cuando haya que elegir modelo/endpoint y armar el request/response correcto
  (Responses API, chat completions, messages, tool calling, reasoning, streaming).
argument-hint: "[go|zen|responses|tools|streaming|errors] <consulta>"
version: "1.1.0"
license: MIT
---

# OpenCode API — Guía de integración

OpenCode expone una **gateway de modelos por HTTP** en dos superficies con la misma auth y el mismo costo por token:

| Superficie | Base URL | Modelo comercial |
|---|---|---|
| **OpenCode Go** | `https://opencode.ai/zen/go/v1` | Suscripción ($5 primer mes, luego $10/mes, con límites 5h/semana/mes) |
| **OpenCode Zen** | `https://opencode.ai/zen/v1` | Pay-as-you-go (créditos, auto-reload) |

No son endpoints equivalentes: **un mismo modelo puede vivir en paths distintos según la superficie** (p. ej. MiniMax en Go va por `/messages` y en Zen por `/chat/completions`). Nunca asumas el path por el nombre del modelo: consultá la tabla de la superficie o `GET {base}/models`.

> Esta skill es para **llamar la API como cliente**. Para configurar OpenCode (la app), sus agentes o plugins, usá la skill `opencode` / `opencode-architecture`.

## Regla de oro: primero elegí el endpoint, después el body

Hay tres protocolos y cada uno tiene un contrato de request distinto:

| Protocolo | Path | Paquete de referencia | Lo usan |
|---|---|---|---|
| **Responses API** (OpenAI) | `/responses` | `@ai-sdk/openai` | GPT 5.x, Grok, **Muse Spark** |
| **Chat Completions** (OpenAI-compatible) | `/chat/completions` | `@ai-sdk/openai-compatible` | DeepSeek, GLM, Kimi, MiMo, Hy3 |
| **Messages API** (Anthropic-compatible) | `/messages` | `@ai-sdk/anthropic` | Claude, Qwen, MiniMax (en Go), Union Alpha |

Antes de escribir una línea de código:

1. `GET {base}/models` con tu key → ids **habilitados para tu cuenta** (cambia seguido; la lista es parcial: sin saldo Zen puede traer sólo free + modelos de Go).
2. Buscá ese `id` en `references/go-models.md` o `references/zen-models.md` → te da el **path exacto**.
3. Seguí el contrato de ese protocolo (`references/responses-api.md` para `/responses`).

Elegir mal el path es la causa #1 de errores: pegarle a `/chat/completions` con un modelo servido por `/responses` devuelve un opaco `{"error":{"message":"Internal server error"}}`.

## Autenticación

Hay **dos esquemas** según el protocolo del endpoint (verificado contra la API real, sep-2026):

| Endpoint | Header de auth |
|---|---|
| `/chat/completions` y `/responses` | `Authorization: Bearer sk-...` |
| `/messages` (Anthropic-compatible) | `x-api-key: sk-...` — con `Bearer` devuelve `401 AuthError: Missing API key.` |

Ambos usan `Content-Type: application/json`. En `/messages` podés mandar los dos headers juntos sin problema (gana `x-api-key`).

- Las keys empiezan con `sk-`. Se obtienen en <https://opencode.ai/auth> (misma cuenta para Go y Zen).
- **Nunca** hardcodees la key: va en `.env` (gitignored) o variable de entorno. En Go usá `EnvironmentFile` de systemd / en Node `process.env`, etc.
- Error típico si falta o está mal: `401` (`AuthError: Missing API key.`).

## Header de sesión (crítico en OpenCode Go)

El gateway de **Go exige** identificar la conversación:

```http
x-opencode-session: <id estable por conversación>
```

Sin él: `{"error":{"type":"MissingSessionID","message":"Error from provider (Console Go): Request is missing x-opencode-session and cannot be routed efficiently..."}}`.

Buenas prácticas que pide la doc de Go:
- **Un id estable por conversación** (no uno fijo global ni uno nuevo por request). Persistilo (ej. localStorage en front, o derivado del chat en back). Se usa para routing y prompt cache.
- Mandá un **User-Agent propio** (ej. `mi-app/1.0`), no el de una librería genérica.
- Sirve para prompt caching: se ve reflejado en `usage.input_tokens_details.cached_tokens`.

## Quickstart

**Chat Completions** (modelos `/chat/completions`):

```bash
curl -s "$BASE/chat/completions" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -H "x-opencode-session: $SID" \
  -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"Hola"}],"max_tokens":64}'
# → {"choices":[{"message":{"content":"..."}}], ...}
```

**Responses** (modelos `/responses`, ej. Muse Spark):

```bash
curl -s "$BASE/responses" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -H "x-opencode-session: $SID" \
  -d '{"model":"muse-spark-1.3-contributor","input":"Hola","max_output_tokens":2000,"reasoning":{"effort":"low"},"store":false,"include":["reasoning.encrypted_content"]}'
# → {"output":[{"type":"message","content":[{"type":"output_text","text":"..."}]}], ...}
```

**Messages** (modelos `/messages`, formato Anthropic): header `x-api-key: $KEY` (no `Bearer`) y body `{"model","max_tokens","messages":[{"role":"user","content":"..."}]}`.

## Responses API: lo que rompe si no lo sabés

Los modelos `/responses` (Muse Spark, GPT 5.x, Grok) son **reasoning models** y el contrato es más estricto. Detalle completo en `references/responses-api.md`; lo esencial:

- **`input`** es un string o un array de items tipados. Roles: `developer`, `system`, `user`, `assistant`.
- **Tipos de contenido**: `user`/`developer` → `input_text`; **`assistant` → `output_text`**. Poner `input_text` en un mensaje `assistant` da
  `content type 'input_text' is not valid on 'assistant' messages`.
- **`instructions`** (top-level) = system/developer prompt. **No persiste** entre turnos: reenviálo en cada request.
- **Replay de razonamiento stateless (recomendado)**: `"store": false` + `"include": ["reasoning.encrypted_content"]`, y reenviá los `reasoning` items tal cual vinieron (necesitan `encrypted_content` y `summary`, `[]` si vacío; el `id` es opcional al reenviar).
- **Orden obligatorio**: cada `reasoning` item debe ir seguido de un `assistant` message o un `function_call` antes del próximo `user`/`system`/`developer`, o da `400 param:"input"`.
- **Alternativa server-managed**: `previous_response_id` (manda solo lo nuevo). **No se puede combinar** con `include` en el mismo request.
- **`max_output_tokens`** cubre **razonamiento + salida** (mínimo 16). Si queda corto, el modelo gasta el budget razonando y el `output` vuelve vacío con `status:"incomplete"`. Sobre-provisioná.
- **`reasoning.effort`**: `minimal|low|medium|high|xhigh`. `none` → 400 (Muse Spark no lo soporta); `max` sólo existe en Muse Spark standard, **no** en Contributor.
- **No-streaming tiene tope de tiempo del servidor** → `504 gateway_timeout` en generaciones largas. Para eso usá `stream: true`.
- `logprobs` no soportado; `truncation:"auto"` rechazado; structured output usa `text.format` (no `response_format`).

## Tool / function calling (loop de agente)

En `/responses` los tools son **planos** (`type":"function"` con `name`/`description`/`parameters` arriba, sin anidar bajo `"function"`). El modelo devuelve items `function_call` en `output`; vos ejecutás y devolvés `function_call_output`:

```jsonc
{"model":"...","input":[ /* ... items previos ... */
  {"type":"function_call_output","call_id":"call_abc","output":"{\"temp\":15}"}
],"tools":[{"type":"function","name":"get_weather","description":"...","parameters":{"type":"object","properties":{"location":{"type":"string"}},"required":["location"]}}]}
```

Reglas que evitan 400:
- `function_call_output.call_id` debe existir y matchear un `function_call` del mismo request (1–64 chars).
- Mantené el orden de los results igual al de los calls; ejecutá **todos** (por defecto `parallel_tool_calls: true`).
- `tool_choice` sólo acepta `"auto"`.
- Al reenviar historial, incluí el `function_call` completo antes de su `function_call_output`.
- Los mensajes de texto intermedios que preceden un tool call llevan `phase:"commentary"`; preservalo al reenviar.

En `/chat/completions` el patrón es el clásico: `tools[].function{...}`, el modelo devuelve `message.tool_calls[]`, y respondés con mensajes `role:"tool"` + `tool_call_id`.

## Streaming

```jsonc
{"model":"...","input":"...","stream":true}
```

SSE. En Responses los eventos útiles son `response.output_text.delta` (texto), `response.function_call_arguments.delta/done` (args de tools), y `response.completed`/`response.failed` (terminal, trae el objeto completo). Acumulá por `output_index`/`item_id`. En Chat Completions, deltas `choices[0].delta`.

## Errores frecuentes → causa

| Error | Causa | Fix |
|---|---|---|
| `content type 'input_text' is not valid on 'assistant' messages` | replay de assistant con tipo de user | usá `output_text` |
| `MissingSessionID ... x-opencode-session` (Go) | falta el header | mandá un session id estable por conversación |
| `401 AuthError: Missing API key.` | `/messages` con `Authorization: Bearer` | en `/messages` usá `x-api-key: sk-...` |
| `403 FreeTierError: free tier can only be used from within OpenCode` | cliente externo con cuenta sin saldo usando modelos `-free` | cargá saldo Zen o usá Go; los `-free` son sólo del cliente oficial |
| `{"error":{"message":"Internal server error"}}` | path equivocado para ese modelo | usá el endpoint de la tabla (`/responses` vs `/chat/completions` vs `/messages`) |
| `output: []`, `status:"incomplete"`, `reason:"max_output_tokens"` | razonamiento consumió todo el budget | subí `max_output_tokens` |
| `400 param:"input"` con reasoning | reasoning sin assistant/function_call después | respetá el orden; insertá un assistant mínimo si el turno fue sólo razonamiento |
| `400` al reenviar `include` + `previous_response_id` | combinación prohibida | elegí un modo: stateless (`store:false`+`include`) **o** `previous_response_id` |
| `HTTP 400 ... reasoning.effort "none"` | Muse Spark no soporta `none` | usá `minimal`/`low`/`medium`/`high`/`xhigh` |
| `504 gateway_timeout` | request no-streaming demasiado largo | `stream:true` |

Tabla ampliada en `references/troubleshooting.md`.

## Privacidad y elección de modelo

La privacidad **depende del modelo**, no de la superficie. Antes de mandar datos sensibles:

- La mayoría de los modelos de Zen/Go son **ZDR** (0 días, sin entrenar con tus datos).
- **`muse-spark-1.3-contributor` y `-1.2-contributor` SÍ entrenan con tus prompts/completions** ("Not ZDR"). Es el tier barato de Meta a cambio de data.
- Modelos `-free` (Big Pickle, MiMo Free, Nemotron Free, etc.) pueden usar la data para mejorar el modelo. **Además, desde un cliente externo dan `403 FreeTierError`** ("free tier can only be used from within OpenCode", verificado sep-2026): para integrar la API usá Go o saldo Zen.
- OpenAI/Anthropic mantienen 30 días (abuse monitoring).

Si el payload tiene PII o secretos, preferí un modelo ZDR (`deepseek-v4-flash`, `glm-5.2`, `kimi-k2.7-code`, etc.). Detalle por modelo en `references/zen-models.md` / `references/go-models.md`.

## Checklist de integración

- [ ] `GET {base}/models` para confirmar el `id` y su path (lista lo habilitado para tu cuenta: puede ser parcial).
- [ ] Si usás `/messages`: `x-api-key`, no `Bearer`.
- [ ] Cliente externo: no cuentes con modelos `-free` (dan `403 FreeTierError`).
- [ ] Key en env/`.env`, nunca en el repo.
- [ ] Header `x-opencode-session` estable por conversación (Go).
- [ ] `instructions` reenviadas en cada turno (Responses).
- [ ] `store:false` + `include:["reasoning.encrypted_content"]` si manejás el historial vos.
- [ ] `max_output_tokens` con margen para razonamiento.
- [ ] Streaming si las respuestas pueden ser largas.
- [ ] Timeouts de cliente/proxy holgados (los agent loops tardan).
- [ ] Elegir modelo ZDR si hay datos sensibles.

## Referencias (leé sólo lo que necesitás)

- `references/go-models.md` — modelos de OpenCode Go, path exacto, límites y privacidad.
- `references/zen-models.md` — modelos de OpenCode Zen, path exacto y precios.
- `references/responses-api.md` — contrato completo de la Responses API: input items, reasoning replay, tools, streaming, parámetros, endpoints auxiliares.
- `references/troubleshooting.md` — catálogo de errores con causa y fix.
- `scripts/opencode_client.py` — cliente de referencia (stdlib): chat/completions, responses y un tool-loop completo. Copialo y adaptalo.
