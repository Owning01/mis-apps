# Responses API — contrato completo

Referencia para los modelos servidos en `/responses` (Muse Spark, GPT 5.x, Grok). Fuente: guías de Meta Model API + docs de OpenCode Go/Zen. En OpenCode, el path es `{base}/responses` (ej. `https://opencode.ai/zen/go/v1/responses`).

## Índice

1. [Endpoints](#endpoints)
2. [Request: parámetros](#request-parámetros)
3. [Input items y tipos de contenido](#input-items-y-tipos-de-contenido)
4. [Message phase](#message-phase)
5. [Reasoning items y replay](#reasoning-items-y-replay)
6. [Reglas de estructura (evitan 400)](#reglas-de-estructura-evitan-400)
7. [Function calling](#function-calling)
8. [Streaming](#streaming)
9. [Shape de la respuesta](#shape-de-la-respuesta)
10. [Notas de compatibilidad OpenAI](#notas-de-compatibilidad-openai)

## Endpoints

| Método | Path | Uso |
|---|---|---|
| POST | `/responses` | Crear respuesta (el endpoint principal) |
| GET | `/responses/{id}` | Recuperar una respuesta guardada |
| POST | `/responses/{id}/cancel` | Cancelar una respuesta en background |
| DELETE | `/responses/{id}` | Borrar (soft-delete; deja de ser referenciable) |
| POST | `/responses/input_tokens` | Contar tokens del input antes de generar |

## Request: parámetros

```jsonc
{
  "model": "muse-spark-1.3-contributor",
  "input": "..." | [ /* items */ ],
  "instructions": "system/developer prompt",   // no persiste entre turnos: reenviar siempre
  "tools": [ /* ... */ ],
  "tool_choice": "auto",                        // sólo "auto" es válido
  "parallel_tool_calls": true,                  // default true
  "max_output_tokens": 16384,                   // razonamiento + salida; mínimo 16
  "reasoning": { "effort": "low", "summary": "auto" },
  "store": false,                               // default true (server-side)
  "include": ["reasoning.encrypted_content"],
  "previous_response_id": "resp_...",           // alternativa a replay stateless
  "stream": true,
  "temperature": 1.0, "top_p": 1.0,             // dejar en default salvo necesidad
  "frequency_penalty": 0, "presence_penalty": 0,
  "prompt_cache_key": "conv-id",                // agrupa requests para cache
  "safety_identifier": "hash-de-usuario",       // hasta 64 chars, sin PII
  "prompt_cache_retention": "in_memory" | "24h",
  "background": true,                           // asíncrono; incompatible con stream en el create
  "text": { "format": { /* JSON schema */ } }   // structured output (NO "response_format")
}
```

Notas:
- **`reasoning.effort`**: `minimal | low | medium | high | xhigh` (+ `max` sólo en Muse Spark standard). `"none"` → 400.
- **`max_output_tokens`**: cubre razonamiento + texto visible. Si el razonamiento consume el budget, `output` vuelve vacío y `status:"incomplete"`.
- **`truncation:"auto"`** es rechazado (sólo `"disabled"`).
- **`logprobs`** no soportado → 400.
- Body en `background:true` limitado a 1 MiB. Media inline hasta 50 MB.

## Input items y tipos de contenido

Si no usás `previous_response_id`, armás `input` como array de items. Roles: `developer`, `system`, `user`, `assistant`.

```jsonc
[
  {"role":"developer","content":[{"type":"input_text","text":"Sos un asistente útil."}]},
  {"role":"user","content":[{"type":"input_text","text":"¿Capital de Francia?"}]},
  {"role":"assistant","content":[{"type":"output_text","text":"París."}]},
  {"role":"user","content":[{"type":"input_text","text":"¿Y su población?"}]}
]
```

| Rol | Tipos de contenido válidos |
|---|---|
| `user` / `developer` / `system` | `input_text`, `input_image`, `input_file`, `input_video` |
| `assistant` (replay) | **`output_text`** (NO `input_text`) |

Error si te equivocás: `content type 'input_text' is not valid on 'assistant' messages param:input_text type:invalid_request_error`.

## Message phase

Los mensajes `assistant` pueden llevar `phase`:

- `"commentary"`: texto intermedio antes de un tool call.
- `"final_answer"`: sólo válido en input; el modelo no lo emite.

Regla: **texto intermedio que precede a un `function_call` debe ir con `phase:"commentary"`**; reenviarlo como final answer antes de un `function_call` da 400. Cuando el modelo devuelve `phase`, preservalo al reenviar (si no hay `phase`, tratalo como final answer).

## Reasoning items y replay

Muse Spark razona internamente. Ese razonamiento viaja como items `reasoning` en `output` y se puede reenviar en `input` para continuidad entre turnos.

**Modo recomendado — replay stateless (sin estado en el server):**

```jsonc
// Request
{"model":"...","input":"...","store":false,"include":["reasoning.encrypted_content"]}
```

```jsonc
// Item reasoning que devuelve el output (reenviar tal cual en el próximo input)
{"type":"reasoning","id":"rs_abc","summary":[],"encrypted_content":"..."}
```

- `encrypted_content` viene **sólo** si pediste `include: ["reasoning.encrypted_content"]`.
- Cada reasoning item de input **necesita `summary`** (`[]` si no hay).
- El `id` es opcional en input cuando hay `encrypted_content`.
- Reenviar un `rs_` id **sin** `encrypted_content` → 400 ("not found or has expired").

**Modo server-managed:** `previous_response_id` (manda sólo lo nuevo). **No combinable con `include`.** Los parámetros top-level no persisten: reenviá `instructions`, `tools` y `reasoning.effort` en cada request.

**Compactación:** no hay truncado automático. Podés dropear reasoning items de turnos viejos (enteros), pero los que conserves deben llevar `encrypted_content` y mantener el pairing `function_call`/`function_call_output`. Medí con `/responses/input_tokens`.

**Summaries:** `reasoning.summary: "auto" | "concise" | "detailed"` genera un resumen legible en `summary[]`. No garantizado.

## Reglas de estructura (evitan 400)

- **Cada `reasoning` item debe ir seguido de un `assistant` message o un `function_call`** antes del próximo `user`/`system`/`developer`. Si el turno fue sólo razonamiento, insertá un assistant mínimo.
- `function_call_output.call_id` debe matchear un `function_call.call_id` del mismo request. `call_id` de 1–64 chars.
- Mantené el orden: cada `function_call` antes de su `function_call_output`.
- Con `previous_response_id` las validaciones de orden se relajan (el server reconstruye).

## Function calling

Tools en formato **plano**:

```json
{"type":"function","name":"get_weather","description":"...","parameters":{"type":"object","properties":{"location":{"type":"string"}},"required":["location"],"additionalProperties":false}}
```

- `strict` (opcional, default `false`): valida el schema contra el subset estricto.
- Salida: items `function_call` en `output` con `name`, `arguments` (JSON string), `call_id`, `status`.
- Devolución: item `function_call_output` con `call_id` + `output` (string).

```jsonc
{"input":[ /* user */, /* reasoning */, /* function_call */,
  {"type":"function_call_output","call_id":"call_abc","output":"{\"resultado\":12}"}
]}
```

- `parallel_tool_calls` (default true): ejecutá **todas** las calls y devolvé un output por cada una, en el mismo orden.
- `tool_choice` sólo `"auto"`.
- `max_tool_calls` limita **sólo** built-ins (`web_search`), no functions.
- Compact tools: `defer_loading:true` + tool `tool_search`.

## Streaming

`"stream": true` → SSE. Eventos comunes:

- `response.created`, `response.in_progress`
- `response.output_item.added` / `.done` (item `status` pasa de `in_progress` a `completed`)
- `response.content_part.added` / `.done`
- `response.output_text.delta` (texto visible)
- `response.function_call_arguments.delta` / `.done` (args de tools)
- `response.reasoning_summary_text.delta` / `.done` (si pediste summary)
- Terminal: `response.completed` / `response.failed` / `response.incomplete`, y `[DONE]`

Detalle: el modelo **no** emite texto de razonamiento (`response.reasoning_text.*` no existe); el chain of thought sólo va encriptado. No descartes items hasta `status:"completed"`. Para background, `GET /responses/{id}?stream=true` live-tails el lifecycle (no los deltas).

**Importante:** los requests **no-streaming** tienen tope de tiempo del server → `504 gateway_timeout` si tardan. Para generaciones largas, streamear.

## Shape de la respuesta

```jsonc
{
  "id": "resp_abc123",
  "object": "response",
  "status": "completed",           // o "incomplete" | "failed" | "cancelled" | "in_progress"
  "model": "muse-spark-1.3-contributor",
  "output": [
    {"type":"reasoning","id":"rs_...","summary":[],"encrypted_content":"..."},
    {"type":"message","role":"assistant","status":"completed",
     "content":[{"type":"output_text","text":"...","annotations":[]}]},
    {"type":"function_call","name":"get_weather","arguments":"{...}","call_id":"call_...","status":"completed"}
  ],
  "usage": {"input_tokens":69,"output_tokens":163,"total_tokens":232,
            "input_tokens_details":{"cached_tokens":0},
            "output_tokens_details":{"reasoning_tokens":73}},
  "error": null,
  "incomplete_details": {"reason":"max_output_tokens"}
}
```

Extraer texto: concatenar `output[].content[].text` de los items `type:"message"`.

## Notas de compatibilidad OpenAI

- Structured output usa **`text.format`**, no `response_format` (se acepta pero no configura nada).
- **No implementados**: `stop`, `verbosity`, `logit_bias`, `prediction`, `n > 1`, audio modalities, `web_search_options`. Omitilos.
- `stream_options.include_usage` es de Chat Completions y no aplica (el stream de Responses ya trae usage).
- Sampling: `temperature`/`top_p` se aceptan pero el modelo está tuneado en los defaults (1.0); dejar sin setear salvo caso puntual.
