# OpenCode Go — modelos y endpoints

- Base URL: `https://opencode.ai/zen/go/v1`
- Suscripción: **$5 el primer mes, luego $10/mes**. Sólo un miembro por workspace puede suscribirse.
- Header obligatorio: `x-opencode-session: <id por conversación>`.
- Lista viva: `GET https://opencode.ai/zen/go/v1/models` (con `Authorization: Bearer`).

## Modelo → endpoint

Usá el path exacto de esta tabla. Si el modelo no figura, consultá `/models` (la lista cambia).

| Modelo | Model ID | Endpoint |
|---|---|---|
| Grok 4.6 | `grok-4.6` | `/responses` |
| GPT 5.6 Luna | `gpt-5.6-luna` | `/responses` |
| Muse Spark 1.3 Contributor | `muse-spark-1.3-contributor` | `/responses` |
| Muse Spark 1.2 Contributor | `muse-spark-1.2-contributor` | `/responses` |
| GLM-5.3-Flash | `glm-5.3-flash` | `/chat/completions` |
| GLM-5.3 | `glm-5.3` | `/chat/completions` |
| GLM-5.2 | `glm-5.2` | `/chat/completions` |
| GLM-5.1 | `glm-5.1` | `/chat/completions` |
| Kimi K3 | `kimi-k3` | `/chat/completions` |
| Kimi K2.7 Code | `kimi-k2.7-code` | `/chat/completions` |
| Kimi K2.6 | `kimi-k2.6` | `/chat/completions` |
| LongCat-2.0 | `longcat-2.0` | `/chat/completions` |
| DeepSeek V4.1 Flash | `deepseek-v4.1-flash` | `/chat/completions` |
| DeepSeek V4 Pro | `deepseek-v4-pro` | `/chat/completions` |
| DeepSeek V4 Flash | `deepseek-v4-flash` | `/chat/completions` |
| DeepSeek V4 Flash Vision Exp | `deepseek-v4-flash-vision-exp` | `/chat/completions` |
| MiMo-V2.5 | `mimo-v2.5` | `/chat/completions` |
| MiMo-V2.5-Pro | `mimo-v2.5-pro` | `/chat/completions` |
| Hy4 preview | `hy4-preview` | `/chat/completions` |
| Hy3 | `hy3` | `/chat/completions` |
| MiniMax M3 | `minimax-m3` | `/messages` |
| MiniMax M2.7 | `minimax-m2.7` | `/messages` |
| MiniMax M2.5 | `minimax-m2.5` | `/messages` |
| Qwen3.8 Max | `qwen3.8-max` | `/messages` |
| Qwen3.8 Flash | `qwen3.8-flash` | `/messages` |
| Qwen3.7 Max | `qwen3.7-max` | `/messages` |
| Qwen3.7 Plus | `qwen3.7-plus` | `/messages` |
| Qwen3.6 Plus | `qwen3.6-plus` | `/messages` |

> En Go, MiniMax/Qwen van por `/messages` (Anthropic). En Zen esos mismos modelos van por `/chat/completions`. **No mezcles las tablas.**
>
> **Stealth / no documentados (vistos en `GET /models`, sep-2026):** `deepseek-flash`, `kimi-k2.5`, `glm-5`, `grok-4.5`, `mimo-v2-pro`, `mimo-v2-omni`, `hy3-preview`, `omen-alpha` (exclusivo de Go). No están en la tabla de docs y su path puede variar: probá el endpoint del modelo equivalente (Grok → `/responses`; Kimi/GLM/MiMo/Hy → `/chat/completions`). `union-alpha` es un stealth de Zen (free por tiempo limitado), no aparecía en `/models` de Go al 18-sep-2026.

Config de OpenCode (no de tu app): el id se referencia como `opencode-go/<model-id>`.

## Límites de uso

Los límites se expresan en **dólares de uso por modelo** y se calculan como:

- **5 horas** = 20% del límite mensual
- **Semanal** = 50%
- **Mensual** = 100%

Ejemplos de límite mensual por modelo (token prices por 1M):

| Modelo | Input | Output | Cached read | Límite/mes |
|---|---|---|---|---|
| GLM-5.3-Flash | $0.15 | $0.50 | $0.03 | $60 |
| GLM-5.3 / 5.2 / 5.1 | $1.40 | $4.40 | $0.26 | $15 / $60 / $60 |
| Kimi K3 | $3.00 | $15.00 | $0.30 | $15 |
| Kimi K2.7 Code / K2.6 | $0.95 | $4.00 | $0.19 / $0.16 | $60 |
| LongCat-2.0 | $0.30 | $1.20 | $0.006 | $60 |
| Muse Spark 1.3 / 1.2 Contributor | $0.10 | $0.20 | $0.002 | $60 |
| MiMo V2.5 | $0.14 | $0.28 | $0.0028 | $60 |
| MiMo V2.5 Pro | $0.435 | $0.87 | $0.003625 | $15 |
| MiniMax M3 / M2.7 | $0.30 | $1.20 | $0.06 | $60 |
| Qwen3.8 Max | $2.00 | $6.00 | $0.25 | $15 |
| Qwen3.8 Flash | $0.15 | $0.47 | $0.016 | $30 |
| Qwen3.7 Max | $2.50 | $7.50 | $0.50 | $30 |
| Qwen3.7 Plus | $0.40 / $1.20 | $1.60 / $4.80 | $0.04 / $0.12 | $60 |
| Qwen3.6 Plus | $0.50 / $2.00 | $3.00 / $6.00 | $0.05 / $0.20 | $60 |
| DeepSeek V4 Pro | $0.66 / $1.32 | $1.98 / $3.96 | $0.022 / $0.044 | $15 |
| DeepSeek V4 Flash | $0.15 / $0.30 | $0.60 / $1.20 | $0.003 / $0.006 | $30 |
| DeepSeek V4.1 Flash | $0.15 / $0.30 | $0.60 / $1.20 | $0.003 / $0.006 | $60 (promo hasta 20-sep) |
| Hy4 preview | $0.834 | $2.501 | $0.042 | $30 |
| Hy3 | $0.14 | $0.58 | $0.035 | $60 |
| Grok 4.6 | $2.00 / $4.00 | $6.00 / $12.00 | $0.50 / $1.00 | $15 |
| GPT 5.6 Luna | $0.20 / $0.40 | $1.20 / $1.80 | $0.02 / $0.04 | $15 |

(DeepSeek tiene precio off-peak/peak; peak = 01:00–04:00 y 06:00–10:00 UTC L-V.)

Si se agota el límite (del modelo o el mensual del workspace), la API responde `429 {"type":"error","error":{"type":"GoUsageLimitError","message":"Monthly usage limit reached. Resets in N days. ...","metadata":{"workspace":"wrk_...","limitName":"monthly"}}}` (verificado sep-2026). Se puede esperar el reset, activar **Use balance** en la consola para caer al saldo pay-as-you-go de Zen (debe tener fondos), o usar el cliente oficial de OpenCode.

## Privacidad (por modelo)

| Modelo | ¿Entrena con tu data? | Retención |
|---|---|---|
| Grok 4.6 | No | 30 días |
| GPT 5.6 Luna | No | 30 días (abuse monitoring) |
| **Muse Spark 1.3 / 1.2 Contributor** | **SÍ** | **Not ZDR** |
| GLM / Kimi / LongCat / MiMo / MiniMax / Qwen / Hy / Union Alpha | No | 0 días |
| DeepSeek V4.x | No | 0 días (acuerdo renovado mensual) |

Disponibilidad de Muse Spark limitada por la [Geographic Use Policy](https://ai.developer.meta.com/legal/geographic-use-policy) de Meta.
