# OpenCode Zen — modelos y endpoints

- Base URL: `https://opencode.ai/zen/v1`
- Pay-as-you-go: cargás créditos y se cobra por request. **Auto-reload** de $20 cuando el saldo baja de $5 (configurable/desactivable).
- Lista viva: `GET https://opencode.ai/zen/v1/models`.
- No requiere `x-opencode-session` (eso es sólo Go), aunque enviarlo no rompe.

## Modelo → endpoint

| Endpoint | Modelos (model IDs) |
|---|---|
| `/responses` | `gpt-6-astra`, `gpt-5.6-sol`, `gpt-5.6-terra`, `gpt-5.6-luna`, `gpt-5.5`, `gpt-5.5-pro`, `gpt-5.4`, `gpt-5.4-pro`, `gpt-5.4-mini`, `gpt-5.4-nano`, `gpt-5.3-codex`, `gpt-5.3-codex-spark`, `gpt-5.2`, `gpt-5.2-codex`, `gpt-5.1`, `gpt-5.1-codex`, `gpt-5.1-codex-max`, `gpt-5.1-codex-mini`, `gpt-5`, `gpt-5-codex`, `gpt-5-nano`, `grok-4.6`, `grok-4.5`, `grok-build-0.1`, `muse-spark-1.3`, `muse-spark-1.2`, `muse-spark-1.3-contributor-free` |
| `/messages` | `claude-fable-5-1`, `claude-fable-5`, `claude-opus-5`, `claude-opus-4-8`, `claude-opus-4-7`, `claude-opus-4-6`, `claude-opus-4-5`, `claude-sonnet-5`, `claude-sonnet-4-6`, `claude-sonnet-4-5`, `claude-haiku-4-5`, `qwen3.7-max`, `qwen3.7-plus`, `qwen3.6-plus`, `qwen3.5-plus`, `union-alpha` |
| `/chat/completions` | `deepseek-v4-pro`, `deepseek-v4-flash`, `deepseek-v4-flash-vision-exp`, `minimax-m3`, `minimax-m2.7`, `minimax-m2.5`, `glm-5.3-flash`, `glm-5.3`, `glm-5.2`, `glm-5.1`, `glm-5`, `kimi-k2.5`, `kimi-k2.6`, `kimi-k2.7-code`, `kimi-k3`, `big-pickle`, `mimo-v2.5-free`, `ling-3.0-flash-fin-free`, `nemotron-3-ultra-free`, `nemotron-3.5-lightning-free` |
| `/models/<model-id>` (Google `@ai-sdk/google`) | `gemini-3.8-flash`, `gemini-3.7-flash`, `gemini-3.6-flash`, `gemini-3.5-flash`, `gemini-3.5-flash-lite`, `gemini-3.1-pro`, `gemini-3-flash` |

Config de OpenCode (no de tu app): el id se referencia como `opencode/<model-id>`.

> Diferencias importantes vs Go: en Zen, **MiniMax y Qwen van por `/chat/completions` y `/messages` respectivamente según la tabla** (no asumas), y existen modelos `-free`.

## Precios (USD por 1M tokens)

| Modelo | Input | Output | Cached read | Cached write |
|---|---|---|---|---|
| Big Pickle / Union Alpha Free (stealth, free por tiempo limitado desde 16-sep-2026) / MiMo-V2.5 Free / Ling 3.0 Flash Fin Free / Nemotron 3 Ultra Free / Nemotron 3.5 Lightning Free / Muse Spark 1.3 Contributor Free | Free | Free | Free | — |
| MiniMax M3 / M2.7 / M2.5 | $0.30 | $1.20 | $0.06 | — / $0.375 |
| GLM 5.3 Flash | $0.15 | $0.50 | $0.03 | — |
| GLM 5.3 / 5.2 / 5.1 | $1.40 | $4.40 | $0.26 | — |
| GLM 5 | $1.00 | $3.20 | $0.20 | — |
| Kimi K2.7 Code | $0.95 | $4.00 | $0.19 | — |
| Kimi K3 | $3.00 | $15.00 | $0.30 | — |
| Kimi K2.6 / K2.5 | $0.95 / $0.60 | $4.00 / $3.00 | $0.16 / $0.10 | — |
| Qwen3.7 Max | $2.50 | $7.50 | $0.50 | $3.125 |
| Qwen3.7 Plus | $0.40 | $1.60 | $0.04 | $0.50 |
| Qwen3.6 Plus | $0.50 | $3.00 | $0.05 | $0.625 |
| Qwen3.5 Plus | $0.20 | $1.20 | $0.02 | $0.25 |
| DeepSeek V4 Pro | $1.74 | $3.48 | $0.145 | — |
| DeepSeek V4 Flash / V4 Flash Vision Exp | $0.14 | $0.28 | $0.028 | — |
| Claude Fable 5.1 | $10.00 | $50.00 | $0.25 | $12.50 |
| Claude Fable 5 | $10.00 | $50.00 | $1.00 | $12.50 |
| Claude Opus 5 / 4.8 / 4.7 / 4.6 / 4.5 | $5.00 | $25.00 | $0.50 | $6.25 |
| Claude Sonnet 5 | $2.00 | $10.00 | $0.20 | $2.50 |
| Claude Sonnet 4.6 | $3.00 | $15.00 | $0.30 | $3.75 |
| Claude Sonnet 4.5 (≤200K / >200K) | $3.00 / $6.00 | $15.00 / $22.50 | $0.30 / $0.60 | $3.75 / $7.50 |
| Claude Haiku 4.5 | $1.00 | $5.00 | $0.10 | $1.25 |
| Gemini 3.8 / 3.7 / 3.6 Flash | $1.50 | $7.50 | $0.15 | — |
| Gemini 3.5 Flash | $1.50 | $9.00 | $0.15 | — |
| Gemini 3.5 Flash Lite | $0.30 | $2.50 | $0.03 | — |
| Gemini 3.1 Pro (≤200K / >200K) | $2.00 / $4.00 | $12.00 / $18.00 | $0.20 / $0.40 | — |
| Gemini 3 Flash | $0.50 | $3.00 | $0.05 | — |
| Grok 4.6 (≤200K / >200K) | $2.00 / $4.00 | $6.00 / $12.00 | $0.50 / $1.00 | — |
| Grok 4.5 (≤200K / >200K) | $2.00 / $4.00 | $6.00 / $12.00 | $0.30 / $0.60 | — |
| Grok Build 0.1 | $1.00 | $2.00 | $0.20 | — |
| Muse Spark 1.3 / 1.2 | $1.25 | $4.25 | $0.15 | — |
| GPT 6 Astra (≤272K / >272K) | $10.00 / $20.00 | $50.00 / $75.00 | $1.00 / $2.00 | $12.50 / $25.00 |
| GPT 5.6 Sol (≤272K / >272K) | $4.00 / $8.00 | $20.00 / $30.00 | $0.40 / $0.80 | $5.00 / $10.00 |
| GPT 5.6 Terra (≤272K / >272K) | $2.00 / $4.00 | $12.00 / $18.00 | $0.20 / $0.40 | $2.50 / $5.00 |
| GPT 5.6 Luna (≤272K / >272K) | $0.20 / $0.40 | $1.20 / $1.80 | $0.02 / $0.04 | $0.25 / $0.50 |
| GPT 5.5 (≤272K / >272K) | $5.00 / $10.00 | $30.00 / $45.00 | $0.50 / $1.00 | — |
| GPT 5.5 Pro / GPT 5.4 Pro | $30.00 | $180.00 | $30.00 | — |
| GPT 5.4 (≤272K / >272K) | $2.50 / $5.00 | $15.00 / $22.50 | $0.25 / $0.50 | — |
| GPT 5.4 Mini | $0.75 | $4.50 | $0.075 | — |
| GPT 5.4 Nano | $0.20 | $1.25 | $0.02 | — |
| GPT 5.3 Codex / GPT 5.2 / 5.2 Codex | $1.75 | $14.00 | $0.175 | — |
| GPT 5.1 / GPT 5 / GPT 5 Codex | $1.07 | $8.50 | $0.107 | — |
| GPT 5.1 Codex Max | $1.25 | $10.00 | $0.125 | — |
| GPT 5.1 Codex Mini | $0.25 | $2.00 | $0.025 | — |
| GPT 5 Nano | $0.05 | $0.40 | $0.005 | — |

Comisión de tarjeta al costo: 4.4% + $0.30 por transacción.

> **Clientes externos y modelos `-free` (verificado sep-2026):** una cuenta sin saldo recibe `403 {"type":"error","error":{"type":"FreeTierError","message":"... free tier can only be used from within OpenCode"}}` en los modelos `-free`; para consumir la API desde tu app cargá créditos Zen (modelos pagos) o usá Go. Además, `GET /models` devuelve sólo lo habilitado para tu cuenta (sin saldo: free + modelos de Go), no el catálogo completo de estas tablas.

## Privacidad

Los modelos se hostean en EE.UU. y por defecto los proveedores son **zero-retention** (no entrenan con tu data), **con estas excepciones**:

- **Big Pickle, MiMo-V2.5 Free, Ling 3.0 Flash Fin Free** — data usada para mejorar el modelo.
- **Nemotron 3 Ultra Free / 3.5 Lightning Free (NVIDIA)** — trial; uso loggeado, datos no ligados a identidad pero **no enviar datos personales/confidenciales**.
- **Muse Spark 1.3 Contributor Free** — prompts/completions usados para entrenar modelos futuros de Meta.
- **OpenAI** — retención 30 días. **Anthropic** — retención 30 días.

Podés deshabilitar modelos a nivel workspace (Admin) para bloquear los que colectan data.

## Deprecados (no usar en código nuevo)

GPT 5.2 Codex / 5.1 Codex / 5.1 Codex Max / 5.1 Codex Mini / 5 Codex (jul-2026), Claude Opus 4.1 (ago-2026), Claude Sonnet 4 (jun-2026), Claude Haiku 3.5 (feb-2026), Gemini 3 Pro (mar-2026), MiniMax M2.5 (ago-2026)/M2.1 (mar-2026), GLM 5 (may-2026)/4.7/4.6 (mar-2026), Kimi K2.5 (ago-2026), Kimi K2 Thinking/K2 (mar-2026), Qwen3 Coder 480B (feb-2026). Verificá `GET /models` antes de fijar un id.
