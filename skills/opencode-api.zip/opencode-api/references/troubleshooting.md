# OpenCode API — troubleshooting

Catálogo de errores observados y documentados, con causa y fix. El formato de error del gateway suele ser:

```json
{"type":"error","error":{"type":"invalid_request_error","message":"...","param":"..."}}
```

El detalle real del upstream a veces viene anidado:
`"Error from provider (Console Go): Upstream request failed: [invalid_request_error] ... param:input_text type:invalid_request_error"`.

## Errores de endpoint / modelo

| Error | Causa | Fix |
|---|---|---|
| `{"error":{"message":"Internal server error"}}` | le pegaste a `/chat/completions` con un modelo que vive en `/responses` (o viceversa) | usá el endpoint exacto de `go-models.md`/`zen-models.md`; confirmá con `GET /models` |
| `model not found` / `400` | id mal escrito o modelo deprecado | ids son case-sensitive y con guiones (`muse-spark-1.3-contributor`, no `Muse Spark 1.3`) |
| `401` / `invalid_request_error` sin message | falta `Authorization: Bearer` o key inválida | key `sk-...` en env, no hardcodeada |
| `401 {"type":"error","error":{"type":"AuthError","message":"Missing API key."}}` en `/messages` | ese endpoint es Anthropic-compatible y no lee `Authorization: Bearer` | mandá `x-api-key: sk-...` (sólo `/messages`) |

## Errores de sesión (OpenCode Go)

| Error | Causa | Fix |
|---|---|---|
| `{"type":"MissingSessionID","message":"... missing x-opencode-session and cannot be routed efficiently"}` | falta el header en Go | `x-opencode-session: <id estable por conversación>` |
| routing/caching pobre, `cached_tokens: 0` | session id cambia por request, o User-Agent genérico | un id por conversación + `User-Agent` propio |

## Errores de la Responses API

| Error | Causa | Fix |
|---|---|---|
| `content type 'input_text' is not valid on 'assistant' messages param:input_text` | replays de assistant con tipo de user | usá `output_text` en mensajes `assistant` |
| `400 param:"input"` junto a un reasoning item | reasoning no seguido de assistant/function_call antes del próximo user | respetá el orden; insertá un assistant mínimo si el turno fue reasoning-only |
| `400` al enviar `include` + `previous_response_id` | combinación prohibida | elegí stateless (`store:false`+`include`) **o** `previous_response_id` |
| `Referenced reasoning item ... was not found or has expired` | reenviaste un `rs_` id sin `encrypted_content` y sin `store` | incluí `encrypted_content` (pideal con `include`) |
| `output: []`, `status:"incomplete"`, `incomplete_details.reason:"max_output_tokens"` | el razonamiento consumió todo el budget | subí `max_output_tokens` (cubre reasoning + salida) |
| `400` con `reasoning.effort:"none"` | Muse Spark no soporta `none` | usá `minimal`/`low`/`medium`/`high`/`xhigh` |
| `400` con `reasoning.effort:"max"` en Contributor | `max` sólo existe en Muse Spark standard | bajá a `xhigh` |
| `400 param:"call_id"` | `function_call_output.call_id` no matchea ningún `function_call`, o mide 0/`>64` chars | copiá el `call_id` del `function_call`; respetá 1–64 chars |
| `400` al reenviar tool calls viejas | falta el `function_call` completo antes del `function_call_output`, o desorden de results | reenviá el item `function_call` íntegro y mantené el orden de los calls |
| `400` por `phase` | texto intermedio antes de un tool call reenviado como final answer | marcá los intermedios con `phase:"commentary"` |
| `504 gateway_timeout` | request no-streaming demasiado largo | `stream:true` (streaming está exento del tope) |
| `400 param:"include"` | valor desconocido en `include` | los valores válidos espejan OpenAI (`reasoning.encrypted_content`, `message.output_text.logprobs`→no soportado) |
| `400` por `logprobs` | Muse Spark es reasoning model | no pidas logprobs |
| `413 payload_too_large` (background) | body > 1 MiB en `background:true` | referenciá media por `file_id` (Files API) |
| `404` al recuperar/chainedear una respuesta recién completada | lag de persistencia | reintentá 1–2 veces con backoff |

## Errores de cuenta / límites

| Error | Causa | Fix |
|---|---|---|
| `403 {"type":"error","error":{"type":"FreeTierError","message":"... free tier can only be used from within OpenCode"}}` | cliente externo con cuenta sin saldo, usando modelos `-free` | cargá saldo Zen o usá Go con cupo; los `-free` son sólo del cliente oficial |
| `401 {"type":"error","error":{"type":"CreditsError","message":"Insufficient balance..."}}` | saldo Zen agotado en un modelo pago | cargar créditos o usar Go |
| `429 {"type":"error","error":{"type":"GoUsageLimitError","message":"Monthly usage limit reached. Resets in N days. ...","metadata":{"limitName":"monthly"}}}` | cupo Go agotado (del modelo o del workspace) | esperar el reset, activar **Use balance**, o usar modelos no-Go |

## Errores de transporte / infra (típicos al integrar)

| Síntoma | Causa | Fix |
|---|---|---|
| El front dice "problema de conexión" pero la API anda por curl | URL del backend hardcodeada (`localhost`) o CORS | apuntá a la URL pública; `Access-Control-Allow-Origin` correcto |
| La request se corta a los ~60s | `proxy_read_timeout` de nginx (default 60s) | subilo (ej. `proxy_read_timeout 300s`) en el location del API |
| Timeout en el cliente durante agent loops | el loop puede hacer varias llamadas al modelo | timeout del cliente holgado (≥ 240s) |
| Rate limit | límites de Go (5h/semana/mes por modelo o del workspace) o del proveedor | monitorear `console.opencode.ai`; activar *Use balance* o esperar el reset (los `-free` no sirven desde clientes externos) |

## Cómo diagnosticar rápido

1. `GET {base}/models` → ¿existe el id?
2. ¿El endpoint coincide con la tabla de la superficie?
3. Reproducí con `curl` mínimo (sin tu app) para aislar.
4. Si es Go, ¿mandaste `x-opencode-session`?
5. ¿El body es válido para el protocolo? (assistant→`output_text`, `tool_choice:"auto"`, sin `logprobs`).
6. Logueá el error completo del gateway: casi siempre el `message` final tiene el `param` exacto.
