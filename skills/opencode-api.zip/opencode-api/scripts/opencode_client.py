#!/usr/bin/env python3
"""Minimal, dependency-free client for the OpenCode API (Go + Zen).

Covers the three protocols and a full tool-calling loop on the Responses API
(stateless encrypted reasoning replay: store=false + include=reasoning.encrypted_content).

Auth: `Authorization: Bearer` for /chat/completions and /responses;
      `x-api-key` for /messages (Anthropic-compatible).
Note: `-free` models are restricted to the official OpenCode client
      (external clients get 403 FreeTierError); use Go or a Zen balance.

Usage:
    export OPENCODE_API_KEY=sk-...
    export OPENCODE_SESSION=$(uuidgen)          # stable per conversation (required by Go)
    python opencode_client.py chat  "deepseek-v4-flash"  "Hola"
    python opencode_client.py resp  "muse-spark-1.3-contributor"  "Hola"
    python opencode_client.py tools "muse-spark-1.3-contributor"  "Cuanto es 7+5? usa sumar"

    # Other surface:
    OPENCODE_BASE=https://opencode.ai/zen/v1 python opencode_client.py resp muse-spark-1.3 "..."
"""
from __future__ import annotations

import json
import os
import sys
import urllib.request

BASE = os.environ.get("OPENCODE_BASE", "https://opencode.ai/zen/go/v1")
KEY = os.environ.get("OPENCODE_API_KEY", "")
SESSION = os.environ.get("OPENCODE_SESSION", "opencode-client")

# Model -> protocol path. Keep this in sync with references/{go,zen}-models.md.
# Unknown models default to /chat/completions; override with OPENCODE_PATH.
PATHS = {
    # Responses API
    "muse-spark-1.3-contributor": "/responses",
    "muse-spark-1.2-contributor": "/responses",
    "muse-spark-1.3": "/responses",
    "gpt-6-astra": "/responses",
    "gpt-5.6-luna": "/responses",
    "grok-4.6": "/responses",
    # Messages API (Anthropic; auth via x-api-key)
    "minimax-m3": "/messages",
    "qwen3.8-max": "/messages",
    "qwen3.8-flash": "/messages",
    "claude-sonnet-5": "/messages",
    "claude-haiku-4-5": "/messages",
    # Chat Completions
    "deepseek-v4-flash": "/chat/completions",
    "deepseek-v4-pro": "/chat/completions",
    "glm-5.3-flash": "/chat/completions",
    "glm-5.2": "/chat/completions",
    "kimi-k3": "/chat/completions",
    "longcat-2.0": "/chat/completions",
    "hy3": "/chat/completions",
}


def _post(path: str, body: dict, stream: bool = False):
    headers = {
        "Content-Type": "application/json",
        "x-opencode-session": SESSION,
        "User-Agent": "opencode-api-skill/1.0",
    }
    # /messages is Anthropic-compatible: it reads x-api-key, not Bearer.
    if path.startswith("/messages"):
        headers["x-api-key"] = KEY
    else:
        headers["Authorization"] = "Bearer " + KEY
    if stream:
        headers["Accept"] = "text/event-stream"
    req = urllib.request.Request(
        BASE.rstrip("/") + path,
        data=json.dumps(body).encode(),
        headers=headers,
    )
    resp = urllib.request.urlopen(req, timeout=300)
    if stream:
        return resp
    data = json.load(resp)
    if isinstance(data.get("error"), dict) and data["error"]:
        raise RuntimeError("provider error: " + json.dumps(data["error"]))
    return data


def _path_for(model: str) -> str:
    return os.environ.get("OPENCODE_PATH") or PATHS.get(model, "/chat/completions")


# ---------------------------------------------------------------- chat completions
def chat(model: str, prompt: str, system: str | None = None) -> str:
    msgs = ([{"role": "system", "content": system}] if system else []) + [
        {"role": "user", "content": prompt}
    ]
    data = _post("/chat/completions", {"model": model, "messages": msgs, "max_tokens": 2048})
    return data["choices"][0]["message"]["content"] or ""


# ---------------------------------------------------------------- messages (Anthropic)
def messages(model: str, prompt: str, system: str | None = None) -> str:
    body = {"model": model, "max_tokens": 2048, "messages": [{"role": "user", "content": prompt}]}
    if system:
        body["system"] = system
    data = _post("/messages", body)
    return "".join(b.get("text", "") for b in data.get("content", []))


# ---------------------------------------------------------------- responses
def responses_text(model: str, prompt: str, instructions: str | None = None) -> str:
    body = {
        "model": model,
        "input": prompt,
        "instructions": instructions or "Sos un asistente útil.",
        "max_output_tokens": 4096,
        "reasoning": {"effort": "low"},
        "store": False,
        "include": ["reasoning.encrypted_content"],
        "prompt_cache_key": SESSION,
    }
    return extract_text(_post("/responses", body))


def extract_text(data: dict) -> str:
    parts = []
    for item in data.get("output", []):
        if item.get("type") == "message":
            for c in item.get("content", []):
                if c.get("text"):
                    parts.append(c["text"])
    return "\n".join(parts)


# ---------------------------------------------------------------- tool loop
def run_tool_loop(
    model: str,
    prompt: str,
    tools: list[dict],
    executors: dict,
    instructions: str | None = None,
    max_rounds: int = 8,
) -> str:
    """Responses API tool-calling loop with stateless reasoning replay.

    `tools` are flat Responses definitions; `executors` maps name -> callable(args)->dict.
    """
    body_base = {
        "model": model,
        "instructions": instructions or "Usá las herramientas cuando hagan falta.",
        "tools": tools,
        "max_output_tokens": 16384,
        "reasoning": {"effort": "low"},
        "store": False,
        "include": ["reasoning.encrypted_content"],
        "prompt_cache_key": SESSION,
    }
    user_item = {"role": "user", "content": [{"type": "input_text", "text": prompt}]}
    inp: list = [user_item]

    for _ in range(max_rounds):
        data = _post("/responses", {**body_base, "input": inp})
        out = data.get("output", [])
        calls = [o for o in out if o.get("type") == "function_call"]
        if not calls:
            return extract_text(data) or json.dumps(data)[:500]
        # echo the whole output (reasoning + message + function_call) then the results
        inp = inp + out
        for call in calls:
            args = json.loads(call.get("arguments") or "{}")
            try:
                result = executors[call["name"]](**args)
            except Exception as exc:  # surface tool errors back to the model
                result = {"error": str(exc)}
            inp.append(
                {
                    "type": "function_call_output",
                    "call_id": call["call_id"],
                    "output": json.dumps(result),
                }
            )
    raise RuntimeError(f"exceeded max tool rounds ({max_rounds})")


# ---------------------------------------------------------------- streaming
def _stream_body(path: str, model: str, prompt: str) -> dict:
    if path.startswith("/messages"):
        return {
            "model": model,
            "max_tokens": 4096,
            "stream": True,
            "messages": [{"role": "user", "content": prompt}],
        }
    if path == "/responses":
        return {"model": model, "input": prompt, "stream": True, "max_output_tokens": 4096}
    return {
        "model": model,
        "stream": True,
        "max_tokens": 4096,
        "messages": [{"role": "user", "content": prompt}],
    }


def stream(model: str, prompt: str) -> None:
    path = _path_for(model)
    resp = _post(path, _stream_body(path, model, prompt), stream=True)
    for raw in resp:
        line = raw.decode("utf-8", "replace").strip()
        if not line.startswith("data: "):
            continue
        chunk = line[6:]
        if chunk == "[DONE]":
            break
        try:
            ev = json.loads(chunk)
        except json.JSONDecodeError:
            continue
        if ev.get("type") == "response.output_text.delta":          # Responses
            print(ev.get("delta", ""), end="", flush=True)
        elif ev.get("type") == "content_block_delta":               # Messages
            print(ev.get("delta", {}).get("text", ""), end="", flush=True)
        else:                                                       # Chat Completions
            for choice in ev.get("choices", []):
                print(choice.get("delta", {}).get("content") or "", end="", flush=True)
    print()


# ---------------------------------------------------------------- demo tools
def _sumar(a: float, b: float) -> dict:
    return {"resultado": a + b}


DEMO_TOOLS = [
    {
        "type": "function",
        "name": "sumar",
        "description": "Suma dos números",
        "parameters": {
            "type": "object",
            "properties": {"a": {"type": "number"}, "b": {"type": "number"}},
            "required": ["a", "b"],
        },
    }
]


def main() -> int:
    if not KEY:
        print("Falta OPENCODE_API_KEY", file=sys.stderr)
        return 2
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    mode, model, *rest = sys.argv[1:]
    prompt = rest[0] if rest else "Hola"
    if mode == "chat":
        print(chat(model, prompt))
    elif mode == "messages":
        print(messages(model, prompt))
    elif mode == "resp":
        print(responses_text(model, prompt))
    elif mode == "tools":
        print(run_tool_loop(model, prompt, DEMO_TOOLS, {"sumar": _sumar}))
    elif mode == "stream":
        stream(model, prompt)
    else:
        print(f"modo desconocido: {mode}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
