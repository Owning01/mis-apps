# Recetas Canónicas de Modelado NoSQL para Consumo Mínimo de Cuota

En bases de datos NoSQL como Firestore, **el modelo de datos determina directamente tu factura o el consumo de tu cuota diaria**. Un mal diseño relacional trasladado a Firestore destruye el Spark Plan en minutos.

---

## Receta 1: Sistema de Likes y Reacciones (Social Feed)

### ❌ Antipatrón Ingenuo:
Guardar un array de UIDs en el documento del post:
```json
{
  "title": "Mi post",
  "likedBy": ["uid1", "uid2", "uid3", "... 20,000 uids"]
}
```
*Problema:* Si llega a 20,000 likes, el documento supera el límite de 1 MB, explota en ancho de banda al leerlo y genera contención de escritura brutal.

### ✅ Patrón Óptimo (Contador Atómico + Subcolección de Registro):
1. **En el documento del post (`/posts/{postId}`):**
   ```typescript
   {
     "title": "Mi post",
     "likesCount": 1420 // Se incrementa con FieldValue.increment(1) -> 0 lecturas previas
   }
   ```
2. **Registro individual de autoría (`/posts/{postId}/likes/{userId}`):**
   ```typescript
   // El docId es el userId del usuario
   {
     "createdAt": serverTimestamp()
   }
   ```
3. **Comprobar si el usuario actual ya dio like (1 lectura ultra-específica):**
   ```typescript
   const myLikeDoc = await getDocFromCache(doc(db, "posts", postId, "likes", currentUserId))
     .catch(() => getDoc(doc(db, "posts", postId, "likes", currentUserId)));
   const hasLiked = myLikeDoc.exists();
   ```
4. **Acción de dar Like:**
   ```typescript
   const batch = writeBatch(db);
   batch.set(doc(db, "posts", postId, "likes", currentUserId), { createdAt: serverTimestamp() });
   batch.update(doc(db, "posts", postId), { likesCount: increment(1) });
   await batch.commit(); // 1 sola transacción atómica
   ```

---

## Receta 2: Feed de Actividad / Timeline (Twitter/Instagram Style)

### Estrategia: Fan-out on Read vs Fan-out on Write

| Enfoque | Cómo funciona | Costo en Cuota Spark | ¿Cuándo usar? |
|---|---|---|---|
| **Fan-out on Write** | Al publicar, se escribe una copia del post en el feed de cada seguidor. | ❌ Destruye las 20k escrituras/día si un usuario tiene muchos seguidores. | **Prohibido en Spark Plan** para usuarios con >10 seguidores. |
| **Fan-out on Read con Cache & Bundles** | Al abrir la app, se leen los posts de los usuarios seguidos (`where('authorId', 'in', followIds)`). | ✅ Máximo 10-30 lecturas por página. | **Recomendado en Spark Plan**. |

### Implementación Óptima en Spark Plan:
- Agrupar seguidos en bloques de hasta 30 (`where in` soporta hasta 30 elementos por query).
- Paginación estricta con `limit(15)`.
- Si el usuario sigue a más de 30 personas, se mantiene una subcolección de `feedItems` poblada únicamente para los últimos 50 eventos globales.

---

## Receta 3: Catálogo de Productos con Búsqueda Multifacética

Firestore **no es un motor de búsqueda full-text**. Hacer queries con múltiples `where` y rangos genera cobros desmedidos e índices compuestos pesados.

### ✅ Patrón: Categorías Indexadas + Bundle Estático para Filtros
1. Para catálogos de menos de 10,000 productos:
   - Exporta el catálogo como **Firestore Bundle** o JSON estático alojado en Firebase Hosting / Cloud Storage.
   - El cliente descarga el archivo comprimido (ej. 150 KB gzipped) **una sola vez al día** (0 lecturas de Firestore).
   - Las búsquedas, filtros por precio, tallas y ordenamiento se resuelven en memoria del cliente con JavaScript/Dart (filtrado instantáneo, 0 ms latencia, $0 costo).
2. Para inventarios dinámicos (stock en vivo):
   - Solo se consulta a Firestore el stock puntual del producto al momento de añadirlo al carrito (`/products/{id}/stock/live`).

---

## Receta 4: Chat Grupal con Mensajes No Leídos

### ❌ Antipatrón:
Consultar `where('read', '==', false)` en toda la colección de mensajes para calcular la insignia de no leídos.
*Gasto:* 50 mensajes no leídos = 50 lecturas cada vez que entra a la lista de chats.

### ✅ Patrón: Cursor de Última Lectura en el Participante
1. Documento del chat (`/chats/{chatId}`):
   ```typescript
   {
     "lastMessage": "Hola, ¿cómo estás?",
     "lastMessageNumber": 450, // Secuencia autoincremental
     "updatedAt": serverTimestamp()
   }
   ```
2. Documento de membresía (`/chats/{chatId}/members/{userId}`):
   ```typescript
   {
     "lastReadMessageNumber": 442
   }
   ```
3. **Cálculo de no leídos (Costo: 0 lecturas adicionales):**
   ```text
   unreadCount = chat.lastMessageNumber - member.lastReadMessageNumber; // 450 - 442 = 8 no leídos
   ```
   ¡Se calcula con una simple resta aritmética sin leer ningún mensaje individual!

---

## Receta 5: Carrito de Compras Transaccional

### ✅ Patrón: Documento Único con Mapa Consolidado
En lugar de crear un documento por cada item del carrito:
```typescript
// /users/{userId}/cart/current
{
  "updatedAt": serverTimestamp(),
  "items": {
    "prod_abc": { "qty": 2, "priceSnapshot": 29.99, "title": "Remera Negra" },
    "prod_xyz": { "qty": 1, "priceSnapshot": 49.99, "title": "Pantalón Denim" }
  },
  "totalQty": 3,
  "estimatedSubtotal": 109.97
}
```
- Modificar una cantidad: `updateDoc(cartRef, { "items.prod_abc.qty": 3, "totalQty": increment(1) })`.
- Leer el carrito entero cuesta **exactamente 1 lectura**, sin importar si tiene 1 o 50 productos.
