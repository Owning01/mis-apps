# Optimización de Realtime Database, Cloud Storage y Cloud Functions

Mientras que Firestore cobra por **operaciones (lecturas/escrituras)**, otros servicios del ecosistema Firebase cobran principalmente por **ancho de banda (egress)** y **tiempo de cómputo**.

---

## 1. Realtime Database (RTDB): El Arma Secreta de Alta Frecuencia

> [!TIP]
> **Diferencia Fundamental de Facturación:**
> - **Firestore:** Cobra por cada documento leído o escrito (\$0 tras superar 50k reads / 20k writes diarios).
> - **Realtime Database:** **¡No cobra por número de operaciones!** Cobra únicamente por **ancho de banda de descarga (Egress)** y almacenamiento (10 GB/mes gratis en Spark).

### Cuándo usar RTDB en lugar de Firestore:

| Caso de Uso | En Firestore | En Realtime Database | Elección Ganadora |
|---|---|---|---|
| **Presencia online (User Online/Offline)** | 1,000 usuarios cambiando estado = miles de writes/reads. Agota la cuota diaria en 1 hora. | Miles de eventos de presencia con payloads de 20 bytes = pocos kilobytes de red. | 🏆 **RTDB** (`.info/connected` + `onDisconnect`) |
| **Indicadores de "Escribiendo..." (Typing...)** | Escribir en Firestore cada tecla = colapso instantáneo de cuotas. | Inapreciable en ancho de banda. | 🏆 **RTDB** |
| **GPS / Posición en tiempo real (Delivery/Tracking)** | 100 repartidores enviando lat/lng cada 2 segundos = 180,000 escrituras/hora (supera el límite diario de Spark en 6 minutos). | Solo transfiere 40 bytes por paquete. Pasa inadvertido en los 10 GB mensuales. | 🏆 **RTDB** |
| **Consultas complejas, filtros y paginación** | Excelente indexación y consultas compuestas. | Muy limitado; tiende a descargar ramas completas si no se diseña bien. | 🏆 **Firestore** |

### Reglas Críticas para RTDB:
1. **Nunca escuchar la raíz (`ref('/')`):** Descargará todo el árbol JSON consumiendo los 10 GB de red en minutos.
2. **Definir `.indexOn` obligatorio:**
   ```json
   {
     "rules": {
       "locations": {
         ".indexOn": ["timestamp", "driverId"]
       }
     }
   }
   ```
   Sin `.indexOn`, Firebase descarga todos los nodos al cliente para ordenarlos en local.

---

## 2. Cloud Storage: Cómo Vivir dentro de 1 GB / Día

El límite del Spark Plan en Storage es de **1 GB de descarga diaria** y 5 GB de almacenamiento total. Si tus usuarios suben fotos de cámara de 4 MB directamente, con 250 descargas diarias agotas la cuota de toda la app.

### A. Compresión Obligatoria en el Cliente (Antes de Subir)
Nunca permitas que el cliente suba la foto cruda (`image/jpeg` de 3–8 MB). Comprímela en el navegador o en la app móvil a formato **WebP**:

```typescript
// En Web (Browser Canvas API - 0 dependencias pesadas):
async function compressImageToWebP(file: File, maxWidth = 1200, quality = 0.8): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.src = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(maxWidth / img.width, 1);
      const canvas = document.createElement("canvas");
      canvas.width = img.width * scale;
      canvas.height = img.height * scale;
      const ctx = canvas.getContext("2d");
      ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
      
      canvas.toBlob((blob) => {
        if (blob) resolve(blob);
        else reject(new Error("Error al comprimir imagen"));
      }, "image/webp", quality);
    };
    img.onerror = reject;
  });
}
```
*Impacto:* Una foto de 4.8 MB se reduce a **~120 KB (97.5% de ahorro en almacenamiento y ancho de banda)**.

---

### B. Headers de Caché Inmutables (`Cache-Control`)
Al subir archivos estáticos (avatares, imágenes de publicaciones), define headers HTTP para que el navegador del usuario almacene la imagen en caché durante 1 año:

```typescript
import { ref, uploadBytes } from "firebase/storage";

const storageRef = ref(storage, `avatars/${userId}.webp`);
const metadata = {
  contentType: "image/webp",
  cacheControl: "public, max-age=31536000, immutable" // Cachea en navegador por 1 año
};

await uploadBytes(storageRef, compressedBlob, metadata);
```
*Sin este header, cada vez que un usuario recarga la página, vuelve a descargar la imagen desde Storage consumiendo cuota diaria.*

---

### C. Placeholders Ultraligeros (BlurHash / ThumbHash)
Guarda un string de 30 caracteres en el documento de Firestore representando una versión borrosa de la imagen. El usuario ve la previsualización al instante sin descargar nada de Storage, y la imagen real solo se descarga cuando hace scroll y entra en el viewport (`loading="lazy"`).

---

## 3. Cloud Functions (2nd Gen / Cloud Run)

La cuota gratuita incluye **2,000,000 de invocaciones/mes** y **400,000 GB-segundos**.

### Reglas de Optimización de Costos:
1. **Configurar Min Instances = 0:**
   Mantén `minInstances: 0`. Pagarás unos milisegundos de cold-start al inicio, pero no pagarás \$0.00 en reposo.
2. **Ajustar Memoria al Mínimo Viable (128 MB / 256 MB):**
   Las funciones por defecto suelen reservarse con 256 MB o 512 MB. Si tu función solo parsea un webhook simple, configúrala con 128 MB o 256 MB para maximizar los GB-segundos gratuitos.
3. **Caché CDN en Funciones HTTP:**
   Si una Cloud Function genera datos compartidos (ej. feed público o sitemap), usa los headers de Firebase Hosting CDN:
   ```typescript
   export const getPublicCatalog = onRequest((req, res) => {
     res.set("Cache-Control", "public, max-age=600, s-maxage=3600");
     res.json(data);
   });
   ```
   Firebase Hosting servirá la respuesta desde sus servidores perimetrales (CDN de Google), **ejecutando la Cloud Function solo 1 vez por hora**.
4. **Blindaje contra Bucles Infinitos:**
   Una función disparada por `onDocumentWritten('/items/{id}')` que dentro hace `updateDoc('/items/{id}')` generará un bucle infinito que quemará 2 millones de ejecuciones en minutos. **Verifica siempre los datos antes de escribir:**
   ```typescript
   if (change.after.data().status === change.before.data().status) {
     return; // No mutó el campo de interés, abortar de inmediato
   }
   ```
