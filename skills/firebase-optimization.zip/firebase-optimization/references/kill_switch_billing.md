# Kill-Switch Automático de Facturación (Presupuesto Cero en Blaze)

> [!CAUTION]
> En Firebase, activar el plan **Blaze** (de pago por uso) es requerido para ciertas funcionalidades (como llamadas HTTP externas en Cloud Functions o integraciones avanzadas de GCP).
> Sin embargo, **por defecto Google Cloud no apaga tus servicios cuando se supera el presupuesto**. Solo envía correos de advertencia.
> Para garantizar que tu factura jamás supere un límite estricto (ej. \$1.00 o \$5.00), debes implementar un **Kill-Switch automatizado**.

---

## Cómo Funciona el Kill-Switch

```text
[ Presupuesto GCP ($1.00 USD) ]
             │
             ▼ Al alcanzar el 100%
   [ Cloud Pub/Sub Topic ]
             │
             ▼ Notificación en tiempo real
 [ Cloud Function Kill-Switch ]
             │
             ▼ Ejecuta Cloud Billing API
 [ Desvincula la Cuenta de Facturación del Proyecto ]
             │
             ▼
[ La app frena el gasto de inmediato. $0 cobro extra ]
```

---

## Paso 1: Habilitar la Cloud Billing API

En Google Cloud Console:
1. Ve a **APIs & Services > Library**.
2. Busca **Cloud Billing API** y haz clic en **Enable**.

---

## Paso 2: Crear el Tópico de Cloud Pub/Sub

```bash
gcloud pubsub topics create billing-kill-switch
```

---

## Paso 3: Configurar la Alerta de Presupuesto en GCP

1. Ve a **Billing > Budgets & alerts**.
2. Crea un presupuesto con monto fijo de **\$1.00 USD** (o el umbral que elijas).
3. En **Actions / Notifications**, marca:
   - ✅ Connect a Pub/Sub topic.
   - Selecciona el tópico: `projects/<TU_PROJECT_ID>/topics/billing-kill-switch`.

---

## Paso 4: Desplegar la Cloud Function del Kill-Switch

Crea una función en Node.js que escuche el tópico y desconecte la facturación:

```typescript
import { CloudEvent } from "@google-cloud/functions-framework";
import { google } from "googleapis";

const billing = google.cloudbilling("v1");

interface BudgetNotification {
  costAmount: number;
  budgetAmount: number;
}

export async function stopBillingOnBudgetCap(event: CloudEvent<string>) {
  // Autenticación interna con el Service Account de la función
  const auth = new google.auth.GoogleAuth({
    scopes: ["https://www.googleapis.com/auth/cloud-billing"]
  });
  google.options({ auth });

  const pubsubData = JSON.parse(Buffer.from(event.data, "base64").toString());
  const cost = pubsubData.costAmount;
  const budget = pubsubData.budgetAmount;

  console.log(`Costo actual acumulado: $${cost} USD. Presupuesto límite: $${budget} USD.`);

  // Si el costo superó o igualó el presupuesto establecido:
  if (cost >= budget) {
    const projectId = process.env.GCP_PROJECT || process.env.GCLOUD_PROJECT;
    const projectName = `projects/${projectId}`;

    console.warn(`🚨 LÍMITE DE PRESUPUESTO ALCANZADO. Desactivando facturación en ${projectName}...`);

    // Desvincular billingAccountName (desactiva cobros en el proyecto)
    await billing.projects.updateBillingInfo({
      name: projectName,
      requestBody: { billingAccountName: "" } // String vacío = desvincular
    });

    console.log("🛑 Facturación desvinculada exitosamente. Se frenó cualquier gasto futuro.");
  }
}
```

---

## Paso 5: Asignar Permisos IAM al Service Account

El Service Account de la Cloud Function debe tener permisos de administrador de facturación sobre la cuenta:

```bash
gcloud billing accounts add-iam-policy-binding YOUR_BILLING_ACCOUNT_ID \
  --member="serviceAccount:YOUR_FUNCTION_SERVICE_ACCOUNT@appspot.gserviceaccount.com" \
  --role="roles/billing.admin"
```

---

## Resultado
Si se produce un ataque de denegación de servicio (DDoS), un error de código o un bucle infinito que supere \$1.00 USD de consumo en un día, **el Kill-Switch desactiva la facturación de forma instantánea y automática**.
Tu cuenta bancaria queda 100% protegida contra sorpresas millonarias.
