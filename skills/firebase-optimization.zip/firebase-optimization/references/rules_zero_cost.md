# Reglas de Seguridad de Firestore a Costo Cero (Zero-Read Rules)

> [!IMPORTANT]
> **El costo oculto de `get()` y `exists()`:**
> Cada llamada a `get(/databases/$(database)/documents/...)` o `exists(...)` dentro de `firestore.rules` **cuenta como 1 lectura de documento facturable / consumible en cuota**.
> Si tienes 100 usuarios consultando colecciones donde las reglas hacen un `get()` de validación de rol, consumirás el doble de lecturas: 1 lectura por el documento + 1 lectura por cada evaluación de regla.

---

## 1. Los Tres Principios de Reglas a Costo Cero

1. **Usa Firebase Auth Custom Claims en lugar de leer documentos de usuario:**
   - ❌ Antipatrón: `get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin'` (1 lectura por cada request).
   - ✅ Óptimo: `request.auth.token.role == 'admin'` (**0 lecturas**, viene decodificado en el JWT criptográfico).

2. **Aprovecha los parámetros de la ruta (`{userId}`, `{orgId}`):**
   - ❌ Antipatrón: Leer el documento para verificar quién es el dueño.
   - ✅ Óptimo: Comparar el wildcard de la ruta directamente:
     ```javascript
     match /users/{userId} {
       allow read, write: if request.auth != null && request.auth.uid == userId;
     }
     ```

3. **Valida escrituras usando `request.resource.data`:**
   - `request.resource.data` contiene el documento entrante tal como quedaría tras la escritura. No cuesta lecturas.
   - `resource.data` representa el documento existente antes de la escritura. Solo cuesta si el documento ya se iba a leer/escribir.

---

## 2. Implementación de Custom Claims (Roles sin Lecturas)

### Asignar Custom Claims en Cloud Functions / Backend (Admin SDK)
```typescript
import * as admin from "firebase-admin";

export async function setAdminRole(uid: string) {
  // Asignar claim 'admin' o rol en el token
  await admin.auth().setCustomUserClaims(uid, {
    role: "admin",
    tenantId: "company_xyz"
  });
  // Cuando el usuario refresque su token (getIdToken(true)), el claim estará disponible
}
```

### Reglas correspondientes en `firestore.rules`:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // Helper: Validar autenticación básica
    function isAuthenticated() {
      return request.auth != null;
    }

    // Helper: Validar rol desde el JWT (Costo: 0 lecturas)
    function isAdmin() {
      return isAuthenticated() && request.auth.token.role == 'admin';
    }

    // Helper: Validar pertenencia a organización (Costo: 0 lecturas)
    function belongsToTenant(tenantId) {
      return isAuthenticated() && request.auth.token.tenantId == tenantId;
    }

    // Colección de reportes protegida:
    match /tenants/{tenantId}/reports/{reportId} {
      allow read: if belongsToTenant(tenantId);
      allow write: if isAdmin();
    }
  }
}
```

---

## 3. Validación de Campos y Estructura sin Lecturas Extras

Evita que los clientes envíen datos inválidos o muten campos restringidos sin necesidad de consultar tablas auxiliares:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    match /posts/{postId} {
      // Lectura pública
      allow read: if true;

      // Creación: Valida campos requeridos y tipos
      allow create: if request.auth != null
        && request.resource.data.authorId == request.auth.uid
        && request.resource.data.keys().hasAll(['title', 'content', 'authorId', 'createdAt', 'likesCount'])
        && request.resource.data.title is string
        && request.resource.data.title.size() <= 120
        && request.resource.data.likesCount == 0 // Previene alterar contadores al inicio
        && request.resource.data.createdAt == request.time;

      // Actualización: Solo autor o no mutar campos críticos
      allow update: if request.auth != null
        && (
          // El autor puede editar contenido pero NO los contadores ni el autorId
          (resource.data.authorId == request.auth.uid 
            && !request.resource.data.diff(resource.data).affectedKeys().hasAny(['authorId', 'createdAt', 'likesCount']))
          ||
          // Cualquier usuario autenticado puede incrementar likes usando increment(1)
          (request.resource.data.diff(resource.data).affectedKeys().hasOnly(['likesCount'])
            && request.resource.data.likesCount == resource.data.likesCount + 1)
        );

      // Eliminación: Solo el autor
      allow delete: if request.auth != null && resource.data.authorId == request.auth.uid;
    }
  }
}
```

---

## 4. Comparativa de Consumo: Custom Claims vs Document Role

Supongamos una app con 5,000 usuarios activos diarios (DAU) que abren la app 3 veces al día:

| Estrategia | Lecturas de Validación de Reglas al Día | Consumo Spark Plan (50k/día) |
|---|---|---|
| **`get()` a `/users/{uid}` en Reglas** | 15,000 a 45,000 lecturas consumidas **solo en reglas** | ⚠️ Agota entre el 30% y 90% del límite diario |
| **Custom Claims en JWT** | **0 lecturas** | ✅ 0% consumido, 50k lecturas libres para la app |
