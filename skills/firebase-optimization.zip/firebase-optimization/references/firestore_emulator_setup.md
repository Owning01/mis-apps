# Guía de Firebase Local Emulator Suite: Testing a Costo Cero

> [!CAUTION]
> **REGLA INQUEBRANTABLE:** NUNCA ejecutes pruebas unitarias, de integración, suites de CI/CD ni desarrollo local apuntando a instancias activas de Firebase Cloud. Un test en un bucle o un pipeline de CI puede consumir la cuota diaria del Spark Plan (50k lecturas) en segundos o generar costos astronómicos en Blaze.

---

## 1. Por qué usar Local Emulator Suite

| Aspecto | Firebase Cloud (Producción/Staging) | Local Emulator Suite |
|---|---|---|
| **Costo** | Consume cuota de Spark / Factura en Blaze | **\$0.00 (100% gratuito e ilimitado)** |
| **Velocidad** | 50ms - 300ms de latencia de red | **< 2ms (en memoria/localhost)** |
| **Aislamiento** | Contaminación de DB y condiciones de carrera | **Datos efímeros, reset instantáneo** |
| **Sin conexión** | Requiere internet estable | **Funciona 100% offline** |
| **Seguridad** | Riesgo de filtrar llaves de servicio | **Entorno sandbox local** |

---

## 2. Instalación y Configuración Inicial

### Paso 1: Instalar Firebase CLI
```bash
npm install -g firebase-tools
```

### Paso 2: Inicializar Emuladores en el Proyecto
```bash
firebase init emulators
```
Selecciona:
- Authentication (puerto 9099)
- Firestore (puerto 8080)
- Realtime Database (puerto 9000)
- Storage (puerto 9199)
- Cloud Functions (puerto 5001)
- Emulator UI (puerto 4000)

Esto generará en tu `firebase.json`:
```json
{
  "emulators": {
    "auth": {
      "port": 9099
    },
    "firestore": {
      "port": 8080
    },
    "functions": {
      "port": 5001
    },
    "storage": {
      "port": 9199
    },
    "ui": {
      "enabled": true,
      "port": 4000
    },
    "singleProjectMode": true
  }
}
```

---

## 3. Conexión de Clientes al Emulador

### A. JavaScript / TypeScript (Web / Node.js)
```typescript
import { initializeApp } from "firebase/app";
import { getFirestore, connectFirestoreEmulator } from "firebase/firestore";
import { getAuth, connectAuthEmulator } from "firebase/auth";
import { getStorage, connectStorageEmulator } from "firebase/storage";
import { getFunctions, connectFunctionsEmulator } from "firebase/functions";

const firebaseConfig = {
  projectId: "demo-local-project", // Usar prefijo demo- para evitar llamadas a GCP
  apiKey: "fake-api-key",
  authDomain: "demo-local-project.firebaseapp.com",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);
const storage = getStorage(app);
const functions = getFunctions(app);

// Activar emuladores solo en desarrollo o tests
if (process.env.NODE_ENV !== "production" || location.hostname === "localhost") {
  connectFirestoreEmulator(db, "127.0.0.1", 8080);
  connectAuthEmulator(auth, "http://127.0.0.1:9099", { disableWarnings: true });
  connectStorageEmulator(storage, "127.0.0.1", 9199);
  connectFunctionsEmulator(functions, "127.0.0.1", 5001);
  console.log("🚀 Conectado a Firebase Local Emulator Suite. Cuota protegida.");
}
```

> [!TIP]
> Si tu `projectId` comienza con `demo-` (ej. `demo-test-project`), los SDKs de Firebase bloquean automáticamente cualquier intento de enviar tráfico a los servidores de producción de Google, garantizando seguridad absoluta.

---

### B. Flutter / Dart
```dart
import 'package:flutter/foundation.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';

Future<void> setupFirebase() async {
  await Firebase.initializeApp();

  if (kDebugMode) {
    // En Android Emulator usa '10.0.2.2', en iOS Simulator / Web usa 'localhost'
    final host = defaultTargetPlatform == TargetPlatform.android ? '10.0.2.2' : 'localhost';

    FirebaseFirestore.instance.useFirestoreEmulator(host, 8080);
    await FirebaseAuth.instance.useAuthEmulator(host, 9099);
    await FirebaseStorage.instance.useStorageEmulator(host, 9199);
    
    // Desactivar SSL para emulador local
    FirebaseFirestore.instance.settings = const Settings(
      persistenceEnabled: false,
      sslEnabled: false,
    );
    
    debugPrint('🛡️ Firebase Emulator Suite conectado. Cuota en vivo blindada.');
  }
}
```

---

## 4. Ejecución en CI/CD y Automatización

Para correr pruebas en GitHub Actions o pipelines locales sin consumir 1 centavo:

```bash
# Iniciar emuladores, correr la suite de tests y apagarlos automáticamente
firebase emulators:exec --only firestore,auth "npm test"
```

### GitHub Actions Workflow Ejemplo:
```yaml
name: Test Suite (Zero Firebase Quota)

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: npm ci
      - name: Install Firebase CLI
        run: npm install -g firebase-tools
      - name: Run Tests with Firebase Emulator
        run: firebase emulators:exec --only firestore,auth "npm test"
        env:
          CI: true
          FIREBASE_AUTH_EMULATOR_HOST: "127.0.0.1:9099"
          FIRESTORE_EMULATOR_HOST: "127.0.0.1:8080"
```

---

## 5. Datos Iniciales y Persistencia del Emulador

Para cargar un dataset falso sin volver a crearlo en cada test:

```bash
# Exportar datos tras configurar el entorno local
firebase emulators:export ./emulator-data

# Iniciar emuladores cargando esos datos e importando al inicio
firebase emulators:start --import=./emulator-data --export-on-exit
```
Esto permite contar con miles de registros de prueba para testear paginación y agregaciones sin costo alguno.
