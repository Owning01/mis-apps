# Guía Maestra de la Caché en Firebase: El Secreto del Costo Cero

> [!IMPORTANT]
> **La regla de oro de la economía de Firebase:**
> En Firestore, **cada documento servido desde la caché local cuesta exactamente \$0.00 y 0 lecturas de cuota**.
> La caché no es una simple optimización de rendimiento: **es la única barrera física que separa un proyecto gratuito y rentable de una factura impagable o el bloqueo de cuotas diarias.**

---

## 1. La Matemática del Impacto: Con Caché vs Sin Caché

Analicemos una aplicación estándar con **2,000 Usuarios Activos Diarios (DAU)**:
- Cada usuario abre la app 3 veces al día.
- En cada sesión visualiza una lista de 15 productos o publicaciones.
- Total de documentos visualizados al día: $2,000 \times 3 \times 15 = 90,000$ visualizaciones.

| Escenario | Tasa de Acierto de Caché (Hit Ratio) | Lecturas Enviadas a Firebase Cloud | Estado en el Spark Plan (Límite: 50,000 reads/día) | Factura Estimada |
|---|---|---|---|---|
| **Sin Caché (Directo a Servidor)** | 0% | **90,000 lecturas/día** | 🚨 **COLAPSO A LAS 14:00 HS** (`RESOURCE_EXHAUSTED`) | Requiere Blaze (\$25–\$100/mes) |
| **Caché Básica por Defecto** | 40% | **54,000 lecturas/día** | ⚠️ **SUPERADO** (Bloqueo al final de la tarde) | Requiere Blaze |
| **Caché Optimizada (SWR + Multi-Tab)** | 85% | **13,500 lecturas/día** | ✅ **100% OPERATIVO** (Solo 27% de la cuota consumida) | **\$0.00 de por vida** |
| **Caché Extrema (Bundles + L1/L2)** | 95% | **4,500 lecturas/día** | 🏆 **HOLGADO** (Solo 9% de la cuota consumida) | **\$0.00 de por vida** |

---

## 2. La Arquitectura de Caché en 3 Capas (L1, L2, L3)

```text
  [ Pantalla / UI ]
         │
         ▼  (Paso 1: ¿Está en RAM?)
 ┌───────────────────────────────────────────────┐
 │ CAPA L1: Memoria RAM (In-Flight / State)       │  Latencia: < 1 ms  | Costo: 0 lecturas
 │ (Deduplicación de Promesas, Zustand, Riverpod) │
 └──────────────────────┬────────────────────────┘
                        │ Miss
                        ▼  (Paso 2: ¿Está en Disco Local?)
 ┌───────────────────────────────────────────────┐
 │ CAPA L2: Persistencia en Disco Local          │  Latencia: 5-15 ms | Costo: 0 lecturas
 │ (IndexedDB en Web, SQLite/LevelDB en Mobile)  │
 └──────────────────────┬────────────────────────┘
                        │ Miss
                        ▼  (Paso 3: ¿Está en CDN?)
 ┌───────────────────────────────────────────────┐
 │ CAPA L3: Edge CDN (Firestore Bundles)         │  Latencia: 25-50 ms | Costo: 0 lecturas DB
 │ (Firebase Hosting CDN / Cache-Control HTTP)   │
 └──────────────────────┬────────────────────────┘
                        │ Miss
                        ▼  (Paso 4: Servidor Cloud)
 ┌───────────────────────────────────────────────┐
 │ CLOUD FIRESTORE (Servidores de Google Cloud)  │  Latencia: 80-250 ms | Costo: 1 LECTURA DE CUOTA
 └───────────────────────────────────────────────┘
```

---

## 3. Implementación del Patrón Stale-While-Revalidate (SWR) en Firestore

El patrón **SWR** devuelve los datos de la caché local instantáneamente para que la interfaz cargue sin ningún retardo (`spinner`), y en paralelo lanza una comprobación de red silenciosa para actualizar los datos si cambiaron:

```typescript
import { doc, getDocFromCache, getDocFromServer, DocumentSnapshot } from "firebase/firestore";

interface SWRResult<T> {
  data: T;
  source: 'cache' | 'server';
}

export async function getDocSWR<T>(
  docRef: any,
  onUpdate?: (freshData: T) => void
): Promise<SWRResult<T>> {
  let cachedSnap: DocumentSnapshot | null = null;

  // 1. Intentar resolver de inmediato desde L2 (Caché local en disco)
  try {
    cachedSnap = await getDocFromCache(docRef);
    if (cachedSnap.exists()) {
      const data = { id: cachedSnap.id, ...cachedSnap.data() } as T;
      
      // Lanzar revalidación en segundo plano sin bloquear al usuario
      if (onUpdate) {
        getDocFromServer(docRef).then((freshSnap) => {
          if (freshSnap.exists()) {
            onUpdate({ id: freshSnap.id, ...freshSnap.data() } as T);
          }
        }).catch(() => {
          // Si está offline o falla la red, la app sigue funcionando con la caché
        });
      }

      return { data, source: 'cache' };
    }
  } catch (_) {
    // Si no estaba en caché, continuar a la llamada de red
  }

  // 2. Si no había caché, ir obligatoriamente al servidor (1 lectura de cuota)
  const freshSnap = await getDocFromServer(docRef);
  return {
    data: { id: freshSnap.id, ...freshSnap.data() } as T,
    source: 'server'
  };
}
```

---

## 4. Detección de Origen mediante Metadata (`fromCache`)

Firestore incluye una propiedad booleana `snapshot.metadata.fromCache` en cada documento o consulta. Sirve para auditar exactamente si una pantalla consumió cuota o vino de la memoria local:

```typescript
import { onSnapshot, doc } from "firebase/firestore";

const unsub = onSnapshot(doc(db, "settings", "global"), (snap) => {
  const isFromCache = snap.metadata.fromCache;
  const hasPendingWrites = snap.metadata.hasPendingWrites;

  if (isFromCache) {
    console.log("⚡ [COSTO $0.00] Datos servidos desde la caché local del dispositivo.");
  } else {
    console.log("🌐 [1 LECTURA CONSUMIDA] Datos descargados desde los servidores de Google.");
  }
});
```

---

## 5. Configuración del Tamaño de Caché (Evitar Evicciones Prematuras)

Por defecto, Firestore en Web y Mobile tiene un límite de caché de aproximadamente **40 MB**. Cuando se alcanza este límite, el SDK ejecuta un algoritmo de **LRU (Least Recently Used)** y elimina documentos antiguos para hacer espacio. Si se eliminan, la próxima vez que el usuario los consulte, se disparará una lectura de red.

### Para maximizar el Hit Ratio en Web:
```typescript
import { initializeFirestore, persistentLocalCache, persistentMultipleTabManager, CACHE_SIZE_UNLIMITED } from "firebase/firestore";

const db = initializeFirestore(app, {
  localCache: persistentLocalCache({
    tabManager: persistentMultipleTabManager(),
    cacheSizeBytes: CACHE_SIZE_UNLIMITED // No purgar documentos antiguos automáticamente
  })
});
```

> [!TIP]
> En aplicaciones móviles (Flutter, Android, iOS), `CACHE_SIZE_UNLIMITED` permite almacenar miles de documentos en la base de datos SQLite local del teléfono. Un catálogo completo de 2,000 productos ocupa menos de 15 MB de almacenamiento en el móvil, garantizando que el usuario jamás vuelva a descargar esos datos de la nube.
