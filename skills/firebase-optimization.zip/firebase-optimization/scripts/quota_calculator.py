#!/usr/bin/env python3
"""
Simulador y Calculadora de Cuotas Firebase (Spark vs Blaze).
Permite modelar el tráfico de usuarios y evaluar si el sistema cabe dentro del plan gratuito ($0).

Uso:
    python quota_calculator.py [--dau 1000] [--reads 15] [--writes 4] [--cache-ratio 0.8]
"""

import sys
import argparse

# Fix Windows console encoding
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

# Límites del Spark Plan (por día o mes según servicio)
SPARK_LIMITS = {
    'firestore_reads_day': 50000,
    'firestore_writes_day': 20000,
    'firestore_deletes_day': 20000,
    'storage_download_mb_day': 1024,  # 1 GB / día
    'rtdb_download_mb_month': 10240,  # 10 GB / mes
    'auth_mau': 50000,
}

def calculate_quota(dau, sessions_day, reads_session, writes_session, cache_hit_ratio, 
                    storage_mb_session=0.2, rtdb_kb_session=10):
    effective_reads_session = reads_session * (1.0 - cache_hit_ratio)
    
    total_sessions_day = dau * sessions_day
    daily_reads = total_sessions_day * effective_reads_session
    daily_writes = total_sessions_day * writes_session
    daily_storage_mb = total_sessions_day * storage_mb_session
    monthly_rtdb_mb = (total_sessions_day * rtdb_kb_session * 30) / 1024.0
    estimated_mau = dau * 3.5  # Aproximación estándar DAU a MAU
    
    read_pct = (daily_reads / SPARK_LIMITS['firestore_reads_day']) * 100
    write_pct = (daily_writes / SPARK_LIMITS['firestore_writes_day']) * 100
    storage_pct = (daily_storage_mb / SPARK_LIMITS['storage_download_mb_day']) * 100
    rtdb_pct = (monthly_rtdb_mb / SPARK_LIMITS['rtdb_download_mb_month']) * 100
    auth_pct = (estimated_mau / SPARK_LIMITS['auth_mau']) * 100
    
    return {
        'dau': dau,
        'sessions_day': sessions_day,
        'cache_hit_ratio': cache_hit_ratio,
        'daily_reads': daily_reads,
        'read_pct': read_pct,
        'daily_writes': daily_writes,
        'write_pct': write_pct,
        'daily_storage_mb': daily_storage_mb,
        'storage_pct': storage_pct,
        'monthly_rtdb_mb': monthly_rtdb_mb,
        'rtdb_pct': rtdb_pct,
        'estimated_mau': estimated_mau,
        'auth_pct': auth_pct,
    }

def print_report(res):
    print("=" * 70)
    print("🔥 REPORTE DE CONSUMO Y PROYECCIÓN DE CUOTAS FIREBASE (SPARK PLAN)")
    print("=" * 70)
    print(f"Parámetros: {res['dau']:,} DAU | {res['sessions_day']} sesiones/día | Caché Local: {res['cache_hit_ratio']*100:.0f}%")
    print("-" * 70)
    
    metrics = [
        ("Firestore Lecturas / día", res['daily_reads'], SPARK_LIMITS['firestore_reads_day'], res['read_pct'], "reads"),
        ("Firestore Escrituras / día", res['daily_writes'], SPARK_LIMITS['firestore_writes_day'], res['write_pct'], "writes"),
        ("Storage Descarga / día", res['daily_storage_mb'], SPARK_LIMITS['storage_download_mb_day'], res['storage_pct'], "MB"),
        ("RTDB Descarga / mes", res['monthly_rtdb_mb'], SPARK_LIMITS['rtdb_download_mb_month'], res['rtdb_pct'], "MB"),
        ("Auth MAU estimado", res['estimated_mau'], SPARK_LIMITS['auth_mau'], res['auth_pct'], "usuarios"),
    ]
    
    all_green = True
    any_critical = False
    
    for name, current, limit, pct, unit in metrics:
        if pct > 100:
            badge = "🚨 EXCEDIDO"
            all_green = False
            any_critical = True
        elif pct > 75:
            badge = "⚠️ ALERTA"
            all_green = False
        else:
            badge = "✅ SEGURO"
            
        print(f"{badge} {name:<26}: {current:>10.1f} / {limit:,} {unit} ({pct:>6.1f}%)")
        
    print("-" * 70)
    if any_critical:
        print("💥 DIAGNÓSTICO: Tu arquitectura SUPERARÍA los límites gratuitos de Spark.")
        print("   Recomendaciones:")
        if res['read_pct'] > 100:
            print("   - Eleva la tasa de acierto de caché usando Firestore Bundles y persistencia local.")
            print("   - Sustituye getDocs completos por native aggregations count().")
            print("   - Acota los límites de paginación de 50 a 15-20 elementos.")
        if res['write_pct'] > 100:
            print("   - Agrupa escrituras en writeBatch o implementa debouncing de 3 segundos.")
            print("   - Mueve eventos volátiles de alta frecuencia (GPS/typing) a Realtime Database.")
        if res['storage_pct'] > 100:
            print("   - Comprime imágenes a WebP en el cliente antes de subirlas a Storage.")
            print("   - Agrega encabezados 'Cache-Control: immutable' para evitar re-descargas.")
    elif not all_green:
        print("⚡ DIAGNÓSTICO: Consumo moderado. Estás cerca del margen límite del 80%.")
    else:
        print("🎉 DIAGNÓSTICO: Arquitectura 100% CABLEADA A COSTO CERO ($0.00 USD/mes).")
        print("   Tu tráfico proyectado vive holgadamente dentro del Spark Plan de por vida.")
    print("=" * 70)

def main():
    parser = argparse.ArgumentParser(description="Calculadora de cuotas y sustentabilidad Spark en Firebase")
    parser.add_argument("--dau", type=int, default=1500, help="Usuarios Activos Diarios (DAU)")
    parser.add_argument("--sessions", type=float, default=2.5, help="Sesiones promedio por usuario al día")
    parser.add_argument("--reads", type=float, default=12.0, help="Lecturas de Firestore brutas por sesión")
    parser.add_argument("--writes", type=float, default=3.0, help="Escrituras de Firestore por sesión")
    parser.add_argument("--cache-ratio", type=float, default=0.75, help="Ratio de acierto de caché local (0.0 a 0.95)")
    args = parser.parse_args()

    results = calculate_quota(
        dau=args.dau,
        sessions_day=args.sessions,
        reads_session=args.reads,
        writes_session=args.writes,
        cache_hit_ratio=args.cache_ratio
    )
    print_report(results)

if __name__ == "__main__":
    main()
