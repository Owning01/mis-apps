#!/usr/bin/env python3
"""
Validador y Auditor Estático de Código Firebase para Optimización de Cuotas.
Detecta antipatrones de alto consumo de lecturas, escrituras y riesgos de costos.

Uso:
    python audit_firebase_code.py <ruta_del_proyecto> [--strict]
"""

import os
import re
import sys
import argparse
from pathlib import Path

# Fix Windows console encoding for UTF-8 / emojis
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

EXTENSIONS = {'.js', '.ts', '.jsx', '.tsx', '.dart', '.py', '.rules'}

class Issue:
    def __init__(self, file_path, line_no, severity, rule_id, message, code_snippet=""):
        self.file_path = file_path
        self.line_no = line_no
        self.severity = severity  # 'CRITICAL', 'WARNING', 'INFO'
        self.rule_id = rule_id
        self.message = message
        self.code_snippet = code_snippet.strip()

    def __str__(self):
        icon = "🚨" if self.severity == "CRITICAL" else ("⚠️ " if self.severity == "WARNING" else "ℹ️ ")
        return f"{icon} [{self.severity}] {self.file_path}:{self.line_no} ({self.rule_id})\n    {self.message}\n    > {self.code_snippet}\n"

def audit_file(file_path: Path):
    issues = []
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
    except Exception as e:
        return [Issue(str(file_path), 0, "WARNING", "IO_ERROR", f"No se pudo leer archivo: {e}")]

    content = "".join(lines)
    is_test_file = any(part in file_path.name.lower() for part in ['test', 'spec'])
    is_rules_file = file_path.suffix == '.rules' or file_path.name == 'firestore.rules'

    # 1. Regla: Prohibición de tests apuntando a Firebase real
    if is_test_file:
        for idx, line in enumerate(lines, 1):
            if re.search(r'initializeApp\(', line) and not re.search(r'connectFirestoreEmulator|useFirestoreEmulator|demo-', content):
                issues.append(Issue(
                    str(file_path), idx, "CRITICAL", "TEST-NO-EMULATOR",
                    "Test inicializa Firebase sin conectar al Local Emulator Suite. Riesgo de consumir cuota de producción.",
                    line
                ))
                break

    # 2. Regla: get() o exists() en firestore.rules (Cada uno cuesta 1 lectura)
    if is_rules_file:
        for idx, line in enumerate(lines, 1):
            if re.search(r'\b(get|exists)\s*\(', line):
                issues.append(Issue(
                    str(file_path), idx, "WARNING", "RULES-EXTRA-READ",
                    "Uso de get() o exists() en reglas de seguridad. Cada invocación consume 1 lectura de cuota. Considera usar Custom Claims (request.auth.token).",
                    line
                ))

    # 3. Regla: Consultas potencialmente sin .limit()
    # Busca query(...), collection(...) asociadas con getDocs o snapshots sin limit
    query_pattern = re.compile(r'(query\s*\([^;]+?\)|collection\s*\([^;]+?\)\.(?:where|orderBy)\([^;]+?\))', re.MULTILINE | re.DOTALL)
    for match in query_pattern.finditer(content):
        chunk = match.group(0)
        line_no = content[:match.start()].count('\n') + 1
        if 'limit(' not in chunk and 'limitToLast(' not in chunk:
            # Chequear si no es un doc() específico
            if '.doc(' not in chunk:
                first_line = chunk.splitlines()[0]
                issues.append(Issue(
                    str(file_path), line_no, "WARNING", "QUERY-NO-LIMIT",
                    "Consulta sin cláusula .limit(). Riesgo de leer cientos o miles de documentos no acotados.",
                    first_line
                ))

    # 4. Regla: Firestore dentro de bucles (Antipatrón N+1)
    loop_regex = re.compile(r'\b(for\s*\(|for\s+[a-zA-Z0-9_]+\s+in|\.forEach\s*\(|\.map\s*\()')
    firestore_call = re.compile(r'\b(getDoc|getDocs|setDoc|updateDoc|deleteDoc|\.get\(|\.set\(|\.update\(|\.delete\()\b')
    
    in_loop_lines = 0
    loop_start_line = 0
    for idx, line in enumerate(lines, 1):
        if loop_regex.search(line):
            in_loop_lines = 15  # Ventana de inspección de bloque
            loop_start_line = idx
        elif in_loop_lines > 0:
            in_loop_lines -= 1
            if firestore_call.search(line) and 'writeBatch' not in line:
                issues.append(Issue(
                    str(file_path), idx, "CRITICAL", "N-PLUS-ONE-LOOP",
                    f"Llamada a Firestore dentro o adyacente a un bucle (iniciado en línea {loop_start_line}). "
                    "Usa writeBatch, bulkWriter o consultas agrupadas (where in) para evitar quemar cuota.",
                    line
                ))

    # 5. Regla: Lectura previa para incrementar contador (Antipatrón Read-Before-Write)
    read_before_inc = re.compile(r'(\+\s*1|\+\+)\s*;')
    for idx, line in enumerate(lines, 1):
        if ('count' in line.lower() or 'likes' in line.lower() or 'views' in line.lower()) and read_before_inc.search(line):
            if any('getDoc' in lines[max(0, idx-5):idx] or '.get(' in l for l in lines[max(0, idx-5):idx]):
                issues.append(Issue(
                    str(file_path), idx, "WARNING", "MANUAL-INCREMENT",
                    "Posible incremento manual tras lectura. Usa 'FieldValue.increment(1)' para actualizar atómicamente sin gastar lecturas.",
                    line
                ))

    # 6. Regla: Listeners onSnapshot sin guardar retorno para unsubscribe
    for idx, line in enumerate(lines, 1):
        if 'onSnapshot(' in line or '.snapshots()' in line:
            stripped = line.strip()
            if stripped.startswith('onSnapshot(') or stripped.startswith('db.') or stripped.startswith('firestore.'):
                if not any(eq in line for eq in ['=', 'return ', 'yield* ']):
                    issues.append(Issue(
                        str(file_path), idx, "WARNING", "UNCHECKED-LISTENER",
                        "onSnapshot invocado sin almacenar la función de desuscripción. Puede provocar listeners huérfanos que consuman lecturas indefinidamente.",
                        line
                    ))

    # 7. Regla: Storage Uploads sin Cache-Control (Riesgo de sobreconsumo de ancho de banda)
    for idx, line in enumerate(lines, 1):
        if re.search(r'\b(uploadBytes|uploadString|putFile|putData)\s*\(', line):
            # Mirar si en las siguientes 8 líneas o en la misma línea está 'cacheControl'
            window = "".join(lines[idx-1:min(len(lines), idx+8)])
            if 'cacheControl' not in window:
                issues.append(Issue(
                    str(file_path), idx, "INFO", "STORAGE-NO-CACHE-CONTROL",
                    "Subida a Cloud Storage sin header 'cacheControl'. Los clientes re-descargarán el archivo cada vez, consumiendo el límite de 1 GB/día de Spark.",
                    line
                ))

    # 8. Regla: RTDB Root Listener (Descarga el árbol entero JSON)
    for idx, line in enumerate(lines, 1):
        if re.search(r'ref\s*\(\s*(?:rtdb|db)?\s*(?:,\s*[\'"`]/[\'"`]\s*)?\)\s*\.\s*(?:on|once)\s*\(', line) or \
           re.search(r'onValue\s*\(\s*ref\s*\(\s*(?:rtdb|db)?\s*\)', line):
            issues.append(Issue(
                str(file_path), idx, "CRITICAL", "RTDB-ROOT-LISTENER",
                "Listener en la raíz de Realtime Database. Descargará la base de datos completa en memoria, agotando la cuota de Egress inmediatamente.",
                line
            ))

    # 9. Regla: Phone Authentication (Límite Spark: solo 10 SMS/día)
    for idx, line in enumerate(lines, 1):
        if re.search(r'\b(signInWithPhoneNumber|verifyPhoneNumber)\s*\(', line):
            issues.append(Issue(
                str(file_path), idx, "WARNING", "AUTH-PHONE-QUOTA-RISK",
                "Uso de autenticación por SMS. El plan Spark solo incluye 10 SMS/día gratis. Prefiere OAuth (Google/Apple), Passkeys o Email Link para mantener costo $0.",
                line
            ))

    return issues

def main():
    parser = argparse.ArgumentParser(description="Auditor de optimización y consumo de cuotas Firebase")
    parser.add_argument("path", help="Ruta de directorio o archivo a escanear")
    parser.add_argument("--strict", action="store_true", help="Falla con código de salida 1 si hay warnings")
    args = parser.parse_args()

    root = Path(args.path)
    if not root.exists():
        print(f"Error: la ruta '{args.path}' no existe.")
        sys.exit(1)

    all_issues = []
    files_scanned = 0

    if root.is_file():
        files = [root]
    else:
        files = [
            p for p in root.rglob("*")
            if p.is_file() 
            and p.suffix in EXTENSIONS 
            and not any(ignore in p.parts for ignore in ['node_modules', '.git', 'build', '.dart_tool', 'dist', '.next'])
        ]

    for f in files:
        files_scanned += 1
        all_issues.extend(audit_file(f))

    print(f"\n🔍 Escaneo completado: {files_scanned} archivos analizados.")
    print("=" * 70)

    criticals = [i for i in all_issues if i.severity == "CRITICAL"]
    warnings = [i for i in all_issues if i.severity == "WARNING"]

    for issue in all_issues:
        print(issue)

    print("=" * 70)
    print(f"📊 Resumen de Auditoría: {len(criticals)} Críticos | {len(warnings)} Advertencias")

    if criticals:
        print("🚨 SE DETECTARON VIOLACIONES CRÍTICAS DE CUOTA O TESTING EN VIVO.")
        sys.exit(1)
    elif warnings and args.strict:
        print("⚠️ Advertencias detectadas en modo estricto.")
        sys.exit(1)
    else:
        print("✅ No se detectaron violaciones críticas de cuota Firebase.")
        sys.exit(0)

if __name__ == "__main__":
    main()
