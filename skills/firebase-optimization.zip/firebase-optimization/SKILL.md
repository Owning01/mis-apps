---
name: firebase-optimization
description: Playbook canónico de optimización extrema de Firebase (Firestore, Realtime DB, Auth, Storage, Functions). Estrategias para exprimir al máximo la cuota gratuita (Spark Plan), reducir lecturas y escrituras al mínimo matemático, arquitecturas cache-first, agregaciones nativas, data bundles, reglas de costo cero, y prohibición estricta de testear contra instancias reales usando Firebase Local Emulator Suite.
metadata:
  model: models/gemini-3.1-pro-preview
  last_modified: Wed, 14 Oct 2026
---

# firebase-optimization — Playbook Canónico de Optimización y Costo Cero en Firebase

Guía de ingeniería avanzada para diseñar, construir y operar aplicaciones sobre **Firebase** con consumo mínimo de recursos, optimización extrema de lecturas/escrituras y aprovechamiento inteligente del **Spark Plan (cuota gratuita)** sin sorpresas de facturación.

---

## 🧭 Router — Guía rápida según tu necesidad

| Tu objetivo o problema actual | Dominio | Sección | Herramientas / Patrones clave |
|---|---|---|---|
| **"No gastar cuota en tests / correr tests locales"** | **Testing Seguro** | **§0 & §5** | Local Emulator Suite, `demo-` project ID, FakeFirestore |
| **"¿Cuánto aguanta el plan gratis? / límites Spark"** | **Cuota Gratuita** | **§1 & §6.2** | Spark breakdown, `quota_calculator.py`, matemática de escala |
| **"Importancia de la caché / por qué es vital"** | **Caché Maestro** | **§2.0** | Arquitectura L1/L2/L3, SWR, [cache_mastery_guide.md](references/cache_mastery_guide.md) |
| **"Tengo muchas lecturas / cómo bajar reads"** | **Lecturas** | **§2** | Cache-first, Native Aggregations, Bundles, In-flight Coalescing |
| **"Reducir escrituras / contadores / batch writes"** | **Escrituras** | **§3** | `FieldValue.increment`, `writeBatch`, Write Buffer, TTL |
| **"Reglas de seguridad lentas o que cobran lecturas"** | **Seguridad** | **§4** | Custom Claims en JWT, 0-read security rules |
| **"Modelado de datos eficiente (likes, feed, chat)"** | **Modelado NoSQL** | **§7** | Subcolecciones vs Maps, [data_modeling_recipes.md](references/data_modeling_recipes.md) |
| **"RTDB vs Firestore / Comprimir Storage"** | **Ancho de Banda** | **§8** | WebP Canvas, [storage_and_rtdb_optimization.md](references/storage_and_rtdb_optimization.md) |
| **"Miedo a cargos en Blaze / frenar gastos"** | **Kill-Switch** | **§9** | Pub/Sub + Cloud Billing API, [kill_switch_billing.md](references/kill_switch_billing.md) |
| **"Auditar código / buscar fugas de cuota en el repo"** | **Auditoría** | **§6.1** | `audit_firebase_code.py`, static checks |

---

## 0. REGLA INQUEBRANTABLE: PROHIBIDO TESTEAR CONTRA FIREBASE REAL

> [!CAUTION]
> **REGLA CERO (ANTI-QUOTA-BURN):**
> **ESTÁ ESTRICTAMENTE PROHIBIDO ejecutar tests unitarios, de integración, suites de CI/CD o pruebas manuales intensivas apuntando a proyectos Firebase en la nube (producción o staging).**
>
> 💥 **¿Por qué?**
> 1. Un solo test automatizado con un bucle `for` o un watcher mal configurado puede consumir las **50,000 lecturas diarias del plan Spark en menos de 60 segundos**, bloqueando la base de datos para el resto del día.
> 2. Si el proyecto está en plan **Blaze**, un test descontrolado puede generar cargos no reembolsables de cientos de dólares.
> 3. Los tests contra la nube sufren de latencia de red (50–300 ms), límites de tasa (rate limiting) y polución de datos entre ejecuciones concurrentes.

### Protocolo Obligatorio de Pruebas:
1. **Desarrollo y Tests Locales:** Utiliza siempre el **Firebase Local Emulator Suite** (`firebase emulators:start`).
2. **Identificador Sandbox:** Configura el `projectId` con el prefijo `demo-` (ej. `demo-app-test`). Los SDKs de Firebase reconocen este prefijo e **impiden a nivel de red cualquier conexión a los servidores reales de Google**.
3. **Mocks en Memoria:**
   - En Flutter/Dart: Usa `fake_cloud_firestore`.
   - En Web/Node.js: Usa emuladores locales o mocks con `@firebase/rules-unit-testing`.
4. **CI/CD:** En GitHub Actions o GitLab CI, ejecuta los emuladores con el comando headless:
   ```bash
   firebase emulators:exec --only firestore,auth "npm test" # o "flutter test"
   ```

*Consulta la guía completa de configuración en [references/firestore_emulator_setup.md](references/firestore_emulator_setup.md).*

---

## 1. Anatomía de la Cuota Gratuita (Spark Plan) & Estrategia de Escala a $0

Firebase ofrece una de las capas gratuitas más generosas de la industria, pero cuenta con límites rígidos. Al alcanzar el límite del Spark Plan, la API devuelve error `RESOURCE_EXHAUSTED` hasta el reinicio de medianoche (medianoche hora del Pacífico, PST/PDT).

### 1.1 Límites Oficiales del Spark Plan (Free Tier)

| Servicio | Límite Gratuito Diario / Mensual | Riesgo Crítico a Vigilar |
|---|---|---|
| **Cloud Firestore** | **50,000 lecturas / día**<br>**20,000 escrituras / día**<br>**20,000 eliminaciones / día**<br>1 GiB almacenamiento total<br>10 GiB egress de red / mes | Escaneos de colecciones completas (`getDocs`), listeners descontrolados en listas grandes. |
| **Realtime Database** | **1 GiB almacenamiento total**<br>**10 GiB descarga / mes**<br>100 conexiones simultáneas | Descargas profundas de nodos raíz JSON, watchers sin indexOn. |
| **Cloud Storage** | **5 GB almacenamiento**<br>**1 GB descarga / día**<br>20,000 uploads / día<br>50,000 downloads / día | Servir imágenes pesadas sin optimizar (usar WebP y CDN/Cache-Control). |
| **Firebase Authentication** | **50,000 Usuarios Activos Mensuales (MAU)** | ⚠️ **PELIGRO SMS:** El cupo gratuito de SMS es de solo **10 verificaciones/día**. ¡Nunca uses Phone Auth para registro masivo en plan gratis! Usa Google, Apple, Email/Password o Passkeys. |
| **Cloud Functions (2nd Gen)** | **2,000,000 invocaciones / mes**<br>400,000 GB-segundos / mes<br>200,000 CPU-segundos / mes<br>5 GB egress / mes | Triggers en cascada (una función que escribe en Firestore y se auto-dispara infinitamente). |
| **Firebase Hosting** | **10 GB almacenamiento**<br>**360 MB / día** (aprox. 10 GB/mes) | Alojar videos o archivos binarios grandes en hosting web. |

### 1.2 La Matemática para soportar 10,000 a 50,000 DAU en el Spark Plan
Para mantenerte en \$0 con miles de usuarios activos diarios:
- **Presupuesto por Usuario Activo:** Si tienes 2,500 usuarios diarios y 50,000 lecturas gratuitas, cada usuario tiene un **presupuesto de 20 lecturas de Firestore por sesión**.
- **Solución Arquitectónica:**
  1. El 90% de los datos leídos deben provenir de la **caché local** o de **Firestore Bundles** servidos por CDN.
  2. Cada pantalla debe paginar con `limit(10)` o `limit(20)`.
  3. Los contadores y métricas agregadas se calculan con native aggregations (`count()`), no descargando documentos.

---

## 2. Optimización Extrema de Lecturas (Read Optimizations)

### 2.0 El Manifiesto de la Caché: Por qué es el Pilar de Vida o Muerte en Firebase

> [!IMPORTANT]
> **La regla de oro económica de Firestore:**
> Cada documento servido desde la caché local del cliente cuesta **\$0.00 y exactamente 0 lecturas de cuota diaria**.
> La caché no es solo una mejora de velocidad o UX: **es el único mecanismo que permite mantener una app con miles de usuarios activos dentro del Spark Plan gratuito de por vida.**

#### La Ecuación del Desastre sin Caché:
Si tienes **2,000 usuarios activos diarios (DAU)** que abren la app 3 veces al día y ven 15 documentos por sesión:
- **Sin Caché (Directo a Servidor):** $2,000 \times 3 \times 15 =$ **90,000 lecturas/día**.
  *Resultado:* Supera el límite gratuito diario de 50,000 lecturas antes de las 15:00 hs. La base de datos arroja `RESOURCE_EXHAUSTED` y la app deja de funcionar.
- **Con Caché Bien Optimizada (85% Hit Ratio):** Solo el 15% de las peticiones van a la nube = **13,500 lecturas/día**.
  *Resultado:* **Consumes solo el 27% de la cuota diaria gratuita.** Te sobran 36,500 lecturas para absorber picos y crecimientos de usuarios sin pagar \$1.00 USD.

#### La Arquitectura en 3 Capas de Caché:
1. **L1 (Memoria RAM):** Instantánea (< 1 ms). Deduplica promesas en vuelo (In-Flight Request Coalescing) y estado reactivo.
2. **L2 (Disco Local):** Persistente (5–15 ms). IndexedDB en navegadores web y SQLite/LevelDB en iOS y Android. Sobrevive a reinicios del dispositivo.
3. **L3 (Edge CDN):** Servidores perimetrales de Firebase Hosting (20–40 ms). Almacena Firestore Bundles y catálogos estáticos; 0 lecturas directas a la base de datos.

*Consulta la guía completa de implementación, SWR y metadata en [references/cache_mastery_guide.md](references/cache_mastery_guide.md).*

---

### 2.1 Cache-First Architecture (Offline Persistence)

Firestore incluye un motor de caché local en disco (IndexedDB en Web, SQLite/LevelDB en Mobile). Configúralo para reutilizar lecturas previas en lugar de volver a consultar los servidores de Google.

#### En TypeScript / Web:
```typescript
import { initializeFirestore, persistentLocalCache, persistentMultipleTabManager } from "firebase/firestore";

// Habilitar caché persistente multi-pestaña optimizada
const db = initializeFirestore(app, {
  localCache: persistentLocalCache({
    tabManager: persistentMultipleTabManager()
  })
});

// Forzar lectura desde caché para datos que rara vez cambian (catálogos, perfiles)
import { getDocFromCache, getDocFromServer, doc } from "firebase/firestore";

async function getDocumentOptimized(collectionName: string, id: string) {
  const docRef = doc(db, collectionName, id);
  try {
    // 1. Intentar desde caché local (Costo: 0 lecturas de cuota)
    return await getDocFromCache(docRef);
  } catch (e) {
    // 2. Si no existe en caché, ir al servidor (Costo: 1 lectura)
    return await getDocFromServer(docRef);
  }
}
```

#### En Flutter / Dart:
```dart
import 'package:cloud_firestore/cloud_firestore.dart';

Future<DocumentSnapshot<Map<String, dynamic>>> getCachedOrServer(String docPath) async {
  final ref = FirebaseFirestore.instance.doc(docPath);
  try {
    // Costo: 0 lecturas en servidor si está en disco local
    return await ref.get(const GetOptions(source: Source.cache));
  } catch (_) {
    // Si no está en caché o falló, traer de red
    return await ref.get(const GetOptions(source: Source.server));
  }
}
```

---

### 2.2 Consultas de Agregación Nativas (`count`, `sum`, `average`)

> [!IMPORTANT]
> **Ahorro masivo:** Para saber cuántos elementos hay en una colección de 5,000 productos:
> - ❌ `(await getDocs(query)).size` descarga **5,000 documentos** = **5,000 lecturas gastadas**.
> - ✅ `getCountFromServer(query)` ejecuta una agregación en servidor = **¡Solo 1 lectura consumida por cada 1,000 índices coincidentes (máx 5 lecturas)!**

```typescript
import { collection, query, where, getCountFromServer, getAggregateFromServer, sum, average } from "firebase/firestore";

// Conteo a costo ultra-bajo
const coll = collection(db, "orders");
const q = query(coll, where("status", "==", "completed"));
const snapshot = await getCountFromServer(q);
console.log("Total órdenes:", snapshot.data().count); // Consume fracción mínima de cuota

// Suma y promedio agregados sin transferir documentos
const statsSnapshot = await getAggregateFromServer(q, {
  totalVendido: sum("amount"),
  promedioTicket: average("amount")
});
console.log("Total:", statsSnapshot.data().totalVendido);
```

---

### 2.3 Firestore Data Bundles (Datos Estáticos a Costo Cero de DB)

Si tienes datos que cambian poco (catálogo de productos, listas de países, configuraciones globales), no hagas que cada usuario consulte Firestore.
Empaqueta los documentos en un **Firestore Bundle** con una Cloud Function o script nocturno, súbelo a Firebase Hosting / Cloud Storage (con CDN caching), y cárgalo en el cliente:

```typescript
// En el cliente Web:
import { loadBundle, namedQuery } from "firebase/firestore";

async function loadProductsCatalog() {
  // Descarga el bundle estático desde la CDN de Firebase Hosting (0 lecturas de Firestore)
  const response = await fetch("/static-bundles/products-catalog.bundle");
  const bundleBuffer = await response.text();
  
  await loadBundle(db, bundleBuffer);
  
  // Ahora la consulta se resuelve 100% desde la caché local del dispositivo
  const q = await namedQuery(db, "all-products");
  const snapshot = await getDocsFromCache(q);
  return snapshot.docs.map(d => d.data());
}
```

---

### 2.4 Paginación por Cursor (`startAfter`)

Nunca utilices `offset()` de manera descuidada: Firestore cobra las lecturas de los documentos saltados.
Usa **paginación basada en punteros (cursor pagination)**:

```typescript
import { collection, query, orderBy, limit, startAfter, getDocs, QueryDocumentSnapshot } from "firebase/firestore";

async function fetchNextPage(lastVisibleDoc: QueryDocumentSnapshot | null, pageSize: number = 20) {
  let q = query(
    collection(db, "posts"),
    orderBy("createdAt", "desc"),
    limit(pageSize) // Estrictamente acotado
  );

  if (lastVisibleDoc) {
    q = query(q, startAfter(lastVisibleDoc));
  }

  const snapshot = await getDocs(q);
  const lastDoc = snapshot.docs[snapshot.docs.length - 1] || null;
  const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

  return { items, lastDoc };
}
```

---

### 2.5 Gestión Disciplinada de Listeners en Tiempo Real (`onSnapshot`)

Los listeners en tiempo real cobran **1 lectura por cada documento inicial retornado**, y luego **1 lectura por cada documento que sufra una modificación mientras el listener esté activo**.

**Reglas de Oro:**
1. **Evitar `onSnapshot` en feeds generales o listas infinitas:** Usa `getDocs` paginado. Reserva `onSnapshot` únicamente para chats activos, tableros de pedidos en vivo o notificaciones directas.
2. **Siempre almacenar y llamar al `unsubscribe` al desmontar el componente o widget:**

```typescript
// En React / Vue:
useEffect(() => {
  const q = query(collection(db, "chats", chatId, "messages"), orderBy("timestamp"), limit(50));
  
  // Suscripción
  const unsubscribe = onSnapshot(q, (snapshot) => {
    // Procesar cambios
  });

  // OBLIGATORIO: Desuscribir en el cleanup
  return () => unsubscribe();
}, [chatId]);
```

```dart
// En Flutter (StatefulWidget / StateNotifier):
StreamSubscription? _sub;

@override
void initState() {
  super.initState();
  _sub = FirebaseFirestore.instance
      .collection('live_alerts')
      .limit(10)
      .snapshots()
      .listen((data) => updateUI(data));
}

@override
void dispose() {
  _sub?.cancel(); // OBLIGATORIO: previene consumo de cuota fantasma en background
  super.dispose();
}
```

---

### 2.6 Modelado de Datos: Documentos Delgados vs Subcolecciones

Firestore tiene un límite de **1 MB por documento**. Si guardas un array de 1,000 comentarios dentro del documento de un post, cada usuario que vea el post descargará 1 MB de datos y gastará ancho de banda.

- **Documento Delgado (`/posts/{postId}`):** Título, autor, extracto, timestamp, contadores pre-calculados (`commentsCount: 142`, `likesCount: 520`).
- **Subcolección (`/posts/{postId}/comments/{commentId}`):** Comentarios detallados paginados con `limit(10)`.

---

### 2.7 Deduplicación de Peticiones en Vuelo (In-Flight Request Coalescing)

Si 5 componentes en una misma pantalla (ej. Avatar, Header, Sidebar, Perfil, Comentarios) solicitan el mismo documento de usuario al renderizarse simultáneamente, el cliente enviará 5 lecturas de red.
**Deduplica las promesas en memoria:**

```typescript
// Wrapper con deduplicación y coalescing en vuelo
const inFlightRequests = new Map<string, Promise<any>>();

export async function fetchDocDeduplicated<T>(docPath: string): Promise<T> {
  if (inFlightRequests.has(docPath)) {
    // Si ya hay una petición en curso para este documento, reutiliza la misma promesa
    return inFlightRequests.get(docPath)!;
  }

  const promise = (async () => {
    try {
      const snap = await getDocFromCache(doc(db, docPath))
        .catch(() => getDocFromServer(doc(db, docPath)));
      return { id: snap.id, ...snap.data() } as T;
    } finally {
      // Liberar al terminar
      inFlightRequests.delete(docPath);
    }
  })();

  inFlightRequests.set(docPath, promise);
  return promise;
}
```
*Impacto:* 5 componentes pidiendo `/users/octavio` en el mismo ciclo de render consumen **exactamente 1 lectura de Firestore**, no 5.

---

## 3. Optimización Extrema de Escrituras (Write Optimizations)

### 3.1 Atómicos Nativos sin Lectura Previa (`FieldValue.increment` / `arrayUnion`)

> [!CAUTION]
> **Antipatrón Destructivo:** Leer un documento para sumar 1 a un contador y volver a escribirlo:
> 1. `getDoc` = 1 lectura.
> 2. Calcular `count + 1`.
> 3. `updateDoc` = 1 escritura.
> **Total:** 1 lectura + 1 escritura + riesgo de colisión por concurrencia.

**Solución Óptima:**
```typescript
import { doc, updateDoc, increment, arrayUnion, serverTimestamp } from "firebase/firestore";

const postRef = doc(db, "posts", "post_123");

// Cero lecturas, 1 escritura atómica inmune a concurrencia:
await updateDoc(postRef, {
  viewsCount: increment(1),
  tags: arrayUnion("firebase", "optimization"),
  lastUpdatedAt: serverTimestamp()
});
```

---

### 3.2 Lotes Atómicos (`writeBatch`) y Agrupación Masiva

Para crear, actualizar o borrar múltiples documentos, no lances promesas individuales en un bucle:

```typescript
import { writeBatch, doc } from "firebase/firestore";

async function saveMultipleItems(items: Array<{ id: string; data: any }>) {
  // Límite de Firestore: hasta 500 operaciones por batch
  const batch = writeBatch(db);

  for (const item of items.slice(0, 500)) {
    const ref = doc(db, "items", item.id);
    batch.set(ref, item.data, { merge: true });
  }

  // Se envía en una única transacción de red compacta
  await batch.commit();
}
```

---

### 3.3 Debouncing y Throttling en el Cliente

En editores de texto, campos de entrada o seguimiento de posición, **nunca escribas a Firestore en cada pulsación de tecla (`onChange`)**. Agrupa los cambios con un debounce de 2 a 5 segundos:

```typescript
import debounce from "lodash.debounce";

const debouncedSave = debounce(async (docId: string, content: string) => {
  const ref = doc(db, "notes", docId);
  await updateDoc(ref, {
    content,
    updatedAt: serverTimestamp()
  });
  console.log("Nota guardada en Firestore tras inactividad del usuario.");
}, 3000); // Esperar 3 segundos de silencio antes de escribir
```

---

### 3.4 Actualizaciones Parciales Quirúrgicas (`updateDoc`)

Evita `setDoc` para modificar un solo campo de un documento existente:
```typescript
// ❌ setDoc sin merge sobrescribe o transfiere todo el objeto
await setDoc(userRef, { lastLogin: new Date() }, { merge: true });

// ✅ updateDoc con notación de punto actualiza campos anidados específicos con mínimo payload:
await updateDoc(userRef, {
  "metadata.lastLogin": serverTimestamp(),
  "preferences.darkMode": true
});
```

---

### 3.5 Contadores Distribuidos (Distributed Sharded Counters)

Firestore tiene un límite de rendimiento físico de **aproximadamente 1 escritura por segundo por documento individual**. Si miles de usuarios dan "Like" al mismo tiempo en un evento masivo, el documento se bloqueará con errores de contención.

Divide el contador en $N$ fragmentos (*shards*):
```typescript
// Incrementar un shard aleatorio (1 de 10 shards)
const numShards = 10;
const randomShard = Math.floor(Math.random() * numShards).toString();
const shardRef = doc(db, "posts", "post_123", "shards", randomShard);

await updateDoc(shardRef, {
  count: increment(1)
});

// Para leer el total a costo controlado, usar agregación nativa:
const shardsColl = collection(db, "posts", "post_123", "shards");
const snapshot = await getAggregateFromServer(shardsColl, {
  totalLikes: sum("count")
});
console.log("Total Likes:", snapshot.data().totalLikes);
```

---

### 3.6 Purgado Automático con Firestore TTL (Time To Live)

Para borrar registros de auditoría, sesiones expiradas o notificaciones antiguas:
- ❌ **No crees una Cloud Function programada (cron)** que busque documentos y llame a `deleteDoc` (gasta lecturas, escrituras y minutos de Cloud Functions).
- ✅ **Habilita Firestore TTL nativo:**
  1. Agrega un campo con marca de tiempo (ej. `expireAt: Timestamp`).
  2. En la consola de Firebase o via gcloud CLI ejecuta:
     ```bash
     gcloud firestore fields ttls update expireAt --collection-group=notifications --enable-ttl
     ```
  3. Los servidores de Google Firestore eliminarán los documentos expirados en segundo plano **sin consumir cuota de eliminaciones diarias del Spark Plan ni cómputo de Functions**.

---

### 3.7 Optimización de Índices (`firestore.indexes.json`)

De manera predeterminada, Firestore indexa automáticamente **todos los campos** de todos los documentos. Cada índice mantenido cuenta como escritura oculta cuando el documento cambia.
- Si tienes campos con texto muy largo, mapas complejos o arrays que **nunca vas a filtrar ni ordenar con `where` o `orderBy`**, crea una **exención de índice de un solo campo (Index Exemption)** en `firestore.indexes.json`:

```json
{
  "indexes": [],
  "fieldOverrides": [
    {
      "collectionGroup": "posts",
      "fieldPath": "richBodyHtml",
      "indexes": []
    }
  ]
}
```

---

### 3.8 Cola de Escritura Agrupada Automática (Auto-Flushing Write Buffer Queue)

En aplicaciones interactivas donde el usuario realiza múltiples acciones seguidas (marcar tareas como completadas, editar campos, alternar interruptores), encolar cada escritura de forma independiente genera decenas de llamadas HTTP a Firestore.
**Implementa un buffer de escritura que agrupe operaciones en batches automáticamente cada 1.5 segundos o al alcanzar 50 operaciones:**

```typescript
class FirestoreWriteBuffer {
  private queue: Array<{ ref: any; data: any; merge: boolean }> = [];
  private timer: NodeJS.Timeout | null = null;
  private readonly maxBatchSize = 50;
  private readonly flushDelayMs = 1500;

  public queueWrite(ref: any, data: any, merge = true) {
    this.queue.push({ ref, data, merge });

    if (this.queue.length >= this.maxBatchSize) {
      this.flush();
    } else if (!this.timer) {
      this.timer = setTimeout(() => this.flush(), this.flushDelayMs);
    }
  }

  public async flush() {
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    if (this.queue.length === 0) return;

    const toCommit = this.queue.splice(0, 500); // Límite de batch de Firestore
    const batch = writeBatch(db);

    for (const op of toCommit) {
      batch.set(op.ref, op.data, { merge: op.merge });
    }

    try {
      await batch.commit();
      console.log(`📦 Batch buffer: ${toCommit.length} escrituras agrupadas en 1 sola transacción.`);
    } catch (err) {
      console.error("Error al commitear batch buffer:", err);
    }
  }
}

export const writeBuffer = new FirestoreWriteBuffer();
```
*Impacto:* Si un usuario tilda 20 checkboxes en 3 segundos, se ejecutan en **1 sola transacción agrupada**, ahorrando conexiones y estabilizando el consumo.

---

## 4. Reglas de Seguridad a Costo Cero (Zero-Read Rules)

> [!IMPORTANT]
> Cada función `get(/databases/...)` o `exists(...)` invocada dentro de `firestore.rules` **cuenta como 1 lectura de documento facturable**.
> Si evalúas permisos de rol leyendo un documento de usuario en cada petición, duplicarás o triplicarás el consumo de lecturas de tu app.

### 4.1 La Solución: Custom Claims en el Token de Auth
Empaqueta roles (`admin`, `moderator`, `teamId`) dentro del JWT del usuario usando el Admin SDK en el login o registro:

```javascript
// firestore.rules
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // 0 lecturas: Valida directo desde el JWT criptográfico
    function isAdmin() {
      return request.auth != null && request.auth.token.role == 'admin';
    }

    function isMemberOf(orgId) {
      return request.auth != null && request.auth.token.orgId == orgId;
    }

    match /organizations/{orgId}/projects/{projectId} {
      allow read: if isMemberOf(orgId);
      allow write: if isAdmin();
    }
  }
}
```

*Revisa el compendio completo de reglas en [references/rules_zero_cost.md](references/rules_zero_cost.md).*

---

## 5. Protocolo de Pruebas con Local Emulator Suite

### 5.1 Arranque de Emuladores
```bash
# Iniciar emuladores con UI interactiva en localhost:4000
firebase emulators:start
```

### 5.2 Conexión Universal (Node / Frontend / Flutter)

Verifica que tu código aplique el interruptor condicional según entorno:
```typescript
if (process.env.NODE_ENV !== "production") {
  connectFirestoreEmulator(db, "127.0.0.1", 8080);
  connectAuthEmulator(auth, "http://127.0.0.1:9099");
}
```

---

## 6. Auditoría Automatizada y Herramientas de Validación

Esta skill incluye un analizador estático en Python para revisar codebases antes de desplegar o hacer commits.

### Ejecutar el Validador:
```bash
python .agents/skills/firebase-optimization/scripts/audit_firebase_code.py <ruta_de_tu_codigo> [--strict]
```

### Reglas que valida el script:
1. `TEST-NO-EMULATOR`: Archivos de test que inicializan Firebase sin conectar emuladores ni usar `demo-`.
2. `RULES-EXTRA-READ`: Uso de `get()` o `exists()` en `firestore.rules`.
3. `QUERY-NO-LIMIT`: Consultas a colecciones sin cláusula `.limit()` o `.limitToLast()`.
4. `N-PLUS-ONE-LOOP`: Llamadas a Firestore (`getDoc`, `setDoc`, etc.) dentro de bucles `for`, `forEach` o `.map`.
5. `MANUAL-INCREMENT`: Lectura seguida de `+ 1` manual en lugar de `FieldValue.increment(1)`.
6. `UNCHECKED-LISTENER`: Invocación de `onSnapshot` sin almacenar la función de desuscripción.
7. `STORAGE-NO-CACHE-CONTROL`: Subidas a Cloud Storage sin encabezados de caché inmutable.
8. `RTDB-ROOT-LISTENER`: Listeners en la raíz de Realtime Database.
9. `AUTH-PHONE-QUOTA-RISK`: Autenticación por SMS con riesgo de agotar el cupo de 10 SMS/día.

### 6.2 Simulador y Calculadora de Cuotas Spark (`quota_calculator.py`)

Modela matemáticamente el tráfico de tu aplicación antes de escribir una sola línea de código para saber si vivirá gratis en Spark:

```bash
# Simular 3,000 usuarios activos diarios con 80% de acierto de caché local:
python .agents/skills/firebase-optimization/scripts/quota_calculator.py --dau 3000 --reads 15 --writes 3 --cache-ratio 0.80
```
El script generará una auditoría visual con alertas en verde (Seguro), amarillo (Alerta > 75%) y rojo (Excedido), con diagnósticos específicos de mitigación.

---

## 7. Modelado NoSQL de Consumo Mínimo (5 Recetas Clave)

El diseño de tu esquema en Firestore determina el 80% de tus costos. Consulta las recetas completas con código en **[references/data_modeling_recipes.md](references/data_modeling_recipes.md)**:

1. **Likes y Reacciones:** Contador atómico en el doc padre (`likesCount`) + subcolección `/likes/{userId}` con docId del usuario (comprobación de estado en 1 sola lectura desde caché).
2. **Timeline / Feed de Actividad:** Fan-out on Read con bloques `where in` de 30 autores y paginación `limit(15)`. Prohibido el Fan-out on Write en usuarios con más de 10 seguidores dentro del plan Spark.
3. **Catálogo con Filtros:** Firestore Bundle o JSON estático en CDN para catálogos < 10,000 productos. Búsqueda y filtrado facetado 100% en memoria en el cliente (\$0 costo, 0 ms latencia).
4. **Insignia de No Leídos en Chats:** Puntero numérico incremental en el chat (`lastMessageNumber`) vs puntero de lectura en el usuario (`lastReadNumber`). Resta aritmética sin leer mensajes individuales.
5. **Carrito de Compras:** Un único documento con mapa consolidado de productos en lugar de un documento por ítem.

---

## 8. Matriz Multiproducto: Firestore vs Realtime Database vs Storage

Aprende a desviar cargas de trabajo entre servicios para no agotar cuotas. Guía detallada en **[references/storage_and_rtdb_optimization.md](references/storage_and_rtdb_optimization.md)**:

| Carga de Trabajo / Evento | Servicio Recomendado | Razón Técnica de Ahorro |
|---|---|---|
| **Presencia online / Conectado** | 🏆 **Realtime Database** | RTDB no cobra por operaciones; usa `.info/connected` + `onDisconnect` con bytes mínimos. |
| **Coordenadas GPS / Telemetría continua** | 🏆 **Realtime Database** | Enviar 1 ping cada 2s en Firestore colapsa las 20k escrituras/día en minutos. En RTDB consume centavos de egress. |
| **Fotos y Avatares de Usuario** | 🏆 **Cloud Storage + WebP** | Comprimir a WebP en el navegador con HTML5 Canvas (<150 KB) y header `Cache-Control: immutable`. |
| **Consultas complejas, filtros y ordenación** | 🏆 **Firestore** | Índices compuestos, consistencia fuerte y agregaciones nativas (`count`, `sum`). |
| **Páginas y Catálogos Públicos** | 🏆 **Firebase Hosting + CDN** | Cachear respuestas HTTP con `s-maxage=3600` para reducir ejecuciones de Cloud Functions en un 99%. |

---

## 9. Blindaje Definitivo: Kill-Switch Automático de Facturación

Si decides activar el plan Blaze para usar Cloud Functions con llamadas externas o extensiones, **Google Cloud no apaga tus servicios por defecto al superar tu presupuesto**.

Para estar 100% protegido contra facturas sorpresa o bucles infinitos:
1. Configura una alerta de presupuesto de **\$1.00 USD** en Google Cloud Billing conectada a un tópico de Cloud Pub/Sub.
2. Despliega la Cloud Function de apagado de emergencia detallada en **[references/kill_switch_billing.md](references/kill_switch_billing.md)**.
3. Al alcanzar \$1.00 USD, la función desvincula la tarjeta de crédito del proyecto automáticamente, deteniendo cualquier cobro adicional al instante.

---

## 10. Checklist Maestro de Entrega para Producción

Antes de enviar a producción cualquier desarrollo con Firebase:

- [ ] **Tests 100% aislados:** Ningún test corre contra la nube; todos usan `Local Emulator Suite` con prefijo `demo-` o mocks.
- [ ] **Auditoría Estática Aprobada:** El script `audit_firebase_code.py` corre con 0 violaciones críticas.
- [ ] **Simulación de Tráfico en Verde:** El script `quota_calculator.py` confirma que el DAU proyectado cabe en el Spark Plan.
- [ ] **Todas las listas acotadas:** Ningún `collection()` o `query()` se ejecuta sin `limit(...)`.
- [ ] **Caché Offline / Persistencia activada:** La app tiene activada la caché en disco en el cliente.
- [ ] **Deduplicación de Peticiones:** Consultas simultáneas al mismo documento usan in-flight coalescing.
- [ ] **Incrementos atómicos:** Todos los contadores usan `FieldValue.increment()`.
- [ ] **Zero-Read Rules:** `firestore.rules` utiliza Custom Claims y wildcards de ruta; sin llamadas a `get()` o `exists()`.
- [ ] **Cleanup de Listeners:** Todos los `onSnapshot` llaman a su `unsubscribe` en el ciclo de vida de desmontaje.
- [ ] **Storage Optimizado:** Imágenes convertidas a WebP en cliente y subidas con `cacheControl: "public, max-age=31536000, immutable"`.
- [ ] **Políticas TTL activas:** Colecciones temporales (notificaciones, carritos viejos) tienen TTL habilitado sin Cloud Functions.
- [ ] **Kill-Switch / Alertas de Facturación:** Presupuesto de \$1.00 USD y alertas de email configuradas en GCP Console.

