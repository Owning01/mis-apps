---
name: generador-fotos
description: Genera y edita imágenes con la cuenta del usuario (Google Flow / Nano Banana y Gemini) sin API key, y las deja en disco. Un solo comando o una sola llamada HTTP. Úsala cuando pidan crear una imagen, un fondo de pantalla, arte conceptual, editar una imagen existente, o recuperar las ya generadas.
---

# Generador Fotos

Puente local que maneja el **Chrome real del usuario** (su perfil, su sesión, sin banderas)
y devuelve las imágenes al harness. No interrumpe lo que el usuario está haciendo: todo
el trabajo ocurre en un **grupo de pestañas colapsado** llamado "Generador Fotos".

## La forma más fácil: un comando

```bash
cd G:\Proyectos\19-ExtensionesChrome\generador-fotos
python generar.py "un faro en un acantilado al atardecer" --fondo
```

Encuela, espera, copia la imagen al Escritorio y (con `--fondo`) la pone de fondo de
pantalla. Al terminar imprime la ruta del archivo.

| Opción | Para qué |
|---|---|
| `--modelo "Nano Banana Pro"` | máximo detalle (`Nano Banana 2.1`, `Nano Banana 2 Lite`) |
| `--aspecto 16:9` | 16:9, 4:3, 1:1, 3:4, 9:16 |
| `--fondo` | además la pone de fondo de pantalla |
| `--espera 300` | segundos máximos |
| `--estado` | ver si el puente y la extensión están conectados |

También `generar.cmd "un gato"` para doble clic.

## Editar una imagen existente (el caso importante)

**Cómo se "menciona" una imagen en Flow**: se adjunta como **ingrediente** de la petición
y el prompt describe el cambio. La extensión lo hace sola:

```bash
# 1. Ver qué hay disponible (id, nombre, ruta)
curl -s http://127.0.0.1:8788/images

# 2. Editar pasando el id (o una ruta directa a un archivo)
curl -s -X POST http://127.0.0.1:8788/flow/generate \
  -H "Content-Type: application/json" \
  -d "{\"prompt\":\"cambiale el cielo por una aurora boreal, conservá todo lo demás\",
       \"image\":\"<id-o-ruta>\",
       \"model\":\"Nano Banana Pro\"}"
```

Por dentro: el puente resuelve el id a una ruta de archivo, la extensión abre
"Añadir ingredientes" y pone el archivo en el `input[type=file]` con el CDP
`DOM.setFileInputFiles`. Eso es lo que hace que Flow lo tome como ingrediente real.

Buenas prácticas al editar:
- Un cambio por vez y describir **qué se conserva** ("cambiá el fondo, conservá el sujeto").
- El mismo modelo que se usó para generarla da resultados más predecibles.
- Las imágenes originales quedan en `data\images\`; editar no las borra.

## Uso por HTTP (para el harness)

| Ruta | Qué hace |
|---|---|
| `GET /health` | `extension_connected` dice si está todo listo |
| `GET /doctor` | **Diagnóstico completo**: dice qué falta y qué hacer |
| `GET /log?n=60` | Últimas líneas del registro, para depurar sin abrir archivos |
| `POST /flow/generate` | Flow / Nano Banana. **El bueno para imágenes y edición** |
| `POST /generate` | Gemini (chat y edición conversacional) |
| `GET /result?id=X` | Resultado: `text`, `images[].file`, `error`, `avisos` |
| `GET /tasks` | Pendientes |
| `POST /flow/state` | Estado del proyecto de Flow (composer, ajustes, imágenes) |
| `POST /state` | Radiografía del DOM de Gemini |
| `GET /images` · `GET /image?id=Y` | Listar y bajar lo ya generado |
| `POST /capture` | Guardar lo que ya está en pantalla |

**Ante cualquier duda, empezar por `GET /doctor`**: devuelve `ok`, la lista de `problemas`
y los `pasos` concretos a seguir.

Campos de `/flow/generate`: `prompt`, `model`, `aspect`, `image`, `wait_seconds`,
`want_images`, `max_images`.

### Un pedido a la vez (respetar)

- Si ya hay uno en curso: **`409`** con `pending_id`. No se encola: esperá.
- Mínimo **30 s** entre pedidos, tope **40 por hora**. Si te pasás: **`429`** con `retry_after`.
- Los pedidos rebotados no gastan el turno.
- Si el Chrome del usuario está cerrado, el puente **lo abre solo** (su perfil, sin banderas)
  y espera a que la extensión enganche. Si no hay ninguna pestaña de Flow, la extensión la abre
  **detrás y sin foco**; si ya hay una abierta, **trabaja sobre esa** (no abre otra).

## Cómo está hecho (para no repetir errores)

```
harness --HTTP--> GeneradorFotos.exe --WebSocket--> extensión --> Chrome del usuario
                        |                                              |
                        +---------- imágenes en disco <-----------------+
```

- **No abre un Chrome propio.** Un perfil aparte queda vacío (sin sesión) y no sirve.
- **No usa headless ni CDP externo.** Nada de `--enable-automation` ni depuración remota.
- **La entrada de Flow la manda el API `debugger` de Chrome.** Es obligatorio: Flow **ignora
  los eventos sintéticos** (`element.click()` y `KeyboardEvent` no hacen nada; con una tecla
  real sí genera).
- **Una sola sesión de debugger por tarea** (`cdpAbrir` / `cdpCerrar`). Antes cada acción
  adjuntaba y soltaba (8-10 veces por envío) y cada attach **cambia el alto del viewport**,
  así que las coordenadas medidas antes quedaban corridas.
- **La pestaña NO se mueve: ese es el corazón del diseño actual.** Con
  `Emulation.setFocusEmulationEnabled` + `Page.setWebLifecycleState("active")` la página cree
  que tiene el foco y que está activa, así que Flow dibuja la caja y el texto entra **con la
  pestaña oculta**. Medido con `POST /flow/probe {"forzar":"cdp"}`: `visible: hidden`,
  `hasComposer: true`, `entro: true`. Sin ventanas nuevas, sin vista dividida, sin robar el
  foco. Y como la página está marcada activa, Chrome deja de congelarle los timers: el estado
  de Flow (Detener, resultados) se actualiza de verdad (importante: una generación de Nano
  Banana Pro pasa de 300 s y antes era invisible hasta el final).
- **Una sola pestaña de Flow, siempre la misma.** Si ya hay una abierta se usa ESA y recién se
  crea si no hay ninguna. El id se recuerda en `chrome.storage.local` (`storage.session` se
  borra en cada recarga de la extensión y por eso abría una pestaña nueva cada vez). La
  pestaña del usuario no se toca: ni grupo, ni ventana, ni foco.
- **La espera vive en el service worker**, no en la página: en una pestaña oculta Chrome frena
  los timers de la página (hasta una vez por minuto). Se consulta liviano (`QUICK_STATE`) cada
  1 s y las imágenes nuevas se cuentan **por URL**, no por `naturalWidth`: una
  `<img loading=lazy>` oculta no se descarga, queda en 0, y con ese criterio se perdían
  generaciones enteras (150 s de espera y un fracaso falso).
- **Latido cada 5 s** desde el puente: sin eso Chrome mata el service worker a los ~30 s.
- **Auto-reparación**: si el content script quedó viejo (no se actualizan al recargar la
  extensión), la extensión inyecta el script y solo como último recurso recarga la pestaña.

## Rendimiento medido (cronómetro por fase)

Cada resultado trae `tiempos` con las fases. Lo del sistema, medido en corridas reales:

| Fase | Antes | Ahora | Qué la define |
|---|---|---|---|
| Pestaña lista | 1,5 s | **0 s** | se reusa la pestaña que ya existe |
| App lista | 90,2 s | **0 s** | esperar a que Flow cargue (con la sesión CDP la página no se congela) |
| Escritura | 1,7 s | **0,3 s** | `insertText` + verificación por condición (60 ms) |
| Ajustes | 8,0 s | **0 s** | si ya están puestos no se abre el panel (memoria por proyecto) |
| Envío | 43,1 s | **6 s** | clic real en el botón + confirmar que arrancó |
| **Total del sistema** | **144 s** | **~7 s** | 20 veces más rápido |

**La generación en sí tarda 5 a 13 minutos y no es culpa del sistema**: Flow encola y Nano
Banana Pro es lento (medido: 305 s una vez, ~12 min otra). Por eso `--espera` es 1200 s:
cortar antes da un fracaso falso, y esperar de más no cuesta nada porque el sistema vuelve
en cuanto aparece la imagen.

## Trampas ya resueltas

| Síntoma | Causa | Solución aplicada |
|---|---|---|
| Se desconecta cada ~30 s | Chrome mata el SW por inactividad | Latido cada 5 s (por el event loop, no desde el hilo) |
| No arranca al abrir Chrome | El SW no tiene evento que lo despierte | `chrome.runtime.onStartup` + `alarm` cada minuto |
| "no pude abrir los ajustes" | El botón de ajustes recién aparece con texto | Orden: escribir → ajustar → Enter |
| "la generación no arrancó" | Los clics de ajustes roban el foco | Refocalizar antes del Enter, **verificar que el texto haya entrado**, y si no arranca, clic real por CDP y activación breve de la pestaña |
| El texto no entra (y el botón queda deshabilitado) | `Input.insertText` sin foco real | Comprobar `composerText` tras escribir; si no entró, tecla por tecla |
| Falla a los 25 s en vez de 45 s | El content script no se actualiza solo | `ensureFlowContent` compara versión y recarga |
| `NameError: new_id` | Un parche borró la función | Revisar que todo helper exista tras editar |
| El latido no enviaba nada | `ws.send()` desde otro hilo | `asyncio.run_coroutine_threadsafe(...)` |
| **Endpoint que se cuelga para siempre** (`TimeoutError` / `RemoteDisconnected` en el cliente) | `do_POST` ya leyó el cuerpo y el handler lo lee **otra vez**: la segunda lectura no tiene bytes | `_read_json` cachea el cuerpo (lo devuelve igual si se pide de nuevo) |
| **Una excepción en un endpoint no deja rastro** | Sin `handle_error`, el servidor cierra la conexión y no dice nada | `ApiServer.handle_error` escribe la excepción en el log |
| **La extensión sigue con código viejo y no hay forma de saberlo** | El SW viejo se mantiene vivo reconectando cada 3 s | `CODE_VERSION` en el hello + `/doctor` lo compara con el disco. Para forzar: `POST /extension/restart` (corta el latido, el SW duerme y vuelve con el código del disco) |
| El CLI se cae con `UnicodeEncodeError` | La consola de Windows usa cp1252 | `sys.stdout.reconfigure(encoding="utf-8", errors="replace")` |
| **Un parche dice que se aplicó pero no está en el archivo** | Los archivos de este proyecto son **CRLF** (medido: `background.js`, `flow.js`, `bridge.py`, `generar.py`); los patrones escritos en LF no coinciden y `str.replace` falla en silencio | Escribir los parches con `nl = "\r\n" if "\r\n" in texto else "\n"` y **abortar si el conteo de coincidencias no es el esperado** (no escribir nada). Confirmar después con un `grep` |
| **La extensión quedó muerta y no vuelve sola** | Se auto-recargó justo cuando el archivo tenía un error de sintaxis: el service worker no arranca, así que no se reconecta ni se auto-recarga (no hay código corriendo) | Es el **único** caso que necesita ⟳ en `chrome://extensions`. Antes de guardar: `node --check` en los dos JS |
| **Una generación tarda 5 minutos y no se ve nada** | Con la pestaña oculta, Flow no actualiza la interfaz (ni "Detener" ni resultados) hasta el final | La sesión CDP se abre **siempre** (página marcada activa) y el bucle de espera informa cada 30 s. `--espera` por defecto 600 s: Nano Banana Pro pasa de 300 s |
| **Dice "arrancó" y no arrancó** | La caja vacía también queda vacía si el texto se perdió | `arranco` marca esa señal sola como `fuerte: false` y el resultado lo dice. Si al final no hay imagen, se captura igual y se informa (la captura trae la última imagen aunque la cuenta falle) |
| **Crea una pestaña de Flow por pedido** | El id se guardaba en `chrome.storage.session`, que se borra cuando la extensión se recarga (y se recarga sola con cada cambio) | Guardarlo en `chrome.storage.local` y reusar cualquier pestaña de Flow abierta |
| **"La pestaña no responde" sin motivo** | Al inyectar una versión nueva de `flow.js` quedaban DOS listeners: el viejo contestaba primero con el contexto ya invalidado y `sendResponse` nunca llegaba (timeout de 8 s en todo) | El script nuevo da de baja al anterior (`removeListener` con el listener guardado en un global) |
| **Los ajustes se reaplican en cada pedido (~8 s)** | El modelo se leía del botón equivocado (devuelve vacío) y el aspecto **no existe en el DOM** con el panel cerrado | Leer el modelo del chip del composer y recordar lo aplicado por proyecto en `storage.local` |
| **`innerText` devuelve "" y todo se lee vacío** | `innerText` necesita layout, y con la pestaña oculta no lo hay | Usar `textContent` (helper `texto()`) |
| **Un rechazo de Flow se ve igual que "todavía generando"** | Nadie leía el texto de la tarjeta del resultado | `tarjetas()` y `panel` en el estado: ahí está el motivo (límite, error, etc.) |
| **Una tarea queda pendiente para siempre y el bucle se muere** | `chrome.debugger.sendCommand` y el `attach` **no tienen timeout propio** | `conTiempo()`: techo de 3 a 8 s para esas llamadas |
| **Un caracter raro en un log mata la conexión** | El puente imprime en la consola de Windows (cp1252): una flecha `→` en un log de la extensión lanzó `UnicodeEncodeError` y **cerró el WebSocket** | El `print` del puente tolera el error (`errors="replace"`) y en los logs de la extensión no se usan símbolos fuera de cp1252 |
| **`Script de Flow desactualizado` en bucle infinito** | La versión se declara en DOS archivos (`background.js` y `flow.js`) y quedaron distintas (20 contra 21): recargaba la pestaña en cada pedido y nunca coincidía | Subir **siempre** las dos juntas (van en el hello del puente y en `/doctor`) |
| **La pestaña quedaba oculta y la imagen aparecía tardísimo** | Tapada u **fuera de la pantalla**, Chrome marca la pestaña ocluida; con la ventana en un rincón visible el composer y los resultados se dibujan igual | Ventana propia **chica (520x420) abajo a la derecha, en pantalla y sin foco**, y comprobar `hasComposer` después de moverla |
| **Una generación tarda 5-13 min cuando el usuario ve menos de 1** | Flow **encola** por cuenta: si se disparan varios pedidos seguidos, los últimos esperan | Un pedido a la vez (el puente ya lo impone con `409`) y no medir con pedidos en paralelo |
| **`windows.getAll({windowTypes})` no devuelve nada y el error se pierde** | El `catch` vacío se comía la excepción y la creación fallaba después con otro error peor (`tab is not defined`) | `chrome.tabs.query({})` primero (siempre contesta) y `catch (e)` que **registra** el mensaje |
| **El puente queda dando 409 para siempre** | Un pendiente cuyo resultado nunca llega (se recargó la extensión o se cerró Chrome) bloquea todo pedido nuevo | Vencimiento a `wait_seconds + 60` y liberación al desconectarse la extensión |
| **Un socket viejo marca "desconectada" a la conexión nueva** | El SW reconecta y el cierre del socket anterior pisaba el estado | En el `finally`, limpiar solo si `state["ws_conn"] is websocket` |
| **Una web cualquiera puede manejar el puente** | Los POST a `127.0.0.1` y los WebSocket no pasan por CORS | Rechazar `Origin` ajeno, exigir `Content-Type: application/json` (eso obliga al preflight, que no contesta CORS), token en `data/token.txt` para el reinicio y solo imágenes de carpetas de usuario conocidas |
| Dos parches se pisan y una función desaparece (queda la llamada, no la definición) | Cada parche reescribe el archivo entero | Antes de dar por bueno un cambio: comprobar que cada `await funcionX(` tenga su `function funcionX` |
| La auto-recarga no dispara aunque el código cambió | La huella se guardaba en una variable y el service worker se reinicia | Guardarla en `chrome.storage.local`: `chrome.runtime.reload()` no relee el disco si no cambió el manifest, pero el `storage` sí persiste |
| `POST /extension/restart` no cambia la versión de código | El reinicio del worker **no** relee el disco en extensiones sin empaquetar | Solo `chrome.runtime.reload()` (o ⟳) relee los archivos |

## Qué más permite Flow (mapa, para seguir creciendo)

Verificado en la interfaz, todavía **sin automatizar** (son las próximas herramientas):

| Función | Dónde | Notas |
|---|---|---|
| **Editar imagen** | ingrediente + prompt | **Ya automatizado** (`image`) |
| **Varias generaciones** | modo vista "Lote" | El ajuste de vista lo habilita |
| **Vídeo (Veo)** | mismo composer | Flow es video-first; pide modelo de vídeo |
| **Escenas** | menú lateral `Escenas` | encadenar tomas |
| **Caracteres** | menú lateral `Caracteres` | consistencia entre imágenes |
| **Herramientas** | menú lateral `Herramientas` | galería de herramientas de la comunidad |
| **Instrucciones del agente** | botón en el composer | guía al agente de Flow |
| **Añadir ingredientes** | botón `add` del composer | subir referencia / colección / personaje |
| **Flow Music / Flow TV** | barra superior | audio y videos |
| **Reutilizar petición** | tarjeta de imagen | repetir el prompt de una imagen |
| **Favorito** | tarjeta de imagen | marcar resultados |
| **Descargar** | `Más opciones` de la tarjeta | la extensión ya captura por su cuenta |

**Modelos**: `Nano Banana Pro`, `Nano Banana 2.1` (por defecto), `Nano Banana 2 Lite`.
**Aspectos**: 16:9, 4:3, 1:1, 3:4, 9:16. Con cuenta PRO la interfaz dice "0 puntos".
**Composer**: es **ProseMirror** (`div[role="textbox"][contenteditable="true"]`).
**Indicador de generación**: `button[aria-label="Detener"]` visible.
**Imágenes**: `img` con `src` en `flow.google.com/asb/...`; necesitan la sesión, se bajan
desde la página con `fetch` + credenciales.

## Si algo falla

1. `python generar.py --estado` → puente y extensión vivos.
2. `data\bridge.log` → paso a paso de lo que intentó.
3. `POST /flow/state` → composer, ajustes y cantidad de imágenes de la pestaña.
4. Si el DOM de Flow cambia: ajustar selectores en `extension\flow.js` y subir
   `FLOW_SCRIPT_VERSION` (así las pestañas se recargan solas).
5. Si el DOM de Gemini cambia: `POST /state` y mirar el volcado.

## Reglas

- Un pedido a la vez. Nunca saltarse los límites de ritmo: protegen la cuenta del usuario.
- Nunca pedir cosas que el usuario no autorizó. Es su cuenta real.
- Automatizar estos sitios va contra sus términos de uso: no hay inmunidad garantizada.
- El repo está versionado: `git log` en `generador-fotos` cuenta la historia de las decisiones.
