# Computer Use — RUNLOG (resumido)
> 1 línea por tarea, sin coordenadas ni texto sensible. Rotar cada 20 líneas. No loggear password.

2026-08-31 21:30 — Chrome vertical Screen2 → groq.com → Continue with Google (UIA) → percatorone@gmail.com → /home OK → Create API Key OpenHer2 → Submit → Copy → gsk_... (1 key, 2 screenshots vert, jitter)
2026-08-31 22:00 — PR2 velocidad: bezier 12 pasos smoothstep + clipboard restore + batch verify:false (0 shot) + screenshot.bin 7.6k vs json 10k + find_element Rust 97ms + list_windows 97ms + pin safe ok (2 builds 10s)
2026-08-31 18:40 — Chrome google.com → perfil Octavio Gonzalez (ejemplo)

