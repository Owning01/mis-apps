# Computer Use — Errores y Aprendizajes
> Cada error nuevo se añade aquí y también en `ANTIPATTERNS.md`. Revisar antes de cada sesión.

## 2026-08-31 — Browser embebido rompía layout
- Síntoma: `POST /shell/browser/open` sin bounds → 0,0,800,600 tapaba toolbar, sin X.
- Fix: `api.rs hidden_default` + `main.rs ESC` + `BrowserPanel.tsx ESC+close` + `computer_login` externo Chrome.

## 2026-08-31 — Monitor equivocado (screenshots)
- Síntoma: `Screen::all()[0]` era secundario 768x1366, Chrome en primario 2048x1152.
- Fix: `detect_best_screen()` con `GetForegroundWindow/GetWindowRect` + `screen:1` primario.

## 2026-08-31 — Click offset DPI
- Síntoma: screenshot 800px → click sin re-escalar → 2.5x offset.
- Fix: `scale_x = screen_w/display_w`, `screen_x = api_x * scale_x` (Anthropic 1568/1.15MP).

## 2026-08-31 21:00 — Groq vertical + UIA vs coords
- Síntoma: `click 384,380` en 768x1366 vertical cayó en wallpaper (Chrome en 3200,0 960x1708, offset 2560 no sumado). `Get-Process chrome` sin `MainWindowHandle` no filtraba.
- Fix: guardar `LAST_OFFSET_X/Y = screen.display_info.x/y` y `scale_coords` añade `+ox` solo si `x<dw`; no sumar si ya es físico UIA. Usar `MoveWindow(2560,0,768,1366)` + `screen:0`.
- Síntoma: `Create API Key` `InvokePattern` no soportado ("Modelo no admitido").
- Fix: fallback `SetCursorPos+BoudingRectangle center + mouse_event` + jitter Bezier ±2px. Para Groq, `Submit` y `Copy` sí soportan `Invoke`.

## 2026-08-31 21:10 — Groq key solo se muestra una vez
- Síntoma: tras `Submit` el dialog muestra `gsk_...` una sola vez; si no se copia se pierde. `Tab+Enter` no disparaba `Submit`.
- Fix: buscar `Submit` por UIA `Name="Submit" Button` (3800,579) → `Invoke`, luego `Copy` (3768,354) → `Get-Clipboard` → `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`.

## 2026-08-31 22:00 — Screenshot.bin bloqueaba + pin poison
- Síntoma: `cargo build` con `Response::from_data(mime,raw)` no compila (1 arg, no 2) y `PINNED_SCREEN.unwrap()` poison tras panic bloqueaba `Screen::all` → timeout 120s en `/screenshot`.
- Fix: `Response::from_data(raw).with_header(Content-Type mime)` + `PINNED_SCREEN.lock().ok()` safe + safe pin `if let Ok(g)=lock` no `unwrap()`. Verificado `400x225 json 10k vs bin 7.6k -25%`.

## 2026-08-31 22:00 — Clipboard dejaba password 5s
- Síntoma: `type_text` con `len>20` hacía `set_text + Ctrl+V` sin restaurar → password quedaba en clipboard.
- Fix: guardar `prev = Clipboard::get_text`, tras `Ctrl+V` sleep 100ms y `set_text(prev)` o limpiar. MCP `computer_type` no expone password en log.

## 2026-08-31 22:00 — Batch siempre capturaba
- Síntoma: `computer_batch {screenshot:{width:400}}` capturaba siempre aunque no necesitara verify → 2 screenshots/task.
- Fix: `VerifyOpts {expect_change}` → `batch` retorna `Ok(None)` si `false`, evita `screenshot_inner2`. Test `verify:false → ok true sin screenshot` `verify:true → 400`.

