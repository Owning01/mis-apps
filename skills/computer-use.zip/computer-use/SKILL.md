---
name: computer-use
description: Control OS nativo de Windows en Modo Directo (63 tools, aceleración C# DesktopBridge, cero tokens visuales UIA, mini-insignia visual con exclusión de captura y escudo anti-cheat). Evasión anti-bot, clics semánticos y formularios atómicos.
---

# Computer Use — Skill Guide & Protocolo Operativo Nativo

> **Arquitectura en Modo Directo**: Opera directamente sobre el escritorio interactivo de Windows (`WinSta0\Default`) asistido por el puente nativo compilado `DesktopBridge.exe` y `NativeIndicator.exe`. No requiere emuladores ni arneses externos intermediarios (sin JEV). 63 herramientas de precisión.

---

## 1. 🚨 Protocolo de Señalización Visual Obligatoria (`computer_indicator`)

Para garantizar que el usuario siempre esté consciente de cuándo el agente está operando el equipo (sin ser intrusivo y protegiendo sus juegos), **todo flujo autónomo debe seguir este ciclo**:

### A. Al Iniciar la Tarea (Mostrar Indicador)
```json
computer_indicator {
  "action": "show",
  "message": "🤖 Agente operando...",
  "position": "top_left",
  "cursor": "working",
  "duration_ms": 10000
}
```
* **Mini-Badge Compacto Top-Left:** Se ancla en la esquina superior izquierda `(x: 14, y: 14)` con apenas **28px de altura**, fondo oscuro traslúcido y borde lumínico sutil para no tapar pestañas ni barras de herramientas.
* **Puntero del Ratón Activo:** Cambia el cursor del sistema a modo de trabajo (`working` = flecha con spinner; o `busy` = reloj de arena/espera).
* **🛡️ Exclusión por Hardware de Capturas (`WDA_EXCLUDEFROMCAPTURE = 0x11`):**
  Windows DWM renderiza la mini-insignia en el monitor físico del usuario pero la **excluye a nivel de kernel de cualquier captura de pantalla** (`computer_screenshot`, BitBlt, Windows Graphics Capture, recortes). Las capturas que analice el agente nunca contendrán el aviso.
* **🎮 Escudo Anti-Cheat Automático (Ricochet & Vanguard):**
  Si el sistema detecta ejecutables de juegos protegidos (`cod.exe`, `callofduty.exe`, `modernwarfare.exe`, `League of Legends.exe`, `LeagueClient.exe`, etc.), el indicador se **suprime silenciosamente al instante**, sin crear ventanas ni ganchos que puedan generar falsos positivos en anti-cheats.

### B. Al Finalizar la Tarea (Ocultar y Restaurar)
```json
computer_indicator {
  "action": "hide"
}
```
* Cierra de inmediato la mini-insignia y restaura los cursores estándar del sistema mediante `SPI_SETCURSORS`.

---

## 2. ⚡ Jerarquía de Inspección Rápida (Zero Visual Tokens)

> **Regla de Oro**: Inspeccionar primero mediante accesibilidad UIA o metadatos (0 tokens visuales, 50-180ms) antes de tomar capturas de pantalla completas (2-4s, miles de tokens).

| Nivel | Herramienta | Latencia | Costo Tokens | Cuándo Usar |
|---|---|---|---|---|
| **L1** | `computer_active_window` | ~10-25 ms | 0 tokens | Obtener HWND, título, posición y comprobar si hay un modal bloqueante (`is_modal: true`). |
| **L2** | `computer_snapshot` | ~150-180 ms | 0 tokens | **La herramienta principal de lectura:** Extrae el árbol completo de controles UIA, nombres, IDs, coordenadas y estados de la ventana sin visión. |
| **L3** | `computer_list_windows` | ~30-50 ms | 0 tokens | Enumerar ventanas abiertas en el escritorio, filtrando por título (`filter: "Chrome"`). |
| **L4** | `computer_map_ui` | ~80 ms | 0 tokens | Asigna identificadores numéricos a todos los controles clicables para usar `computer_click { "id": N }`. |
| **L5** | `computer_click_text` | ~100-350 ms | 0 tokens | Clic semántico directo sobre un texto o botón con tipeo opcional en 1 solo turno. |
| **L6** | `computer_detect_block` | ~60 ms | 0 tokens | Detecta bloqueos anti-bot (Cloudflare, reCAPTCHA, Google "navegador no seguro") y entrega coordenadas del checkbox. |
| **L7** | `computer_screenshot` | ~200 ms | Tokens visión | Usar solo cuando la interfaz sea un Canvas, juego o renderizado sin accesibilidad. Pasar `link: true` para obtener archivo en disco. |

---

## 3. 🌐 Navegación y Gestión de Ventanas

### A. Abrir URLs en el Navegador Real del Usuario (`computer_login`)
Lanza URLs directamente en Google Chrome utilizando el perfil auténtico del usuario (cookies, sesiones activas y sin banderas de automatización anti-bot):
```json
computer_login {
  "url": "https://www.facebook.com/marketplace/search?query=sarten"
}
```

### B. Enfocar y Traer al Frente (`computer_focus_window`)
Restaura ventanas minimizadas y las trae al primer plano vinculando hilos de entrada Win32:
```json
computer_focus_window {
  "hwnd": 460478
}
```
*O buscando por título: `computer_focus_window { "title": "Chrome" }`.*

### C. Acciones de Ventana Nativas (`computer_window_action`)
Acelerado por `DesktopBridge.exe` en <15ms:
```json
computer_window_action {
  "action": "maximize",
  "target_window": "Chrome"
}
```
*Acciones admitidas: `maximize`, `minimize`, `restore`, `close`, `snap_left`, `snap_right`.*

---

## 4. 🛡️ Evasión y Detección de Bloqueos Anti-Bot (Vía Humana)

1. **Detección Automática:**
   `computer_detect_block {}` $\rightarrow$ devuelve `checkbox_location: { "x": 520, "y": 410 }`.
2. **Superación como Humano (`computer_human_click`):**
   Genera una **curva cúbica de Bézier** con micro-jitter y duración de pulsación realista (70-120ms):
   ```json
   computer_human_click { "x": 520, "y": 410 }
   ```
3. **Estrategia Combinada (`computer_pass_barrier`):**
   Ejecuta la estrategia óptima según el tipo de desafío detectado (`auto`, `checkbox`, `wait`, `reload`, `real_chrome`).

---

## 5. 🎯 Clics Semánticos y Formularios en 1 Solo Turno

### A. Clic y Tipeo Combinado (`computer_click_text`)
```json
computer_click_text {
  "target_window": "Chrome",
  "text": "Buscar en Marketplace",
  "dismiss_overlay_first": true,
  "clear_first": true,
  "type_text": "sarten para huevos",
  "press_enter": true,
  "human_like": true
}
```
* `dismiss_overlay_first: true`: barre previamente modales y avisos de cookies para que no tapen el clic.

### B. Relleno Atómico de Formularios (`computer_fill_form`)
Soporta detección de sinónimos (`email` $\leftrightarrow$ `correo` $\leftrightarrow$ `usuario`, `password` $\leftrightarrow$ `contraseña` $\leftrightarrow$ `clave`) e interactúa directamente en el `Edit` control:
```json
computer_fill_form {
  "target_window": "Login",
  "fields": [
    { "label": "email", "value": "usuario@correo.com" },
    { "label": "password", "secret_b64": "MTIzNDU2", "is_secret": true }
  ],
  "submit_button": "Iniciar Sesión"
}
```

---

## 6. 📋 Portapapeles y Teclado

* **Copiar:** `computer_copy {}` $\rightarrow$ `{ "ok": true, "text": "..." }`.
* **Pegar ultra-rápido:** `computer_paste { "text": "contenido largo", "press_enter": true }` (100x más rápido que tipear carácter a carácter).
* **Atajos de teclado:** `computer_hotkey { "combo": "ctrl+shift+esc" }`, `computer_hotkey { "combo": "alt+f4" }`.

---

## 7. 📁 Archivos, Subidas a Drive y Diálogos Nativos

* **Diálogos de Archivo Nativos (`#32770`):** `computer_handle_file_dialog { "path": "C:\\ruta\\archivo.pdf", "action": "open" }`. Usa `DesktopBridge.exe` Win32 (`WM_SETTEXT` + `IDOK`) en ~35ms sin ensuciar el portapapeles ni fallar por station desasociada.
* **Subida por Arrastre Directo (`computer_upload_file`):** Inyecta archivos en drop zones (Google Drive, Gmail, Slack, MercadoLibre) sin abrir exploradores.
* **Watcher de Descargas (`computer_wait_download`):** Espera a que termine una descarga en `Downloads` y devuelve su ruta y hash SHA256.

---

## 8. 👤 Cuentas Múltiples de Google/Gmail y Navegación Aislada (`computer_login`)

* **Listar perfiles detectados:**
```json
computer_login { "list_profiles": true }
```
Devuelve los perfiles de Chrome y Edge (ej. `"Octavio"` / `gohcreppyss@gmail.com`, `"Gabriel"` / `percatorone17@gmail.com`).

* **Abrir directamente en la cuenta deseada:**
```json
computer_login {
  "url": "https://mail.google.com",
  "profile": "percatorone17@gmail.com"
}
```
Inicia Chrome con `--profile-directory="Profile 1"` de forma instantánea y con todas las cookies y sesiones activas.

---

## 9. 🛡️ Modales, Cookies y Overlays (`computer_dismiss_overlay`)

En páginas como MercadoLibre, Facebook, X, o sitios de noticias con banners de cookies que interceptan clics:
```json
computer_dismiss_overlay { "max_attempts": 2 }
```
Inspecciona controles UIA buscando botones de aceptación/cierre (`"Aceptar cookies"`, `"Entendido"`, `"Cerrar"`, `"Aceptar todo"`) o presiona `Escape` si hay un modal bloqueante.

---

## 10. ☕ Modo Anti-Suspensión y Prevención de Bloqueo (`computer_awake`)

Evita que la pantalla se apague o Windows entre en suspensión durante tareas largas:
```json
computer_awake { "enabled": true }
```
*(Para desactivar: `{ "enabled": false }`)*

---

## 9. 🔄 Flujo de Trabajo Recomendado (Workflow Canónico)

```mermaid
flowchart TD
    A["computer_indicator (show, top_left, working)"] --> B["computer_login o computer_focus_window"]
    B --> C["computer_snapshot (UIA 0-tokens)"]
    C --> D{"¿Elementos identificados?"}
    D -- Sí --> E["computer_click_text / computer_type / computer_key"]
    D -- No (Canvas/Gráfico) --> F["computer_screenshot (link: true, auto)"]
    F --> E
    E --> G["computer_wait_for o computer_snapshot"]
    G --> H["computer_indicator (hide)"]
    H --> I["Resumen final al usuario"]
```
