# El selector

La apariencia del selector **no es una decisión de diseño** — es esta especificación. Copia textualmente el markup, el CSS y el cableado de abajo; los únicos valores que cambian en cada ejecución son los nombres de las variantes y la cantidad. Se mantiene idéntico en todos los proyectos para que siempre se lea como cromo del arnés, nunca como parte del diseño que se está juzgando. No lo reestiles con los tokens, las fuentes o los colores del proyecto.

Es una píldora oscura flotante, abajo al centro. El vidrio oscuro funciona sobre cualquier página — clara u oscura — y por eso no es consciente del tema.

## Markup

Primero el span del resaltado deslizante, un botón por variante, un divisor finísimo y después el botón de repetición (solo cuando al menos una variante tiene movimiento que volver a disparar):

```html
<nav class="proto-picker" aria-label="Prototype variants">
  <span class="proto-picker-highlight" aria-hidden="true"></span>
  <button class="proto-picker-item" data-active aria-current="true">Quiet</button>
  <button class="proto-picker-item">Editorial</button>
  <button class="proto-picker-item">Playful</button>
  <span class="proto-picker-divider" aria-hidden="true"></span>
  <button class="proto-picker-item proto-picker-replay" aria-label="Replay animation (R)">↻</button>
</nav>
```

En un framework, conserva los nombres de clase y la estructura; solo cambia la sintaxis de renderizado.

## Estilos

```css
.proto-picker {
  position: fixed;
  bottom: 24px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 2147483647;
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 4px;
  border-radius: 999px;
  background: rgba(10, 10, 10, 0.82);
  -webkit-backdrop-filter: blur(12px) saturate(1.4);
  backdrop-filter: blur(12px) saturate(1.4);
  box-shadow:
    0 0 0 1px rgba(255, 255, 255, 0.08) inset,
    0 8px 24px rgba(0, 0, 0, 0.24),
    0 2px 6px rgba(0, 0, 0, 0.12);
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  font-size: 13px;
  line-height: 1;
  -webkit-font-smoothing: antialiased;
  user-select: none;
  -webkit-user-select: none;
}

.proto-picker-highlight {
  position: absolute;
  top: 4px;
  left: 0;
  height: 28px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.12);
  will-change: transform;
}

/* El deslizamiento se activa solo después del primer pintado (data-ready), para que la carga no anime nada. */
.proto-picker[data-ready] .proto-picker-highlight {
  transition:
    transform 250ms cubic-bezier(0.23, 1, 0.32, 1),
    width 250ms cubic-bezier(0.23, 1, 0.32, 1);
}

@media (prefers-reduced-motion: reduce) {
  .proto-picker[data-ready] .proto-picker-highlight { transition: none; }
}

.proto-picker-item {
  position: relative; /* se sitúa por encima del resaltado */
  display: flex;
  align-items: center;
  height: 28px;
  padding: 0 12px;
  border: 0;
  border-radius: 999px;
  background: transparent;
  color: rgba(255, 255, 255, 0.55);
  font: inherit;
  cursor: pointer;
  transition: color 150ms ease-out;
}

.proto-picker-item:hover {
  color: rgba(255, 255, 255, 0.85);
}

.proto-picker-item:active {
  transform: scale(0.97);
}

.proto-picker-item:focus-visible {
  outline: 2px solid rgba(255, 255, 255, 0.4);
  outline-offset: 2px;
}

.proto-picker-item[data-active] {
  color: #fff;
}

.proto-picker-divider {
  width: 1px;
  height: 16px;
  margin: 0 4px;
  background: rgba(255, 255, 255, 0.12);
}

.proto-picker-replay {
  padding: 0 10px;
  font-size: 14px;
}

.proto-picker[data-position="top"] {
  bottom: auto;
  top: 24px;
}
```

## Reglas

- **Textual.** Estos valores son la especificación. Nada de fuentes del proyecto, nada de colores de marca, nada de cambio de tema, nada de sombras o bordes extra.
- **El resaltado se desliza; el cambio de variante es instantáneo.** La píldora activa se anima entre botones (250 ms, ease-out marcado) como feedback espacial sobre el propio selector — pero la variante que se está previsualizando cambia sin transición. La transición de `width` es una excepción deliberada a la regla de transform/opacity: el elemento mide 28px de alto, está posicionado de forma absoluta y no tiene dependientes de layout, así que el costo de pintado es despreciable.
- **Una única modificación permitida:** si una variante ocupa la parte inferior central de la pantalla (una pila de toasts, un bottom sheet, un dock), pon `data-position="top"` para que el selector nunca tape el trabajo. Nada más sobre él puede moverse o cambiar.
- **La repetición es condicional.** Renderiza el botón de repetición y su divisor solo cuando al menos una variante tenga una animación de entrada o de estado que valga la pena volver a disparar; una comparación estática se queda con una píldora más corta.

## Contrato de comportamiento

El contrato es fijo sin importar cómo renderice el arnés:

- Las teclas numéricas `1–N` y `←`/`→` cambian de variante; `R` repite. Ignora los eventos de teclado cuando el foco está en un input, textarea, select o contenteditable, o cuando se mantiene presionado un modificador.
- Al hacer clic en un ítem se cambia a esa variante; exactamente un ítem lleva `data-active` y `aria-current="true"` en todo momento, y el resaltado se desliza hasta él.
- La selección persiste entre recargas mediante un parámetro de URL (`?v=2`), con caída a la variante 1. El resaltado toma su posición inicial sin animarse (`data-ready` se agrega después del primer pintado).
- Cambiar remonta la variante (para que se repitan las animaciones de entrada); la tecla de repetición remonta sin cambiar.

## Cableado de referencia

Textual para la rama de HTML independiente; en un framework, conserva el mismo comportamiento pero exprésalo de forma idiomática (estado en vez de `innerHTML`, un remontaje con clave en vez de `requestAnimationFrame`, refs y un efecto de layout para medir el resaltado).

```js
// `variants` es un arreglo de funciones de render, una por variante, en el orden del selector.
const stage = document.getElementById('stage');
const picker = document.querySelector('.proto-picker');
const highlight = picker.querySelector('.proto-picker-highlight');
const items = [...picker.querySelectorAll('.proto-picker-item:not(.proto-picker-replay)')];
const replay = picker.querySelector('.proto-picker-replay');
let current = 0;

function moveHighlight() {
  const el = items[current];
  highlight.style.width = el.offsetWidth + 'px';
  highlight.style.transform = `translateX(${el.offsetLeft}px)`;
}

function mount(i) {
  stage.innerHTML = '';
  // Limpia primero y renderiza en el siguiente frame, para que se repitan las animaciones de entrada.
  requestAnimationFrame(() => { stage.innerHTML = variants[i](); });
}

function setActive(i) {
  if (i < 0 || i >= variants.length) return;
  current = i;
  items.forEach((el, j) => {
    el.toggleAttribute('data-active', j === i);
    if (j === i) el.setAttribute('aria-current', 'true');
    else el.removeAttribute('aria-current');
  });
  moveHighlight();
  const url = new URL(location);
  url.searchParams.set('v', i + 1);
  history.replaceState(null, '', url);
  mount(i);
}

items.forEach((el, i) => el.addEventListener('click', () => setActive(i)));
replay?.addEventListener('click', () => mount(current));
window.addEventListener('resize', moveHighlight);

document.addEventListener('keydown', (e) => {
  if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) || e.target.isContentEditable) return;
  if (e.metaKey || e.ctrlKey || e.altKey) return;
  const num = parseInt(e.key, 10);
  if (num >= 1 && num <= variants.length) setActive(num - 1);
  else if (e.key === 'ArrowRight') setActive((current + 1) % variants.length);
  else if (e.key === 'ArrowLeft') setActive((current - 1 + variants.length) % variants.length);
  else if (e.key === 'r' || e.key === 'R') mount(current);
});

setActive((parseInt(new URLSearchParams(location.search).get('v'), 10) || 1) - 1);
// Activa el deslizamiento solo después del primer pintado, para que la carga no anime nada.
requestAnimationFrame(() => requestAnimationFrame(() => picker.setAttribute('data-ready', '')));
```
