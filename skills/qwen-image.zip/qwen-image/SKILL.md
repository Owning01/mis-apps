---
name: qwen-image
description: >-
  Generar o editar imágenes con IA en local (Qwen-Image-2.1, RTX 3090).
  Úsala cuando pidan: crea una imagen, generame un logo/fondo/poster,
  edita esta foto, cambia X de esta imagen, fondo transparente, PNG con alfa,
  keyframe o concept art. No sirve para video (eso es minimax-h3) ni para
  dibujos animados cuadro a cuadro (eso es hand-drawn-canvas-animation).
---

# qwen-image — crear imágenes en local

## Antes de generar

1. ComfyUI tiene que estar arriba: tool `qwen_status` (cola libre) o
   `comfy-qwen` en terminal. URL: `http://127.0.0.1:8188`. Tras reiniciar
   arranca solo (~30 s); la primera generación carga pesos (~30 s extra).

## Tres formas de crear

- **Desde el chat (esta sesión / OpenCode):** tool `qwen_generate`.
- **Desde terminal:** `qwen --mode t2i --prompt "..." --seed 42`.
- **Web manual:** abrir `:8188`, workflows `qwen-image-2.1`, prompt y Run.

## Modos

| Quiero | Comando |
|---|---|
| Texto → imagen 1024px (~20-50 s) | `--mode t2i --prompt "..."` |
| Wide 2K 2048×1152 (~90 s) | `--mode 2k --prompt "..."` |
| Editar una foto | `--mode edit --image f.png --prompt "cambia X, conserva Y"` |
| Objeto con fondo transparente | `--mode rgba --prompt "... fondo transparente"` |
| Combinar dos imágenes | `--mode references --image a.png --reference b.png --prompt "..."` |

## Cómo pedir (prompt)

- En inglés rinde mejor. Describí la foto terminada: sujeto + acción,
  lugar, luz, materiales, tratamiento (foto casual, retrato, etc.).
- Para texto dentro de la imagen, entrecomillalo exacto.
- En edición: nombrá EL cambio Y lo que se conserva; un cambio por vez
  con `--seed` fijo para comparar.

## Base RTX 3090 (no tocar sin motivo)

1024px · 40 steps (50 en 2K) · Euler · CFG 1 · negative vacío ·
dimensiones múltiplo de 32. Con poca RAM: encoder a CPU o `--lowvram`.

## Verificación obligatoria

ABRIR el PNG y mirarlo antes de entregar. Cada run deja evidencia en
`G:\ComfyUI-Qwen21\outputs\qwen21-*` (`prompt.json`, `history.json`, PNG).
En `rgba`, comprobar que el canal alfa varía (no un damero gris).

## Si falla

- `queue is busy`: reintentar luego o `--allow-queue`.
- Sin VRAM: bajar a 1024px, batch 1, no pedir 2K de entrada.
- `Missing node` / modelo ausente: ComfyUI desactualizado o modelos sin
  verificar en `G:\ComfyUI-Qwen21\models` (son 3 archivos, 17 GB).
