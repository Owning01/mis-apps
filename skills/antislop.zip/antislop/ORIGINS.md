# Origins and licensing of this merged skill

This folder is a **local merge** of two previously separate skills. Both original
copies are archived at `C:/Users/perca/.agents/backupo/antislop-merge-2026-09-25/`.

## 1. antislop (the rule filter)

- Source: https://github.com/miqdadbadjuber/anti-slop (`skills/antislop/SKILL.md`)
- Contributes: the two usage modes, the install pointer, the core principle, the
  craftsmanship standard (C-1 to C-5), Part 1 slop patterns, Part 2 rules
  (R-01 to R-38), Part 3 liveliness toolkit, and the Delivery Gate.
- No LICENSE file shipped with the local install, so the terms of that repo apply
  as-is upstream. Treat the rule text as third-party content, not as ours.

## 2. anti-ui-slop (the playbooks and the evidence policy)

- Source: UIZZE, https://uizze.com, skill version `1.2.13`, design stack
  `4.1.1` (pinned commit `5a149f3fdb1b5793f10567233b1dcab98fc305fd`).
- Skill frontmatter declared MIT; the bundled design stack is Apache-2.0
  (see `LICENSE.uizze-design-stack` and `MANIFEST.uizze.json`).
- Contributes: the "work from the product" rule, the one-playbook router in
  `reference/` (new-work, operate, polish, distill, audit, ios), and the optional
  visual evidence policy in `reference/uizze-reference-policy.md`.
- UIZZE keeps the router, reference policy, packaging, versioning, and
  distribution of its own parts (see `MODIFICATIONS.md`).

## 3. Third-party material inside the playbooks

`reference/ios.md` includes material distilled from ehmo's
`platform-design-skills` (Apple Human Interface Guidelines), MIT licensed.
See `NOTICE` for the full third-party notice.

## What this merge changed

- One entry point: `SKILL.md` now carries the rules **and** the playbook router.
  There is no second skill to load.
- The install wizard that offered to download sub-skills (`antislop-ui`,
  `antislop-copywriting`, `antislop-human`, `antislop-layoutmobile`,
  `antislop-code`) was replaced by a pointer block that only references files
  that actually exist in this folder. This install ships the core plus the
  playbooks, nothing else.
- The em dash rule (R-02) still bans `—` in any text the agent writes. The
  headings of this file keep the character as documentation structure, which is
  the rule's own documented carve-out.
