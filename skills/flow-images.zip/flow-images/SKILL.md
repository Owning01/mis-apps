---
name: flow-images
description: Genera imágenes en Google Flow (flow.google.com) usando la cuenta del usuario, sin API key, manejando su Chrome real. Úsala cuando pidan crear imágenes con Flow, usar Nano Banana, generar arte conceptual desde Flow, elegir modelo o relación de aspecto en Flow, o crear un proyecto nuevo en Flow. También documenta por qué Flow necesita eventos reales de teclado y por qué no sirve una extensión.
---

# Flow Images (Nano Banana)

Maneja Google Flow en el Chrome real del usuario. Sin API key, sin headless, sin
banderas de automatización. Las acciones se hacen con las tools `browser.*`.

## Dato clave: Flow exige eventos confiables

Probado en vivo:

| Acción | Resultado |
|---|---|
| `element.click()` sintético sobre "Iniciar generación" | **no hace nada** |
| `KeyboardEvent('Enter')` sintético | **no hace nada** |
| Enter real con `browser.press` | **genera** |
| Pegado sintético de texto (`ClipboardEvent`) | entra, pero a veces falla |

**Camino automático (preferido)**: `POST /flow/generate` en el puente.
La extensión resuelve la tecla con el API `debugger` de Chrome y ya no hace falta
manejar la pestaña a mano:

```bash
curl -s -X POST http://127.0.0.1:8788/flow/generate \
  -H "Content-Type: application/json" \
  -d "{\"prompt\":\"un faro al atardecer\",\"model\":\"Nano Banana Pro\",\"aspect\":\"1:1\"}"
```

**Camino manual (si el puente no está)**: manejar la pestaña con las tools `browser.*`.
Para eso está el resto de esta skill.

## Modelos y ajustes (verificados)

En el panel de generación, junto al composer:

**Familias de modelos** (botón `aria-label="Seleccionar familia de modelos"`):

| Modelo | Para qué |
|---|---|
| 🍌 Nano Banana Pro | máxima calidad |
| 🍌 Nano Banana 2.1 | equilibrio (viene elegido) |
| 🍌 Nano Banana 2 Lite | rápida, más barata |

**Relación de aspecto** (radios del mismo panel): `16:9`, `4:3`, `1:1`, `3:4`, `9:16`.

**Costo**: con la cuenta PRO el panel dice "La generación consumirá 0 puntos".

**Ajustes de vista** (botón `Ajustes`): modo Cuadrícula/Lote, tamaño S/M/L, sonido al
pasar el cursor, vídeos silenciosos, mostrar detalles del recuadro, borrar petición al
enviar (viene activado).

## Procedimiento para generar una imagen

`tabID` = la pestaña de Flow (si no hay, abrir una con `browser.tabs.open`).

### 1. Asegurar un proyecto abierto

Si la pestaña está en `flow.google.com/u/1/` (inicio), hay que entrar a un proyecto:

- Ya existe uno: clic en la tarjeta del proyecto.
- Ninguno sirve: `browser.find` con "Nuevo proyecto" y `browser.click` en el ref `@eN`.

La URL de trabajo es `https://flow.google.com/u/1/project/<uuid>`.

### 2. Escribir el prompt

El composer es un editor **ProseMirror**. Pegar el texto con un evento de pegado:

```js
const c = document.querySelector('div[role="textbox"][contenteditable="true"]');
c.focus();
const dt = new DataTransfer();
dt.setData('text/plain', 'EL PROMPT');
c.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
```

### 3. (Opcional) Elegir modelo y aspecto

```js
// Abrir el panel de generación
[...document.querySelectorAll('button')].find(b => b.getAttribute('aria-label') === 'Activador de ajustes')?.click();
// Abrir la lista de modelos
[...document.querySelectorAll('button')].find(b => b.getAttribute('aria-label') === 'Seleccionar familia de modelos')?.click();
```

Después, clic por texto en la opción ("🍌 Nano Banana Pro", "🍌 Nano Banana 2 Lite",
"🍌 Nano Banana 2.1"). Los radios de aspecto se eligen por su texto: "16:9", "1:1", etc.
Cerrar con `Escape`.

### 4. Enviar (paso crítico)

1. `browser.evaluate`: enfocar el composer (`document.querySelector('div[role="textbox"][contenteditable="true"]').focus()`).
2. `browser.press` con `Enter`. **Tiene que ser esta tool.**

Queda generando si aparece `button[aria-label="Detener"]`.

### 5. Esperar el resultado

`browser.wait` o consultar hasta que `button[aria-label="Detener"]` desaparezca.
Suele tardar 20-60 s por imagen.

```js
!!document.querySelector('button[aria-label="Detener"]')   // true = sigue generando
```

### 6. Sacar la imagen

Las imágenes generadas son `img` con `src` que empieza con
`https://flow.google.com/asb/` (o `lh3.googleusercontent.com`), de ~1376x768.
Esa URL **necesita la sesión**: hay que bajarla desde la página, no con curl.

Para verla con el usuario: `browser.screenshot` y `browser.preview`.
Para guardar el archivo: bajar desde la página (fetch + blob + `<a download>`) y después
`browser.files.list` / `browser.files.get` para copiarlo al servidor.

## Reglas

- Una imagen a la vez: no mandar otro prompt mientras `Detener` siga visible.
- No tocar la pestaña del usuario sin avisar: usar una pestaña propia con
  `browser.tabs.open` y decirle que la está viendo.
- Un pedido por vez y sin ráfagas. Es la cuenta real del usuario.
- Flow es sensible al foco: enfocar el composer antes del Enter, siempre.
- Si el panel de modelos no aparece, repetir el clic en "Activador de ajustes": tarda
  en montar.
