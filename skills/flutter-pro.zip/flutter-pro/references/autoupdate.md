# Autoupdate — referencia completa

Implementación rápida y probada en producción (OpenHer Mobile, 2026): update
contra manifiesto propio, sin tienda, con verificación de integridad. Lo de
`SKILL.md §11` es el resumen; acá está todo el detalle del código.

## 1. Arquitectura

```
GitHub Release ──latest.json──▶ check() ──APK──▶ download() ──sha256──▶ ready
                                                                  │
                                             FileProvider ──install()── sistema
```

Tres piezas: `UpdateInfo/UpdateState/UpdatePhase` (modelo), `UpdateService`
(`ChangeNotifier`, toda la red y el disco) y la banda (`UpdateBanner`, solo
pinta el estado). La UI nunca toca red ni disco.

## 2. Manifiesto `latest.json`

Lo genera el script de publish y la app lo exige completo:

```json
{"version": "1.21.0", "versionCode": 35,
 "url": "https://github.com/<org>/<repo>/releases/download/v1.21.0/app-release.apk",
 "sha256": "caa7…5fc8",
 "notes": "qué cambió", "published_at": "2026-10-11T04:27:11Z"}
```

- `versionCode` es lo que decide (Android rechaza `<=` instalado).
- `sha256` en hex minúsculas. Sin él no hay instalación.
- `url` tiene que ser `https://` (el cliente lo exige).

Generación y verificación en el publish (PowerShell):

```powershell
$sha256 = (Get-FileHash -Path $apk -Algorithm SHA256).Hash.ToLowerInvariant()
# ...subir asset + escribir latest.json con ese sha...
# Verificación con cache-buster (GitHub sirve el asset viejo desde caché):
curl.exe -sL -o $tmp "$url?nc=<epoch>"
if ((Get-FileHash -Path $tmp -Algorithm SHA256).Hash.ToLowerInvariant() -ne $sha256) {
  throw "El publicado no coincide con lo compilado" }
if (-not $seen.sha256) {
  throw "El manifiesto publicado no trae sha256 (la app lo exige)" }
```

## 3. Modelo

```dart
class UpdateInfo {
  const UpdateInfo({required this.version, required this.versionCode,
    required this.apkUrl, this.sha256 = '', this.notes = '',
    this.publishedAt = ''});
  // fingerprint: primeros 12 del hex + … (el completo no entra en la banda).
  String get fingerprint => ...;
  // fromJson tira FormatException si falta lo esencial: un manifiesto a
  // medias instalaría un APK sin poder compararlo.
}

enum UpdatePhase {
  idle,         // nada que decir: la banda se esconde
  checking,     // chequeo en vuelo: tampoco se muestra (un fallo de chequeo
                // no es accionable y el banner parpadearía)
  available,    // hay versión nueva: banda con Descargar
  downloading,  // con recibidos/total + Cancelar siempre visible
  ready,        // sha ok: botón Instalar
  installDenied,// sin permiso de orígenes desconocidos: mensaje + cómo darlo
  failed,       // fallo de descarga: Reintentar (canRetry)
}
```

Regla de visibilidad: el fallo de **chequeo** no se muestra; el de
**descarga** sí (`canRetry = failed && info != null && error != null`);
`installDenied` se muestra porque hay un permiso que conceder.

## 4. Servicio (`UpdateService extends ChangeNotifier`)

**`check({force})`** — GET al manifiesto con timeout + throttle 24 h en
`SharedPreferences` (los fallos no consumen ventana; `force` la salta).
Compara `versionCode` contra el instalado (`package_info_plus`). Solo avisa
si el remoto es mayor. Sin sha256 en el manifiesto: error claro, no se sigue.

**`download()`** — idempotente (si ya está `ready`, no re-baja):

1. Si el APK de esa versión ya está en disco **y** su sha coincide → `ready`
   directo (cubre reintentos y reinstalaciones sin gastar datos). Si no
   coincide → se borra (era un parcial con el nombre justo: el viejo piso de
   2 MB dejaba pasar truncados al instalador).
2. Stream a `<cache>/updates/openher-<v>.apk` emitiendo `received/total`.
3. Verifica sha256 **antes** de `ready`; mismatch → borra + error claro.
4. Tras descarga ok: `discardApks(keepVersion:)` (cada APK ~50 MB; nadie los
   limpia solo).

**`cancelDownload()`** — flag que el loop chequea por chunk: cierra el sink y
**borra el parcial**. Cancelar a medias y dejar el archivo es el bug que
llevaba truncados al instalador.

**`install()`** — `FileProvider.getUriForFile` + `ACTION_VIEW` con
`application/vnd.android.package-archive` y
`FLAG_GRANT_READ_URI_PERMISSION`. Si `canRequestPackageInstalls == false`:
fase `installDenied` (no `false` silencioso) y redirección a Ajustes.

**SHA-256 puro en Dart** (sin dependencias): procesa el archivo por chunks;
hay vectores de test (`""`, `"abc"`, binario) clavados en `update_test.dart`.

## 5. Android nativo

`AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES"/>
<provider android:name="androidx.core.content.FileProvider"
    android:authorities="${applicationId}.fileprovider"
    android:exported="false" android:grantUriPermissions="true">
    <meta-data android:name="android.support.FILE_PROVIDER_PATHS"
        android:resource="@xml/file_paths" />
</provider>
```

`res/xml/file_paths.xml` mínimo (solo `updates/`, nada más):

```xml
<paths><cache-path name="updates" path="updates/" /></paths>
```

`MainActivity` (Kotlin): canal `installApk(path)` que abre el `Intent`
y canal `canRequestPackageInstalls`. `REQUEST_INSTALL_PACKAGES` se documenta
como requerido por el autoupdate (no es opcional).

## 6. Banda (`UpdateBanner`)

Pinta según fase: disponible (versión + notas + Descargar), descargando
(`12/53 MB (42%)` + Cancelar), listo (fingerprint + Instalar), fallo
(Reintentar), `installDenied` (cómo conceder el permiso). Nunca tapa: una
sola banda, sin diálogos ni bloqueos.

## 7. Tests que la cubren

- Vectores SHA-256 + mismatch que borra.
- `https` exigido (http → error claro).
- Throttle 24 h (fallos no consumen ventana, `force` la salta).
- Cancel a mitad: sink cerrado + parcial borrado.
- `discardApks` deja solo la versión indicada.
- `installDenied` con mensaje accionable.
- Banda: MB totales + fingerprint visibles en cada fase.

## 8. Trampas (medidas, no teoría)

1. `flutter build apk` compila feliz un manifest inválido: verificar con
   `aapt2 dump xmltree --file AndroidManifest.xml <apk>` (sin dos `action`
   seguidos) **antes** de publicar.
2. **Bumpear `pubspec.yaml` ANTES de compilar**: si no, el APK conserva el
   `versionCode` viejo y el update se ofrece para siempre.
3. GitHub sirve el asset viejo desde caché: verificar con `?nc=<epoch>`.
4. APK `arm64-only` si el peso importa (26 MB vs 73 MB universal).
5. Con datos móviles: mostrar tamaño y pedir confirmación antes de bajar
   (~50 MB a ciegas no).
