---
name: flutter-pro
description: Orquestadora Flutter integral con ultra-enfoque en optimización profunda, velocidad (60/120fps), renderizado de alto rendimiento, arquitectura por capas (MVVM, Riverpod 2.x, BLoC), Dart 3 sealed classes, GoRouter persistente, fix de layout constraints, networking robusto con Dio interceptors, formularios accesibles y herramientas MCP Flutter/Dart. Usa para estructurar proyectos, crear layouts responsivos, diagnosticar errores, optimizar rendimiento y diseñar UI premium.
metadata:
  model: models/gemini-3.1-pro-preview
  last_modified: Mon, 28 Sep 2026
  replaces:
    - flutter-apply-architecture-best-practices
    - flutter-build-responsive-layout
    - flutter-fix-layout-issues
    - flutter-optimize-code
    - flutter-premium-design
---

# flutter-pro — Orquestadora Flutter Integral & Motor de Alto Rendimiento

Guía y playbook definitivo para ingeniería de software en Flutter: arquitectura limpia, estado moderno (Riverpod / BLoC / MVVM), renderizado a 60/120 fps (Impeller), optimización quirúrgica de memoria, networking resiliente, navegación declarativa y diagnósticos en tiempo real con herramientas MCP.

---

## Router — Guía rápida según tu tarea

| Tu intención / trigger | Dominio | Sección | Herramientas / Conceptos clave |
|---|---|---|---|
| "estructura proyecto / capas / MVVM / Riverpod / BLoC / domain models / sealed class" | **A Arquitectura & Estado** | §1 | Clean MVVM, Riverpod 2 (`AsyncNotifier`), BLoC/Cubit, Dart 3 `sealed class`, DI |
| "responsive / adaptativo / tablet / desktop / large screen / breakpoints / LayoutBuilder" | **B Responsive & Adaptive** | §2 | `LayoutBuilder`, `MediaQuery.sizeOf`, `Expanded`, `Flexible`, `ConstrainedBox`, `AppBreakpoints` |
| "overflow / RenderFlex overflowed / unbounded height / InputDecorator / ParentData" | **C Layout Fix** | §3 | `get_runtime_errors`, `Expanded`, `Flexible`, unbound constraints resolution |
| "optimizar / performance / jank / 120fps / rebuilds / const / isolate / memory / startup" | **D Ultra-Optimización** | §4 | Impeller, `itemExtent`, `Isolate.run`, `RepaintBoundary`, `memCache`, TTFD, leaks |
| "premium UI / diseño / theme / tipografía / spacing / glassmorphism / micro-interactions / se ve genérico / plantilla / dirección de arte / anti-slop" | **E UI Premium** | §5 (§5.3 tasteskill v2 → Flutter) | `FlexColorScheme`, GoogleFonts, 8dp grid, `AnimatedSwitcher`, Haptics, Spring physics, `draw.mjs`, house rules |
| "navegación / tabs persistentes / deep links / auth redirect / go_router" | **F Navegación** | §6 | `GoRouter`, `StatefulShellRoute.indexedStack`, `refreshListenable` |
| "formularios / validación / teclado / focus / autofill" | **G Formularios** | §7 | `Form`, `Scrollable.ensureVisible`, `AutofillGroup`, dismiss keyboard |
| "api / dio / jwt refresh / token / offline / result / failure" | **H Networking** | §8 | Dio `QueuedInterceptor`, `Result<T, Failure>`, offline caching |
| "testing / unit test / widget test / mocktail / goldens" | **I Testing** | §9 | `testWidgets`, `mocktail`, `pumpAndSettle`, golden tests |
| "diagnosticar con mcp / runtime error / inspect / hot reload" | **J Herramientas MCP** | §10 | `analyze_files`, `get_runtime_errors`, `hot_reload`, `widget_inspector` |

**Orden de aplicación en proyectos integrales:**
`Arquitectura (§1) → Navegación (§6) → Tokens & UI (§5) → Formularios/Red (§7, §8) → Responsive (§2) → Constraints Fix (§3) → Auditoría de Rendimiento & Profiling (§4) → Tests (§9)`

---

## 1. Arquitectura por Capas & Gestión de Estado Moderno

### 1.1 Separación de Responsabilidades (SoC)
Divide la aplicación en 3 capas fundamentales sin acoplamiento circular:
1. **Presentation (UI Layer):** Widgets declarativos lean + State Holders (ViewModels, Notifiers o Cubits). No realizan llamadas HTTP directas ni manipulan DB.
2. **Domain Layer (Core):** Modelos de dominio inmutables (`@freezed` o plain Dart 3 records/classes) y Use Cases opcionales para reglas de negocio complejas.
3. **Data Layer:** `Repositories` (Single Source of Truth, coordinación de cache y mapping a Domain) + `DataSources/Services` (APIs remotas, SQLite/Drift, LocalStorage).

```text
lib/
├── core/
│   ├── network/        # Dio client, interceptors, network result
│   ├── theme/          # AppTheme, AppSpacing, AppRadius
│   └── utils/          # Extensions, helpers
├── data/
│   ├── datasources/    # RemoteApiClient, LocalStorage
│   ├── models/         # DTOs (Data Transfer Objects) con fromJson/toJson
│   └── repositories/   # Implementaciones concretas de repositorios
├── domain/
│   ├── models/         # Modelos de negocio inmutables
│   └── repositories/   # Interfaces abstractas de repositorios
└── presentation/
    ├── routing/        # GoRouter configuración y guards
    └── features/
        └── [feature_name]/
            ├── state/  # ViewModels, Riverpod Notifiers o Cubits
            └── views/  # Widgets de pantalla y componentes
```

---

### 1.2 Modelado de Estado con Dart 3 `sealed class` (Patrón Exhaustivo)
Evita estados booleanos incoherentes (`isLoading: true, hasError: true`). Modela el estado de pantalla con tipos algebraicos cerrados:

```dart
sealed class UiState<T> {
  const UiState();
}

final class UiInitial<T> extends UiState<T> {
  const UiInitial();
}

final class UiLoading<T> extends UiState<T> {
  const UiLoading();
}

final class UiSuccess<T> extends UiState<T> {
  final T data;
  const UiSuccess(this.data);
}

final class UiError<T> extends UiState<T> {
  final String message;
  final Exception? exception;
  const UiError(this.message, [this.exception]);
}
```

**Consumo exhaustivo en el árbol de widgets:**
```dart
@override
Widget build(BuildContext context) {
  return switch (state) {
    UiInitial() => const SizedBox.shrink(),
    UiLoading() => const Center(child: CircularProgressIndicator.adaptive()),
    UiSuccess(:final data) => ProfileDataView(user: data),
    UiError(:final message) => ErrorCard(message: message, onRetry: loadData),
  }; // El compilador de Dart 3 valida que ningún caso quede sin manejar.
}
```

---

### 1.3 Estado Moderno: ¿Qué patrón elegir?

#### Opción A: Clean MVVM (ChangeNotifier Seguro)
> **Regla de oro:** `ChangeNotifier` de Flutter NO tiene el getter `mounted`. Debe manejarse un flag de desecho seguro para prevenir memory leaks y llamadas a `notifyListeners()` tras un async.

```dart
abstract class SafeChangeNotifier extends ChangeNotifier {
  bool _isDisposed = false;
  bool get isDisposed => _isDisposed;

  @override
  void notifyListeners() {
    if (!_isDisposed) super.notifyListeners();
  }

  @override
  void dispose() {
    _isDisposed = true;
    super.dispose();
  }
}

class ProfileViewModel extends SafeChangeNotifier {
  ProfileViewModel({required UserRepository userRepository}) : _userRepository = userRepository;

  final UserRepository _userRepository;
  UiState<User> _state = const UiInitial();
  UiState<User> get state => _state;

  Future<void> loadProfile(String id) async {
    _state = const UiLoading();
    notifyListeners();

    try {
      final user = await _userRepository.getUser(id);
      if (isDisposed) return; // Validación de ciclo de vida seguro
      _state = UiSuccess(user);
    } catch (e) {
      if (isDisposed) return;
      _state = UiError(e.toString());
    } finally {
      notifyListeners();
    }
  }
}
```

#### Opción B: Riverpod 2.x (`AsyncNotifier` — Recomendado en apps modernas)
```dart
import 'package:flutter_riverpod/flutter_riverpod.dart';

final profileProvider = AsyncNotifierProvider<ProfileNotifier, User>(ProfileNotifier.new);

class ProfileNotifier extends AsyncNotifier<User> {
  @override
  Future<User> build() async {
    // Carga inicial reactiva
    final repository = ref.watch(userRepositoryProvider);
    return repository.getUser('current-user-id');
  }

  Future<void> refresh() async {
    state = const AsyncValue.loading();
    state = await AsyncValue.guard(() async {
      return ref.read(userRepositoryProvider).getUser('current-user-id');
    });
  }
}

// Consumo con ConsumerWidget (Rebuild granular y zero jank):
class ProfileView extends ConsumerWidget {
  const ProfileView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Escucha solo el estado puntual sin reconstruir todo el layout
    final profileAsync = ref.watch(profileProvider);

    return profileAsync.when(
      data: (user) => Text(user.name),
      loading: () => const Center(child: CircularProgressIndicator.adaptive()),
      error: (err, stack) => Text('Error: $err'),
    );
  }
}
```

#### Opción C: BLoC / Cubit (Enterprise Standard)
```dart
import 'package:flutter_bloc/flutter_bloc.dart';

class ProfileCubit extends Cubit<UiState<User>> {
  ProfileCubit(this._userRepository) : super(const UiInitial());

  final UserRepository _userRepository;

  Future<void> loadUser(String id) async {
    emit(const UiLoading());
    try {
      final user = await _userRepository.getUser(id);
      emit(UiSuccess(user));
    } catch (e) {
      emit(UiError(e.toString()));
    }
  }
}
```

---

## 2. Layouts Responsivos y Adaptativos

### 2.1 Principio Rector: Negociación de Constraints
> **"Constraints go down. Sizes go up. Parent sets position."**

- **Ventana vs Pantalla:** Toma decisiones basadas en el tamaño de la ventana (`MediaQuery.sizeOf(context)`), nunca por tipo de hardware ("phone" vs "tablet") ni por orientación forzada.
- **`MediaQuery.sizeOf(context)` vs `LayoutBuilder`:**
  - `MediaQuery.sizeOf(context)`: Más económico (solo escucha tamaño, no insets). Úsalo para decisiones a nivel de pantalla/scaffold.
  - `LayoutBuilder`: Reconstruye cuando cambian las constraints del **padre**. Úsalo dentro de componentes reutilizables o cards que se adaptan al espacio disponible.

### 2.2 Breakpoints y Contenedores Adaptativos
```dart
// En pantallas grandes (Tablet/Desktop), nunca dejes un formulario o lista estirarse al 100% de la pantalla:
class CenteredConstrainedLayout extends StatelessWidget {
  const CenteredConstrainedLayout({super.key, required this.child, this.maxWidth = 840});

  final Widget child;
  final double maxWidth;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: child,
      ),
    );
  }
}
```

---

## 3. Diagnóstico Quirúrgico y Fix de Constraints (Layout Issues)

### 3.1 Las 5 Violaciones Típicas y su Resolución

| Error en Consola | Causa Técnica | Solución Inmediata |
|---|---|---|
| **"Vertical viewport was given unbounded height"** | Un scrollable (`ListView`, `GridView`) dentro de un parent vertical no acotado (`Column`). | Envolver el scrollable en `Expanded` (si está en Column) o asignarle altura fija con `SizedBox(height: ...)` o `shrinkWrap: true` (solo en listas diminutas < 10 items). |
| **"An InputDecorator... cannot have an unbounded width"** | `TextField` o `TextFormField` dentro de una `Row` o `Flex` horizontal sin restricción. | Envolver el `TextField` en `Expanded` o `Flexible`. |
| **"A RenderFlex overflowed by X pixels"** | Los hijos dentro de un `Row`/`Column` suman más tamaño del que el padre dispone. | Envolver textos o widgets flexibles en `Expanded` o `Flexible`, o reemplazar `Row`/`Column` por `Wrap` o `SingleChildScrollView`. |
| **"Incorrect use of ParentData widget"** | Un `Expanded`/`Flexible` está fuera de `Row`/`Column`/`Flex`, o un `Positioned` está fuera de `Stack`. | Mover el widget a ser hijo directo del contenedor correspondiente. |
| **"RenderBox was not laid out"** | Error secundario en cascada provocado por un fallo superior. | Ignorar este mensaje y subir en el stack trace hasta encontrar el error primario (unbounded o overflow). |

### 3.2 Protocolo de Fix en Vivo con MCP
Si estás en una sesión de desarrollo activa:
1. Lanza la herramienta MCP `get_runtime_errors` para capturar el error y archivo exacto con número de línea.
2. Aplica la corrección correspondiente.
3. Ejecuta `hot_reload` para validar que las rayas amarillas/negras desaparecen.

---

## 4. Ultra-Optimización: Velocidad a 60/120 FPS y Eficiencia Crítica

### 4.1 Renderizado de Listas: La optimización de 1 línea (`itemExtent`)
Cuando renderizas listas largas (`ListView.builder`), Flutter debe medir la altura de cada elemento dinámicamente durante el scroll, consumiendo ciclos de CPU en el UI thread.

```dart
// ❌ Lento: Flutter calcula el layout de cada elemento al scrollear
ListView.builder(
  itemCount: 10000,
  itemBuilder: (context, i) => ListTile(title: Text('Item $i')),
)

// ⚡ Ultra-rápido: Cálculo matemático directo O(1) de offset y scrollbar
ListView.builder(
  itemCount: 10000,
  itemExtent: 64.0, // O prototypeItem: const ListTile(title: Text('Prototype'))
  itemBuilder: (context, i) => ListTile(title: Text('Item $i')),
)
```

**Banderas de micro-optimización en listas ultra-livianas:**
```dart
ListView.builder(
  itemCount: items.length,
  itemExtent: 72,
  addAutomaticKeepAlives: false, // Libera memoria al salir de viewport
  addRepaintBoundaries: false,   // Ahorra capas de composición en items muy simples
  itemBuilder: (context, index) => ItemTile(item: items[index]),
);
```

---

### 4.2 Concurrencia de Alto Impacto con `Isolate.run()`
Cualquier tarea pesada en el UI thread (parsing de JSON, desencriptación, ordenamiento masivo) bloquea los frames y produce *jank*. 
> Usa `Isolate.run()` (estándar desde Dart 2.19+) en lugar de worker isolates complejos:

```dart
import 'dart:convert';
import 'dart:isolate';

// ❌ Evitar en build o en el UI thread:
// final data = jsonDecode(heavyJsonString);

// ⚡ Concurrencia real fuera del UI thread:
Future<List<TransactionModel>> parseHeavyTransactions(String jsonPayload) async {
  return Isolate.run(() {
    final decoded = jsonDecode(jsonPayload) as List<dynamic>;
    return decoded
        .map((item) => TransactionModel.fromJson(item as Map<String, dynamic>))
        .toList();
  });
}
```

---

### 4.3 Aislamiento de Repintado (`RepaintBoundary`)
Cuando un widget dentro de un árbol cambia (ejemplo: un contador, una animación o un spinner), Flutter repinta por defecto a todos sus hermanos en el mismo `RenderObject`.
- **Aislar animaciones y videos:** Envolver cualquier widget que cambie a 60fps con `RepaintBoundary`.
- **Identificar repintados innecesarios:** Habilitar `debugRepaintRainbowEnabled = true` en debug. Si un elemento estático cambia de color al correr una animación cercana, necesita un `RepaintBoundary`.

```dart
RepaintBoundary(
  child: RotatingLoadingSpinner(),
)
```

---

### 4.4 Decodificación y Caché de Imágenes Quirúrgica
El 80% de los crashes por OOM (Out Of Memory) en Flutter ocurren por cargar imágenes de 4K o alta resolución en su tamaño original en memoria RAM.

```dart
// ❌ Carga la imagen a resolución completa (ej. 12MB RAM por imagen de 4000x3000px):
Image.asset('assets/images/avatar.png')

// ⚡ Decodificación a nivel de GPU al tamaño exacto de visualización (100x100px = ~40KB):
Image.asset(
  'assets/images/avatar.png',
  cacheWidth: 200, // píxeles físicos (ej. 100 logical pixels * 2x DPR)
  cacheHeight: 200,
)

// Para imágenes de red con cached_network_image:
CachedNetworkImage(
  imageUrl: user.avatarUrl,
  memCacheWidth: 200,
  memCacheHeight: 200,
  maxWidthDiskCache: 600,
  placeholder: (context, url) => const ShimmerBox(width: 50, height: 50),
)
```

---

### 4.5 Prevención de Memory Leaks y Retención de `BuildContext`
1. **Regla de oro de Controllers y Subscriptions:** Todo `AnimationController`, `TextEditingController`, `ScrollController`, `FocusNode`, `StreamSubscription` o `Timer` DEBE ser cancelado en `dispose()`:
```dart
@override
void dispose() {
  _textController.dispose();
  _scrollController.dispose();
  _animationController.dispose();
  _streamSubscription.cancel();
  _timer?.cancel();
  super.dispose();
}
```
2. **`BuildContext` a través de Brechas Asíncronas:**
```dart
// ❌ Peligroso: el widget puede haber sido desmontado durante el await
final data = await api.fetchData();
Navigator.of(context).pushNamed('/details'); // Crashea o fuga memoria

// ⚡ Seguro en Flutter moderno:
final data = await api.fetchData();
if (!context.mounted) return;
Navigator.of(context).pushNamed('/details');
```

---

### 4.6 Optimización de Startup Time (TTID & TTFD)
- **Time to Initial Display (TTID):**
  - Nunca pongas llamadas HTTP lentas o inicializaciones pesadas antes de `runApp()`.
  - Agrupa las inicializaciones locales concurrentes con `Future.wait`:
```dart
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // ⚡ Inicializaciones locales en paralelo (no secuenciales):
  await Future.wait([
    SharedPreferences.getInstance(),
    Firebase.initializeApp(),
    initializeLocalDatabase(),
  ]);

  runApp(const MyApp());
}
```
- **Deferred Components / Lazy Loading en Web y Android:** Carga módulos pesados bajo demanda con `import 'package:mi_modulo/heavy.dart' deferred as heavy;` y `await heavy.loadLibrary();`.

---

### 4.7 Compilación de Producción y Shrinking
Comandos de compilación optimizados con ofuscación y descarte de símbolos de depuración:
```bash
# Android App Bundle (optimizado por ABI y con split de debug info)
flutter build appbundle --obfuscate --split-debug-info=./build/symbols

# Android APK por arquitectura (reduce drásticamente el tamaño final)
flutter build apk --split-per-abi --obfuscate --split-debug-info=./build/symbols

# iOS IPA
flutter build ipa --obfuscate --split-debug-info=./build/symbols
```

---

## 5. Design System Premium & Micro-Interacciones

### 5.1 Estética Visual de Alto Nivel
Evita apps genéricas y aburridas:
- **Colores:** No uses primarios saturados por defecto (`Colors.blue`, `Colors.red`). Utiliza `FlexColorScheme` con sub-themes y Material 3 habilitado: `ThemeData(useMaterial3: true)`.
- **Superficies Modernas:** Dark Mode estilizado con tonos carbón/navy (`0xFF0F172A` o `0xFF121824`) en lugar de negro puro (`0xFF000000`).
- **Bordes & Sombras sutiles:** Bordes ultra-delgados con opacidades bajas (`0.06` a `0.10`) y sombras suaves y difuminadas (`blurRadius: 24`, opacidad `0.04`).

```dart
// Tarjeta Premium con Tokens
Container(
  decoration: BoxDecoration(
    color: Theme.of(context).colorScheme.surface,
    borderRadius: AppRadius.borderLg,
    border: Border.all(
      color: Theme.of(context).colorScheme.onSurface.withOpacity(0.08),
      width: 1,
    ),
    boxShadow: AppShadows.soft(context),
  ),
  child: child,
);
```

### 5.2 Tipografía y Espaciado (8dp Grid)
- Utiliza Google Fonts reconocidas: `Outfit`, `Inter`, `Plus Jakarta Sans`.
- Mantén una jerarquía clara:
  - **Títulos:** Bold/SemiBold con `letterSpacing: -0.5`.
  - **Cuerpo:** Regular con `height: 1.4` a `1.6`.
  - **Detalles/Subtítulos:** Opacidad reducida (`onSurface.withOpacity(0.6)`).

### 5.3 Dirección de arte anti-slop (taste-skill v2 → Flutter)
Reescritura para Flutter de la skill `design-taste-frontend` (tasteskill v2). Misma premisa: una pantalla hecha por un modelo es el promedio de todo lo que vio (título centrado, tres cards con icono arriba, gradiente suave, labels en mayúsculas micro-trackeadas). Acá esos defaults se reemplazan por decisiones, con el mismo método en 4 partes:
1. **El script reparte direcciones, tú eliges.** `node <taste>/scripts/draw.mjs` (skill `design-taste-frontend`) reparte 3 de 20 direcciones investigadas y luego reparte type system, paleta, hero y secciones desde `library/` (247 sitios reales). Elegí la que cargue algo que solo este cliente tiene, no la más familiar. Mapeá roles web → pantallas Flutter (hero → bienvenida/destacada, features → lista, pricing → paywall, faq → ayuda, testimonial → reseñas, gallery → galería). La hoja repartida se adopta, no se mezcla con tu layout de siempre.
2. **La idea sale del sujeto.** Inventario de 8–12 cosas solo de este cliente (nombre y qué significa, calle y número, números del brief, materiales, rituales y horarios, impresos de su mundo). Frase obligada antes de construir: "En esta pantalla, **[X del sujeto]** se vuelve **[dispositivo de la dirección]**". Test del competidor: si la frase también le sirve al de al lado, no es idea.
3. **House style sin ornamentos** (tabla de reglas → Flutter, abajo). Se verifica, no se desea.
4. **Mirá lo que hiciste.** Screenshots en 390 / 768 / 1440 (teléfono / tablet / desktop donde aplique), rúbrica de `references/critique.md`, fix, mirar de nuevo. Máximo 3 rondas.

§5.1 y §5.2 siguen vigentes salvo choque: donde 5.3 prohíbe algo que 5.1 permite, manda 5.3. Caso concreto: **sombras en reposo prohibidas** (5.1 permitía `AppShadows.soft` en cards). Card en reposo → paso de tono + borde 1px opacidad `0.06`–`0.10`. Sombra solo en lo que flota de verdad: `AlertDialog`, `ModalBottomSheet`, menús.

#### Carrera (run) adaptada
1. **Brief + inventario** (igual que v2 §1). Ante todo: ¿qué imágenes existen de verdad? Fotos del proyecto, screenshots reales, herramienta de generación, o nada. El `--have` del draw es honesto o la dirección sale mal.
2. **Argumento.** Una línea por pantalla/sección (claim + prueba). Borrá la sección sin claim. Así evitás la secuencia stock (hero, 3 features, testimonial, pricing, CTA).
3. **Draw.** `node <taste>/scripts/draw.mjs --sector <cercano> --brief "<línea>" --sections <roles> --options 3`, elegir contra el inventario, repartir hoja completa con `--direction <id>`. `--keep palette,type` si hay marca. Releer la hoja antes de cada pantalla que construyas (`--show`).
4. **Idea + una cosa viva.** La frase del punto 2 más un elemento interactivo con contenido real, usable con el pulgar (targets ≥ 48px), que funciona sin animación. Se construye con la pantalla, no como "motion" después.
5. **Copy deck en texto plano antes de widgets** (`references/copy.md`): headlines ≤ 2 líneas a todo ancho (~32 caracteres; mediana de galería: 5 palabras); una acción primaria con nombre de lo que hace (un solo `FilledButton`); contenido completo, nada de secciones flacas.
6. **Construir con la animación apagada en la cabeza:**
   - Tokens Dart desde la hoja (ground/ink/accent + roles de tipo). Todo referencia tokens. Base neutra: `ThemeData(useMaterial3: true)` + `FlexColorScheme` (5.1).
   - Hero/pantalla principal exacta al blueprint, a 390 y a desktop. Lo grande, grande; lo chico, chico.
   - Cada sección con su blueprint y el contenido del proyecto. Geometría igual, sujeto distinto. Vecinas con composición distinta. La idea entra a TODAS (precio, ayuda, acerca de).
   - Imágenes en orden: propias → generadas → mundo real del sujeto con `assets.mjs` (Openverse, Wikimedia, AIC, Met; solo licencias comerciales; `--get` descarga a `assets/`, `--credits` imprime créditos) → dibujadas en código (`CustomPainter`, flat, colores de la paleta) → dealt genéricas solo si encajan → solo tipo y color. **Piso: ≥ 4 imágenes reales** (fotos, archivo, mapas, fragmentos de la propia UI cuentan; `CustomPainter`/SVG no cuentan). En Flutter: descargar a `assets/`, declarar en `pubspec.yaml`, `cached_network_image` para remoto.
   - Estados y semántica: `Semantics`, `semanticLabel` en cada `Image`, foco visible, layout de teléfono como composición propia.
7. **Gate.** `lint.mjs` para frases stock en el código + checklist Flutter (abajo) + screenshots (`flutter screenshot` o integration_test en 390–768–1440) + crítica con `references/critique.md`. Cero FAIL; cada WARN se defiende en una frase o se arregla.
8. **Look.** Solo las imágenes juzgan. Top 3 problemas → fix → re-mirar. Máximo 3 rondas.
9. **Move (obligatorio, más que un fade).** 1 signature move de la hoja; entrada por sección (título → texto → imagen, stagger 60–90ms, sube 16–32px + opacity, una vez al entrar en viewport; nunca contenido oculto si falla el controller); feedback en cada control (`InkWell` splash, press-scale, focus); una imagen en movimiento (clip muteado con `video_player` o Ken Burns lento). Solo `Transform`/`Opacity` (nunca animar layout en build); fallback con `MediaQuery.of(context).disableAnimations`. Re-mirar screenshots: nada sin aparecer.
10. **Report.** Dirección + seed, redraws con motivo, frase-idea, cosa viva, scores, créditos (título/creador/licencia/fuente + dónde está el crédito), qué dibujos suplantan fotos, contenido muestra a cambiar. Sin checkout falso: destino real (`url_launcher`) o `mailto:`; jamás formulario de pago falso.

#### Reglas de casa → Flutter (todo build, toda dirección)
| Regla | En Flutter |
|---|---|
| Headlines ≤ 2 líneas a todo ancho | Copy corto + `maxLines: 2, overflow: TextOverflow.ellipsis`; verificar a 390px |
| Enunciados son párrafos | `Text` cuerpo 16–20, `height: 1.5`; nada de 42px en 4 líneas |
| Sin eyebrows | Nada de label chico arriba del título; la info va al título o al cuerpo |
| Sin monospace fuera de código | Cara de texto; números alineados con `FontFeature.tabularFigures()` |
| Sin numeración 01/02/03 | Orden por posición/tamaño; lista real si el orden importa |
| Sin hairlines | Nada de `Divider` decorativo ni cajitas 1px; espacio, tono, escala (tablas y `TextField` reales: exentos) |
| Sin gradientes | Color plano o foto; única excepción: scrim neutro bajo texto sobre foto |
| Sin sombras en reposo | Tono + borde 5.1; sombra solo en diálogo/menú flotante |
| Sin paleta assistant | Nada de crema + terracota ni violeta/índigo; la paleta repartida |
| Sin labels MAYÚSCULAS micro-trackeadas | Caja de oración, tamaño legible, `letterSpacing` normal |
| Sin cards con icono arriba ni filas de cards idénticas | Blueprint repartido (slivers variados, nada de card grid) |
| Sin glass | Nada de `BackdropFilter` decorativo ni pill-nav flotante; `NavigationBar` M3 plano |
| Sin emoji/shapes/fake dashboards | Imagen real, fragmento real de UI, o nada; nada de shimmer gris como contenido |
| Sin palabra-acento en titular | Una familia, un color; el énfasis lo llevan las palabras |
| ≤ 2 tipografías | `google_fonts` con el sistema repartido |

Leyes cortas: 2–3 tamaños hacen el trabajo (ratio display/cuerpo ~4.3; display `letterSpacing: -0.5` a `-1.5`, `height: 0.9`–`1.05`); techo 5 tamaños; alineado a izquierda (centrar, un momento como máximo); márgenes 16–32 (`EdgeInsets`), un solo grid 8dp; gap entre secciones netamente mayor que cualquier gap interno (`SizedBox(height: 96–160)` en teléfono); texto corrido en tinta plena (`onSurface`), jamás gris; superficies separadas por tono (`surface` vs `surfaceContainerLow/High`), nunca línea ni sombra; una imagen dominante (hero ≥ mitad de la primera pantalla); mismos crops (`AspectRatio` + `BoxFit.cover`), esquinas cuadradas salvo dirección contraria; nada tapa un titular; botones planos de un fill, esquinas cuadradas o full-pill decididas una vez (el radio suave 9–16px es el default débil); navegación: wordmark, 3–5 destinos, 1 acción; el cierre es diseñado (pantalla final con marca, no sitemap).

#### Casos especiales
- **Marca existente:** `--keep palette,type`, solo composición del draw; si la marca exige un device baneado, se conserva el asset, se declara y listo.
- **Rediseño/review:** lint + screenshots + crítica primero; rediseño desde el paso 2 con contenido real.
- **Un widget, no una pantalla:** saltear el draw, igualar entorno + reglas + screenshots.
- **Sin Chrome/Node o sin red:** `flutter screenshot` + checklist manual; dibujar imágenes; declararlo en el report.
- Archivos de trabajo en `.taste-skill/` en la raíz del proyecto. Referencias y scripts viven en la skill `design-taste-frontend` (`references/*.md`, `scripts/draw.mjs|assets.mjs|lint.mjs`, `library/`); esta sección no los duplica.

---

## 6. Navegación Declarativa Persistente (GoRouter)

El estándar para navegación profesional en Flutter es `go_router`. La estructura clave para apps móviles modernas es `StatefulShellRoute.indexedStack`, que **mantiene el estado y la posición del scroll intactos al alternar entre pestañas del Bottom Navigation Bar**:

```dart
final appRouter = GoRouter(
  initialLocation: '/home',
  refreshListenable: authStateNotifier, // Redirección reactiva ante login/logout
  redirect: (context, state) {
    final isLoggedIn = authStateNotifier.isLoggedIn;
    final isGoingToLogin = state.matchedLocation == '/login';

    if (!isLoggedIn && !isGoingToLogin) return '/login';
    if (isLoggedIn && isGoingToLogin) return '/home';
    return null;
  },
  routes: [
    GoRoute(
      path: '/login',
      builder: (context, state) => const LoginView(),
    ),
    StatefulShellRoute.indexedStack(
      builder: (context, state, navigationShell) {
        return ScaffoldWithNavBar(navigationShell: navigationShell);
      },
      branches: [
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: '/home',
              builder: (context, state) => const HomeView(),
            ),
          ],
        ),
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: '/settings',
              builder: (context, state) => const SettingsView(),
            ),
          ],
        ),
      ],
    ),
  ],
);

// Scaffold contenedor de la barra de navegación:
class ScaffoldWithNavBar extends StatelessWidget {
  const ScaffoldWithNavBar({super.key, required this.navigationShell});

  final StatefulNavigationShell navigationShell;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: navigationShell,
      bottomNavigationBar: NavigationBar(
        selectedIndex: navigationShell.currentIndex,
        onDestinationSelected: (index) => navigationShell.goBranch(
          index,
          initialLocation: index == navigationShell.currentIndex,
        ),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}
```

---

## 7. Formularios, Validación y Gestión del Teclado

### 7.1 Auto-Scroll al Campo con Error
En formularios extensos, cuando la validación falla en un campo que no está visible en pantalla, la app debe hacer scroll suave hacia él:

```dart
class FormUtils {
  static void scrollToField(GlobalKey key) {
    if (key.currentContext != null) {
      Scrollable.ensureVisible(
        key.currentContext!,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        alignment: 0.1, // Muestra el campo cerca de la parte superior
      );
    }
  }
}
```

### 7.2 Ocultamiento del Teclado y Relleno Automático (Autofill)
- **Dismiss en scroll:** Configura `keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag` en tu `SingleChildScrollView` o `ListView`.
- **Dismiss al tocar fuera:** Envuelve la pantalla en un `GestureDetector(onTap: () => FocusScope.of(context).unfocus())`.
- **AutofillGroup:** Agrupa inputs para permitir sugerencias automáticas del OS (iOS Keychain y Android Autofill):

```dart
AutofillGroup(
  child: Column(
    children: [
      TextFormField(
        autofillHints: const [AutofillHints.email],
        keyboardType: TextInputType.emailAddress,
        decoration: const InputDecoration(labelText: 'Email'),
      ),
      TextFormField(
        autofillHints: const [AutofillHints.password],
        obscureText: true,
        decoration: const InputDecoration(labelText: 'Password'),
      ),
    ],
  ),
)
```

---

## 8. Networking Resiliente con Dio & Renovación de Tokens (JWT)

### 8.1 Renovación Atómica de Tokens con `QueuedInterceptor`
Cuando múltiples llamadas asíncronas fallan con un código `401 Unauthorized`, un interceptor común lanzaría 5 peticiones simultáneas de refresh token, provocando desincronización y logout accidental. 
> Utiliza `QueuedInterceptor` de Dio para pausar la cola, ejecutar una sola renovación de token y reintentar las peticiones encoladas:

```dart
import 'package:dio/dio.dart';

class AuthInterceptor extends QueuedInterceptor {
  AuthInterceptor(this.dio, this.tokenStorage);

  final Dio dio;
  final TokenStorage tokenStorage;

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) async {
    final token = await tokenStorage.getAccessToken();
    if (token != null) {
      options.headers['Authorization'] = 'Bearer $token';
    }
    handler.next(options);
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) async {
    if (err.response?.statusCode == 401) {
      try {
        final refreshToken = await tokenStorage.getRefreshToken();
        if (refreshToken == null) {
          return handler.next(err);
        }

        // Llamada de renovación aislada (sin interceptor para no ciclar)
        final refreshResponse = await Dio().post(
          'https://api.ejemplo.com/auth/refresh',
          data: {'refreshToken': refreshToken},
        );

        final newAccessToken = refreshResponse.data['accessToken'];
        await tokenStorage.saveAccessToken(newAccessToken);

        // Reintentar la petición original con el nuevo token
        final requestOptions = err.requestOptions;
        requestOptions.headers['Authorization'] = 'Bearer $newAccessToken';
        
        final cloneReq = await dio.fetch(requestOptions);
        return handler.resolve(cloneReq);
      } catch (refreshError) {
        await tokenStorage.clearTokens();
        return handler.next(err);
      }
    }
    handler.next(err);
  }
}
```

---

## 9. Testing & Validación Automatizada

### 9.1 Unit Testing con `mocktail`
```dart
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

class MockUserRepository extends Mock implements UserRepository {}

void main() {
  late MockUserRepository mockUserRepository;
  late ProfileViewModel viewModel;

  setUp(() {
    mockUserRepository = MockUserRepository();
    viewModel = ProfileViewModel(userRepository: mockUserRepository);
  });

  tearDown(() {
    viewModel.dispose();
  });

  test('loadProfile emite UiLoading y luego UiSuccess al responder el repo', () async {
    final user = User(id: '1', name: 'Octavio');
    when(() => mockUserRepository.getUser('1')).thenAnswer((_) async => user);

    expect(viewModel.state, isA<UiInitial>());
    
    final future = viewModel.loadProfile('1');
    expect(viewModel.state, isA<UiLoading>());

    await future;
    expect(viewModel.state, isA<UiSuccess<User>>());
    expect((viewModel.state as UiSuccess<User>).data.name, 'Octavio');
  });
}
```

### 9.2 Widget Testing (Simulación de UI y Eventos de Usuario)
```dart
testWidgets('ProfileView muestra CircularProgressIndicator al cargar', (tester) async {
  final mockRepo = MockUserRepository();
  when(() => mockRepo.getUser(any())).thenAnswer(
    (_) => Future.delayed(const Duration(seconds: 1), () => User(id: '1', name: 'Test')),
  );

  final vm = ProfileViewModel(userRepository: mockRepo);
  vm.loadProfile('1');

  await tester.pumpWidget(
    MaterialApp(
      home: Scaffold(
        body: ListenableBuilder(
          listenable: vm,
          builder: (context, _) => switch (vm.state) {
            UiLoading() => const CircularProgressIndicator(),
            _ => const SizedBox.shrink(),
          },
        ),
      ),
    ),
  );

  expect(find.byType(CircularProgressIndicator), findsOneWidget);
  await tester.pumpAndSettle(); // Espera a que termine la animación/asincronía
});
```

---

## 10. Integración con Herramientas MCP Flutter / Dart

Cuando operes en este workspace, utiliza las herramientas del servidor MCP `flutter_dart-mcp-server` para acelerar el ciclo de desarrollo y verificación sin depender de inspecciones a ciegas:

| Herramienta MCP | Momento de Uso | Acción Esperada |
|---|---|---|
| `analyze_files` | Post-edición de código | Corre análisis estático en archivos específicos para atrapar syntax y typing errors antes de compilar. |
| `get_runtime_errors` | Ante excepciones o fallos | Consulta el stack trace activo del runtime de Flutter para ubicar con precisión quirúrgica el archivo y la línea del error. |
| `hot_reload` | Tras corregir lógica o UI | Aplica el cambio en milisegundos en la sesión Flutter activa sin reiniciar el estado de la app. |
| `hot_restart` | Tras modificar `main()` o DI | Reinicia la máquina virtual de Dart cuando se alteran singletons o la jerarquía de routing inicial. |
| `widget_inspector` | Diagnóstico de composición | Inspecciona el widget tree real para detectar render objects desbordados o constraints erróneas. |
| `pub_dev_search` | Antes de añadir dependencias | Busca versiones oficiales, compatibilidad y scores en pub.dev para evitar librerías obsoletas o abandonadas. |

---

## 11. Autoupdate rápido (Android, sin tienda)

> Detalle completo (código, manifiesto, nativo, tests, trampas): `references/autoupdate.md`.

Manifiesto `latest.json` en tu release (generalo en el script de publish con
`Get-FileHash`, y verificalo al final con cache-buster `?nc=<epoch>`):

```json
{"version": "1.2.3", "versionCode": 12,
 "url": "https://.../app-release.apk",
 "sha256": "<hex del Get-FileHash>",
 "notes": "qué cambió", "published_at": "<iso>"}
```

Servicio mínimo (`lib/core/update/update_service.dart`):

1. `check()`: GET al manifiesto con timeout. Compara `versionCode` contra el
   instalado (`package_info_plus`). Solo avisa si el remoto es mayor.
2. `download(info, onProgress)`: stream a `<cache>/updates/openher-<v>.apk`,
   reportando `recibidos/total`. **Borra el parcial si se interrumpe** (un APK
   truncado pasa cualquier piso de tamaño y el instalador lo rechaza).
3. Verifica `sha256` del archivo **antes** de marcar `ready`; si falla, error
   claro y borra el archivo. Exige `https://` en la URL.
4. `install()`: `FileProvider.getUriForFile` + `ACTION_VIEW`
   (`application/vnd.android.package-archive`, `FLAG_GRANT_READ_URI_PERMISSION`).
   Si `canRequestPackageInstalls == false`, manda a Ajustes y expone fase
   `installDenied` con mensaje ("concedé instalar apps desconocidas").
5. Tras descarga ok, borra APKs viejos (`discardApks(keep: version)`): cada
   versión pesa ~50 MB y nadie los limpia solo.

Android (`AndroidManifest.xml` + `res/xml/file_paths.xml`):

```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES"/>
<provider android:name="androidx.core.content.FileProvider"
    android:authorities="${applicationId}.fileprovider"
    android:exported="false" android:grantUriPermissions="true">
    <meta-data android:name="android.support.FILE_PROVIDER_PATHS"
        android:resource="@xml/file_paths" />
</provider>
```

UI: banda con estados (`idle/available/downloading/ready/failed`) + MB
totales + fingerprint corto del sha + Cancelar siempre visible (cierra el sink
y borra el parcial). El fallo de **chequeo** no se muestra; el de **descarga**
sí, con Reintentar. Throttle del chequeo a 24 h (fallos no consumen ventana).

Trampas que ya mordieron (no repetir):

- `flutter build apk` compila feliz un manifest inválido: antes de publicar,
  `aapt2 dump xmltree --file AndroidManifest.xml <apk>` sin dos `action` seguidos.
- **Bumpear `pubspec.yaml` ANTES de compilar**: si no, el APK conserva el
  `versionCode` viejo y el update se ofrece para siempre.
- GitHub sirve el asset viejo desde caché: toda verificación con `?nc=<epoch>`.
- Compila **arm64-only** si el peso importa (26 MB vs 73 MB universal).

## Apéndice A — Tokens Globales del Sistema (`ui/core/tokens/`)

```dart
import 'package:flutter/material.dart';

abstract class AppSpacing {
  static const v4  = SizedBox(height: 4);   static const h4  = SizedBox(width: 4);
  static const v8  = SizedBox(height: 8);   static const h8  = SizedBox(width: 8);
  static const v12 = SizedBox(height: 12);  static const h12 = SizedBox(width: 12);
  static const v16 = SizedBox(height: 16);  static const h16 = SizedBox(width: 16);
  static const v24 = SizedBox(height: 24);  static const h24 = SizedBox(width: 24);
  static const v32 = SizedBox(height: 32);  static const h32 = SizedBox(width: 32);
  static const v48 = SizedBox(height: 48);  static const h48 = SizedBox(width: 48);

  static const p8  = EdgeInsets.all(8);
  static const p16 = EdgeInsets.all(16);
  static const p24 = EdgeInsets.all(24);
  static const pageH24 = EdgeInsets.symmetric(horizontal: 24);
}

abstract class AppBreakpoints {
  static const double mobileMax = 600;
  static const double tabletMax = 1024;

  static bool isMobile(BuildContext context) => MediaQuery.sizeOf(context).width <= mobileMax;
  static bool isTablet(BuildContext context) =>
      MediaQuery.sizeOf(context).width > mobileMax && MediaQuery.sizeOf(context).width <= tabletMax;
  static bool isDesktop(BuildContext context) => MediaQuery.sizeOf(context).width > tabletMax;
}

abstract class AppRadius {
  static const sm = Radius.circular(12);
  static const md = Radius.circular(16);
  static const lg = Radius.circular(24);

  static const borderSm = BorderRadius.all(sm);
  static const borderMd = BorderRadius.all(md);
  static const borderLg = BorderRadius.all(lg);
}

abstract class AppShadows {
  static List<BoxShadow> soft(BuildContext context) => [
    BoxShadow(
      color: Theme.of(context).colorScheme.shadow.withOpacity(0.04),
      blurRadius: 24,
      offset: const Offset(0, 8),
    ),
  ];
}
```

---

## Apéndice B — Checklist Maestro de Calidad & Release

Antes de dar por finalizada una pantalla o feature en Flutter, audita:

- [ ] **State & Lifecycle:** Estados modelados con `sealed class UiState`, controllers y subscriptions liberados en `dispose()`, y callbacks asíncronos protegidos con `context.mounted` o `!isDisposed`.
- [ ] **Render Performance:** `ListView` grandes usando `itemExtent` o `prototypeItem`. Widgets animados y spinners aislados con `RepaintBoundary`.
- [ ] **Memory & Assets:** Imágenes con `cacheWidth`/`cacheHeight` configurados. Cero fugas de closures capturando `BuildContext`.
- [ ] **Layout Safety:** Cero warnings de `unbounded height/width` o `RenderFlex overflowed`. Pantallas adaptativas usando `AppBreakpoints` y contenedores centrados con `maxWidth`.
- [ ] **Navigation & Forms:** Tabs implementados con `StatefulShellRoute.indexedStack`. Formularios con auto-scroll en caso de error y `AutofillGroup`.
- [ ] **Networking:** `QueuedInterceptor` en Dio para renovación de tokens y manejo tipado de errores de red.
- [ ] **Autoupdate (si aplica):** manifiesto con `sha256`, APK verificado antes de `ready`, parcial borrado al cancelar, viejos descartados, `versionCode` bumpeado antes de compilar.
- [ ] **Verification:** Código sin errores de análisis (`analyze_files` vía MCP limpio) y tests unitarios / de widget verificados.
