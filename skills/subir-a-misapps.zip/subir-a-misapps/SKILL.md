---
name: subir-a-misapps
description: Publicar apps o archivos en la tienda Apps de Octa (https://appsdeocta.web.app). Úsala SIEMPRE que el usuario pida subir algo a la página, pasar un archivo a otro dispositivo o al celular ("subime X a la página", "pasame esto al celu", "subilo como temporal", "publicá esta app"), crear o borrar un release en Owning01/mis-apps, o limpiar archivos temporales.
---

# Subir a Apps de Octa

0. Clasificá: "temporal/pasar/rápido" → TEMPORAL (paso 4); si no → PERMANENTE. ¿Duda? Preguntá en 1 línea, nunca adivines el destino.
1. CUENTA (el usuario tiene 2): `gh auth status` → usuario activo. `gh repo view <DUEÑO/REPO> --json name`: si falla, cuenta equivocada → `gh auth switch --hostname github.com --user <OTRO>` (o `gh auth login`). Sin acceso, FRENAR.
2. Destino: sin repo propio → `Owning01/mis-apps`; con repo propio → SU repo. Si falta en `config.json` (clonar el repo si hace falta): agregar a `repos[]` + patrón en `categories` (si no cae en "Otras"), commit+push y `firebase deploy --only hosting` (sin sesión, avisar). Detalle: `Owning01/mis-apps/SUBIR-APPS.md`.
3. Permanente: `gh release create <app>-vX.Y.Z <archivo> --repo <DUEÑO/REPO> --title "<App> vX.Y.Z" --notes "<qué es>"`. Tag único; versión nueva = tag nuevo. El archivo debe quedar ADJUNTO: drafts o releases sin archivos NO se muestran.
4. Temporal: igual pero tag `temp-<slug>-AAAAMMDD` + `--prerelease --title "[TEMP] <nombre]"`. Sale en el tab Temporales.
5. Limpieza (en cada subida temporal): `gh release list -R Owning01/mis-apps`; borrar `temp-*` de +7 días con `gh release delete <tag> -y -R Owning01/mis-apps` + `gh api -X DELETE repos/Owning01/mis-apps/git/refs/tags/<tag>`.
6. Verificá que APARECE: `gh release view <tag> -R <DUEÑO/REPO> --json tagName,assets` (tag presente + assets>0).
7. Respondé corto: link directo `https://github.com/<DUEÑO>/<REPO>/releases/download/<tag>/<archivo>` + la página. Nada más.
8. Límite 2 GB por archivo. Nunca pidas logins al que descarga: la descarga es directa.
