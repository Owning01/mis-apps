# FAILURES — registro de fallas del scrapeador

**Bitácora append-only.** Cuando agentes usen `x-scrape` y encuentren algo que no funciona, lo
**documentan acá** con el formato de abajo. No lo arregles en silencio: si lo arreglás, dejá la
entrada igual con `estado: arreglado` y la fecha del fix.

Esto existe porque el scrapeador depende de un tercero que cambia sin avisar. Una sola sesión de
pruebas encontró **17 problemas reales**, cuatro de los cuales eran **el propio scraper
reportando algo falso**.

---

## Formato

```markdown
### F-n | <titulo corto> | <fecha ISO> | estado: abierto|arreglado|workaround

**Sintoma:** qué se ve, con el mensaje de error o el valor de salida exacto.
**Contexto:** comando completo que lo dispara, y qué devolvió (`status`, exit code, campos).
**Causa:** por qué pasa. Si es de terceros, decirlo explícito.
**Workaround:** qué hacer mientras tanto, si hay algo.
**Arreglado en:** commit / fecha / línea.
```

`estado: abierto` es lo normal. **No cierres una falla sin verificarla de nuevo** con el comando
que la disparaba.

---

## F-1 | Carga de X que nunca resuelve, reportada como `empty` | 2026-10-04 | estado: arreglado

**Sintoma:** `search` devolvía `status: "empty"` con 0 resultados, cuando la búsqueda sí tenía
resultados.

**Contexto:** `node scripts/scrape.js search "video diffusion" --limit 10`. Tardaba 76 s con
`navigations: 1`. El `session` decía `cuenta: Gbro`, `challenge: false`, `logged_out: false` y
`titulo` correcto — o sea, sesión viva y página cargada. Pero `cargados: 0`.

**Causa:** X sirve la columna de resultados en dos estados: *cargando* (spinners, 0 articles) y
*resuelto*. A veces el primero **se queda colgado para siempre**. El health check solo miraba
"hay rows?", así que un spinner eterno y una búsqueda genuinamente vacía eran indistinguibles.
Medido: la página resuelve en ~10 s cuando resuelve, y `responses >= 400` era 0 — no era bloqueo,
ni Cloudflare, ni throttling.

**Workaround:** si ves `empty` con 0 resultados, esperá y reintentá. No lo tomes como "no hay nada".

**Arreglado en:** 2026-10-04. Se agregó `cargando` y `articulos` al probe, un estado `stalled`
distinto de `empty`, y un reintento con más espera. `stalled` sale con código 3.

---

## F-2 | El scraper nunca decía si había mirado o no | 2026-10-03 | estado: arreglado

**Sintoma:** `user` contra una cuenta devolvió `cuenta: ""` y `results: []`. Imposible distinguir
"cuenta sin posts" de "el scraper falló".

**Contexto:** `node scripts/scrape.js user "gbroOCT"`. Resuelto probando `@elonmusk` como control.

**Causa:** faltaba el triaje explícito de salud de la carga.

**Arreglado en:** 2026-10-03. Campo `status` con `ok | empty | blocked | stalled`.

---

## F-3 | Texto en chino o con emoji no podía marcarse como copypasta | 2026-10-04 | estado: arreglado

**Sintoma:** dos tweets con texto **idéntico** en chino + emoji no se marcaban como duplicados.

**Contexto:** fixture con texto chino, emoji y japonés en dos autores distintos.

**Causa:** los shingles de 3-gramas necesitan ≥3 palabras. El chino no separa por espacios, así
que una frase en chino es **un** solo token: 2 palabras totales, 0 shingles, y `jaccard()` siempre
devolvía 0. El caso peor: los posts cortos, que son justo los más copiados.

**Arreglado en:** 2026-10-04. Fallback a shingles de 4 caracteres cuando hay <3 shingles.

---

## F-4 | Umbral de dedup mal calibrado | 2026-10-04 | estado: arreglado

**Sintoma:** el dedup exacto daba **0 duplicados** en un corpus donde había 2 pares copiados.

**Contexto:** `@codesthea` ~ `@axiatechie`.

**Causa:** comparar texto normalizado **exacto** no detecta el mismo contenido reordenado. Al
pasar a shingles el número bajó mucho: con word-sets daba 0.57, con 3-gramas da **0.158**.

**Arreglado en:** 2026-10-04. Umbral recalibrado a **0.12**, medido: siembra de contenido = 0.158,
amplificación legítima (`@invideoOfficial` ~ `@aran_leigh`) = 0.041. Separación de ~4x, un solo
copypasta marcado de 99.

---

## F-5 | El ranking por keywords enterraba los hallazgos buenos | 2026-10-03 | estado: arreglado

**Sintoma:** el anuncio oficial de `@tavus` (48% de personas creyó que un avatar era humano)
quedaba en el **puesto 60 de 99**; un promo de build local puntúa 15 contra su 3.

**Causa:** el score contaba repeticiones de keywords. Un post corto y oficial pierde contra uno
largo y keyword-stuffed.

**Arreglado en:** 2026-10-03. `analyze.js --rank authority`, con diversidad de autor (un post
por autor primero, después completa). `@tavus` ahora entra al top-5.

---

## F-6 | `--limit` tomaba el valor de `--out` | 2026-10-03 | estado: arreglado

**Sintoma:** `--limit 5 --out f.json` producía `limit: "<ruta del archivo>"` y `results: []`.

**Causa:** el parser reasignaba la función `flag` dentro de un loop.

**Arreglado en:** 2026-10-03. Parser de un solo paso. Con test.

---

## F-7 | La paginación no cargaba páginas nuevas | 2026-10-03 | estado: arreglado

**Sintoma:** `--pages 3 --limit 30` devolvía 7 resultados.

**Causa:** la búsqueda de X usa **lista virtualizada**: al scrollear se desmonta lo que quedó
atrás, así que contar `article` al final nunca pasa de ~7-12. Hay que **extraer y acumular** en
cada paso de scroll.

**Arreglado en:** 2026-10-03.

---

## F-8 | `node --check` no detecta errores de orden | 2026-10-04 | estado: workaround

**Sintoma:** `const allowMedia = flags.media === true;` colocado **antes** de `const flags = {}`.
`node --check` pasaba, pero al ejecutar: `ReferenceError: Cannot access 'flags' before
initialization`.

**Causa:** `--check` valida **sintaxis**, no orden de declaración (TDZ).

**Workaround:** después de tocar JS, corré el script de verdad con un input que no toque la red
(por ejemplo sin argumentos, que debe salir con código 2). El parseo solo no alcanza.

**Mitigación:** existe `test-smoke.js`, que corre el script de verdad. Lo cushiona, no lo
reemplaza.

---

## F-9 | El costo de CPU es intrínseco, no del código | 2026-10-04 | estado: documentado

**Sintoma:** una corrida saturaba **~430% de CPU** (31-34 procesos, 8,6 s de CPU por cada 2 s de
reloj).

**Contexto:** cualquier corrida de `scrape.js`. El usuario lo notó como "se disparó muy arriba".

**Medición:**

| Escenario | CPU acumulada |
|---|---|
| Solo arrancar y cerrar Brave, sin navegar | 11,9 s |
| Arrancar + 12 s en x.com | 52,2 s |
| Con media bloqueada por `route()` | 47,8 s |
| Con `--blink-settings=imagesEnabled=false` | 50,7 s |
| Con lo anterior + `--disable-gpu` | 49,6 s |

**Causa:** **cargar x.com en un navegador headless es caro**, y es un SPA que rasteriza por
software. No es el scraping.

**Workaround:** no hay optimización de media que sirva (las tres variantes están dentro de ruido).
Los levers reales: cargar menos páginas, agrupar con `multi`, usar `--cache`, y no correrlo en
paralelo con trabajo pesado.

**GPU:** ver F-11. La GPU está activa y solo al 4%: el trabajo pesado es JavaScript y layout del
SPA, que corre en CPU aunque la GPU esté ociosa.

---

## F-10 | `process.exit()` truncaba la salida cuando stdout es un pipe | 2026-10-04 | estado: arreglado

**Sintoma:** `node scrape.js --gpu-check` por pipe devolvía `stdout` de **6 bytes**: la palabra
`Brave`. Interactivo se veía perfecto; por pipe, el renderer se perdía.

**Contexto:** cualquier `console.log(...)` seguido de `process.exit()`.

**Causa:** en Node, cuando stdout es un pipe, las escrituras son **asíncronas**. `process.exit()`
mata el proceso antes de que se vacíen. En una TTY son síncronas y por eso el bug no se veía
interactuando a mano.

**Workaround:** nunca `process.exit()` después de imprimir. Usar `process.exitCode = N` y
`return`.

**Arreglado en:** 2026-10-04. Las tres llamadas a `process.exit()` del script pasaron a
`process.exitCode` + `return`.

---

## F-11 | Brave's Shields hace que el chequeo de GPU dé un "GPU activa" falso | 2026-10-04 | estado: arreglado

**Sintoma:** `--gpu-check` informaba `GPU activa` con el renderer `Brave` en pantalla, incluso
sin GPU.

**Contexto:** `node scrape.js --gpu-check`.

**Causa:** Brave's **Shields sustituye `WEBGL_debug_renderer_info` por la cadena literal
`"Brave"`** como contramedida de anti-fingerprinting. Un `<canvas>` con `getContext('webgl')`
en `about:blank` devuelve `"Brave"` **tanto si hay RTX 3090 como si hay SwiftShader**. El regex
de detección de software (`swiftshader|llvmpipe|...`) no matchea `"Brave"`, así que el chequeo
daba aprobado sin haber verificado nada. Era el peor tipo de bug: un test de salud que siempre
pasa.

Agravante: `chrome://gpu` devuelve `innerText` **vacío** (el contenido va en shadow DOM), así
que scrapear ese texto tampoco sirve.

**Arreglado en:** 2026-10-04. El canvas se corre ahora **sobre una página `chrome://`**, donde
Shields no interviene, y ahí sí devuelve
`ANGLE (NVIDIA, NVIDIA GeForce RTX 3090 (0x00002204) Direct3D11 vs_5_0 ps_5_0, D3D11)`.
Tres salidas: `0` GPU confirmada, `4` software, `3` no verificable. Si el renderer vuelve
enmascarado como `Brave`, devuelve `3` y lo dice. El test de humo falla si llega enmascarado.

**Dato de fondo:** la GPU **ya estaba activa sin ningún flag**. Agregar
`--use-angle=d3d11 --enable-gpu --ignore-gpu-blocklist` produce un renderer idéntico, y
`--ignore-gpu-blocklist` puede forzar un driver peor. No se agregan.

---

## F-12 | HTTP 429 se reportaba como "no hay resultados" | 2026-10-04 | estado: arreglado

**Sintoma:** `search` devolvía `status: "empty"` con 0 resultados, `titulo: ""`, `cuenta: null`,
`cargando: false`, `challenge: false`, `logged_out: false`. Es decir: **ninguna señal visible de
problema**.

**Contexto:** `node scrape.js search "video diffusion" --limit 5` después de ~30 navegaciones
en el día contra la cuenta del agente.

**Causa:** **X responde 200 para el HTML del documento y 429 para todas las llamadas a la API**
(`api.x.com/1.1/account/settings.json`, `/i/api/graphql/.../Viewer`). El HTML llega vacío y
el SPA no tiene con qué pintar: página en blanco, **sin spinner included**. El triaje solo
miraba el DOM, no la red, así que caía en el mismo saco que una búsqueda legítima sin
resultados.

Confirmado con un probe que registró respuestas: `goto=200`, `arts=0`, `spinners=0`,
`bodyLen=0`, `429 api.x.com/...`, `429 x.com/i/api/graphql/.../Viewer`.

**Por qué importa:** esto es la **peor clase de falla de un scraper**. Un agente leía
`status: empty`, concluía "no hay nada sobre este tema en X" y lo reportaba como hallazgo.
No es un resultado: es una ausencia de mirada.

**Workaround:** si ves `empty` **y** `session.titulo` viene vacío, no es una búsqueda vacía.
Esperar **horas** antes de reintentar.

**Arreglado en:** 2026-10-04. Se escucha `page.on('response')` y se cuentan `429` / `4xx` /
`5xx`. Nuevo estado **`throttled`** (código de salida **5**) que gana sobre todos los demás, más
**`no_render`** para "página en blanco sin 429". Los contadores quedan en `red` dentro del JSON.
El poll de espera corta apenas aparece un 429 (esperar más no sirve) y **no reintenta**: un
reintento solo gasta cuota.

---

## F-13 | `--start-minimized` no minimiza nada | 2026-10-04 | estado: arreglado

**Sintoma:** `--show` abría la ventana pero **visible**, no minimizada. Medido con
`IsIconic` de Win32: `False` en las 3 muestras.

**Contexto:** `node scrape.js search "q" --show`.

**Causa:** **`--start-minimized` solo afecta a la ventana inicial del navegador.** Playwright
crea la ventana de la pestaña **después** del arranque, vía CDP. Ese flag nunca la alcanza.

**Workaround:** ninguno con flags de Chromium.

**Arreglado en:** 2026-10-04. Se minimiza después del arranque con
`ShowWindow(hwnd, SW_MINIMIZE)` desde un `.ps1` temporal. Verificado: `IsIconic` pasa a `True`
justo después de la llamada.

**Trampa al implementarlo:** el one-liner de PowerShell con comillas anidadas falló
(`Command failed`), porque concatené sentencias con espacio en vez de `;`. Va en un archivo
`.ps1` invocado con `-File`.

---

## F-14 | Ternario invertido: el JSON decía "headless" con ventana abierta | 2026-10-04 | estado: arreglado

**Sintoma:** el JSON reportaba `ventana: "oculta (headless)"` mientras `headless: false` y
había una ventana visible con título real.

**Contexto:** `node scrape.js search "q" --show`.

**Causa:** se escribió `ventana: !headed2 ? 'visible-minimizada' : 'oculta (headless)'`. El `!`
da la respuesta al revés: si hay ventana (`headed2` verdadero) cae en `'oculta'`. Es
exactamente la clase de bug que este scraper ya acumuló: **el reporte dice lo contrario de lo
que pasó**.

**Arreglado en:** 2026-10-04. Invertido a `headed2 ? ... : ...` y verificado con las tres
combinaciones: sin flag → `oculta (headless)`, `--show` → `visible-minimizada`,
`--show --focus` → `visible`.

---

## F-15 | Un validador reescribió el archivo que validaba y lo dejó en 0 bytes | 2026-10-04 | estado: arreglado

**Sintoma:** `FAILURES.md` quedó con **0 bytes**. Las 14 entradas de este archivo desaparecieron.

**Contexto:** script de barrido CJK que, al encontrar caracteres, reescribía el archivo original
con `io.open(p, "w", ...)`. El loop interior reassignaba la variable de texto mientras iteraba
sobre ella, y el write final terminó vaciando el archivo. Peor: el validador corría **sobre los
archivos que él mismo genera**.

**Causa:** un validador que **reescribe** la entrada que valida no es un validador, es un
editor que empieza a borrar. Le faltó (a) leer a una variable, transformar a otra, y recién
después escribir, y (b) una verificación de tamaño antes del write.

**Workaround:** los validadores **solo leen y reportan**. Si hay que corregir, se edita con
herramientas explícitas y se vuelve a validar.

**Arreglado en:** 2026-10-04. `FAILURES.md` reconstruido completo (F-1 a F-15) desde el
contenido de la sesión. Los validadores ya no escriben.

---

## F-16 | Cada consulta recargaba x.com entero: 8x mas peticiones y 4x mas CPU | 2026-10-04 | estado: arreglado

**Sintoma:** la cuenta del agente se throttleaba (HTTP 429, ver F-12) tras unas 30 navegaciones
en el dia. Dos symptoms derivados: `multi` con 7 consultas tardaba 87 s y saturaba la CPU
repetidamente, y el scraper estaba pegándole a X mucho mas de lo necesario.

**Contexto:** `multi` hacia `page.goto(busqueda)` **una vez por consulta**.

**Causa:** `page.goto` a x.com es un **arranque completo de la SPA**. Medido 2026-10-04
contando peticiones con `page.on('request')`:

| Accion | Peticiones totales | A la API de X |
|---|---:|---:|
| `page.goto` a una busqueda | **197** | **23** |
| Cambiar la consulta dentro del SPA | 25 | 10 |
| Un scroll | 18 | 5 |

Una persona **no recarga x.com para cada busqueda**: escribe en la caja y le da Enter. El
scraper si. Multiplicado por N consultas, y Each arranque tambien paga el costo de CPU de
rasterizar el SPA entero.

Ademas, el arranque pide endpoints que el scraper **nunca usa**: `fleetline`,
`live_pipeline/update_subscriptions`, `CreatorStudioTabBarItemQuery`, `DataSaverMode`,
`hashflags.json` (ruido de barra lateral y streaming). `viewer_context.json` y
`flow/timeline.json` se piden **3 veces** en una sola navegacion.

**Arreglado en:** 2026-10-04. `multi` ahora hace `goto` **solo para la primera consulta** y
despues cambia la consulta **dentro del SPA** (`buscarEnSpa()`, usa
`[data-testid="SearchBox_Search_Input"]` + Enter). Si el salto falla (caja ausente, DOM
cambiado) **cae a `goto`**, asi que nunca es peor que antes.

Medido con 4 consultas nuevas:

| | Antes | Ahora |
|---|---:|---:|
| Peticiones totales | ~788 | **391** |
| Llamadas a la API | ~92 | **52** |
| Recargas de la SPA | 4 | **1** |
| 429 | 3 en el dia | **0** |

El JSON ahora distingue `navigations` (recargas caras) de `spa_saltos` (saltos baratos), y
`red.peticiones` / `red.api` dan el costo real de la corrida.

**Pendiente:** bloquear el ruido de arranque (`fleetline`, `live_pipeline`,
`CreatorStudioTabBarItemQuery`, `DataSaverMode`, `hashflags.json`) bajaria el costo del primer
goto. No se hizo porque `settings.json` participa en la deteccion de sesion y no se quiere
tocar eso sin pruebas. `--pages` sigue siendo scroll, que ya era barato (18 peticiones).

---

## F-17 | Los tests dependian de una carpeta externa y se rompieron al moverla | 2026-10-04 | estado: arreglado

**Sintoma:** `test-analyze.js` salia con codigo 2 y `faltan entradas de prueba:`. Los14 tests
dejaban de correr **sin ningun otro sintoma**: el resto de la skill estaba bien.

**Contexto:** se reorganizo `G:/Proyectos/x-research/` y los raw se movieron a `data/raw/`.
`test-analyze.js` apuntaba a `G:/Proyectos/x-research/raw-01.json`.

**Causa:** el test tomaba sus fixtures de una carpeta de research **fuera de la skill**. Cualquier
movida, rename o limpieza de ese proyecto rompia los tests de la skill, y no hay ningun aviso
en el codigo de scrape.js ni de SKILL.md: el dano aparecia lejos de su causa.

**Workaround:** `node test-analyze.js G:/Proyectos/x-research/data/raw`.

**Arreglado en:** 2026-10-04. Los 3 raw de la ronda 2026-10-03 se copiaron a
`scripts/fixtures/` y el test los usa por defecto (`path.join(__dirname, 'fixtures')`).
Sigue acepta un override por argv.

**Regla general:** un test no debe depender de que nadie mueva una carpeta. Los fixtures viajan
con la skill.


---

## Tabla de estados (post F-12)

| `status` | Salida | Significado | ¿Confiar? |
|---|---|---|---|
| `ok` | 0 | Se miró y hubo artículos | Sí |
| `empty` | 0 | La página cargó y no hay resultados | Sí, si `session.titulo` no está vacío |
| `no_render` | 3 | Página en blanco: **no se miró nada** | No |
| `stalled` | 3 | Spinners eternos: la carga no resolvió | No |
| `blocked` | 3 | Cloudflare o sesión cerrada | No |
| `throttled` | 5 | HTTP 429: cuenta rate-limited | No, y **dejar de correr** |

**Regla:** los cuatro que dicen "no" tienen `titulo` vacío o `cargando: true`. Si ves `empty`,
**siempre** mirá `session.titulo` antes de concluir algo.

## Ventana visible: cómo usarla

| Combo | Efecto |
|---|---|
| (nada) | headless, sin ventana |
| `--show` | ventana real **minimizada**: la ves en la barra de tareas, no tapa la pantalla ni roba el foco |
| `--show --focus` | ventana visible al frente |
| `--headed` | ventana visible al frente (igual que `--show --focus`) |

El JSON lleva `ventana: oculta (headless) | visible-minimizada | visible` y `headless: bool`.

---

## F-18 | `account.js` salia con codigo 3 y stdout vacio | 2026-10-04 | estado: arreglado

**Sintoma:** `node account.js whoami` devolvio codigo 3 y **no escribio ningun JSON**. No habia
forma de saber si fallo antes de mirar o si se callo.

**Contexto:** primer script que escribe en la cuenta (perfil, avatar, publicaciones).

**Causa:** **bug mio.** El script tiene ~8 `return` de salida temprana (sesion caida, throttle,
selector inexistente) y en la primera version todos esos `return` salteaban la impresion del
JSON: la impresion estaba solo en el camino feliz. Peor: el `finally` solo cerraba el contexto.

**Arreglado en:** 2026-10-04. La salida se movio al `finally` con un helper `emit()` con guarda
`emitted`, para que se escriba **una vez en todos los caminos**. Mismo principio que F-2 aplicado
a escritura: si el script puede fallar, tiene que decir como fallo.

**Regla que sale de aca:** en un script que ESCRIBE, el exito no es "no tiro error", es **"se vio
el efecto"**. `account.js` relee el perfil despues de guardar (`antes` / `despues`) y marca
`verificado: true` solo si la sesion estaba sana.

---

## F-19 | El perfil propio no se encontraba: tres suposiciones incorrectas | 2026-10-04 | estado: arreglado

**Sintoma:** `abrirEditor()` devolvia `null` y el script cancelaba la escritura con
`no_render`, aunque la sesion estaba perfecta (`logueado: true`, 0 errores 4xx/5xx).

**Contexto:** intento de cambiar la bio de @gbroOCT.

**Causa:** tres suposiciones mias, las tres verificadas con sonda de DOM antes de arreglar:

| Suposicion | Realidad (medida 2026-10-04) |
|---|---|
| El menu del switcher tiene "Your profile" | **No existe.** Solo "Add an existing account" y "Log out @gbroOCT" |
| `[data-testid="UserName"]` es un link y se puede clickear | Es un **DIV**. El click no hacia nada |
| El boton dice "Edit profile" | Es `<a data-testid="editProfileButton">` y dice **"Set up profile"**, porque la cuenta esta incompleta (sin bio, sin avatar) |

**Arreglado en:** 2026-10-04. El perfil se alcanza por
`a[data-testid="AppTabBar_Profile_Link"]`, con fallback al handle del
`data-testid="UserAvatar-Container-<handle>"`. El editor se busca por **testid**, no por texto.

**Regla que sale de aca:** en X, el texto de un boton depende del estado de la cuenta. Buscar por
texto es buscar algo que cambia solo. El `data-testid` es lo estable.

---

## F-20 | Un sleep fijo decidia que la pagina "no se miró" | 2026-10-04 | estado: arreglado

**Sintoma:** `status: no_render` con `titulo: ""`, `logueado: false` y solo **85 peticiones / 1
llamada a la API**. Ningun 429. X no estaba throttleado: la pagina **no termino de cargar** y el
script lo reporto como que no habia mirado.

**Contexto:** `salud()` hacia `sleep(2500)` una vez y decidia.

**Causa:** **bug mio, y es exactamente F-1/F-12 repetido en un script nuevo.** `scrape.js` ya
documenta la respuesta correcta (poll corto con tope de espera, no un sleep fijo) y yo no la
replique al escribir el script nuevo.

**Arreglado en:** 2026-10-04. `salud()` ahora hace poll cada 2 s hasta 25 s y recien ahi decide, y
distingue por lo que **si** vio (`429` > challenge > sin pintar > deslogueado).

**Regla que sale de aca:** las clases de falla conocidas se repiten si no se las busca. Al escribir un
script nuevo que navega, copiar el `go()` de `scrape.js` es mas barato que reinventar el poll.

---

## F-22 | El editor de perfil no existe: `setup_profile` responde "Something went wrong" | 2026-10-04 | estado: arreglado

**Sintoma:** el boton para editar el perfil **no abre un dialogo**. Navega a
`https://x.com/i/flow/setup_profile`, y ahi la pagina dice literalmente
`Something went wrong. Try reloading.` con un unico boton `Retry`. **0 inputs, 0 textareas.**
`account.js` buscaba un dialogo con campos, no lo encuentra, y cancela con `no_render`.

**Contexto:** primer intento real de cambiar la bio de @gbroOCT.

**Causa:** **comportamiento de un tercero**, y se compone con F-21. El flujo de edicion de perfil
es una ruta distinta del feed: pide sus propios endpoints, y con la cuenta degradada **esos** fallan
aunque el home cargue. Confirmado con sonda de red: **1 respuesta HTTP 429** en 101 peticiones,
contra las **0** del home en la misma sesion.

O sea: **F-21 no es solo "el home no trae articulos".** X degrada de forma *selectiva por ruta*, y
el home puede verse perfecto mientras la ruta que necesito esta caida. Un chequeo de salud que solo
mira el home **no dice si se puede escribir**.

**Workaround (encontrado 2026-10-04, mismo dia):** la ruta `/i/flow/setup_profile` es **evitable**.
`https://x.com/settings/profile` carga el formulario completo sin pasar por el flujo de setup.
Medido: 3 `input[type=file]`, 2 `textarea`, el campo de nombre con valor `"Gbro"`, **0 errores 429**
— en la misma sesión donde el flujo de setup tiraba 429.

`account.js` ahora va **primero a la pagina de ajustes** y usa el link del perfil solo como red de
seguridad. `abrirEditor()` devuelve además `ruta: 'ajustes' | 'perfil'` para que el JSON diga por
dónde entró.

**Estado: `workaround` → RESUELTO, pero no por este rodeo.** El camino `/i/flow/setup_profile` sigue
caído: eso es de X y no se arregla desde el script. Lo que se resolvió fue el otro lado:

| Qué | Estado |
|---|---|
| El rodeo por `x.com/settings/profile` | Funciona. Bio y avatar escritos y verificados |
| El diálogo de recorte que bloqueaba el `Save` | Resuelto (F-27) |
| Cuál de los 2 `input[type=file]` es el del avatar | Resuelto (F-26) |
| El `data-testid` real del botón | `Profile_Save_Button`, no `ProfileSaveButton` |
| Que el `Save` del perfil se haya ejecutado | **Sí**, con la bio |

Los dos selector incorrectos (`ProfileSaveButton`, `[aria-label*="rofile picture"]`) no son
ninguno: el botón es `Profile_Save_Button` y el de la cámara es `[aria-label="Add avatar photo"]`.

**Estado final: `post` también verificado.** Los cuatro caminos de `account.js` corrieron contra X:

| Acción | Verificación | Resultado |
|---|---|---|
| `whoami` | lee y compara | `Gbro` / `@gbroOCT` |
| `profile --bio` | relee el texto y compara | publicado |
| `avatar` | la URL deja de ser `sticky/default_profile_images` | `pbs.twimg.com/profile_images/2106829987479191552/r4BvLnB4_normal.png` (200, `image/png`) |
| `post` | busca el tweet en el perfil y compara el **texto** | `x.com/gbroOCT/status/2106849765644259547` |

Los cuatro significan lo mismo: se **vio el efecto**, no solo que no fallara. Ver F-25, que es el por
qué de que haga falta decirlo.

---

## F-31 | Un guarda verdadero para un modo entero de la verificación, sin decir nada | 2026-10-04 | estado: arreglado

**Síntoma:** `account.js post` reportaba `verificado: false` sobre un post **que estaba publicado**
con URL y texto correctos en el perfil.

**Causa:** **bug mío, el peor de los tres de este bloque.** El bloque de verificación pedía:

```js
if (tocoAlgo && res.despues && res.antes) { ... }
```

Pero el modo `post` **nunca llena `res.antes`**: no se relee el perfil antes de publicar, no tiene
sentido. El guarda era falso para *todo* el modo, así que la verificación entera se saltaba en
silencio y caía al `verificado = false` genérico de abajo, que no decía por qué.

**Lo agravante:** el `nota` tampoco explicaba nada. Decía "la sesión estaba sana pero el cambio NO
quedo verificado", que es **falso**: la sesión estaba sana, el tweet estaba publicado, y la
verificación ni se había ejecutado. El mensaje escondía el bug.

**Corregido en:** 2026-10-04. El guarda ahora es `(res.antes || modo === 'post')`, y el `nota` de
`no_verificado` **distingue las causas**:

- `no se encontró el tweet en el perfil`
- `la URL no es de un /status/`
- `el texto del perfil NO coincide con el enviado`
- `no hubo ningún cambio que confirmar`

**Verificado:** el cuarto post dio `verificado: true`, `post_coincide: true`, y existe en
`x.com/gbroOCT/status/2106849765644259547`.

**Regla que sale de acá:** un guarda que es falso para un modo entero del programa **no es una
validación, es un bug**: no protege nada y silencia el camino entero. Y cuando un script dice
"algo falló", tiene que decir **qué** comparó y qué encontró: un `nota` genérico sobre un bug de
lógica convierte un error visible en un misterio.

---

## F-30 | "La URL no cambió" no prueba que un post se publicó | 2026-10-04 | estado: arreglado

**Síntoma:** el primer post se publicó bien y el script dijo `no_verificado`.

**Causa:** **suposición mía.** La verificación era `if (!/compose\/post/.test(page.url())) → no se
publicó`. Pero al publicar bien, X **se queda en `/compose/post`**: no hay redirección ni URL del
tweet. El criterio daba falso negativo sobre unpost que existía.

**Corregido en:** 2026-10-04. Se va al perfil y se busca el tweet, con **poll** hasta 30 s (no un
sleep fijo: la timeline del perfil llega tarde, ver F-20).

---

## F-28 | `post` reportaba "publicado" con la página redirigida a otro lado | 2026-10-04 | estado: arreglado

**Síntoma:** el primer intento de `post` devolvió `accion: "publicado: ..."` cuando **nada se
publicó**: la URL había redirigido a `x.com/i/graduated-access`.

**Causa:** **bug mío.** El `accion` se armaba con el texto que se iba a publicar, sin comprobar
nada. La URL de destino se guardaba, pero nadie la miraba.

**Corregido en:** 2026-10-04. Se guarda `url_publicacion_intento`, y si X redirige a otra ruta el
script sale con `no_verificado` en vez de decir "publicado". Este fue el primer aviso de que la
verificación tenía que Basarse en el efecto y no en la intención.

Lo que se descubrió después: **la URL tampoco sirve para confirmar el éxito**, porque al publicar
bien X se queda en `/compose/post`. Ese camino queda documentado en F-30.

---

## F-29 | El compositor tarda más que 3 s en montar | 2026-10-04 | estado: arreglado

**Síntoma:** `post` decía "no se encontró el campo de texto" con la página bien cargada y cero 429.

**Causa:** el selector estaba bien, faltaba **esperar**. Una sonda con 12 s de espera vio el
`div[data-testid="tweetTextarea_0"][role="textbox"][contenteditable="true"]`; el script usaba
`sel()` (que no espera) con 3 s de demora.

**Estructura real, medida:** el compositor tiene **6** elementos `tweetTextarea*`, pero solo 2 son el
campo editable. Los otros son `_label` y `_RichTextInputContainer`. Tomar el primero a ciegas es un
error esperando que ocurra.

**Corregido en:** 2026-10-04. `selEspera(...)` con 30 s sobre el selector exacto. Además: el botón
`tweetButton` **arranca siempre deshabilitado** (`aria-disabled="true"`) y se habilita solo con
texto, así que ahora se espera a que se habilite en vez de comprobarlo una vez y rendirse.

---

## F-27 | El diálogo de recorte se llama "Edit media", no "crop" | 2026-10-04 | estado: arreglado

**Síntoma:** al subir el avatar, el click en `Save` no|subía nada. Playwright reportaba que un
`<span>Apply</span>` interceptaba el click, y el perfil seguía con la imagen por defecto.

**Contexto:** `account.js avatar` y `account.js post`.

Medido en `/compose/post`: el compositor tiene **6** elementos `tweetTextarea*` y solo **2** son el
campo editable (`_label` y `_RichTextInputContainer` son los otros). Tomar el primero a ciegas es un
error esperando que ocurra.

**Causa:** **bug mío, dos veces en el mismo flujo.**

| Suposición | Realidad (medida 2026-10-04) |
|---|---|
| El diálogo de recorte tiene texto "crop" | Se llama exactamente **"Edit media"**. El filtro `/crop/i` no lo encontraba nunca |
| El botón de confirmar no tiene testid | Tiene `data-testid="applyButton"` |

Como el recorte nunca se cerraba, su overlay seguía tapando el `Save` del formulario. El click
"funcionaba" en el sentido de que no tiraba error — y no subía nada.

Un detalle que costó una corrida extra: el `data-testid` del botón de guardar es
**`Profile_Save_Button`** (con guion bajo), no `ProfileSaveButton`. Y el de la cámara es
`[aria-label="Add avatar photo"]`, no `[aria-label*="rofile picture"]`. Los dos que el código
buscaba no existían.

**Corregido en:** 2026-10-04. Búsqueda del diálogo **por `applyButton`**, con el texto "Edit media"
como red de seguridad. Si tras 3 intentos el overlay sigue ahí, sale con `no_verificado` y lo dice:
no intenta el `Save` debajo de un overlay.

**Verificado:** `recorte: "confirmado"`, `avatar_verificado: true`, y el perfil público muestra
`pbs.twimg.com/profile_images/2106829987479191552/r4BvLnB4_normal.png` (**200**, `image/png`,
16.283 bytes). De `sticky/default_profile_images` a una imagen propia.

---

## F-26 | El `input[type=file]` del avatar no es el primero: el primero es el del banner | 2026-10-04 | estado: arreglado

**Síntoma:** el avatar no subía, pero el script reportaba `verificado: true`.

**Causa:** **bug mío.** El diálogo de edición tiene **2** `input[type="file"]`: el del **banner** y
el del **avatar**. `setInputFiles` sobre `.first()` ponía la imagen en el banner. El `Save` "funcionaba"
y nada pasaba.

El orden del DOM lo delata y es estable:

```
fileInput,  UserAvatar-Container-unknown,  fileInput
```

El del avatar es el que va **después** del `UserAvatar-Container`, no el primero.

**Corregido en:** 2026-10-04. Se busca en el DOM cuál `input[type=file]` sigue al contenedor, en vez
de asumir el índice. El JSON ahora reporta `file_input_idx` y `file_input_total`.

**Regla que sale de acá:** cuando hay N elementos del mismo tipo y el sitio tiene una noción de
"cuál es el mío", **no uses el índice**: buscá el elemento por su contexto en el DOM. Un índice es
una suposición que se rompe en silencio.

---

## F-25 | `verificado: true` sin haber verificado nada | 2026-10-04 | estado: arreglado

**Síntoma:** `account.js avatar` salió con `status: ok`, `verificado: true`, 923 peticiones y **cero
429**, mientras `nota` decía *"No se identifico el campo de bio. No se guardo nada."*

**Causa:** **bug mío, y la peor clase.** El chequeo final era:

```js
if (escribiendo && res.status === 'ok') res.verificado = true;
```

Derivaba el "verificado" **del estado de la sesión**, no del efecto. Con la sesión sana y el trabajo
sin hacer, decía "verificado". Es F-1/F-12 otra vez, pero en el camino de éxito: donde antes se
mintió por omisión, ahora se mintió por afirmación.

Lo delataron dos cosas que no cuadraban: `accion: "perfil: sin cambios"` junto a un `nota` que decía
que no se guardó nada, y un `nota` sobre un overlay interceptando el click con `ok` de salida.

**Corregido en:** 2026-10-04. Nuevo estado **`no_verificado`** (código 3). `verificado` solo es `true`
si hubo un cambio real **Y** se relee el estado para confirmarlo, y la confirmación es **distinta
según la acción**:

| Acción | Cómo se confirma |
|---|---|
| `profile --bio` | `despues.bio` es exactamente el texto pedido |
| `profile --name` | `despues.nombre` arranca por el nombre pedido |
| `avatar` | la URL del avatar propio **deja de ser** `sticky/default_profile_images` |
| `post` | hay URL de publicación |

El avatar necesitó una comprobación a parte: "el click no tiró error" no es "la imagen subió".

**Regla que sale de acá:** *excepción cero* no es éxito. En un sistema que escribe, el estado
positivo tiene que leer el efecto observable, no la ausencia de excepción.

---

## F-24 | El chequeo de entorno tapaba las validaciones de argumentos | 2026-10-04 | estado: arreglado

**Sintoma:** `account.js post "texto"` **sin `--yes`** salía con código **2** y el mensaje
`Brave no encontrado`, en vez de código 6 y "falta --yes".

**Contexto:** lo encontró `test-account.js`, el test nuevo de escritura. En una máquina donde
Brave no está donde se espera, la **falta de permiso** se reportaba como **problema de entorno**.

**Causa:** **bug mío.** El orden dentro del IIFE era: chequeo de Brave → guardas de `--yes` →
resto de validaciones. El primer `return` se llevaba puesto todos los mensajes que importan.

Por qué importa más allá del mensaje: un llamador que lee el código de salida **no puede
distinguir "no autorizaste la escritura" de "el entorno está roto"**, y esa distinción decide si
reintenta o cambia de estrategia.

**Arreglado en:** 2026-10-04. Chequeo de Brave **movido al final**, después de todas las guardas de
argumentos. El chequeo de entorno no depende de la red; las reglas del comando tampoco: no hay
razón para que una tapa a la otra.

**Regla que sale de acá:** en un script, **validá los argumentos antes que el entorno**. Un chequeo
de entorno es caro en la realidad (lee el disco) y genérico; una regla del comando es específica y
es la que el usuario puede corregir. La genérica no debe tapar la específica.

---

## F-23 | Seguir insistiendo después del 429 empeoraba el bloqueo y se reportaba como `no_render` | 2026-10-04 | estado: arreglado

**Sintoma:** el editor "no se encontraba" (`no_render`) cuando en realidad la cuenta ya estaba
throttleada. El script no lo decía.

**Contexto:** 3 intentos de setear la bio en ~6 minutos, cada uno un arranque completo de x.com.

**Causa:** **bug mio.** `abrirEditor()` hacía poll 25 s buscando el formulario y, si no aparecía,
devolvía `null` como si fuera un problema de selectores. Pero cuando X devuelve 429, el formulario
**nunca** va a aparecer: el estado honesto era `throttled`, y se estaba reportando `no_render`. Cada
intento extra sumaba peticiones a una cuenta ya castigada (F-16).

**Arreglado en:** 2026-10-04. `abrirEditor()` toma el conteo de 429 **antes** de abrir los ajustes y
corta con `status: throttled` en cuanto aparezca uno. Además el `catch` distingue un 429 lanzado
desde adentro (`e.code === THROTTLE`) de un error real del script.

**Regla que sale de aca:** en un script que escribe, "no encontré el control" y "me bloquearon" son
diagnósticos distintos y requieren acciones opuestas: el primero se depura, el segundo **se para**.
Reportarlos igual es lo mismo que F-1/F-12 en otro disguise.

---

## F-21 | X degrada el contenido **antes** de devolver 429 | 2026-10-04 | estado: arreglado

**Sintoma:** con la sesion sana (`titulo: "Home / X"`, `logueado: true`, **0 errores 4xx/5xx**),
la home cargo **0 articulos** y el header del perfil no renderizo: el editor no aparecio nunca,
ni con 25 s de espera.

**Contexto:** 5 arranques de x.com en ~20 min (3 corridas de `account.js` + 2 sondas de DOM).

**Causa:** comportamiento de un tercero. X **degrada el contenido en silencio** cuando la cuenta esta
siendo usada de mas: el shell de la SPA carga (por eso `titulo` y `logueado` son correctos) pero
los articulos no llegan. **No hay 429 que ver**, asi que el detector de throttling de F-12 no se
dispara, y el estado honesto era `empty` ("no hay resultados para esta consulta"), que es mentira.

**Arreglado en:** 2026-10-04. Nuevo estado **`degraded`** (codigo de salida 5, igual que
`throttled` a proposito: los dos piden parar y esperar horas, y distinguirlos obligaria al
llamador a separar dos causas que se resuelven igual).

La funcion `degradado(probe)` en `scrape.js` decide con una regla que distingue las dos situations
que se ven iguales a ojo:

| Situación | `cargados` | perfil (nombre/avatar/bio) | Estado |
|---|---:|---|---|
| Degradación | 0 | los tres ausentes | **`degraded`** |
| Cuenta sin posts | 0 | los tres presentes | `empty` (legítimo) |
| Resultado normal | >0 | da igual | `ok` |

La regla: **una cuenta sin posts igual tiene página de perfil.** Si no hay ni nombre, ni avatar, ni
bio, no hay una página que pueda estar vacía, y lo que se está viendo es una columna que no cargó.
`PROBE` ahora mide los tres (`perfilNombre`, `perfilAvatar`, `perfilBio`) para que el diagnóstico
sea visible sin tener que adivinar.

`multi` corta en el primer `degraded`, y `degraded` entró en la lista `FALLAS` para que no lo
pise un `ok` posterior.

**Verificado:** `test-account.js` prueba la función contra los tres casos de la tabla más los de
challenge y con-artículos. Y contra X de verdad: una búsqueda de una cadena sin sentido dio
`status=empty` con `perfilAvatar=true` (correcto, no es degradación), y una búsqueda con
resultados dio `ok`.

**Lo que NO se arregla:** esto detecta la degradación, no la causa. X sigue degradando. Lo único
que hace el script es **dejar de gastar peticiones de una cuenta castigada** y decirlo con un
estado honesto en vez de un `empty` mentiroso.

---

## Cómo sumar una falla

1. Agregá la entrada con el formato de arriba, `estado: abierto`.
2. Si encontraste el fix, ponelo y cambiá a `estado: arreglado` con la fecha.
3. Si **no** lo arreglaste pero encontraste un rodeo, `estado: workaround`.
4. Si es comportamiento de un tercero (X cambió el DOM, una query desaparece), marcalo como tal
   en **Causa** — así se distingue "bug mío" de "se movió la plataforma".