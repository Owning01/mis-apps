#!/usr/bin/env node
// Etapa de ANALISIS. Toma la salida de scrape.js y produce un corpus limpio.
//   node analyze.js <raw.json> [--out corpus.json] [--rank date|authority] [--dup 0.45]
//
// Hace lo que scrape.js NO debe hacer: rankear por keywords. Rankear por repeticion de
// palabras premia el promo y entierra el anuncio oficial (ver MEJORAS.md A1).
const fs = require('fs');
const path = require('path');

// --- args ---
const FLAGS = ['out', 'rank', 'dup', 'official'];
const flags = {};
const pos = [];
for (let i = 2; i < process.argv.length; i++) {
  const a = process.argv[i];
  if (a.startsWith('--')) {
    const n = a.slice(2);
    if (FLAGS.includes(n) && i + 1 < process.argv.length) flags[n] = process.argv[++i];
    else flags[n] = true;
  } else pos.push(a);
}
const src = pos[0];
if (!pos.length) {
  console.error('uso: node analyze.js <raw.json...> [--out corpus.json] [--rank date|authority] [--dup 0.45]');
  process.exit(2);
}
const rank = flags.rank || 'date';
// CALIBRADO con medicion, no a ojo. Con shingles de 3-gramas (no word-sets):
//   @codesthea ~ @axiatechie  = 0.158  <- siembra de contenido, mismo texto reordenado
//   @invideoOfficial ~ @aran_leigh = 0.041  <- amplificacion legitima, mismo tema distinto
// El gap es de ~4x, asi que 0.12 separa limpio. Con word-sets daba 0.57 y habia que usar 0.45.
const dupThreshold = Number(flags.dup) || 0.12;
const officialList = new Set(
  (flags.official ||
    'tavus,invideoOfficial,ComfyUI,MaxonVFX,stitchbygoogle,runwayml,AdobeV,OpenAI,' +
    'GoogleAI,GoogleDeepMind,SoraAI,Civitai,HuggingFace,grothendiegg,huggingface,'
  )
    .split(',')
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean)
);

const STOP = new Set(
  ('the a an and or to of in for on with is it this that be are was i you my we our at as by from ' +
    'so if no not just got get has have had but they them their there here what when which who how')
    .split(' ')
);

// ---------- helpers ----------
const norm = (s) =>
  (s || '')
    .toLowerCase()
    .replace(/https?:\/\/\S+/g, ' ')
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();

const shingle = (s) => {
  const w = norm(s).split(' ').filter((x) => x.length > 2 && !STOP.has(x));
  const out = new Set();
  for (let i = 0; i + 2 < w.length; i++) out.add(w.slice(i, i + 3).join(' '));
  // Fallback: con menos de 3 palabras no hay 3-grama que sacar, y el texto se
  // escaparia SIEMPRE del dedup. Es el caso del chino/emoji (sin espacios) y de
  // los posts cortos, que son justo los que mas se copian. Ahi usamos
  // shingles de caracteres, que no dependen de la segmentacion por espacios.
  if (out.size < 3) {
    const flat = norm(s).replace(/\s+/g, '');
    for (let i = 0; i + 4 <= flat.length; i++) out.add(flat.slice(i, i + 4));
  }
  return out;
};

const jaccard = (a, b) => {
  if (!a.size || !b.size) return 0;
  let inter = 0;
  for (const x of a) if (b.has(x)) inter++;
  return inter / (a.size + b.size - inter);
};

// ---------- carga ----------
// Acepta varias entradas y tres formas, porque scrape.js emite {mode, results}
// o {mode, queries:[{q,results}]}, y un corpus ya aplanado es un array pelado.
function extract(raw) {
  if (Array.isArray(raw)) return raw;
  if (raw && Array.isArray(raw.queries)) return raw.queries.flatMap((q) => q.results || []);
  if (raw && Array.isArray(raw.results)) return raw.results;
  return [];
}
const rows = [];
const leidos = [];
for (const f of pos) {
  let raw;
  try {
    raw = JSON.parse(fs.readFileSync(f, 'utf8'));
  } catch (e) {
    console.error('no pude leer ' + f + ': ' + e.message);
    process.exit(1);
  }
  const n = extract(raw).length;
  leidos.push(f + '(' + n + ')');
  rows.push(...extract(raw));
}
const stats = { entrada: rows.length, leidos, sin_url: 0, invalidos: 0 };

// 1) dedup por URL exacta
const byUrl = new Map();
for (const r of rows) {
  if (!r || typeof r !== 'object') { stats.invalidos++; continue; }
  if (!r.url) { stats.sin_url++; continue; } // sin URL no se puede deduplicar
  if (!byUrl.has(r.url)) byUrl.set(r.url, r);
}
stats.por_url = byUrl.size;

// 2) dedup difuso por shingles + marca de copypasta (A2 / 2.3)
const shingles = new Map(); // url -> Set
const items = [];
const copypairs = [];
for (const r of byUrl.values()) {
  const sh = shingle(r.text);
  let dupOf = null;
  let best = 0;
  for (const [url, other] of shingles) {
    const j = jaccard(sh, other);
    if (j > best) {
      best = j;
      dupOf = url;
    }
  }
  const es_copypasta = dupOf != null && best >= dupThreshold;
  shingles.set(r.url, sh);
  if (es_copypasta) copypairs.push({ a: dupOf, b: r.url, j: +best.toFixed(3) });
  items.push({ ...r, _shingles: sh, _dup: dupOf, _j: +best.toFixed(3), es_copypasta });
}
stats.dedup_difuso = items.length - copypairs.length;
stats.pares_copypasta = copypairs.length;

// 3) ranking (A1)
function authority(r) {
  const h = (r.handle || '').toLowerCase();
  const len = (r.text || '').length;
  let s = officialList.has(h) ? 60 : 0;
  // sustancia: longitud con saturación (250 chars ~ suficiente)
  s += Math.min(len, 250) / 5;
  // densidad: caracteres por palabra; un post largo y vacío no vale
  const words = norm(r.text).split(' ').filter(Boolean).length || 1;
  s += Math.min(len / words, 12);
  if (es_copypasta(r)) s -= 25; // siembra de contenido: baja
  return s;
}
const copypastaUrls = new Set(items.filter((x) => x.es_copypasta).map((x) => x.url));
const es_copypasta = (r) => copypastaUrls.has(r.url);

const byAuthority = (a, b) =>
  authority(b) - authority(a) || (b.when || '').localeCompare(a.when || '');

function diversify(sorted) {
  // En research interesa amplitud de autores, no volumen: sin esto MaxonVFX mete sus
  // 2 posts y empuja a @tavus (el hallazgo mas importante de la ronda) al puesto 6.
  // Se saca primero el mejor post de cada autor y despues se completa con el resto.
  const seen = new Set();
  const first = [];
  const rest = [];
  for (const r of sorted) {
    const h = (r.handle || '').toLowerCase();
    if (seen.has(h)) rest.push(r);
    else {
      seen.add(h);
      first.push(r);
    }
  }
  return first.concat(rest);
}

const cmp = rank === 'authority' ? byAuthority : (a, b) => (b.when || '').localeCompare(a.when || '');
const ordered = diversify(items.slice().sort(cmp));

const out = ordered.map((r) => {
  const o = { ...r };
  delete o._shingles;
  delete o._dup;
  o.oficial = officialList.has((r.handle || '').toLowerCase());
  o.es_copypasta = !!es_copypasta(r);
  if (rank === 'authority') o._rank = +authority(r).toFixed(1);
  return o;
});

const dest = flags.out || 'corpus.json';
fs.writeFileSync(dest, JSON.stringify(out, null, 1), 'utf8');

// ---------- reporte ----------
console.error('analyze.js  rank=' + rank + '  dup=' + dupThreshold);
console.error('  entradas               : ' + stats.leidos.join(' '));
console.error('  filas de entrada       : ' + stats.entrada);
  if (stats.sin_url) console.error('  descartadas sin URL    : ' + stats.sin_url);
  if (stats.invalidos) console.error('  descartadas invalidas  : ' + stats.invalidos);
console.error('  unicas por URL         : ' + stats.por_url);
console.error('  copypasta (Jaccard>=' + dupThreshold + ') : ' + stats.pares_copypasta);
console.error('  finales tras dedup     : ' + out.length);
console.error('  -> ' + dest);
if (copypairs.length) {
  console.error('\n  pares marcados:');
  for (const p of copypairs) console.error('    ' + p.j + '  ' + p.a + '  ~  ' + p.b);
}
if (rank === 'authority') {
  console.error('\n  top 8 por autoridad:');
  out.slice(0, 8).forEach((r, i) =>
    console.error(
      '    ' + (i + 1) + '. @' + r.handle + ' [' + r._rank + (r.oficial ? ', oficial' : '') + '] ' +
        (r.text || '').replace(/\s+/g, ' ').slice(0, 70)
    )
  );
}
