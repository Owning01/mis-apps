#!/usr/bin/env node
// Genera el avatar de la cuenta como PNG, de forma reproducible.
//   node make-avatar.js --out avatar.png [--bg "#0b1020" --fg "#ffffff" --accent "#7dd3fc"]
//
// POR QUE UN SVG Y NO UNA IMAGEN DIFUSION: un avatar se lee a 40px en la barra
// lateral. Un mark geométrico con contraste alto se sigue entendiendo; una
// imagen generada por modelo se convierte en ruido a ese tamaño. Este archivo
// se versiona, se regenera y se cambia de color en un flag.
//
// Render: se dibuja el SVG en una pagina en blanco y se saca un PNG con
// Playwright, que ya es dependencia del scraper. Sin ImageMagick, sin sharp.
const fs = require('fs');
const path = require('path');
const os = require('os');

function findPlaywrightCore() {
  try { return require('playwright-core'); } catch {}
  const roots = [
    process.env.NPM_CONFIG_CACHE || path.join(os.homedir(), 'AppData', 'Local', 'npm-cache'),
    'G:/Dev/npm-cache',
  ];
  const candidates = [];
  for (const root of roots) {
    const npx = path.join(root, '_npx');
    if (!fs.existsSync(npx)) continue;
    for (const dir of fs.readdirSync(npx)) {
      candidates.push(path.join(npx, dir, 'node_modules', 'playwright-core'));
    }
  }
  for (const c of candidates) {
    if (fs.existsSync(path.join(c, 'package.json'))) return require(c);
  }
  throw new Error('playwright-core no encontrado. Instalalo con: npm i -g playwright-core');
}
const { chromium } = findPlaywrightCore();

const FLAGS_WITH_VALUE = ['out', 'bg', 'fg', 'accent', 'size'];
const flags = {};
for (let i = 2; i < process.argv.length; i++) {
  const a = process.argv[i];
  if (a.startsWith('--')) {
    const n = a.slice(2);
    if (FLAGS_WITH_VALUE.includes(n) && i + 1 < process.argv.length) flags[n] = process.argv[++i];
    else flags[n] = true;
  }
}
const out = flags.out || 'avatar.png';
const size = Number(flags.size) || 400;
const bg = flags.bg || '#0b1020';
const fg = flags.fg || '#f8fafc';
const accent = flags.accent || '#38bdf8';

// El motivo: un SHUTTLE, la herramienta del telar. Lleva el hilo de un lado al
// otro y el "harness" del telar es justamente lo que sostiene los hilos. De ahi
// el nombre de la cuenta. Se dibuja como una lente alargada (dos aristas) con
// la ojo del shuttle adentro y tres hilos passing through.
const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 400 400">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${bg}"/>
      <stop offset="100%" stop-color="#1e1b4b"/>
    </linearGradient>
    <filter id="soft" x="-30%" y="-30%" width="160%" height="160%">
      <feGaussianBlur stdDeviation="10"/>
    </filter>
  </defs>

  <rect width="400" height="400" fill="url(#bg)"/>

  <!-- hilos de fondo: la trama que el harness sostiene -->
  <g opacity="0.30" stroke="${accent}" stroke-width="5" stroke-linecap="round" fill="none">
    <path d="M-20 130 C 90 130, 150 175, 250 175 S 380 150 420 150"/>
    <path d="M-20 250 C 90 250, 150 215, 250 215 S 380 240 420 240"/>
  </g>

  <!-- shuttle: lente de 25..375, rotada -18deg. Puntas afinadas para que lea
       como shuttle y no como un ojo. -->
  <g transform="rotate(-18 200 200)">
    <!-- halo, para que la silueta se despegue del fondo -->
    <path d="M25 200 C40 162,100 134,200 134 C300 134,360 162,375 200 C360 238,300 266,200 266 C100 266,40 238,25 200 Z"
          fill="${accent}" opacity="0.40" filter="url(#soft)"/>
    <!-- cuerpo -->
    <path d="M25 200 C40 162,100 134,200 134 C300 134,360 162,375 200 C360 238,300 266,200 266 C100 266,40 238,25 200 Z"
          fill="${fg}"/>
    <!-- ojo del shuttle -->
    <ellipse cx="200" cy="200" rx="78" ry="25" fill="${bg}"/>
    <!-- el hilo pasando por el ojo -->
    <path d="M120 200 L280 200" stroke="${accent}" stroke-width="11" stroke-linecap="round" fill="none"/>
  </g>
</svg>`;

(async () => {
  // playwright-core NO trae navegadores: hay que pasarle el binario de Brave,
  // igual que hace scrape.js. Es un contexto NUEVO (no el perfil del usuario),
  // asi que no toca la sesion ni las cookies.
  const BRAVE =
    process.env.BRAVE_PATH ||
    'C:/Users/perca/AppData/Local/BraveSoftware/Brave-Browser/Application/brave.exe';
  if (!fs.existsSync(BRAVE)) {
    console.error(`Brave no encontrado en ${BRAVE}`);
    process.exitCode = 2;
    return;
  }
  const browser = await chromium.launch({ executablePath: BRAVE, headless: true });
  const page = await browser.newPage({ viewport: { width: size, height: size }, deviceScaleFactor: 1 });
  await page.setContent(
    `<html><body style="margin:0;padding:0;width:${size}px;height:${size}px;overflow:hidden">${svg}</body></html>`,
    { waitUntil: 'load' }
  );
  const dest = path.resolve(out);
  await page.screenshot({ path: dest, omitBackground: false });
  await browser.close();
  console.log(`avatar escrito en ${dest} (${size}x${size})`);
})();
