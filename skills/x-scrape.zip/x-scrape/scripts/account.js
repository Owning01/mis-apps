#!/usr/bin/env node
// Gestionar la CUENTA de X (perfil y publicaciones) via Brave + tu sesion real.
//
// Esto es ESCRITURA: cambia datos visibles de la cuenta y publica posts.
// El scraper (scrape.js) es solo lectura; este script es el complemento.
//
//   node account.js whoami
//   node account.js profile --name "Shuttle" --bio "texto"
//   node account.js avatar "C:\ruta\imagen.png"
//   node account.js post "texto del tweet" --yes
//
// REGLAS (por que estan asi, no son capricho):
//  1. Una accion por invocacion. Menos superficie, menos pedidos a la API, menos
//     riesgo de que X marque la cuenta como automatizada. La sesion real es lo
//     mas valioso que tenes: perderla mata tambien el scraping.
//  2. Toda escritura pide --yes. Sin --yes sale con codigo 2 y no toca nada:
//     asi un `post` accidental no publica nada.
//  3. Antes de escribir, chequea salud de sesion y red. Un `empty` con titulo
//     vacio es throttle o carga colgada (FAILURES.md F-1/F-12), NO un fallo
//     de selectores: en ese caso aborta en vez de_reportar exito.
//  4. Escribe SIEMPRE con el mismo perfil real y con pausas humanas. Nada de
//    inear cabeceras ni de camuflar el trafico: la cuenta se identifica como
//     automatica en la bio, y eso es lo correcto.
const fs = require('fs');
const path = require('path');
const os = require('os');

const BRAVE =
  process.env.BRAVE_PATH ||
  'C:/Users/perca/AppData/Local/BraveSoftware/Brave-Browser/Application/brave.exe';
const USER_DATA =
  process.env.BRAVE_USER_DATA ||
  'C:/Users/perca/AppData/Local/BraveSoftware/Brave-Browser/User Data';
const PROFILE = process.env.BRAVE_PROFILE || 'Default';

const MIN_PAUSE = Number(process.env.X_SCRAPE_MIN_PAUSE) || 3000;
const MAX_PAUSE = Number(process.env.X_SCRAPE_MAX_PAUSE) || 8000;

// La pagina de ajustes es la ruta que funciona para editar (ver F-22: el flujo
// /i/flow/setup_profile puede caerse y dejar la cuenta sin forma de editar).
const URL_AJUSTES = 'https://x.com/settings/profile';

// Codigos de salida (mismos que scrape.js para no aprender dos juegos):
//   0 ok | 2 uso/entorno | 3 bloqueado, stalled o sin render | 5 throttleado (429)
//   6 cancelado por falta de --yes | 1 error propio
//   3 tambien significa "sin verificar": la sesion estaba sana pero el cambio no se
//     confirmo. Nunca digas exito sin haber releido el perfil despues.
const OK = 0, USO = 2, NO_MIRO = 3, THROTTLE = 5, SIN_YES = 6, ERROR = 1;

function findPlaywrightCore() {
  try { return require('playwright-core'); } catch {}
  const roots = [
    process.env.NPM_CONFIG_CACHE || path.join(os.homedir(), 'AppData', 'Local', 'npm-cache'),
    'G:/Dev/npm-cache',
  ];
  const candidates = [];
  for (const root of roots) {
    const npx = path.join(root, '_npx');
    if (!fs.existsSync(npx)) continue;
    for (const dir of fs.readdirSync(npx)) {
      candidates.push(path.join(npx, dir, 'node_modules', 'playwright-core'));
    }
  }
  for (const c of candidates) {
    if (fs.existsSync(path.join(c, 'package.json'))) return require(c);
  }
  throw new Error('playwright-core no encontrado. Instalalo con: npm i -g playwright-core');
}

const { chromium } = findPlaywrightCore();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const pausaHumana = () => sleep(MIN_PAUSE + Math.random() * (MAX_PAUSE - MIN_PAUSE));

// ---------- args ----------
const FLAGS_WITH_VALUE = ['name', 'bio', 'out', 'image'];
const flags = {};
const pos = [];
for (let i = 2; i < process.argv.length; i++) {
  const a = process.argv[i];
  if (a.startsWith('--')) {
    const n = a.slice(2);
    if (FLAGS_WITH_VALUE.includes(n) && i + 1 < process.argv.length) flags[n] = process.argv[++i];
    else flags[n] = true;
  } else pos.push(a);
}
const [modo, ...resto] = pos;
const out = flags.out || null;
const headed = flags.headed === true || flags.show === true;
const confirmar = flags.yes === true;

const USO_TXT =
  'uso:\n' +
  '  node account.js whoami\n' +
  '  node account.js profile --name "X" --bio "Y"   [--yes]\n' +
  '  node account.js avatar "<ruta.png>"              [--yes]\n' +
  '  node account.js post "<texto>"                    [--yes]\n' +
  'flags: --yes (obligatorio para escribir) --headed --show --out <archivo>';

// ---------- helpers de DOM ----------

// X cambia los data-testid. En vez de confiar en uno solo, se prueban varios y
// si ninguno existe se devuelve null -> eso dispara `no_render`, no un falso OK.
const sel = async (loc, lista) => {
  for (const s of lista) {
    const n = await loc.locator(s).count();
    if (n > 0) return loc.locator(s).first();
  }
  return null;
};

// Igual que `sel`, pero ESPERA a que aparezca. El header del perfil de X tarda
// en resolver: medido el 2026-10-04, el boton de editar aparece ~8s despues de
// la navegacion. Con un sleep fijo de 3s el selector "no existia" y el script
// cancelaba la escritura y no encontraba el editor.
// Reparte el presupuesto entre los selectores: si el primero no aparece, igual
// le queda tiempo al segundo.
const selEspera = async (loc, lista, ms) => {
  const cada = Math.max(1500, Math.ceil((ms || 20000) / lista.length));
  for (const s of lista) {
    const n = loc.locator(s).first();
    try {
      await n.waitFor({ state: 'visible', timeout: cada });
      return n;
    } catch {}
  }
  return null;
};

// Un input de React no se puede poner con el setter normal: React guarda el valor
// anterior en su fibra y lo ignora. Hay que pisar el setter del prototipo y
// despachar el evento `input`, que es lo que React escucha de verdad.
async function setReactValue(loc, valor) {
  await loc.click();
  await loc.press('Control+A');
  await loc.press('Delete');
  await loc.evaluate((el, v) => {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }, valor);
}

// Un boton "Save"/"Guardar" puede ser <button> o <div role=button>; X usaba las
// dos. El texto se compara sin acentos para que funcione en interfaz en español.
const norm = (s) => (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
async function botonPorTexto(raiz, textos) {
  for (const t of textos) {
    const b = raiz.getByRole('button', { name: t, exact: false });
    if (await b.count()) return b.first();
  }
  return null;
}

(async () => {
  if (!modo) { console.error(USO_TXT); process.exitCode = USO; return; }

  // ORDEN: primero TODAS las guardas de argumentos, despues el chequeo de que
  // Brave exista. Al reves (como estaba antes) el chequeo de entorno tapaba las
  // validaciones: un `post` sin --yes en una maquina sin Brave reportaba
  // "Brave no encontrado" en vez de "falta --yes", y el llamador no podia
  // distinguir un problema de entorno de una falta de permiso. El chequeo de
  // entorno no depende de la red; las reglas del comando tampoco.
  const escribiendo = ['profile', 'avatar', 'post'].includes(modo);
  if (escribiendo && !confirmar) {
    console.error(`"${modo}" ESCRIBE en la cuenta. Falta --yes: no se toco nada.\n${USO_TXT}`);
    process.exitCode = SIN_YES;
    return;
  }
  if (modo === 'avatar' && !resto[0]) { console.error('avatar necesita una ruta de imagen.'); process.exitCode = USO; return; }
  if (modo === 'avatar' && !fs.existsSync(resto[0])) {
    console.error(`No existe el archivo: ${resto[0]}`); process.exitCode = USO; return;
  }
  if (modo === 'post' && !resto.join(' ').trim()) { console.error('post necesita un texto.'); process.exitCode = USO; return; }
  if (modo === 'profile' && flags.name === undefined && flags.bio === undefined) {
    console.error('profile necesita --name y/o --bio.'); process.exitCode = USO; return;
  }
  // Limite de X: nombre 50, bio 160. Chequear antes evita que el propio editor
  // rechace el guardado y el script reporte un exito que no ocurrio.
  if (flags.bio !== undefined && String(flags.bio).length > 160) {
    console.error(`La bio tiene ${String(flags.bio).length} caracteres; el limite de X son 160. No se toco nada.`);
    process.exitCode = USO; return;
  }
  if (flags.name !== undefined && String(flags.name).length > 50) {
    console.error(`El nombre tiene ${String(flags.name).length} caracteres; el limite de X son 50. No se toco nada.`);
    process.exitCode = USO; return;
  }
  if (modo === 'avatar' && flags.image) { /* flag alterno, no-op */ }

  // Ahora si: el entorno. Este chequeo va al final a proposito.
  if (!fs.existsSync(BRAVE)) { console.error(`Brave no encontrado en ${BRAVE}`); process.exitCode = USO; return; }

  let ctx;
  const res = {
    modo, started_at: new Date().toISOString(), status: 'ok',
    session: null, antes: null, despues: null, accion: null, url: null,
  };

  // EMITIR SIEMPRE. Hay como ocho `return` de salida temprana (sesion caida,
  // throttle, selector que no se encontro) y en la primera version de este
  // script NINGUNO escribia el JSON: salia con codigo 3 y stdout vacio, que es
  // indistinguible de "se callo". Un script que escribe en la cuenta y no dice
  // que paso es peor que uno que falla: no se sabe si publico o no.
  // Por eso la salida va en el `finally`, no en el camino feliz.
  let emitted = false;
  const emit = () => {
    if (emitted) return;
    emitted = true;
    const txt = JSON.stringify(res, null, 2);
    if (out) { fs.writeFileSync(out, txt, 'utf8'); console.error(`escrito en ${out}`); }
    else console.log(txt);
  };

  try {
    ctx = await chromium.launchPersistentContext(USER_DATA, {
      executablePath: BRAVE,
      headless: !headed,
      viewport: { width: 1440, height: 900 },
      args: [`--profile-directory=${PROFILE}`],
    });
    const page = ctx.pages()[0] || (await ctx.newPage());

    // --- ESTADO DE RED: misma idea que F-12 ---
    // X puede devolver 200 para el HTML y 429 para toda la API. Para una
    // ESCRITURA eso es peor: creeria que publico y no publico nada.
    const http = { '429': 0, '4xx': 0, '5xx': 0, peticiones: 0, api: 0 };
    const esApi = (u) => /api\.x\.com|\/i\/api\/|\/graphql/i.test(u);
    page.on('request', (r) => { http.peticiones++; if (esApi(r.url())) http.api++; });
    page.on('response', (r) => {
      const s = r.status();
      if (s === 429) http['429']++;
      else if (s >= 500) http['5xx']++;
      else if (s >= 400) http['4xx']++;
    });

    // Chequeo de sesion + de que la pagina PINTO. Sin esto no se escribe nada.
    //
    // POLL, no sleep fijo. La primera version esperaba 2.5s y decisiona: si la
    // pagina no habia pintado todavia, reportaba `no_render` con titulo vacio y
    // salia. Medido 2026-10-04: una corrida vio 85 peticiones y 1 sola llamada a
    // la API, o sea no termino de cargar, no estaba throttleada. Es el mismo
    // error que scrape.js ya documenta (F-1/F-12) repetido en un script nuevo:
    // "no miro" y "no hay nada" tienen que ser estados distintos.
    async function salud() {
      const limite = Date.now() + 25000;
      let st = null;
      do {
        await sleep(2000);
        st = await page.evaluate(() => ({
          titulo: document.title,
          body: document.body.innerText.slice(0, 400),
          challenge: /Just a moment|Verify you are human|Checking your browser/i.test(document.body.innerText),
          logueado: !!document.querySelector('[data-testid="SideNav_AccountSwitcher_Button"]'),
          cargados: document.querySelectorAll('article[data-testid="tweet"]').length,
        }));
        res.session = { titulo: st.titulo, logueado: st.logueado, challenge: st.challenge, cargados: st.cargados, red: http };
        if (http['429'] > 0) return 'throttled';
        if (st.challenge) return 'blocked';
        if (st.titulo && st.body.trim() && st.logueado) return 'ok';
      } while (Date.now() < limite);
      // Se agoto la espera: decidir por lo que SI se vio, nunca Suponer.
      if (http['429'] > 0) return 'throttled';
      if (st.challenge) return 'blocked';
      if (!st.titulo || !st.body.trim()) return 'no_render';
      if (/Log in|Sign up/i.test(st.body) && !st.logueado) return 'blocked';
      return st.logueado ? 'ok' : 'no_render';
    }

    // --- ACCIONES ---
    // Ir al propio perfil. MEDIDO 2026-10-04 con sonda de DOM: el menu del
    // switcher NO tiene item "Your profile" (solo "Add an existing account" y
    // "Log out @gbroOCT"), asi que buscarlo por texto nunca encuentra nada y la
    // escritura se cancelaba sola sin avisar. Las dos rutas que SI existen:
    //   1. el link de perfil de la barra lateral, que ya trae el /handle
    //   2. el data-testid del avatar, que es UserAvatar-Container-<handle>
    async function irAlPerfil() {
      const link = page.locator('a[data-testid="AppTabBar_Profile_Link"]').first();
      if (await link.count()) {
        const href = await link.getAttribute('href');
        if (href && /^\/[A-Za-z0-9_]{1,15}$/.test(href)) {
          await page.goto('https://x.com' + href, { waitUntil: 'domcontentloaded', timeout: 60000 });
          return href.slice(1);
        }
      }
      const av = await page.evaluate(() => {
        const el = document.querySelector('[data-testid^="UserAvatar-Container-"]');
        return el ? el.getAttribute('data-testid').replace('UserAvatar-Container-', '') : null;
      });
      if (av) {
        await page.goto('https://x.com/' + av, { waitUntil: 'domcontentloaded', timeout: 60000 });
        return av;
      }
      return null;
    }

    async function leerPerfil() {
      const d = page.locator('[data-testid="UserName"]').first();
      const bio = page.locator('[data-testid="UserDescription"]').first();
      return {
        nombre: (await d.count()) ? (await d.innerText()).trim() : null,
        bio: (await bio.count()) ? (await bio.innerText()).trim() : null,
        handle: await page.evaluate(() => {
          const a = document.querySelector('a[href^="/"][data-testid="UserName"]')?.getAttribute('href');
          return a ? a.replace('/', '') : null;
        }),
      };
    }

    // MEDIDO 2026-10-04 con sonda de DOM sobre /gbroOCT:
    //  - [data-testid="UserName"] es un DIV, no un link. La primera version
    //    hacia click ahi esperando navegar y eso no hacia NADA.
    //  - el control real es <a data-testid="editProfileButton"> y su texto es
    //    "Set up profile" (no "Edit profile") cuando la cuenta esta incompleta.
    //
    // Y despues, F-22: ese link lleva a /i/flow/setup_profile, que con la cuenta
    // degradada responde "Something went wrong. Try reloading." con CERO inputs.
    // La ruta que SÍ funciona es directo a la pagina de ajustes, y tiene el
    // formulario completo: name, bio, avatar y Save, sin pasar por el flujo.
    //
    // Por eso: ajustes primero, y el link del perfil solo como red de seguridad.
    async function abrirEditor() {
      // 1) La pagina de ajustes. Trae el formulario y no depende del flujo.
      //
      // OJO con QUERER ESPERAR: la caja de busqueda global es un input y esta
      // SIEMPRE, desde el primer frame. Esperar "un input" devuelve al instante
      // con el campo equivocado y el formulario de perfil todavia no esta.
      // Hay que esperar una marca del formulario de edicion: los textareas (la
      // bio es el unico) o los input[type=file] del avatar.
      const n429antes = http['429'];
      await page.goto(URL_AJUSTES, { waitUntil: 'domcontentloaded', timeout: 60000 });
      const enAjustes = await selEspera(page, [
        '[role="dialog"] textarea',
        'textarea[data-testid]',
        'input[type="file"][data-testid]',
      ], 30000);

      // CORTAR SI EMPEZO A THROTTLEAR. Sin esto se sigue insistiendo con la
      // escritura mientras X devuelve 429: cada intento es un arranque de x.com
      // y empeora el bloqueo (F-16). Medido 2026-10-04: 8 respuestas 429 en una
      // sola corrida, y el editor "no encontrado" era en realidad la cuenta ya
      // bloqueada. Un `no_render` sin decir por lo menos "te tiraron 429" es
      // volver a mentir (ver F-1/F-12).
      if (http['429'] > n429antes) {
        const e = new Error('La cuenta throttleo al abrir la pagina de ajustes (HTTP 429). No se toco nada.');
        e.code = THROTTLE;
        throw e;
      }

      if (enAjustes) {
        // MEDIDO 2026-10-04: en la pagina de ajustes hay VARIOS [role="dialog"].
        // El primero NO es el de editar perfil: es el de "View keyboard
        // shortcuts", que tiene cero inputs. Con `.first()` el codigo tomaba ese,
        // contaba 0 campos y devolvia null -> "no se encontro el editor", con la
        // pagina perfectamente cargada y cero 429.
        //
        // Por eso se elige el dialogo que REALMENTE contiene los campos, no el
        // primero. Y si ninguno los contiene, se usa la pagina entera.
        const dialogos = page.locator('[role="dialog"]');
        const nDlg = await dialogos.count();
        let root = null;
        let n = 0;
        for (let i = 0; i < nDlg; i++) {
          const d = dialogos.nth(i);
          const c = await d.locator('input:not([type="file"]), textarea').count();
          if (c > n) { n = c; root = d; }
        }
        // Fallback: el formulario puede estar en la pagina, sin dialogo.
        if (n === 0) {
          const c = await page.locator('input:not([type="file"]), textarea').count();
          if (c > 0) { root = page; n = c; }
        }
        if (n > 0) return { dlg: root, boxes: root.locator('input:not([type="file"]), textarea'), n, ruta: 'ajustes' };
      }

      // 2) Red de seguridad: el link del perfil.
      await irAlPerfil();
      let editar = await selEspera(page, ['[data-testid="editProfileButton"]'], 20000);
      if (!editar) editar = await botonPorTexto(page, ['Edit profile', 'Editar perfil', 'Set up profile']);
      if (!editar) return null;
      await editar.click();
      await page.waitForTimeout(3000);

      // Mismo criterio que arriba: el dialogo que tiene los campos, no el primero.
      const dialogos2 = page.locator('[role="dialog"]');
      const nDlg2 = await dialogos2.count();
      let root2 = null;
      let n2 = 0;
      for (let i = 0; i < nDlg2; i++) {
        const d = dialogos2.nth(i);
        const c = await d.locator('input:not([type="file"]), textarea').count();
        if (c > n2) { n2 = c; root2 = d; }
      }
      if (n2 === 0) {
        const c = await page.locator('input:not([type="file"]), textarea').count();
        if (c > 0) { root2 = page; n2 = c; }
      }
      if (!n2) return null;
      return { dlg: root2, boxes: root2.locator('input:not([type="file"]), textarea'), n: n2, ruta: 'perfil' };
    }

    if (modo === 'whoami' || modo === 'profile' || modo === 'avatar') {
      await page.goto('https://x.com/home', { waitUntil: 'domcontentloaded', timeout: 60000 });
      const st = await salud();
      if (st !== 'ok') {
        res.status = st;
        process.exitCode = st === 'throttled' ? THROTTLE : NO_MIRO;
        return;
      }
      await page.waitForTimeout(2000);
      res.handle = await irAlPerfil();
      await selEspera(page, ['[data-testid="UserName"]'], 20000);
      await page.waitForTimeout(1500);
      res.url = page.url();
      res.antes = await leerPerfil();

      if (modo === 'whoami') { res.accion = 'ninguna (lectura)'; }
      else {
        const ed = await abrirEditor();
        if (!ed) {
          // No se encuentra el editor: puede ser DOM nuevo o throttle. En una
          // escritura, "no lo encontre" NO es exito.
          res.status = http['429'] > 0 ? 'throttled' : 'no_render';
          res.nota = 'No se encontro el editor de perfil. No se modifico nada.';
          process.exitCode = NO_MIRO;
          return;
        }

        if (modo === 'profile') {
          // Primero inventariar los campos del dialogo, DESPUES decidir cual es
          // cual. Adivinar por posicion a ciegas es como se borra el campo
          // equivocado: el nombre de pantalla y el usuario se parecen mucho.
          const campos = [];
          for (let i = 0; i < ed.n; i++) {
            const b = ed.boxes.nth(i);
            campos.push({
              i,
              b,
              tag: await b.evaluate((el) => el.tagName),
              ro: await b.evaluate((el) => !!el.readOnly || !!el.disabled),
              cur: await b.inputValue().catch(() => ''),
              label: (await b.getAttribute('aria-label')) || (await b.getAttribute('placeholder')) || (await b.getAttribute('name')) || '',
            });
          }
          res.campos = campos.map(({ i, tag, ro, cur, label }) => ({ i, tag, ro, cur, label }));

          // Nombre: primero editable cuyo valor NO empieza con @ (el usuario
          // empieza con @ y ademas suele venir de solo lectura).
          const nombre = campos.find((c) => !c.ro && !/^\s*@/.test(c.cur) && /name|nombre|display/i.test(c.label))
            || campos.find((c) => !c.ro && !/^\s*@/.test(c.cur) && c.tag === 'INPUT');
          // Bio: el unico textarea del dialogo.
          const bio = campos.find((c) => c.tag === 'TEXTAREA');

          let cambios = [];
          if (flags.name !== undefined) {
            if (!nombre) { res.nota = 'No se identifico el campo de nombre. No se guardo nada.'; }
            else if (nombre.cur === flags.name) cambios.push('nombre (ya era igual)');
            else { await setReactValue(nombre.b, flags.name); cambios.push('nombre'); }
          }
          if (flags.bio !== undefined) {
            if (!bio) { res.nota = 'No se identifico el campo de bio. No se guardo nada.'; }
            else if (bio.cur === flags.bio) cambios.push('bio (ya era igual)');
            else { await setReactValue(bio.b, flags.bio); cambios.push('bio'); }
          }

          const real = cambios.filter((c) => !c.includes('ya era igual'));
          res.accion = `perfil: ${cambios.join(' + ') || 'sin cambios'}`;
          if (real.length) {
            const guardar = (await sel(ed.dlg, ['[data-testid="ProfileSaveButton"]', 'div[data-testid="ProfileSaveButton"]'])) ||
              (await botonPorTexto(ed.dlg, ['Save', 'Guardar']));
            if (!guardar) { res.status = 'no_render'; res.nota = 'No se encontro el boton Save. No se guardo.'; process.exitCode = NO_MIRO; return; }
            await pausaHumana();
            await guardar.click();
            await page.waitForTimeout(4000);
          }
        }

        if (modo === 'avatar') {
          // MEDIDO 2026-10-04 con sonda: en la pagina de ajustes el boton NO
          // tiene data-testid. Es <button aria-label="Add avatar photo">. Y hay
          // que distinguirlo de "Add banner photo" y de "Add photos or video",
          // que son OTROS dos botones con el mismo patron y hacen otra cosa.
          // Por eso el selector exige "avatar", no unicamente "photo".
          const camara = await sel(ed.dlg, [
            '[aria-label="Add avatar photo"]',
            '[aria-label*="avatar" i][role="button"]',
            '[data-testid="ProfileIconCameraIcon"]',
          ]);
          if (!camara) {
            const donde = await page.evaluate(() =>
              [...document.querySelectorAll('[aria-label]')]
                .map((e) => e.getAttribute('aria-label'))
                .filter((a) => /avatar|photo|foto|camera/i.test(a)));
            res.status = 'no_render';
            res.nota = 'No se encontro el boton de camara. No se subio nada. Botones de imagen presentes: ' +
              (donde.length ? donde.join(' | ') : 'ninguno');
            process.exitCode = NO_MIRO;
            return;
          }
          await camara.click();
          await page.waitForTimeout(2500);

          // MEDIDO 2026-10-04 (F-26): el dialogo de edicion tiene **2**
          // input[type=file]: el del BANNER y el del AVATAR. Tomar `.first()`
          // subia la imagen al banner, no al avatar: el click en Save "funcionaba"
          // y el perfil seguia con la imagen por defecto.
          //
          // El orden del DOM lo delata y es estable:
          //     fileInput, UserAvatar-Container-unknown, fileInput
          // o sea el del avatar es el que va DESPUES del contenedor. No se
          // asume el indice: se busca en el DOM cual input sigue al contenedor.
          const idxAvatar = await ed.dlg.evaluate((root) => {
            const cont = root.querySelector('[data-testid^="UserAvatar-Container-"]');
            const todos = [...root.querySelectorAll('input[type="file"]')];
            if (cont && todos.length) {
              // el input que aparece despues del contenedor en orden de documento
              let despues = null;
              let vistoCont = false;
              for (const el of todos) {
                if (el === cont) { vistoCont = true; continue; }
                if (vistoCont && cont.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) { despues = el; break; }
              }
              if (despues) return todos.indexOf(despues);
              // si el contenedor viene despues de todos, el ultimo es el suyo
              const i = todos.indexOf(cont);
              return i >= 0 ? i : todos.length - 1;
            }
            return todos.length > 1 ? todos.length - 1 : 0;
          });
          const files = ed.dlg.locator('input[type="file"]');
          const nFiles = await files.count();
          if (!nFiles) {
            res.status = 'no_render'; res.nota = 'No aparecio ningun input[type=file]. No se subio nada.';
            process.exitCode = NO_MIRO; return;
          }
          const input = files.nth(Math.min(idxAvatar, nFiles - 1));
          res.file_input_idx = Math.min(idxAvatar, nFiles - 1);
          res.file_input_total = nFiles;
          await input.setInputFiles(path.resolve(resto[0]));
          await page.waitForTimeout(4000);
          // X abre un dialogo de RECORTE encima del formulario (medido
          // 2026-10-04: el boton se llama "Apply"). Hay que confirmar ahi PRIMERO
          // y esperar a que el overlay desaparezca: si se clickea el Save del
          // formulario con el recorte abierto, el overlay intercepta el click y
          // Playwright reintenta hasta agotar los 30 s.
          let recorteConfirmado = false;
          for (let intento = 0; intento < 3 && !recorteConfirmado; intento++) {
            // MEDIDO 2026-10-04 (F-27): el dialogo de recorte NO dice "crop".
            // Su texto es exactamente **"Edit media"**, con un boton
            // `data-testid="applyButton"`. El filtro por /crop/ no lo encontraba
            // nunca, y entonces se clickeaba el Save del formulario con el
            // recorte abierto encima: el overlay interceptaba el click y la
            // subida no ocurria.
            //
            // Por testid primero: es estable y no depende de como X traduzca.
            let recorte = page.locator('[role="dialog"]').filter({ has: page.locator('[data-testid="applyButton"]') }).first();
            if (!(await recorte.count())) {
              recorte = page.locator('[role="dialog"]').filter({ hasText: /Edit media/i }).first();
            }
            if (!(await recorte.count())) { if (intento === 0) res.recorte = 'no apareció'; break; }
            const okRecorte = (await sel(recorte, ['[data-testid="applyButton"]'])) ||
              (await botonPorTexto(recorte, ['Apply', 'Aplicar', 'Done', 'Listo']));
            if (!okRecorte) { res.recorte = 'apareció pero sin botón'; break; }
            await okRecorte.click();
            await recorte.waitFor({ state: 'detached', timeout: 20000 }).catch(() => {});
            await page.waitForTimeout(1000);
            const sigue = await page.locator('[role="dialog"]').filter({ has: page.locator('[data-testid="applyButton"]') }).count();
            recorteConfirmado = sigue === 0;
          }
          res.recorte = recorteConfirmado ? 'confirmado' : (res.recorte || 'no se pudo confirmar');
          if (!recorteConfirmado) {
            res.status = 'no_verificado';
            res.nota = 'El dialogo de recorte ("Edit media") no se pudo confirmar. El Save del ' +
              'formulario esta debajo de ese overlay, asi que no se subio nada.';
            process.exitCode = NO_MIRO;
            return;
          }

          // MEDIDO: el data-testid real es "Profile_Save_Button", con guion bajo.
          // "ProfileSaveButton" (sin guion) NO existe: por eso el primer intento
          // de avatar reportaba "no se encontro Save".
          const listo = (await sel(ed.dlg, [
            '[data-testid="Profile_Save_Button"]',
            '[data-testid="ProfileSaveButton"]',
          ])) || (await botonPorTexto(ed.dlg, ['Save', 'Guardar']));
          if (!listo) { res.status = 'no_render'; res.nota = 'No se encontro Save tras elegir la imagen. No se subio nada.'; process.exitCode = NO_MIRO; return; }
          await pausaHumana();
          await listo.click({ timeout: 20000 }).catch(async (e) => {
            // Si el overlay intercepta, reintentar una vez con force: el click
            // forcido va al boton correcto aunque haya otro elemento encima.
            res.nota = 'Primer click interceptado por un overlay, reintentando.';
            await listo.click({ force: true, timeout: 15000 });
          });
          await page.waitForTimeout(5000);
          res.accion = `avatar: subida ${path.basename(resto[0])}`;
        }

        await page.goto('https://x.com/home', { waitUntil: 'domcontentloaded' });
        await page.waitForTimeout(2500);
        await irAlPerfil();
        // El header del perfil tarda en resolver: con 3s el UserName salia null
        // y `antes`/`despues` quedaban vacios, que es indistinguible de "no
        // cambio nada". Un poco mas de espera y, sobre todo, esperar el elemento.
        await selEspera(page, ['[data-testid="UserName"]'], 20000);
        await page.waitForTimeout(1500);
        res.despues = await leerPerfil();
        res.url = page.url();
      }
    }

    if (modo === 'post') {
      const texto = resto.join(' ');
      if (texto.length > 280) {
        res.status = 'error'; res.nota = `El texto tiene ${texto.length} caracteres; el limite son 280. No se publico.`;
        process.exitCode = ERROR; return;
      }
      await page.goto('https://x.com/compose/post', { waitUntil: 'domcontentloaded', timeout: 60000 });
      const st = await salud();
      if (st !== 'ok') {
        res.status = st;
        process.exitCode = st === 'throttled' ? THROTTLE : NO_MIRO;
        return;
      }
      await page.waitForTimeout(2000);

      // MEDIDO 2026-10-04 (F-28): /compose/post es un dialogo con VARIOS
      // tweetTextarea (6 en total, incluyendo etiquetas y contenedores), y el
      // boton es `tweetButton`. Con `.first()` se tomaba uno de adorno.
      // Ademas, si la URL no queda en /compose/post, no se publico: se abrio
      // otra cosa (en una corrida fue /i/graduated-access) y el script reportaba
      // "publicado" igual.
      // MEDIDO 2026-10-04 (F-29): el compositor tarda MAS que 3 s en montar.
      // Una sonda con 12 s de espera lo vio; el script con 3 s reportaba "no se
      // encontro el campo de texto" con la pagina bien cargada y cero 429.
      // El selector estaba bien: faltaba ESPERAR por el.
      //
      // Estructura real (medida): el compositor tiene 6 elementos
      // `tweetTextarea*`, pero solo 2 son el campo editable:
      //   div[data-testid="tweetTextarea_0"][role="textbox"][contenteditable="true"]
      // Los otros son `_label` y `_RichTextInputContainer`.
      const ta = (await selEspera(page, [
        '[data-testid="tweetTextarea_0"][contenteditable="true"][role="textbox"]',
        'div[data-testid="tweetTextarea_0"][contenteditable="true"]',
        '[data-testid="tweetTextarea_0"][role="textbox"]',
      ], 30000));
      if (!ta) {
        res.status = 'no_render';
        res.nota = 'No se encontro el campo de texto del compositor. No se publico. URL: ' + page.url();
        process.exitCode = NO_MIRO; return;
      }
      await ta.click();
      await page.keyboard.type(texto, { delay: 25 + Math.random() * 45 });
      await page.waitForTimeout(2000);

      // El texto tiene que estar ADENTRO del textarea. X a veces acepta el click
      // y deja el campo vacio, y entonces el boton queda deshabilitado.
      const escrito = await ta.evaluate((el) => (el.innerText || el.value || '').trim().length);
      res.caracteres_escritos = escrito;
      if (!escrito) {
        res.status = 'no_render';
        res.nota = 'El texto no quedo escrito en el compositor (0 caracteres). No se publico.';
        process.exitCode = NO_MIRO; return;
      }

      // MEDIDO: `tweetButton` arranca SIEMPRE deshabilitado (aria-disabled="true")
      // con el compositor vacio, y se habilita solo cuando hay texto. Por eso se
      // espera a que se habilite en vez de comprobarlo una vez y rendirse.
      const btn = (await selEspera(page, ['[data-testid="tweetButton"]'], 10000)) ||
        (await botonPorTexto(page, ['Post', 'Publicar', 'Twittear']));
      if (!btn) { res.status = 'no_render'; res.nota = 'No se encontro el boton de publicar. No se publico.'; process.exitCode = NO_MIRO; return; }
      let deshabilitado = true;
      const limiteEspera = Date.now() + 15000;
      while (Date.now() < limiteEspera && deshabilitado) {
        deshabilitado = await btn.evaluate((el) => !!el.disabled || el.getAttribute('aria-disabled') === 'true');
        if (deshabilitado) await page.waitForTimeout(1000);
      }
      if (deshabilitado) {
        res.status = 'no_render';
        res.nota = 'El boton Post quedo deshabilitado. No se publico.';
        process.exitCode = NO_MIRO; return;
      }
      await pausaHumana();
      await btn.click();
      await page.waitForTimeout(5000);

      // MEDIDO 2026-10-04 (F-30): al publicar bien, la URL **se queda en
      // /compose/post**. No hay URL del tweet. Asi que "la URL no cambio" no
      // sirve como prueba de nada: fue exactamente el criterio que se uso y dio
      // `no_verificado` sobre un post que SI estaba publicado.
      //
      // La unica comprobacion fiable es ir al perfil y buscar el tweet. Y hay que
      // hacerlo con POLL: tras publicar, el perfil puede tardar en servir la
      // timeline, y una espera fija da 0 articulos (F-20).
      await page.goto('https://x.com/home', { waitUntil: 'domcontentloaded', timeout: 60000 });
      await sleep(2500);
      const irAlPerfilPost = await irAlPerfil();
      const limitePost = Date.now() + 30000;
      let encontrado = null;
      while (Date.now() < limitePost && !encontrado) {
        const art = page.locator('article[data-testid="tweet"]').first();
        if (await art.count()) {
          encontrado = await art.evaluate((a) => {
            const t = a.querySelector('[data-testid="tweetText"]');
            const l = a.querySelector('a[href*="/status/"]');
            const tm = a.querySelector('time');
            return {
              texto: t ? (t.innerText || '') : null,
              len: t ? (t.innerText || '').length : 0,
              url: l ? 'https://x.com' + l.getAttribute('href') : null,
              cuando: tm ? tm.getAttribute('datetime') : null,
            };
          });
        }
        if (!encontrado) await page.waitForTimeout(2000);
      }
      res.buscado_en_perfil = irAlPerfilPost;
      if (!encontrado) {
        res.status = 'no_verificado';
        res.nota = 'Se clickeo Post y el compositor quedo en /compose/post, pero el perfil de ' +
          irAlPerfilPost + ' no muestra ningun articulo todavia. Puede ser la timeline delayed. ' +
          'Revisar a mano antes de asumir que se publico.';
        res.despues = { url_publicacion: null };
        process.exitCode = NO_MIRO;
        return;
      }
      res.despues = encontrado;
      res.accion = `publicado (verificado en el perfil): ${texto.slice(0, 60)}${texto.length > 60 ? '…' : ''}`;
    }

    // Verificar el avatar DE VERDAD. Medido 2026-10-04: el click en Save
    // "funciono" (sin error, sin 429) y el perfil seguia mostrando
    // `abs.twimg.com/sticky/default_profile_images/...`: el avatar NO se habia
    // subido. Un `verificado: true` derivado solo de "no tiro error" habria
    // reportado un exito falso.
    //
    // La unica señal buena es que la URL del avatar propio deje de ser la de
    // las imagenes por defecto de X.
    async function avatarEsDefault() {
      return page.evaluate(() => {
        const c = [...document.querySelectorAll('[data-testid^="UserAvatar-Container-"]')]
          .filter((x) => /Container-gbroOCT$/.test(x.getAttribute('data-testid')));
        for (const cont of c) {
          const img = cont.querySelector('img');
          if (img && /default_profile_images/.test(img.src)) return true;
        }
        // Si no hay ningun avatar propio, tampoco se subio.
        return c.length === 0;
      });
    }

    // Resultado. En escritura, exito = SE VIO EL EFECTO.
    //
    // No alcanza con que la sesion estuviera sana: en la corrida del
    // 2026-10-04T18:26 el script salio con status ok y verificado true, con
    // 923 peticiones y cero 429, mientras la nota decia "No se identifico el
    // campo de bio. No se guardo nada." Eso es el F-1/F-12 de nuevo, ahora en el
    // camino de exito: un verificado:true que nadie verifico.
    //
    // verificado solo es true si hubo un cambio real Y se relee el perfil
    // despues para confirmarlo.
    if (escribiendo && res.status === 'ok') {
      const tocoAlgo = res.accion && !/sin cambios/i.test(res.accion);
      let confirmed = false;
      // OJO: `post` NO tiene `antes` (no se relee el perfil antes de publicar), asi
      // que pedir `res.antes` aca descartaba TODA la verificacion del post en
      // silencio: caia al `verificado = false` de abajo sin explicar por que.
      // Un guarda que es falso para un modo entero no es un guarda, es un bug.
      const hayBase = res.despues && (res.antes || modo === 'post');
      if (tocoAlgo && hayBase) {
        if (flags.bio !== undefined && res.despues.bio === flags.bio) confirmed = true;
        else if (flags.name !== undefined && String(res.despues.nombre || '').split('\n')[0] === flags.name) confirmed = true;
        else if (modo === 'post' && res.despues) {
          // Verificacion real: el tweet existe en el perfil, con URL de /status/,
          // timestamp de HOY, y un texto que se parece al que se mando.
          //
          // MEDIDO 2026-10-04T20:33: comparar SOLO el largo daba falso negativo.
          // Se mandaron 159 caracteres y X sirvio 157: cuenta los saltos de linea
          // de otra forma. Con tolerancia de 2 el post real daba "no_verificado"
          // sobre un tweet que estaba publicado. Comparar el TEXTO es lo que
          // sobrevive a la normalizacion.
          const pedido = resto.join(' ');
          const servido = (res.despues.texto || '').replace(/\s+/g, ' ').trim();
          const pedidoPlano = pedido.replace(/\s+/g, ' ').trim();
          // Que el tweet sea de AHORA: evita dar por bueno un post viejo.
          const hoy = new Date().toISOString().slice(0, 10);
          const esDeHoy = !res.despues.cuando || res.despues.cuando.slice(0, 10) === hoy;
          res.post_coincide = servido === pedidoPlano;
          confirmed = !!(
            res.despues.url &&
            /\/status\/\d+/.test(res.despues.url) &&
            servido.length > 0 &&
            servido === pedidoPlano &&
            esDeHoy
          );
        }
        else if (modo === 'avatar') {
          // Re-navegar al perfil y mirar la URL del avatar, no confiar en el
          // exito del click (F-25).
          const sigueDefault = await avatarEsDefault();
          res.avatar_verificado = !sigueDefault;
          confirmed = !sigueDefault;
        }
      }
      res.verificado = !!(tocoAlgo && confirmed);
      if (!res.verificado) {
        res.status = 'no_verificado';
        const porQue = [];
        if (modo === 'post') {
          if (!res.despues || !res.despues.url) porQue.push('no se encontro el tweet en el perfil');
          else if (!/\/status\/\d+/.test(res.despues.url)) porQue.push('la URL no es de un /status/');
          else if (res.post_coincide === false) porQue.push('el texto del perfil NO coincide con el enviado');
          else porQue.push('no se pudo determinar');
        } else if (!tocoAlgo) {
          porQue.push('no hubo ningun cambio que confirmar');
        } else {
          porQue.push('el valor releido no coincide con el pedido');
        }
        res.nota = (res.nota ? res.nota + ' | ' : '') +
          'La sesion estaba sana pero el cambio NO quedo verificado (' + porQue.join('; ') + '). ' +
          'No se reporta exito. Revisar a mano.';
        process.exitCode = NO_MIRO;
        return;
      }
    }
    process.exitCode = OK;
  } catch (e) {
    // Un 429 lanzado desde adentro (ver abrirEditor) NO es un error del script:
    // es la cuenta bloqueada. Reportarlo como `throttled`, no como `error`.
    res.status = e && e.code === THROTTLE ? 'throttled' : 'error';
    res.nota = String((e && e.message) || e);
    process.exitCode = e && e.code === THROTTLE ? THROTTLE : ERROR;
  } finally {
    emit();
    if (ctx) await ctx.close().catch(() => {});
  }
})();
