#!/usr/bin/env node
// X / Twitter scraper via Brave + tu sesion real. SOLO LECTURA.
//   node scrape.js search "opencode" [--limit 15] [--top] [--since 2026-01-01] [--pages 2] [--headed] [--out f.json]
//   node scrape.js multi "q1" "q2" ...   [--limit] [--top] [--since] [--out]
//   node scrape.js user <handle> | tweet <id|url>
//
// Sale por stdout un JSON con status. SIETE estados, no tres:
//   ok | empty | no_render | stalled | blocked | throttled | degraded
// NUNCA devuelve [] con status ok: si no miro, lo dice (ver MEJORAS.md B1).
// `degraded` es el caso donde la sesion esta viva pero X no entrega contenido
// (FAILURES.md F-21): sin el, eso se reportaba como `empty`, que es mentira.
const fs = require('fs');
const path = require('path');
const os = require('os');

const BRAVE =
  process.env.BRAVE_PATH ||
  'C:/Users/perca/AppData/Local/BraveSoftware/Brave-Browser/Application/brave.exe';
const USER_DATA =
  process.env.BRAVE_USER_DATA ||
  'C:/Users/perca/AppData/Local/BraveSoftware/Brave-Browser/User Data';
const PROFILE = process.env.BRAVE_PROFILE || 'Default';

// Anti-ban: espera aleatoria entre consultas y tope por invocacion (MEJORAS.md C2).
const MIN_PAUSE = Number(process.env.X_SCRAPE_MIN_PAUSE) || 3000;
const MAX_PAUSE = Number(process.env.X_SCRAPE_MAX_PAUSE) || 8000;
const MAX_QUERIES = Number(process.env.X_SCRAPE_MAX_QUERIES) || 12;
let navigations = 0;   // recargas COMPLETAS de x.com (caro)
let spaSaltos = 0;     // cambios de consulta dentro del SPA (barato)

function findPlaywrightCore() {
  try {
    return require('playwright-core');
  } catch {}
  const roots = [
    process.env.NPM_CONFIG_CACHE || path.join(os.homedir(), 'AppData', 'Local', 'npm-cache'),
    'G:/Dev/npm-cache',
  ];
  const candidates = [];
  for (const root of roots) {
    const npx = path.join(root, '_npx');
    if (!fs.existsSync(npx)) continue;
    for (const dir of fs.readdirSync(npx)) {
      candidates.push(path.join(npx, dir, 'node_modules', 'playwright-core'));
    }
  }
  for (const c of candidates) {
    if (fs.existsSync(path.join(c, 'package.json'))) return require(c);
  }
  throw new Error(
    'playwright-core no encontrado. Instalalo con: npm i -g playwright-core' +
      (candidates.length ? `\nBusque en:\n  ${candidates.slice(0, 5).join('\n  ')}` : '')
  );
}

const { chromium } = findPlaywrightCore();

// ---------- args: un solo punto de parseo, testeado ----------
const FLAGS_WITH_VALUE = ['limit', 'out', 'since', 'pages', 'cache'];

const flags = {};
const pos = [];
for (let i = 2; i < process.argv.length; i++) {
  const a = process.argv[i];
  if (a.startsWith('--')) {
    const name = a.slice(2);
    if (FLAGS_WITH_VALUE.includes(name) && i + 1 < process.argv.length) flags[name] = process.argv[++i];
    else flags[name] = true;
  } else {
    pos.push(a);
  }
}
const limit = Number(flags.limit) || 15;
// --headed: ventana al frente. --show: ventana real pero MINIMIZADA, para que
// el operador vea que el scraper esta trabajando (barra de tareas) sin que le
// tape la pantalla ni le robe el foco.
// --focus: junto con --show,|maximizar en vez de minimizar.
const headed = flags.headed === true;
const showWin = flags.show === true;
const focused = flags.focus === true;
const headed2 = headed || focused || showWin;
const minimise = showWin && !focused;
const out = flags.out || null;
const since = flags.since || null;
const pages = Math.min(Number(flags.pages) || 1, 10);
const cacheDir = flags.cache || null;
const cacheHours = Number(process.env.X_SCRAPE_CACHE_H || 12);

// Consulta ya scrapeada dentro de la ventana: se reusa y NO se pega un hit a X.
function cacheRead(q) {
  if (!cacheDir) return null;
  const f = path.join(cacheDir, require('crypto').createHash('sha1').update(q + '|' + tab + '|' + (since || '')).digest('hex') + '.json');
  try {
    const j = JSON.parse(fs.readFileSync(f, 'utf8'));
    if (Date.now() - j.scraped_ms > cacheHours * 3600e3) return null;
    return j;
  } catch { return null; }
}
function cacheWrite(q, payload) {
  if (!cacheDir) return;
  try {
    fs.mkdirSync(cacheDir, { recursive: true });
    const f = path.join(cacheDir, require('crypto').createHash('sha1').update(q + '|' + tab + '|' + (since || '')).digest('hex') + '.json');
    fs.writeFileSync(f, JSON.stringify({ scraped_ms: Date.now(), ...payload }), 'utf8');
  } catch {}
}
const tab = flags.top ? '' : '&f=live'; // Top = relevancia; Latest = cronologico
const [mode, arg] = pos;
// --media deja de bloquear imagenes y video (default: bloquear, por CPU)
const allowMedia = flags.media === true;

// --gpu-check: imprime que renderer usa el navegador y sale.
//
// Medido 2026-10-04: SIN ningun flag ya renderiza por ANGLE/D3D11 sobre la RTX
// 3090. Agregar --use-angle=d3d11 / --enable-gpu / --ignore-gpu-blocklist NO
// cambia nada (mismo renderer) y --ignore-gpu-blocklist puede forzar un driver
// malo. Por eso NO se agregan: la GPU ya esta activa. Este flag existe para
// poder VERIFICARLO y detectar una regresion.
//
// TRAMPA (FAILURES.md F-11): NO se puede leer el renderer desde una pagina normal.
// Brave's Shields sustituye WEBGL_debug_renderer_info por la palabra "Brave" como
// anti-fingerprinting, asi que un canvas en about:blank devuelve literalmente
// "Brave" tanto si hay GPU como si hay SwiftShader. Hay que correr el canvas
// sobre una pagina chrome://, donde Shields no interviene.
// Ademas chrome://gpu da innerText VACIO (el contenido va en shadow DOM), asi que
// no sirve parsearlo: el canvas sobre esa pagina es la unica lectura util.
// --start-minimized NO alcanza (medido 2026-10-04): Playwright crea la ventana
// DESPUES del arranque del navegador, y ese flag solo afecta a la ventana inicial.
// Medido: --show dejaba la ventana VISIBLE (IsIconic = false en las 3 muestras).
// Por eso se minimiza despues, con ShowWindow(SW_MINIMIZE) de Win32.
// Devuelve si encontro y minimizo alguna ventana.
function minimiseWindow() {
  if (!minimise) return false;
  // Un one-liner de PowerShell con comillas anidadas es fragil (fallo medido:
  // "Command failed"). Va en un .ps1 temporal invocado con -File.
  const ps1 = [
    "$ErrorActionPreference = 'SilentlyContinue'",
    "Add-Type -Namespace X -Name U -MemberDefinition '[DllImport(\"user32.dll\")] public static extern bool ShowWindow(IntPtr h,int c);'",
    "$w = @(Get-Process brave | Where-Object { $_.MainWindowTitle -ne '' })",
    "if ($w.Count -gt 0) { [X.U]::ShowWindow($w[0].MainWindowHandle, 6) | Out-Null; Write-Output 'ok' }",
  ].join('\r\n');
  const f = path.join(os.tmpdir(), 'xscrape-minimiza.ps1');
  try {
    fs.writeFileSync(f, ps1, 'utf8');
    const r = require('child_process').execFileSync(
      'powershell',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', f],
      { encoding: 'utf8', timeout: 20000 }
    );
    return /ok/.test(r);
  } catch (e) {
    return false;
  } finally {
    try { fs.unlinkSync(f); } catch {}
  }
}

async function gpuCheck() {
  let c2;
  try {
    c2 = await chromium.launchPersistentContext(USER_DATA, {
      executablePath: BRAVE,
      headless: !headed2,
      viewport: { width: 1280, height: 900 },
      args: [`--profile-directory=${PROFILE}`].concat(minimise ? ['--start-minimized'] : []),
    });
    const pg = c2.pages()[0] || (await c2.newPage());
    await pg.goto('chrome://gpu', { waitUntil: 'domcontentloaded', timeout: 60000 });
    await sleep(4000);

    const canvas = await pg.evaluate(() => {
      try {
        const cv = document.createElement('canvas');
        const g = cv.getContext('webgl');
        if (!g) return 'SIN WEBGL';
        const d = g.getExtension('WEBGL_debug_renderer_info');
        return d ? g.getParameter(d.UNMASKED_RENDERER_WEBGL) : 'sin debug_renderer_info';
      } catch (e) {
        return 'error';
      }
    });

    console.log('renderer: ' + canvas);

    if (/swiftshader|llvmpipe|\bWARP\b|software|swangle/i.test(canvas)) {
      console.error('  RESULTADO: renderizado por SOFTWARE. La GPU no se esta usando.');
      return 4;
    }
    if (canvas === 'Brave') {
      console.error('  RESULTADO: no verificable. Brave esta enmascarando el renderer.');
      console.error('  Es un sintoma de que la pagina NO es una pagina chrome://.');
      return 3;
    }
    if (!/ANGLE|Direct3D|D3D11|Vulkan|OpenGL|Metal/i.test(canvas)) {
      console.error('  RESULTADO: renderer desconocido, no se puede afirmar nada.');
      return 3;
    }
    console.error('  RESULTADO: GPU activa (aceleracion por hardware confirmada).');
    return 0;
  } catch (e) {
    console.error('  no se pudo verificar la GPU: ' + e.message.split('\n')[0]);
    return 3;
  } finally {
    if (c2) await c2.close().catch(() => {});
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Ritmo: los intervalos uniforme se leen como robóticos. Se usa una distribución
// sesgada a los valores bajos (ley exponencial), que es como se distribuyen los
// tiempos humanos reales entre acciones.
const jitter = (base, spread) => Math.round(base + (Math.random() + Math.random() - 1) * spread);
const pause = () => sleep(MIN_PAUSE + Math.floor(Math.random() * (MAX_PAUSE - MIN_PAUSE)));

// ---------- selectores de X (verificados 2026-10-03) ----------
const EXTRACT = () =>
  [...document.querySelectorAll('article[data-testid="tweet"]')].map((a) => {
    const t = (el) => (el ? el.textContent.trim() : null);
    const nameBox = a.querySelector('div[data-testid="User-Name"]');
    const statusA = a.querySelector('a[href*="/status/"]');
    const time = statusA ? statusA.querySelector('time') : null;
    return {
      user: t(nameBox && nameBox.querySelector('span')),
      handle: (statusA && statusA.getAttribute('href').slice(1).split('/')[0]) || null,
      when: time ? time.getAttribute('datetime') : null,
      text: t(a.querySelector('[data-testid="tweetText"]')),
      url: statusA ? statusA.href : null,
    };
  });

const PROBE = () => ({
  // X sirve la columna de resultados en dos estados indistinguibles a simple vista:
  // (a) cargando, con spinners y cero articles; (b) resuelto, con articles.
  // El caso (a) se puede quedar colgado para siempre. Sin este dato el scraper
  // reportaba "empty" y callers le creian: era mentira (hallazgo 2026-10-04).
  cargando: document.querySelectorAll('[role="progressbar"], [aria-busy="true"]').length > 0,
  articulos: document.querySelectorAll('article').length,
  cuenta:
    (document.querySelector('[data-testid="SideNav_AccountSwitcher_Button"] span') || {}).textContent ||
    null,
  // NO uses SideNav_NewTweetButton: X lo renombro y da false aunque haya sesion (MEJORAS.md B2)
  challenge: /Just a moment|Verify you are human|Checking your browser/i.test(document.body.innerText),
  logged_out: /Log in|Sign up/i.test(document.body.innerText) && !document.querySelector('[data-testid="SideNav_AccountSwitcher_Button"]'),
  titulo: document.title,
  cargados: document.querySelectorAll('article[data-testid="tweet"]').length,
  // Para detectar DEGRADACION (F-21): si la sesion esta viva pero NO hay ni
  // nombre, ni avatar, ni bio, entonces no hay una pagina de perfil real que
  // pueda estar vacia. Ver la funcion degradado() mas abajo.
  perfilNombre: !!document.querySelector('[data-testid="UserName"]'),
  perfilAvatar: !!document.querySelector('[data-testid^="UserAvatar-Container-"], img[src*="profile_images"]'),
  perfilBio: !!document.querySelector('[data-testid="UserDescription"]'),
});

function searchUrl(q) {
  const s = since ? ` since:${since}` : '';
  return `https://x.com/search?q=${encodeURIComponent(q + s)}&src=typed_query${tab}`;
}

(async () => {
  // --gpu-check se atiende PRIMERO: antes del chequeo de uso y antes de tocar
  // la red. Va aca adentro a proposito: como IIFE aparte hacia `await`,
  // devolvia el control al modulo y la IIFE principal imprimia `uso:` y salia
  // con codigo 2 antes de que terminara el chequeo.
  //
  // OJO: se usa process.exitCode + return, NO process.exit(). Con stdout en un
  // pipe, process.exit() descarta las escrituras pendientes y el JSON (o el
  // renderer) se pierde. Ver FAILURES.md F-10.
  if (flags['gpu-check']) { process.exitCode = await gpuCheck(); return; }
  if (!mode) {
    // Códigos de salida: 0 ok | 2 uso/entorno | 3 bloqueado, stalled o sin render |
    // 4 renderizado por software | 5 throttleado (429) O degradado | 1 error propio.
    // `degraded` comparte el 5 con `throttled` a propósito: los dos piden la misma
    // acción —parar y esperar horas—. Un código distinto obligaría a que el
    // llamador distinguiera dos causas que se resuelven exactamente igual.
console.error('uso: node scrape.js <search|multi|user|tweet> <arg...> [--limit N] [--top] [--since YYYY-MM-DD] [--pages N] [--headed] [--show] [--focus] [--media] [--cache <dir>] [--gpu-check] [--out f]');
    process.exitCode = 2;
    return;
  }
  if (!fs.existsSync(BRAVE)) {
    console.error(`Brave no encontrado en ${BRAVE}`);
    process.exitCode = 2;
    return;
  }

  let minimised = false;
  let ctx;
  try {
    ctx = await chromium.launchPersistentContext(USER_DATA, {
      executablePath: BRAVE,
      headless: !headed2,
      viewport: { width: 1440, height: 900 },
      args: [`--profile-directory=${PROFILE}`].concat(minimise ? ['--start-minimized'] : []),
    });

    const page = ctx.pages()[0] || (await ctx.newPage());

    // --- ESTADO DE RED (FAILURES.md F-12) ---
    // X puede devolver 200 para el HTML y 429 para TODAS las llamadas a la API.
    // El resultado visible es una pagina en blanco: sin titulo, sin articulos y
    // SIN spinners. Antes eso caia en el mismo saco que "no hay resultados", que
    // es una mentira: la cuenta esta rate-limited, no la busqueda vacia.
    let http = { '429': 0, '4xx': 0, '5xx': 0, 'peticiones': 0, 'api': 0 };
    // CUANTO CUESTA. Medido 2026-10-04: un page.goto a una busqueda son 197
    // peticiones (23 a la API); cambiar la consulta DENTRO del SPA son 25 (10 a la
    // API). O sea ~8x. Por eso `multi` reutiliza el SPA en vez de recargar.
    const esApi = (u) => /api\.x\.com|\/i\/api\/|\/graphql|settings\.json/i.test(u);
    page.on('request', (r) => {
      http.peticiones++;
      if (esApi(r.url())) http.api++;
    });
    page.on('response', (r) => {
      const s = r.status();
      if (s === 429) http['429']++;
      else if (s >= 500) http['5xx']++;
      else if (s >= 400) http['4xx']++;
    });

    // --- COSTO DE CPU (medido 2026-10-04) ---
    // Sin esto, UNA corrida saturaba ~400% de CPU (31 procesos, 8,4s de CPU por
    // cada 2s de reloj). El culpable NO es el scraping: es que X decodifica video
    // en multihilo y pinta imagenes que este scraper ni usa.
    // Bloquear media y apagar animaciones deja la corrida en un costo normal.
    if (!allowMedia) {
      await page.route('**/*', (route) => {
        const u = route.request().url();
        const esPesado =
          /\.(mp4|webm|m4v|mov|m3u8|mpd)(\?|$)/i.test(u) ||   // video / HLS / DASH
          /video\.twimg\.com|pbs\.twimg\.com\/.*\.(mp4|webm)/i.test(u) ||
          /\.(png|jpe?g|gif|webp|avif)(\?|$)/i.test(u) ||
          /twimg\.com\/.*\/(profile_images|ext_tw_video)/i.test(u);
        return esPesado ? route.abort() : route.continue();
      });
    }
    const out0 = {
      scraped_at: new Date().toISOString(),
      mode,
      query: null,
      search_url: null,
      limit,
      headless: !headed2,
      ventana: headed2 ? (minimise ? 'visible-minimizada' : 'visible') : 'oculta (headless)',
      tab: flags.top ? 'top' : 'live',
      since,
      status: 'ok',
      session: null,
      results: [],
      queries: null,
    };

    // goto + scroll-acumulate + probe de salud (B1).
    //
    // PAGINACION: la busqueda de X usa lista VIRTUALIZADA. Al scrollear se DESMONTA lo que
    // quedo atras, asi que contar articles al final nunca pasa de ~7-12 aunque haya paginas.
    // Por eso se extrae y acumula en CADA paso de scroll, no solo al terminar.
    // qSpa: si viene, se intenta cambiar la consulta DENTRO del SPA en vez de
    // recargar. Medido 2026-10-04: goto = 197 peticiones, salto en el SPA = 25.
    // Si el salto falla (caja de busqueda ausente, DOM cambiado), cae a goto.
    async function go(url, maxPages, settleMs, qSpa) {
      let reusada = false;
      if (qSpa && (await buscarEnSpa(qSpa))) {
        reusada = true;
        spaSaltos++;
        console.error('  salto en el SPA (sin recargar) -> "' + qSpa + '"');
      } else {
        navigations++;
        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
        await page.addStyleTag({
          content: '*,*::before,*::after{animation:none!important;transition:none!important}',
        }).catch(() => {});
      }

      // Esperar a que la columna RESUELVA. Medido 2026-10-04: la pagina puede
      // tardar ~10s, y en ~(1 de cada N) intentos queda colgada en spinner
      // para siempre. Poll corto + tope de espera, en vez de un solo sleep fijo.
      const limite = Date.now() + (settleMs || 25000);
      let articles = 0;
      do {
        await sleep(2000);
        const st = await page.evaluate(() => ({
          a: document.querySelectorAll('article').length,
          c: document.querySelectorAll('[role="progressbar"], [aria-busy="true"]').length,
        }));
        articles = st.a;
        if (articles > 0) break;
        // Si X ya nos esta contestando 429, esperar mas no sirve: la pantalla
        // no va a pintar nunca. Salimos ya y el estado lo dira.
        if (http['429'] > 0) break;
        if (Date.now() > limite) break;
      } while (true);
      // Una sola vez por corrida. Antes el guard era `navigations === 1`, que con
      // salto en el SPA se cumple en todas las consultas: minimizaba N veces y
      // lanzaba N procesos de PowerShell (medido 2026-10-04).
      if (minimise && !minimised) {
        minimised = true;
        const ok = minimiseWindow();
        console.error('  ventana minimizada: ' + (ok ? 'si' : 'no se pudo'));
      }
      await sleep(jitter(1200, 800));

      const acc = new Map();
      const absorb = async () => {
        const rows = await page.evaluate(EXTRACT);
        let nuevos = 0;
        for (const r of rows) {
          const k = r.url || r.id || JSON.stringify([r.handle, r.text]);
          if (k && !acc.has(k)) { acc.set(k, r); nuevos++; }
        }
        return { total: acc.size, nuevos, enPantalla: rows.length };
      };

      const primero = await absorb();
      if (maxPages > 1) {
        let quieto = 0;
        for (let p = 1; p < maxPages; p++) {
          await page.evaluate(() => {
            // salto variable: siempre el mismo tamano tambien delata automatizacion
            const vh = window.innerHeight;
            window.scrollBy(0, vh * (0.45 + Math.random() * 0.5));
          });
          await sleep(jitter(2200, 1600));
          const s = await absorb();
          console.error('  scroll ' + p + ': +' + s.nuevos + ' (acumulado ' + s.total + ', en pantalla ' + s.enPantalla + ')');
          quieto = s.nuevos === 0 ? quieto + 1 : 0;
          if (quieto >= 2) break; // dos vueltas sin nada nuevo = fin de la lista
        }
      }
      return { probe: await page.evaluate(PROBE), rows: [...acc.values()] };
    }

    // Cambiar la consulta SIN recargar la pagina. Una persona no recarga x.com
    // para cada busqueda: escribe en la caja y le da Enter. Recargar cuesta 197
    // peticiones; esto cuesta 25 (medido 2026-10-04).
    // Devuelve false si no se pudo, para que el llamador caiga a page.goto.
    async function buscarEnSpa(q) {
      try {
        const input = await page.$('[data-testid="SearchBox_Search_Input"]');
        if (!input) return false;
        const actual = (await input.inputValue().catch(() => '')) || '';
        if (actual.trim() === q) return false;
        await input.click({ clickCount: 3 });
        await input.fill(q);
        await page.keyboard.press('Enter');
        await page.waitForFunction(
          (qq) => {
            const i = document.querySelector('[data-testid="SearchBox_Search_Input"]');
            return i && (i.value || '').trim() === qq;
          },
          q,
          { timeout: 20000 }
        ).catch(() => {});
        await sleep(jitter(1500, 900));
        return true;
      } catch {
        return false;
      }
    }

    // Senal de DEGRADACION (FAILURES.md F-21).
    //
    // X no siempre throttlea con 429: a veces levanta la sesion (el shell de la
    // SPA carga, por eso `titulo` y el switcher estan bien) pero NO entrega el
    // contenido. Medido 2026-10-04: `titulo: "Home / X"`, `logueado: true`,
    // cero 4xx/5xx/429, y `cargados: 0`. Sin este chequeo eso caia en `empty`:
    // "no hay resultados para esta consulta", que es una mentira.
    //
    // Como se distingue de una busqueda legitimamente vacia: una cuenta sin posts
    // tiene el perfil con avatar, nombre y bio. Sin ninguno de esos, no hay
    // pagina de perfil que pueda estar vacia, y lo que se esta viendo es una
    // columna que no cargo.
    function degradado(probe) {
      if (probe.cargados > 0) return false;
      if (probe.challenge || probe.logged_out || !probe.titulo) return false;
      const hayPerfil =
        probe.perfilNombre || probe.perfilAvatar || probe.perfilBio;
      return !hayPerfil;
    }

    function health(probe, rows) {
      // El 429 va PRIMERO y por sobre todo: si X esta rate-limiteando, el
      // resultado viene con challenge:false, logged_out:false y cero articulos,
      // o sea indistinguible de una busqueda vacia si no se mira la red.
      if (http['429'] > 0) return 'throttled';
      if (probe.challenge) return 'blocked';
      if (probe.logged_out) return 'blocked';
      if (!rows.length) {
        // Sesion viva pero la columna no entrego nada: X esta degradando la
        // respuesta, no es que la consulta no tenga resultados.
        if (degradado(probe)) return 'degraded';
        // 0 articles + spinners = la carga nunca resolvio. NO es "no hay resultados".
        if (probe.cargando) return 'stalled';
        if (probe.articulos) return 'ok'; // hay articles pero el extractor no los vio
        // Sin titulo y sin articulos = la pantalla nunca se pinto. No se miro nada,
        // asi que no se puede decir que no haya resultados.
        if (!probe.titulo) return 'no_render';
        return 'empty';
      }
      return 'ok';
    }

    if (mode === 'multi') {
      const qs = pos.slice(1);
      if (!qs.length) throw new Error('faltan terminos de busqueda');
      if (qs.length > MAX_QUERIES) {
        console.error(`AVISO: ${qs.length} consultas > tope de ${MAX_QUERIES}; proceso las primeras ${MAX_QUERIES}.`);
      }
      out0.queries = [];
      for (const q of qs.slice(0, MAX_QUERIES)) {
        const hit = cacheRead(q);
        if (hit) {
          console.error('  cache: "' + q + '" reutilizado, sin tocar X');
          out0.queries.push({ q, url: hit.url, status: hit.status, results: hit.results, cached: true });
          continue;
        }
        if (out0.queries.length) {
          const w = MIN_PAUSE + Math.floor(Math.random() * (MAX_PAUSE - MIN_PAUSE));
          console.error('  anti-ban: pausa ' + (w / 1000).toFixed(1) + 's antes de "' + q + '"');
          await sleep(w);
        }
        const url = searchUrl(q);
        let probe;
        let rows;
        let rec;
        // La primera consulta del lote necesita goto (no hay nada cargado).
        // Despues se reutiliza el SPA.
        const primera = out0.queries.length === 0;
        for (const intento of [1, 2]) {
          ({ probe, rows } = await go(url, pages, intento === 1 ? 25000 : 40000, primera ? null : q));
          rec = { q, url, status: health(probe, rows), results: rows.slice(0, limit) };
          out0.session = out0.session || probe;
          if (rec.status !== 'stalled') break;
          if (intento === 1) {
            console.error('  stalled en "' + q + '", reintento con mas espera...');
            navigations++;
            await sleep(5000);
          }
        }
        if (rec.status === 'stalled') {
          console.error('  stalled persistente en "' + q + '": la carga de X no resuelve. Abandono.');
          out0.status = 'stalled';
          break;
        }
        out0.queries.push(rec);
        if (rec.status === 'ok') cacheWrite(q, rec);
        if (rec.status === 'blocked') {
          console.error('Bloqueado en "' + q + '", corto.');
          out0.status = 'blocked';
          break;
        }
        if (rec.status === 'throttled') {
          console.error('Throttleado (HTTP 429) en "' + q + '", corto.');
          out0.status = 'throttled';
          break;
        }
        if (rec.status === 'no_render') {
          console.error('La pagina no pinto en "' + q + '", corto.');
          out0.status = 'no_render';
          break;
        }
        // F-21: la sesion esta viva pero X no entrega contenido. Cortar YA: seguir
        // preguntando es gastar peticiones de una cuenta que ya esta castigada, y
        // cada respuesta vacia se.Reportaria como "no hay resultados".
        if (rec.status === 'degraded') {
          console.error('X devuelve la sesion sin contenido en "' + q + '", corto. Ver F-21.');
          out0.status = 'degraded';
          break;
        }
      }
      const seen = new Set();
      out0.results = out0.queries
        .flatMap((x) => x.results)
        .filter((r) => r.url && !seen.has(r.url) && seen.add(r.url));
      out0.query = out0.queries.map((q) => q.q).join(' | ');
      out0.cached = out0.queries.filter((q) => q.cached).length;
      // No pises un estado de falla con "empty": si X nos throttleo o la pagina
      // no pinto, hay que seguir diciendolo aunque alguna consulta haya dado datos.
      const FALLAS = ['blocked', 'throttled', 'stalled', 'no_render', 'degraded'];
      if (!FALLAS.includes(out0.status)) out0.status = out0.results.length ? 'ok' : 'empty';
    } else {
      let url;
      if (mode === 'search') {
        if (!arg) throw new Error('falta el termino de busqueda');
        url = searchUrl(arg);
      } else if (mode === 'user') {
        if (!arg) throw new Error('falta el handle');
        url = `https://x.com/${arg.replace(/^@/, '')}`;
      } else if (mode === 'tweet') {
        if (!arg) throw new Error('falta el id o la url');
        const id = String(arg).match(/status\/(\d+)/)?.[1] || String(arg);
        url = `https://x.com/i/status/${id}`;
      } else {
        throw new Error(`modo desconocido: ${mode}`);
      }
      out0.query = arg || null;
      out0.search_url = url;
      let probe;
      let rows;
      out0.status = 'empty';
      for (const intento of [1, 2]) {
        ({ probe, rows } = await go(url, pages, intento === 1 ? 25000 : 40000));
        out0.session = probe;
        out0.status = health(probe, rows);
        // Reintentar un throttle solo gasta cuota y empeora el bloqueo.
        if (out0.status !== 'stalled' || out0.status === 'throttled') break;
        if (intento === 1) {
          console.error('  stalled, reintento con mas espera...');
          navigations++;
          await sleep(5000);
        }
      }
      out0.results = rows.slice(0, limit);
    }

    out0.navigations = navigations;
    out0.spa_saltos = spaSaltos;
    // Estado de red de la corrida. Sirve para que un agente vea POR QUE
    // una consulta fallo, no solo que fallo.
    out0.red = http;

    const json = JSON.stringify(out0, null, 2);
    if (out) {
      fs.mkdirSync(path.dirname(path.resolve(out)), { recursive: true });
      fs.writeFileSync(out, json, 'utf8');
      console.error(`-> ${out}`);
    }
    console.log(json);
    if (out0.status === 'throttled') {
      console.error('\nstatus=throttled: X respondio HTTP 429 a la API. La cuenta esta rate-limited.');
      console.error('  NO es que no haya resultados. DEJA DE CORRER ESTE SCRAPER un rato (horas, no minutos).');
      console.error('  Reintentar ahora empeora el bloqueo. No abras Brave a mano para "desbloquear".');
      process.exitCode = 5;
    } else if (out0.status === 'blocked') {
      console.error('\nstatus=blocked: Cloudflare challenge o sesion cerrada. NO confies este corpus.');
      process.exitCode = 3;
    } else if (out0.status === 'no_render') {
      console.error('\nstatus=no_render: la pagina quedo en blanco (sin titulo, sin articulos).');
      console.error('  NO se llego a mirar nada. No concluyas que no hay resultados. Reintenta.');
      process.exitCode = 3;
    } else if (out0.status === 'stalled') {
      console.error('\nstatus=stalled: la columna de resultados de X nunca cargo (spinners eternos).');
      console.error('  NO es que no haya resultados. Reintenta mas tarde.');
      process.exitCode = 3;
    } else if (out0.status === 'degraded') {
      console.error('\nstatus=degraded: la sesion esta VIVA (pinta, estas logueado, cero errores HTTP)');
      console.error('  pero X no entrega contenido: ni articulos, ni pagina de perfil. Ver FAILURES.md F-21.');
      console.error('  NO es que no haya resultados. X esta degradando la respuesta en silencio,');
      console.error('  sin un 429 que lo delate. Deja de correr: cada consulta gasta mas cuota.');
      process.exitCode = 5;
    } else if (out0.status === 'empty') {
      console.error('\nstatus=empty: la pagina cargo y no hay resultados. Puede ser cuenta sin posts.');
      console.error('  (si esperabas resultados, mira session.profilNombre: en false probablemente');
      console.error('   sea degraded y no empty.)');
    }
  } catch (e) {
    console.error('FALLO: ' + String(e.message || e).split('\n')[0]);
    process.exitCode = 1;
  } finally {
    if (ctx) await ctx.close().catch(() => {});
  }
})();
