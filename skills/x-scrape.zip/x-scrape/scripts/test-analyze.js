#!/usr/bin/env node
// Tests de analyze.js contra el corpus REAL de la ronda 2026-10-03.
// Corre sin navegador: node test-analyze.js [ruta/corpus.json]
// Falla si el ranking reproduce los sesgos que documenta MEJORAS.md A1/A2.
const { execFileSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

// Tests contra las salidas REALES de scrape.js de la ronda 2026-10-03 (3 archivos).
// Fixtures PROPIOS de la skill, no rutas a una carpeta de research externa.
// Antes apuntaba a G:/Proyectos/x-research/ y el 2026-10-04 broke al mover esa
// carpeta a data/raw/: los tests dejaron de correr sin que nadie lo notara.
// Un test que depende de que alguien no mueva una carpeta no es un test.
// Override: node test-analyze.js <carpeta-con-los-raw>
const FIX = path.join(__dirname, 'fixtures');
const RONDA = process.argv[2] || FIX;
const INPUTS = ['raw-01.json', 'raw-top.json', 'raw-agents.json'].map((f) => RONDA + '/' + f);
const ANALYZE = path.join(__dirname, 'analyze.js');
const tmp = path.join(os.tmpdir(), 'analyze-test-' + process.pid + '.json');

let pass = 0;
let fail = 0;
function ok(cond, label, detail) {
  if (cond) {
    pass++;
    console.log('  PASA  ' + label);
  } else {
    fail++;
    console.log('  FALLA ' + label + (detail ? '  -> ' + detail : ''));
  }
}

const faltan = INPUTS.filter((f) => !fs.existsSync(f));
if (faltan.length) {
  console.error('faltan entradas de prueba:\n  ' + faltan.join('\n  '));
  process.exit(2);
}

function run(extra) {
  execFileSync('node', [ANALYZE].concat(INPUTS, ['--out', tmp]).concat(extra || []), {
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  return JSON.parse(fs.readFileSync(tmp, 'utf8'));
}

console.log('\n=== test-analyze ===');
console.log('entradas: ' + INPUTS.length + ' raw files de la ronda 2026-10-03\n');

// --- A1: el ranking premia repeticion; el fix no debe ---
console.log('[A1] ranking por autoridad');
{
  const auth = run(['--rank', 'authority']);
  const byDate = run(['--rank', 'date']);

  const idxAuth = auth.findIndex((r) => r.handle === 'tavus');
  const idxDate = byDate.findIndex((r) => r.handle === 'tavus');

  ok(idxAuth !== -1, 'el post de @tavus sigue en el corpus');
  ok(idxAuth < 5, '@tavus entra al top 5 por autoridad', 'quedo en ' + (idxAuth + 1));
  ok(idxAuth < idxDate, 'por autoridad @tavus sube respecto del orden por fecha',
     'auth=' + (idxAuth + 1) + ' date=' + (idxDate + 1));

  const sami = auth.findIndex((r) => r.handle === 'samiirr_0');
  ok(sami === -1 || sami > idxAuth, 'el promo @samiirr_0 queda por debajo de @tavus',
     'samiirr=' + (sami + 1) + ' tavus=' + (idxAuth + 1));

  const isCopy = auth.find((r) => r.handle === 'samiirr_0');
  ok(isCopy == null || typeof isCopy._rank === 'number', 'el rank por autoridad se emite');
}

// --- A2: el dedup exacto no encontraba copypasta; el difuso si ---
console.log('\n[A2] dedup difuso');
{
  const r = run([]);
  const code = r.find((x) => x.handle === 'codesthea');
  const axia = r.find((x) => x.handle === 'axiatechie');

  ok(!!code || !!axia, 'el par de copypasta esta en el corpus de entrada');
  const marcados = r.filter((x) => x.es_copypasta);
  ok(marcados.length >= 1, 'el dedup marca al menos 1 par', 'marcados=' + marcados.length);

  if (code && axia) {
    // uno de los dos debe haber sido marcado como duplicado del otro
    const unoMarcado = code.es_copypasta || axia.es_copypasta;
    ok(unoMarcado, 'code/axiatechie: al menos uno marcado es_copypasta');
  }
}

// --- B3: oficial ---
console.log('\n[B3] marca de cuenta oficial');
{
  const r = run([]);
  const tavus = r.find((x) => x.handle === 'tavus');
  const leigh = r.find((x) => x.handle === 'aran_leigh');
  ok(tavus && tavus.oficial === true, '@tavus queda marcado oficial');
  ok(!leigh || leigh.oficial === false, '@aran_leigh NO queda marcado oficial');
}

// --- higiene: no perder filas ni duplicar URLs ---
console.log('\n[estructura]');
{
  const r = run([]);
  ok(r.length > 0, 'el corpus de salida no esta vacio');
  const urls = r.map((x) => x.url);
  ok(new Set(urls).size === urls.length, 'no hay URLs repetidas');
  ok(!r.some((x) => x._shingles), 'los shingles internos se limpian antes de guardar');
  ok(r.every((x) => 'es_copypasta' in x), 'todos los items llevan es_copypasta');
}

fs.unlinkSync(tmp);
console.log('\n=== ' + pass + ' pasaron, ' + fail + ' fallaron ===');
process.exit(fail ? 1 : 0);
