#!/usr/bin/env node
// Informe de validación DESPUÉS de cada adquisición.
//
//   node validate.js data\corpus\*.json            # informe, sin escribir baseline
//   node validate.js data\corpus\*.json --baseline # actualiza el baseline
//   node validate.js raw-10.json --raw             # valida un volcado crudo
//
// POR QUÉ EXISTE. La hipótesis abierta del README desde la ronda 2: "falta un
// filtro de calidad". Y hay algo más grave detrás: un scraper que sale con
// código 0 puede llevar tres semanas produciendo datasets incompletos sin que
// nadie lo note. El exit code dice que el script no crasheó, nada más.
//
// Lo que mira, y por qué cada chequeo:
//  - NULL RATES: si `text` pasa de 7% a 60%, el DOM cambió. No es que " bajaron
//    los resultados": es que el extractor ya no encuentra el campo.
//  - SCHEMA DRIFT: campos que aparecen o desaparecen entre corridas.
//  - DUPLICATE INFLATION: si de 100 items pasan a ser 60 únicos, el dedup se
//    rompió o X está sirviendo el mismo contenido.
//  - COUNT ANOMALY: una ronda que trae 3 items donde las otras traen 25.
//  - AUTOR CONCENTRATION: si un handle representa el 20%, no es fuente.
//
// TODO OFFLINE: lee JSON, no toca red ni navegador. Cuesta milisegundos y por
// eso se puede correr en cada adquisición.
const fs = require('fs');
const path = require('path');

const flags = {};
const pos = [];
for (let i = 2; i < process.argv.length; i++) {
  const a = process.argv[i];
  if (a.startsWith('--')) {
    const n = a.slice(2);
    if (n === 'baseline') flags.baseline = true;
    else if (n === 'raw') flags.raw = true;
    else if (n === 'json') flags.json = true;
    else if (n === 'min-null') flags.minNull = process.argv[++i];
    else flags[n] = true;
  } else pos.push(a);
}
const BASE = process.env.X_VALIDATE_BASELINE || path.join(__dirname, 'fixtures', 'validate-baseline.json');

// ---------- carga ----------
const items = [];
const errores = [];
for (const p of pos) {
  if (!fs.existsSync(p)) { errores.push(`no existe: ${p}`); continue; }
  let j;
  try { j = JSON.parse(fs.readFileSync(p, 'utf8')); } catch (e) {
    errores.push(`no se pudo leer ${p}: ${String(e).slice(0, 60)}`); continue;
  }
  // Acepta las tres formas que produce el scraper.
  if (Array.isArray(j)) items.push(...j);
  else if (Array.isArray(j.results)) items.push(...j.results);
  else if (Array.isArray(j.queries)) {
    for (const q of j.queries) if (Array.isArray(q.results)) items.push(...q.results);
  } else if (j.results) items.push(j.results);
  else errores.push(`forma desconocida: ${p}`);
}
const N = items.length;

// ---------- perfil de nulabilidad ----------
const CAMPOS = ['user', 'handle', 'when', 'text', 'url'];
const perfil = {};
for (const c of CAMPOS) {
  const vacios = items.filter((it) => it[c] === null || it[c] === undefined || String(it[c]).trim() === '').length;
  perfil[c] = N ? Math.round((vacios / N) * 1000) / 10 : 0;  // % con un decimal
}
const claves = new Set();
for (const it of items) for (const k of Object.keys(it || {})) claves.add(k);

// ---------- duplicados ----------
const porUrl = new Map();
const porTexto = new Map();
for (const it of items) {
  const u = (it.url || '').trim();
  if (u) porUrl.set(u, (porUrl.get(u) || 0) + 1);
  const t = (it.text || '').replace(/\s+/g, ' ').trim();
  if (t) porTexto.set(t, (porTexto.get(t) || 0) + 1);
}
const dupUrl = items.length - porUrl.size;   // sobre TODOS los items, no solo los que traen url
const unicos = porUrl.size || porTexto.size;

// ---------- autores ----------
const autores = new Map();
for (const it of items) {
  const h = (it.handle || '?').toLowerCase();
  autores.set(h, (autores.get(h) || 0) + 1);
}
const topAutores = [...autores.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);

// ---------- hallazgos ----------
// Umbral: 2x la tasa del baseline, o 30% si no hay baseline.
const minNull = flags.minNull ? Number(flags.minNull) : null;
const hallazgos = [];
let base = null;
try { base = JSON.parse(fs.readFileSync(BASE, 'utf8')); } catch {}

const umbralNull = (campo) => {
  if (minNull) return minNull;
  if (base && base.perfil && typeof base.perfil[campo] === 'number') return Math.min(95, Math.max(30, base.perfil[campo] * 2));
  return 30;
};

for (const c of CAMPOS) {
  const p = perfil[c];
  if (p === 0) continue;   // un campo siempre presente es lo esperado
  if (p >= umbralNull(c)) {
    hallazgos.push({
      nivel: 'ALTO',
      tipo: 'null-rate',
      que: `\`${c}\` viene ${p}% vacío (umbral ${umbralNull(c)}%)`,
      por_que: 'Probablemente el DOM cambió y el extractor ya no encuentra el campo. NO es que "hubo menos resultados".',
      accion: 'Correr `validate.js <archivo> --raw` sobre un volcado nuevo y comparar `campos_por_item`. Si `text` aparece vacío en todos, el selector esta roto.',
    });
  }
}

// Schema drift contra el baseline
if (base && base.campos) {
  const antes = new Set(base.campos);
  const nuevos = [...claves].filter((k) => !antes.has(k));
  const idos = [...antes].filter((k) => !claves.has(k));
  if (nuevos.length) hallazgos.push({ nivel: 'INFO', tipo: 'schema-nuevo', que: `campos nuevos: ${nuevos.join(', ')}`, por_que: 'El extractor cambio o X agrego datos al DOM.', accion: 'Confirmar que es intentional.' });
  if (idos.length) hallazgos.push({ nivel: 'ALTO', tipo: 'schema-perdido', que: `campos que desaparecieron: ${idos.join(', ')}`, por_que: 'El extractor se rompio o cambio el contrato.', accion: 'Revisar EXTRACT en scrape.js.' });
}

// Duplicados. MEDIDO 2026-10-05: el umbral de 40% era tan alto que un corpus
// con medio dataset repetido pasaba limpio. Y peor: se contaban solo los items
// CON url, asi que si el extractor falla (url=null en todos) daria 0 duplicados
// y el informe diria "OK". Ese es el falso negativo que este script viene a
// cazar: decir "todo bien" porque no se miró el campo.
//
// Se mide sobre TODOS los items, y ademas el maximo de repeticiones de una
// misma URL: un item repetido 30 veces es un selector que matchea de mas;
// dos URLs repetidas dos veces es overlap normal de `multi`.
const sinUrl = items.filter((it) => !String(it.url || '').trim()).length;
const maxRep = porUrl.size ? Math.max(...porUrl.values()) : 0;
const pctDup = N ? Math.round((dupUrl / N) * 1000) / 10 : 0;
if (pctDup >= 25 || maxRep >= 5) {
  hallazgos.push({
    nivel: 'ALTO', tipo: 'duplicados',
    que: `${dupUrl} de ${N} items comparten URL (${pctDup}%), la mas repetida aparece ${maxRep} veces`,
    por_que: 'O X esta sirviendo lo mismo varias veces, o el extractor fallo y todo cae al mismo lado.',
    accion: maxRep >= 5
      ? 'Un item repetido ' + maxRep + ' veces casi siempre es un selector que matchea de mas: revisar EXTRACT.'
      : 'Mirar si las queries de `multi` se solapan en resultados.',
  });
}
if (N && sinUrl / N > 0.5) {
  hallazgos.push({
    nivel: 'ALTO', tipo: 'sin-url',
    que: `${sinUrl} de ${N} items sin URL`,
    por_que: 'Sin URL no se puede deduplicar ni verificar. Si el scraper afirma que estos items existen pero no deja de donde, el corpus no es auditable.',
    accion: 'Revisar en EXTRACT el selector del link al status (/status/ en el href).',
  });
}

// Conteo anormal
if (base && typeof base.items === 'number' && base.items > 0) {
  const ratio = N / base.items;
  if (ratio < 0.35 || ratio > 3) {
    hallazgos.push({
      nivel: 'MEDIO', tipo: 'conteo',
      que: `${N} items contra ${base.items} del baseline (${Math.round(ratio * 100)}%)`,
      por_que: 'Un salto de 3x o una caida a menos de un tercio suele ser throttling o cambio de DOM, no "el tema tiene menos contenido".',
      accion: 'Mirar `status` y `red` del volcado antes de concluir algo del tema.',
    });
  }
}

// Concentracion de autor
for (const [h, c] of topAutores) {
  const p = N ? (c / N) * 100 : 0;
  if (p >= 15 && c >= 3) {
    hallazgos.push({
      nivel: 'MEDIO', tipo: 'autor',
      que: `@${h} representa el ${Math.round(p)}% del corpus (${c} posts)`,
      por_que: 'Un autor repetido no es fuente: es curation, y arrastra su sesgo a todo el documento.',
      accion: 'Buscar la fuente primaria del dato, como se hizo con los repos de las rondas 4 a 7.',
    });
  }
}

// Textos vacios: distinguir copypasta de drift
const sinTexto = items.filter((it) => !String(it.text || '').trim()).length;
if (sinTexto) {
  hallazgos.push({
    nivel: 'INFO', tipo: 'sin-texto',
    que: `${sinTexto} items sin texto`,
    por_que: 'Puede ser un post solo-imagen, o el extractor fallo. Con pocos items es ruido; con muchos, es drift.',
    accion: 'Si supera el 15%, suspectar drift antes que contenido sin texto.',
  });
}

// ---------- salida ----------
const informe = {
  validado_at: new Date().toISOString(),
  archivos: pos,
  items: N,
  campos_por_item: [...claves].sort(),
  perfil_nulos_pct: perfil,
  duplicados_por_url: dupUrl,
  pct_duplicados: pctDup,
  unicos,
  autores_unicos: autores.size,
  top_autores: topAutores.map(([h, c]) => ({ handle: h, n: c })),
  hallazgos: hallazgos,
  veredicto: hallazgos.some((h) => h.nivel === 'ALTO') ? 'SOSPECHOSO' : hallazgos.length ? 'OK_CON_RESERVAS' : 'OK',
};

if (flags.json) {
  console.log(JSON.stringify(informe, null, 2));
} else {
  console.log('\n=== informe de validacion ===\n');
  console.log(`items: ${N}   unicos: ${unicos}   autores: ${autores.size}`);
  console.log(`duplicados por URL: ${dupUrl} (${pctDup}%)`);
  console.log('\nperfil de nulos:');
  for (const [c, p] of Object.entries(perfil)) {
    const barra = '#'.repeat(Math.round(p / 5)).padEnd(20, '.');
    console.log(`  ${c.padEnd(8)} ${String(p).padStart(5)}%  ${barra}`);
  }
  console.log('\ntop autores: ' + topAutores.map(([h, c]) => `@${h}:${c}`).join('  '));
  console.log('\n--- hallazgos ---');
  if (!hallazgos.length) console.log('  ninguno');
  for (const h of hallazgos) {
    console.log(`\n  [${h.nivel}] ${h.que}`);
    console.log(`     por que: ${h.por_que}`);
    console.log(`     accion:  ${h.accion}`);
  }
  console.log(`\nveredicto: ${informe.veredicto}`);
  console.log(informe.veredicto === 'OK'
    ? '\nEl exit code 0 y esto de acuerdo: se miró y se extrajo.'
    : '\nOJO: el exit code puede ser 0 y el dataset estar incompleto. Eso es justo lo que este informe existe para detectar.');
}

if (flags.baseline) {
  fs.mkdirSync(path.dirname(BASE), { recursive: true });
  fs.writeFileSync(BASE, JSON.stringify({ items: N, campos: informe.campos_por_item, perfil: perfil, saved_at: informe.validado_at }, null, 2));
  console.error(`\nbaseline actualizado: ${BASE}`);
}
if (errores.length) {
  console.error('\narchivos con problema:');
  for (const e of errores) console.error('  ' + e);
  process.exitCode = 1;
}
