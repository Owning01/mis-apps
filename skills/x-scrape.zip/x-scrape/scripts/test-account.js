#!/usr/bin/env node
// Tests de account.js SIN navegador ni red, para los caminos que se deciden
// ANTES de abrir Brave.
//
// Por que existe: account.js es el unico script que ESCRIBE en la cuenta. Los
// otros tests cubren scrape.js (lee) y analyze.js (calcula). Este cubre el
// contrato de la escritura, que es donde un bug cuesta caro.
//
// Que se testea aca, y por que NO necesita red:
//  - la guarda de `--yes`: sin el, no se escribe NADA. Es lo mas importante.
//  - el limite de caracteres de X (nombre 50, bio 160, post 280).
//  - que un error de entorno no se reporte como exito.
//  - `degraded` de scrape.js: la funcion que decide si "vacio" es mentira.
//    Se prueba por extraccion de fuente, porque vive dentro del IIFE.
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const S = path.join(__dirname, 'account.js');
const SCRAPE = path.join(__dirname, 'scrape.js');
let pass = 0;
let fail = 0;
function check(cond, label, detail) {
  if (cond) { pass++; console.log('  PASA  ' + label); }
  else { fail++; console.log('  FALLA ' + label + (detail ? '  -> ' + detail : '')); }
}
function run(script, args, env) {
  try {
    const out = execFileSync('node', [script].concat(args || []), {
      encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'],
      env: Object.assign({}, process.env, env || {}),
      timeout: 60000,
    });
    return { code: 0, out };
  } catch (e) {
    return { code: e.status === undefined ? -1 : e.status, out: (e.stdout || '') + (e.stderr || '') };
  }
}
// Brave inexistente: asi ningun test abre un navegador de verdad, pero el
// script igual recorre el parseo de argumentos y las guardas.
const SIN_BRAVE = { BRAVE_PATH: 'C:\\no\\existe\\brave.exe' };

console.log('\n=== test-account.js (sin red, sin navegador) ===\n');

// 1) La guarda de --yes. Es lo mas importante del script.
console.log('[guarda de --yes: escribir sin permiso]');
{
  const casos = [
    ['post', 'hola'],
    ['profile', '--bio', 'x'],
    ['avatar', 'C:\\no\\existe.png'],
  ];
  for (const args of casos) {
    const r = run(S, args.concat(['--yes']).slice(0, -1), SIN_BRAVE); // SIN --yes a proposito
    check(r.code === 6, args[0] + ' sin --yes sale con codigo 6', 'code=' + r.code);
    check(/--yes/i.test(r.out), args[0] + ' sin --yes explica que falta --yes', r.out.slice(0, 120));
    check(/no se toco nada|no se toc[oó] nada/i.test(r.out),
      args[0] + ' sin --yes dice que no toco nada', r.out.slice(0, 160));
  }
}

// 2) Sin ningun modo: uso, codigo 2.
console.log('\n[sin argumentos]');
{
  const r = run(S, [], SIN_BRAVE);
  check(r.code === 2, 'sin modo sale con codigo 2', 'code=' + r.code);
  check(/whoami/.test(r.out), 'el uso lista whoami', r.out.slice(0, 120));
}

// 3) Modo desconocido: falla limpio, sin ReferenceError/TypeError.
console.log('\n[modo invalido]');
{
  const r = run(S, ['modoinventado', 'x'], SIN_BRAVE);
  const crash = /ReferenceError|TypeError|SyntaxError/.test(r.out);
  check(!crash, 'no crashea con modo desconocido', (r.out.match(/(Reference|Type|Syntax)Error.*/) || [''])[0]);
  check(r.code === 2, 'modo desconocido sale con codigo 2', 'code=' + r.code);
}

// 4) Limites de caracteres de X. Chequear ANTES evita que el editor rechace el
//    guardado y el script reporte un exito que no ocurrio.
console.log('\n[limites de caracteres]');
{
  const bioLarga = 'a'.repeat(161);
  const r1 = run(S, ['profile', '--bio', bioLarga, '--yes'], SIN_BRAVE);
  check(r1.code === 2, 'bio de 161 caracteres se rechaza (limite 160)', 'code=' + r1.code);
  check(/160/.test(r1.out), 'el error de bio dice el limite 160', r1.out.slice(0, 140));

  const nombreLargo = 'a'.repeat(51);
  const r2 = run(S, ['profile', '--name', nombreLargo, '--yes'], SIN_BRAVE);
  check(r2.code === 2, 'nombre de 51 caracteres se rechaza (limite 50)', 'code=' + r2.code);

  const postLargo = 'a'.repeat(281);
  const r3 = run(S, ['post', postLargo, '--yes'], SIN_BRAVE);
  // El limite de post se chequea DESPUES de abrir el navegador (no antes), asi
  // que con Brave inexistente el error visible es el de entorno. Lo que importa
  // es que no se reporte exito.
  check(r3.code !== 0, 'post de 281 caracteres no reporta exito', 'code=' + r3.code);
}

// 5) Argumentos faltantes: no debe crashear.
console.log('\n[argumentos faltantes]');
{
  const r1 = run(S, ['post', '--yes'], SIN_BRAVE);
  check(!/ReferenceError|TypeError/.test(r1.out), 'post sin texto no crashea', r1.out.slice(0, 120));
  const r2 = run(S, ['avatar', '--yes'], SIN_BRAVE);
  check(!/ReferenceError|TypeError/.test(r2.out), 'avatar sin ruta no crashea', r2.out.slice(0, 120));
  const r3 = run(S, ['avatar', 'C:\\ruta\\que\\no\\existe.png', '--yes'], SIN_BRAVE);
  check(/no existe/i.test(r3.out), 'avatar con archivo inexistente avisa', r3.out.slice(0, 140));
}

// 6) account.js debe seguir la regla de F-10: nunca process.exit() con stdout
//    en pipe. Se verifica por fuente, que es como se cumplio la regla.
console.log('\n[reglas de codigo que ya costaron una falla]');
{
  const src = fs.readFileSync(S, 'utf8');
  // Nota: `process.exit(` con argumentos NO cuenta. `process.exitCode = n` es lo
  // correcto y esta en todos lados. Lo que prohibe F-10 es `process.exit()` a
  // secas, que descarta escrituras pendientes cuando stdout es un pipe.
  check(!/process\.exit\s*\(\s*\)/.test(src),
    'account.js no usa process.exit() a secas (F-10: trunca stdout en pipe)',
    (src.match(/.*process\.exit\s*\(\s*\).*/) || [''])[0].trim());
  check(!/process\.exit\s*\(\s*[^)\s]/.test(src),
    'account.js no usa process.exit(valor) (F-10)',
    (src.match(/.*process\.exit\s*\(\s*[^)\s].*/) || [''])[0].trim());
  check(/process\.exitCode/.test(src), 'account.js usa process.exitCode');
  // F-25: reportar verificado:true con la sesion sana pero sin cambio real. Es
  // el F-1/F-12 en el camino de EXITO, y por eso tiene que estar en un test.
  check(/no_verificado/.test(src),
    'account.js tiene el estado no_verificado (F-25: exito sin ver el efecto)');
  check(!/res\.verificado = res\.status === 'ok'/.test(src),
    'verificado NO se deriva solo del estado de sesion');
  // El JSON tiene que emitirse en el finally: hay ~8 salidas tempranas y en la
  // primera version de este script ninguna escribia nada (F-18).
  check(/finally\s*\{[^}]*emit\(\)/s.test(src) || /\}\s*finally\s*\{\s*emit\(\)/s.test(src),
    'account.js emite el JSON en un finally (F-18: si no, las salidas tempranas no escriben nada)');
}

// 7) La funcion degradado() de scrape.js: decide si "vacio" es mentira (F-21).
//    Vive dentro del IIFE, asi que se prueba extrayendo la fuente y evaluando
//    la funcion contra los casos medidos.
console.log('\n[degraded: distinguir vacio real de respuesta degradada (F-21)]');
{
  const src = fs.readFileSync(SCRAPE, 'utf8');
  const m = src.match(/function degradado\(probe\)\s*\{[\s\S]*?\n    \}/);
  check(!!m, 'la funcion degradado() existe en scrape.js');
  if (m) {
    const degradado = eval('(' + m[0].replace(/^\s*function degradado/, 'function') + ')');
    // Caso medido 2026-10-04: sesion viva, cero articulos, cero errores HTTP.
    const vivo = { cargados: 0, challenge: false, logged_out: false, titulo: 'Home / X',
      perfilNombre: false, perfilAvatar: false, perfilBio: false };
    check(degradado(vivo) === true, 'sesion viva sin contenido => degradado (no empty)');
    // Una cuenta sin posts es un caso legitimo de vacio: el perfil EXISTE.
    const sinPosts = { cargados: 0, challenge: false, logged_out: false, titulo: 'Gbro (@x) / X',
      perfilNombre: true, perfilAvatar: true, perfilBio: true };
    check(degradado(sinPosts) === false, 'cuenta sin posts con perfil visible => NO degradado');
    // Si hay articulos, nunca es degradado.
    const conPosts = { cargados: 7, challenge: false, logged_out: false, titulo: 'x',
      perfilNombre: false, perfilAvatar: false, perfilBio: false };
    check(degradado(conPosts) === false, 'con articulos nunca es degradado');
    // Challenge o sesion cerrada tienen su propio estado: no mezclarlos.
    const challenge = { cargados: 0, challenge: true, logged_out: false, titulo: 'Just a moment',
      perfilNombre: false, perfilAvatar: false, perfilBio: false };
    check(degradado(challenge) === false, 'con challenge NO es degradado (ese es blocked)');
  }
}

// 8) Los 7 estados deben estar todos en la documentacion de la skill, o el
//    proximo agente va a tratar `degraded` como `empty`.
console.log('\n[documentacion de los estados]');
{
  const doc = fs.readFileSync(path.join(__dirname, '..', 'SKILL.md'), 'utf8');
  for (const st of ['ok', 'empty', 'no_render', 'stalled', 'blocked', 'throttled', 'degraded']) {
    check(new RegExp('`' + st + '`').test(doc), 'SKILL.md documenta el estado ' + st);
  }
}


// 4) validate.js: el informe tiene que DETECTAR lo que dice detectar.
console.log('\n[validate.js: detecta drift, no lo ignora]');
{
  const tmp = path.join(require('os').tmpdir(), 'xscrape-val-' + Date.now());
  fs.mkdirSync(tmp, { recursive: true });
  // Sin baseline: si no, el veredicto depende del ultimo --baseline que se corrio.
  process.env.X_VALIDATE_BASELINE = path.join(tmp, 'sin-baseline.json');
  const items = [];
  for (let i = 0; i < 40; i++) {
    items.push({ user: 'U' + i, handle: 'h' + i, when: '2026-01-01', text: 'texto ' + i, url: 'https://x.com/h' + i + '/status/' + i });
  }
  // Romperlo a proposito: la mitad sin texto, un autor monopolizando, duplicados.
  // MEDIDO 2026-10-05: la primera version hacia 1 duplicado sobre 41 items (2.4%),
  // muy por debajo de cualquier umbral, asi que el test NUNCA ejercitaba el
  // detector de duplicados. Un test que no puede fallar no prueba nada: el caso
  // tiene que cruzar el umbral. Un solo item repetido 8 veces lo hace (maxRep=8).
  for (let i = 0; i < 25; i++) items[i].text = null;
  for (let i = 0; i < 20; i++) items[i].handle = 'spam';
  for (let i = 30; i < 38; i++) items[i].url = items[29].url;
  const bad = path.join(tmp, 'malo.json');
  fs.writeFileSync(bad, JSON.stringify(items), 'utf8');

  const r = run(path.join(__dirname, 'validate.js'), [bad, '--raw', '--json']);
  check(r.code === 0, 'validate.js sale con codigo 0', 'code=' + r.code);
  let inf = null;
  try { inf = JSON.parse(r.out.slice(r.out.indexOf('{'))); } catch {}
  check(!!inf, 'validate.js emite JSON parseable');
  if (inf) {
    check(inf.veredicto === 'SOSPECHOSO', 'detecta null-rate + duplicados => SOSPECHOSO', inf.veredicto);
    const tipos = inf.hallazgos.map((h) => h.tipo);
    check(tipos.includes('null-rate'), 'detecta null-rate', tipos.join(','));
    check(tipos.includes('duplicados'), 'detecta duplicados', tipos.join(','));
    check(tipos.includes('autor'), 'detecta concentracion de autor', tipos.join(','));
    check(inf.perfil_nulos_pct.text > 50, 'el perfil de nulos mide el ratio real', String(inf.perfil_nulos_pct.text));
    // Cada hallazgo tiene que decir QUE y POR QUE, no solo que algo anda mal.
    check(inf.hallazgos.every((h) => h.que && h.por_que && h.accion),
      'cada hallazgo dice que, por que y que hacer');
  }

  // Un corpus limpio NO debe dar falsos positivos.
  const ok = [];
  for (let i = 0; i < 40; i++) ok.push({ user: 'U' + i, handle: 'h' + i, when: '2026-01-01', text: 't' + i, url: 'https://x.com/h' + i + '/status/' + i });
  const good = path.join(tmp, 'limpio.json');
  fs.writeFileSync(good, JSON.stringify(ok), 'utf8');
  const r2 = run(path.join(__dirname, 'validate.js'), [good, '--raw', '--json']);
  let inf2 = null;
  try { inf2 = JSON.parse(r2.out.slice(r2.out.indexOf('{'))); } catch {}
  check(inf2 && inf2.veredicto === 'OK', 'un corpus limpio da OK, no SOSPECHOSO', inf2 && inf2.veredicto);

  const vacio = path.join(tmp, 'vacio.json');
  fs.writeFileSync(vacio, '[]', 'utf8');
  const r3 = run(path.join(__dirname, 'validate.js'), [vacio, '--raw']);
  check(!/TypeError|ReferenceError/.test(r3.out), 'no crashea con array vacio', (r3.out.match(/(Type|Reference)Error.*/) || [''])[0]);
  const roto = path.join(tmp, 'roto.json');
  fs.writeFileSync(roto, '{no es json', 'utf8');
  const r4 = run(path.join(__dirname, 'validate.js'), [roto, '--raw']);
  check(r4.code === 1, 'avisa y sale con 1 si un archivo no se puede leer', 'code=' + r4.code);
  fs.rmSync(tmp, { recursive: true, force: true });
}

// 5) validate.js no debe medir engagement: el extractor NO lo captura.
console.log('\n[validate.js: no promete lo que no mide]');
{
  const src = fs.readFileSync(path.join(__dirname, 'validate.js'), 'utf8');
  // Si alguna vez agrega chequeos de likes/views, este test falla a proposito.
  // ElExtractor saca 5 campos y ninguno es de engagement: armar un chequeo
  // sobre datos que no existen daria un falso "todo bien".
  check(!/likes|retweets|favorite_count|view_count/.test(src),
    'validate.js no chequea engagement: el extractor no lo captura');
}

console.log('\n=== ' + pass + ' pasaron, ' + fail + ' fallaron ===');
process.exit(fail ? 1 : 0);
