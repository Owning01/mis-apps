#!/usr/bin/env node
// Humo de scrape.js SIN navegador ni red.
//
// Existe por un motivo concreto: `node --check` valida SINTAXIS, no orden de
// ejecucion. Dos veces puse un `const` usandolo antes de declararlo (TDZ) y
// --check lo aprueba; solo revienta al correr de verdad. Este test corre el
// script de verdad, con entradas que salen antes de tocar la red.
const { execFileSync } = require('child_process');
const path = require('path');

const S = path.join(__dirname, 'scrape.js');
let pass = 0;
let fail = 0;
function check(cond, label, detail) {
  if (cond) { pass++; console.log('  PASA  ' + label); }
  else { fail++; console.log('  FALLA ' + label + (detail ? '  -> ' + detail : '')); }
}
function run(args, env) {
  try {
    const out = execFileSync('node', [S].concat(args || []), {
      encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'],
      env: Object.assign({}, process.env, env || {}),
      timeout: 180000,
    });
    return { code: 0, out };
  } catch (e) {
    return { code: e.status === undefined ? -1 : e.status, out: (e.stdout || '') + (e.stderr || '') };
  }
}

console.log('\n=== test-smoke scrape.js (sin red) ===\n');

// 1) TDZ: el clasico. Si alguien usa flags/pos antes de declararlos, esto revienta.
console.log('[orden de declaracion]');
{
  const r = run([]);
  const refErr = /Cannot access '.*' before initialization/.test(r.out);
  check(!refErr, 'sin ReferenceError de TDZ', (r.out.match(/ReferenceError.*/) || [''])[0]);
  check(r.code === 2, 'sin argumentos sale con codigo 2 (uso)', 'code=' + r.code);
}

// 2) modo desconocido: debe fallar limpio, no crashear
console.log('\n[modo invalido]');
{
  const r = run(['modoinventado', 'x']);
  const crash = /ReferenceError|TypeError|SyntaxError/.test(r.out);
  check(!crash, 'no crashea con modo desconocido', (r.out.match(/(Reference|Type|Syntax)Error.*/) || [''])[0]);
}

// 3) Brave inexistente: mensaje util y codigo 2
console.log('\n[brave inexistente]');
{
  const r = run(['search', 'x'], { BRAVE_PATH: 'C:\\no\\existe\\brave.exe' });
  check(/no encontrado/i.test(r.out), 'avisa que no encuentra Brave');
  check(r.code === 2, 'sale con codigo 2', 'code=' + r.code);
}

// 4) --gpu-check debe correr el bloque y no caer al mensaje de uso.
//    Lanza Brave de verdad: por eso el timeout es generoso.
console.log('\n[--gpu-check]');
{
  const r = run(['--gpu-check']);
  check(!/^uso:/m.test(r.out), 'el bloque --gpu-check se ejecuta (no cae al mensaje de uso)');
  // Si Brave esta abierto a mano no se puede tomar el lock del perfil y el
  // navegador muere antes de arrancar. NO es un fallo del script: es la trampa
  // documentada. Distinguirlo evita perseguir un bug que no existe.
  const lock = /Target page, context or browser has been closed|ProcessSingleton/i.test(r.out);
  if (lock) {
    console.log('  AVISO  Brave abierto a mano: la GPU no se puede verificar. Cerralo y volve a correr.');
  }
  // Si el renderer vuelve enmascarado como "Brave", el chequeo no puede
  // afirmar nada y debe decirlo con codigo 3 (FAILURES.md F-11).
  const enmascarado = /^renderer: Brave\s*$/m.test(r.out);
  check(!enmascarado, 'el renderer NO viene enmascarado por Shields', r.out.slice(0, 160));
  check(/^renderer: /m.test(r.out) || lock,
    'imprime una linea renderer (o el lock de Brave impide verificarlo)', r.out.slice(0, 160));
  check(r.code === 0 || r.code === 4 || r.code === 3,
    'sale con un codigo propio (0 GPU / 4 software / 3 no verificable)', 'code=' + r.code);
}

// 5) el parseo de flags no se rompe: --limit debe ser numerico
console.log('\n[parseo de flags]');
{
  const r = run(['search', 'x', '--limit', 'abc'], { BRAVE_PATH: 'C:\\no\\existe\\brave.exe' });
  const nan = /limit: NaN|"limit": null/.test(r.out);
  check(!nan, '--limit abc no produce NaN ni null');
}

console.log('\n=== ' + pass + ' pasaron, ' + fail + ' fallaron ===');
process.exit(fail ? 1 : 0);
