---
name: x-scrape
description: >-
  Lee y busca contenido de Twitter/X automatizando Brave con Playwright, reusando la sesión
  real que ya está iniciada en el perfil del usuario (sin pedirle credenciales ni exports).
  Úsala SIEMPRE que el usuario pida scrapear, buscar o extraer algo de X/Twitter: "scrapear X",
  "scrappear X", "buscar en X", "qué dicen en X sobre X", "qué se está hablando de X",
  "posts de X", "tweets", "opiniones en twitter", "X.com", "trends de X". También para leer
  el timeline o los posts de una cuenta, o un tweet puntual por URL o ID.
  NO usar agent-reach para esto (su backend de Twitter tiene la búsqueda caída con HTTP 404);
  no inventar Scrapy ni curl contra x.com: ahí no hay sesión y Cloudflare bloquea.
---

# X / Twitter — scraping con el perfil real de Brave

Automatiza **Brave** con Playwright contra el perfil del usuario. La sesión de X ya está
iniciada ahí, así que **no se piden credenciales, no se exportan cookies y no se toca nada**.

## Si encontrás una falla, documentala

`scripts/` depende de un tercero que cambia sin avisar. **Si algo no funciona, no lo resuelvas en
silencio.** Agregá la entrada a [FAILURES.md](FAILURES.md) con el formato de esa página
(sintoma · contexto · causa · workaround · cuándo se arregló).

Reglas:

- **`estado: abierto`** por defecto. Solo `arreglado` si lo **verificaste de nuevo** con el
  comando que lo disparaba.
- **Distinguí bug mío de cambio de la plataforma** en el campo *Causa*. Si X cambió el DOM o una
  query desaparece, decilo: el fix es distinto.
- Si solo encontraste un rodeo, es `estado: workaround`.
- No borres entradas viejas. Es bitácora append-only: el historial dice qué se rompió y cuándo.

Ya hay **31 fallas registradas** (F-1 a F-31), **catorce** de las cuales son de este scraper
**mintiendo**:

| Falla | Qué reportaba en vez de decir la verdad |
|---|---|
| F-1 | `empty` cuando X se había colgado cargando |
| F-12 | `empty` cuando la cuenta estaba rate-limited con 429 |
| F-18 | **nada**: salía con código 3 y stdout vacío |
| F-20 | `no_render` cuando la página simplemente no había terminado de cargar |
| F-21 | `empty` cuando X degradaba la respuesta en silencio |
| F-23 | `no_render` cuando la cuenta ya estaba throttled |
| F-24 | código 2 (entorno) cuando en realidad faltaba `--yes` (permiso) |
| F-25 | `verificado: true` sin verificar el efecto: la sesión estaba sana y el trabajo sin hacer |
| F-26 | avatar "subido" cuando la imagen había ido al banner |
| F-27 | avatar no subido por un overlay que se creaba un diálogo llamado "Edit media" |
| F-28 | `post` "publicado" con la página redirigida a otro lado |
| F-29 | "no se encontró el campo de texto" esperando 3 s a algo que tarda 12 |
| F-30 | `no_verificado` sobre un post publicado, porque X no cambia la URL |
| F-31 | `no_verificado` sin decir por qué: un guarda era falso para todo el modo `post` |

Leelas antes de debuggear de cero. **El patrón se repite y es una sola cosa:** casi ninguna falla era
de lógica de extracción, eran de *reporte*. El script sabía o no sabía; lo que fallaba era decirlo.

Y el subpatrón de las últimas (F-25, F-31): **"no falló" se está convirtiendo en "funcionó".** Un
overlay, un `force: true`, un click que no tira excepción. Nada de eso es un efecto observado. Por
eso existe `no_verificado`, y por eso el `nota` dice **qué** se comparó y qué se encontró.

## Regla de oro

**Nunca pidas ni uses tokens de X.** No hace falta: el navegador abre con la sesión puesta.

Si te piden scrapear X, el camino correcto es este. `agent-reach` **no** sirve para X: su backend
(`twitter-cli`) tiene la búsqueda rota con HTTP 404 y su guía de cookies quedó obsoleta.

## Pipeline

```
scrape.js   →   raw.json   →   analyze.js   →   corpus.json
 (extrae)      (crudo)       (dedup + rank)   (para analizar)
```

Son dos etapas a propósito: **la etapa de análisis se testea sin navegador**, en segundos,
contra un JSON guardado. Cambiar el ranking o el dedup no requiere lanzar Brave.

## Cómo está configurado (ya hecho, no rehagas)

`C:\Users\perca\.config\opencode\opencode.json` → MCP `@playwright/mcp`:

```
--executable-path C:/Users/perca/AppData/Local/BraveSoftware/Brave-Browser/Application/brave.exe
--user-data-dir   C:/Users/perca/AppData/Local/BraveSoftware/Brave-Browser/User Data
--profile-dir-name Default
--headless --shared-browser-context
```

Con eso las tools de Playwright del MCP ya van a Brave con tu sesión. **Requiere reiniciar la
sesión de OpenCode** para que tome efecto.

## Uso

```powershell
$S = "$HOME\.agents\skills\x-scrape\scripts"

# --- extraer ---
node $S\scrape.js search "AI video" [--top] [--since 2026-01-01] [--pages 3] [--limit 20] [--headed] [--out raw.json]
node $S\scrape.js multi "q1" "q2" "q3" --top --limit 15 --out raw.json   # N consultas, 1 arranque
node $S\scrape.js user "gbroOCT"
node $S\scrape.js tweet 2106100988751057316          # o una URL /i/status/<id>

# --- analizar (sin navegador, instantáneo) ---
node $S\analyze.js raw.json --out corpus.json --rank authority

# --- tests (ninguno necesita red) ---
node $S\test-analyze.js     # 14 tests del ranking y el dedup
node $S\test-smoke.js       # 10 tests de humo de scrape.js (orden de declaración, flags)
node $S\test-account.js     # 50 tests: --yes, límites, degraded, validate.js
```

### Flags

| Flag | Default | Qué hace |
|---|---|---|
| `--limit N` | 15 | Máximo de resultados por consulta |
| `--top` | off | Pestaña **Top** (relevancia). Sin flag va a **Latest** (cronológico) |
| `--since YYYY-MM-DD` | sin filtro | Agrega el operador `since:` nativo de X |
| `--pages N` | 1 | Vueltas de scroll para paginar (tope duro: 10) |
| `--headed` | headless | Muestra la ventana. Útil si X cambia el DOM |
| `--out f` | stdout | Guarda el JSON |
| `--show` | off | Ventana real **minimizada**: la ves trabajar en la barra de tareas sin que tape la pantalla ni robe el foco |
| `--focus` | off | Con `--show`, muestra la ventana al frente en vez de minimizar |
| `--headed` | off | Ventana visible al frente (igual que `--show --focus`) |
| `--gpu-check` | off | Verifica que la GPU esté activa y sale. `0` GPU · `4` software · `3` no verificable |
| `--cache <dir>` | off | Reusa consultas ya scrapeadas en las últimas `X_SCRAPE_CACHE_H` (12 h) sin tocar X |
| `--media` | bloqueado | Deja de bloquear imágenes y video. Cuesta CPU |

`analyze.js`: `--rank date\|authority`, `--dup 0.12`, `--out f`.

## Latest vs Top — no son intercambiables

Medido en la ronda 2026-10-03:

| Pestaña | Qué devuelve | Para qué |
|---|---|---|
| **Latest** (default) | Más volumen, **1 post por autor**, mucho spam | Frescura: qué está pasando ahora |
| **Top** (`--top`) | Menos volumen, más densidad, autores oficiales | Importancia: qué hay que saber del tema |

**Recomendación:** para investigación, empezá con **Top** (trae las cuentas oficiales y los
anuncios de producto, que es lo que importa) y usá **Latest** para barrier. Para volumen bruto,
Latest rinde más pero hay que filtrar el spam.

## `status`: el scraper siempre dice si miró o no

La salida nunca es `[]` con éxito. Siempre trae `status`:

| `status` | Significa | Qué hacer |
|---|---|---|
| `ok` | Miró y hay resultados | Usar |
| `empty` | La página cargó pero no hay resultados | Legítimo: cuenta sin posts, o query sin match. **No es un error** |
| `blocked` | Challenge de Cloudflare o sesión cerrada | **No confíes en el corpus.** Sale con código 3 |

Igual en modo `multi`: cada query trae su propio `status`.

## Trampas verificadas (no las aprendas a palos)

| Trampa | Qué pasa | Qué hacer |
|---|---|---|
| **Brave abierto a mano** | No se puede tomar el lock del perfil y falla | Cerrá Brave antes de lanzar |
| **`@handle` sin comillas en PowerShell** | `@jack` es *splatting*, se expande a nada → `Missing argument` | Siempre comillas: `"jack"` |
| **Detectar sesión con `SideNav_NewTweetButton`** | X lo renombró, da `false` aunque estés logueado | Usá `SideNav_AccountSwitcher_Button` |
| **Contar articles para paginar** | La búsqueda de X es **virtualizada**: al scrollear se desmonta lo de atrás, y el conteo nunca pasa de ~7 | Extraer y **acumular** en cada paso de scroll (ya está hecho) |
| **Rankear por keywords** | Premia la repetición: un promo puntúa 15 y un anuncio oficial 3 | Usá `analyze.js --rank authority` |
| **Dedup por texto exacto** | No detecta copyparta: dio 0 duplicados donde había 2 | `analyze.js` usa shingles 3-gramas, umbral 0.12 |
| **`user-posts` de twitter-cli** | Devuelve tweets que *mencionan* al usuario, no los suyos | No uses twitter-cli para esto |
| **Obscura / motores Chromium-free** | No leen las cookies de Brave, y X los challengea | No sirven para una cuenta autenticada |

## Los 7 estados, y por qué 5 son "no confíes"

| `status` | Salida | Qué pasó | ¿Confiar? |
|---|---|---|---|
| `ok` | 0 | Se miró y hubo artículos | Sí |
| `empty` | 0 | La página cargó y no hay resultados | Sí, **si `session.titulo` no está vacío** |
| `no_render` | 3 | Página en blanco: no se miró nada | No |
| `stalled` | 3 | Spinners eternos: la carga no resolvió | No |
| `blocked` | 3 | Cloudflare o sesión cerrada | No |
| `throttled` | 5 | HTTP 429: la cuenta está rate-limited | No, y **dejá de correr** |
| `degraded` | 5 | Sesión **viva** pero X no entrega contenido | No, y **dejá de correr** |

### `degraded` — el que se aggregates último (F-21)

Es el estado más tramposo porque **no hay ningún error que lo delate**. La sesión carga, estás
logueado, cero 4xx, cero 429, título correcto — y no hay artículos. Sin el estado, eso caía en `empty`:
"no hay resultados para esta consulta", que es mentira.

**Cómo se distingue de una búsqueda legítimamente vacía:** una cuenta sin posts igual tiene página de
perfil con nombre, avatar y bio. Si no hay ni nombre, ni avatar, ni bio, no hay una página que pueda
estar vacía: lo que se ve es una columna que no cargó.

Mirá `session.perfilNombre` / `perfilAvatar` / `perfilBio` para confirmar. Si los tres vienen `false`
con `cargados: 0`, es `degraded`.

Comparte código de salida 5 con `throttled` a propósito: los dos piden **parar y esperar horas**, y
un código distinto obligaría al llamador a distinguir dos causas que se resuelven igual.

Y el corolario: **X degrada de forma selectiva por ruta** (F-22). El feed puede estar perfecto
mientras `/i/flow/setup_profile` está caído. Un chequeo de salud del home no dice si podés escribir.

Un `empty` con `titulo: ""` **no es** una búsqueda vacía: es una página que nunca se pintó. Revisá
`session.titulo` y `red` antes de concluir que no hay nada que encontrar.

### `throttled` — respetalo

X responde `200` para el HTML y **`429` para toda la API**. El SPA no tiene con qué pintar: página
en blanco, sin spinner. Es indistinguible de "sin resultados" si solo mirás el DOM.

Cuando aparece: **pará por horas, no minutos.** Reintentar empeora el bloqueo. No abras Brave a
mano para "desbloquear", eso también cuenta. Una cuenta con ~30 navegaciones seguidas se
throttlea; agrupá con `multi` y usá `--cache`.

## GPU — ya está activa, no la fuerces

Medido con `nvidia-smi`: **la GPU está en uso y solo al 4%**. La aceleración...

```bash
node scrape.js --gpu-check
# renderer: ANGLE (NVIDIA, NVIDIA GeForce RTX 3090 (0x00002204) Direct3D11 vs_5_0 ps_5_0, D3D11)
#   RESULTADO: GPU activa (aceleracion por hardware confirmada).
```

Sin ningún flag, Brave ya renderiza por **ANGLE/D3D11 sobre la RTX 3090**. Agregar
`--use-angle=d3d11`, `--enable-gpu` o `--ignore-gpu-blocklist` da un renderer **idéntico**, y
`--ignore-gpu-blocklist` puede forzar un driver peor. **No se agregan.**

**No verifiques la GPU con un canvas en una página normal**: Brave's Shields reemplaza
`WEBGL_debug_renderer_info` por la cadena `"Brave"`, así que da el mismo valor con y sin GPU, y
el chequeo "pasa" siempre. Hay que correrlo sobre una página `chrome://` (ver F-11).

Que la GPU esté libre y el CPU siga al 400% es normal: el trabajo pesado es **JavaScript y layout
del SPA**, que corre en CPU aunque la GPU esté ociosa. Ningún flag de GPU lo mueve.

## Como navega (y por que importa)

Una persona **no recarga x.com para cada busqueda**: escribe en la caja y le da Enter.
El scraper **si lo hacia**, y eso lo costaba caro.

| Accion | Peticiones | A la API |
|---|---:|---:|
| `page.goto` a una busqueda | **197** | **23** |
| Cambiar la consulta dentro del SPA | 25 | 10 |
| Un scroll | 18 | 5 |

`multi` ahora hace `goto` **una sola vez** (primera consulta) y despues salta dentro del SPA.
Medido con 4 consultas: **788 -> 391 peticiones**, **92 -> 52 llamadas a la API**, **4 -> 1
recarga de la SPA**. Eso baja las dos cosas a la vez: el throttle de la cuenta **y** el pico de
CPU (un renderizado del SPA en vez de cuatro).

Si el salto en el SPA falla, cae a `goto` automaticamente: nunca es peor que antes. Mirá
`navigations` y `spa_saltos` en el JSON, y `red.peticiones` para el costo de la corrida.

## Costo de CPU — medido, no supuesto

Una corrida **satura ~430% de CPU** (31-34 procesos). No es el scraping: es cargar x.com.

| Escenario | CPU acumulada |
|---|---|
| Solo arrancar y cerrar Brave, sin navegar | **11,9 s** |
| Arrancar + 12 s en x.com | **52,2 s** |
| Bloqueando media con `route()` | 47,8 s |
| Con `--blink-settings=imagesEnabled=false` | 50,7 s |
| Eso + `--disable-gpu` | 49,6 s |

**Las tres optimizaciones de media están dentro del ruido.** El costo es intrínseco del SPA en
headless. Los levers que sí sirven:

1. **Cargar menos páginas.** Es lo único que baja el costo de verdad.
2. **Agrupar con `multi`**: una sola,~5 s de arranque para N consultas.
3. **`--cache <dir>`**: una consulta ya hecha no vuelve a pegarle a X. Es la palanca más grande.
4. **No lo corras mientras hacés otra cosa pesada.**

Media e imágenes van bloqueados por default (ahorra red y RAM, ~8% de CPU). Con `--media` dejás
de bloquearlos si los necesitás.

## Límites del corpus

- **Nunca es un censo.** Con paginación decente salen ~10-25 por consulta; el feed es infinito.
- **El rango de fechas es amplio.** Sin `--since`, la pestaña Top mete posts viejos de alto
  engagement. Fijá `--since` si te importa la actualidad.
- **El copypasta no se borra, se marca.** `analyze.js` pone `es_copypasta: true` pero lo deja en el
  corpus: que alguien siembre contenido sobre un tema es información sobre el tema.
- **Las cifras no están verificadas.** X es un feed de marketer. ARR, valuaciones y premios salen
  de cuentas chicas sin fuente primaria. Para un documento, marcá la confianza y verificá contra
  fuente primaria antes de citar.
- **Distinguí oficial de tercero.** `analyze.js` marca `oficial` con una lista curada de handles.
  No es exhaustiva.

## Validar lo extraído, no confiar en el exit code

```powershell
node $S\validate.js data\corpus\*.json --raw          # informe legible
node $S\validate.js data\raw\*.json --raw --baseline  # actualiza el baseline
node $S\validate.js raw-nuevo.json --json             # salida para máquinas
```

**Offline:** lee JSON, no toca red ni navegador. Corre en milisegundos, por eso se puede correr en
**cada** adquisición. Es la respuesta a la pregunta que el exit code no contesta: *¿salió bien
porque extrajo lo que debía, o solo porque no crasheó?*

Chequea nulabilidad por campo, schema drift contra baseline, inflación de duplicados, anomalías de
conteo y concentración de autor. Cada hallazgo dice **qué**, **por qué** y **qué hacer**.

| Veredicto | Significado |
|---|---|
| `OK` | El exit code y este informe coinciden: se miró y se extrajo |
| `OK_CON_RESERVAS` | Nada grave, pero hay que mirarlo |
| `SOSPECHOSO` | El exit code puede ser 0 y el dataset estar incompleto |

**Los umbrales vienen del baseline** (`fixtures/validate-baseline.json`, se overridea con
`X_VALIDATE_BASELINE`): un campo que venía 4% vacío no puede estar 60% de golpe sin que sea drift.

### Lo que este script NO mide, y está bien que no mida

**Engagement.** El `EXTRACT` saca 5 campos (`user`, `handle`, `when`, `text`, `url`) y ninguno es
likes/retweets/views. Armar un chequeo sobre datos que el extractor no captura daría un falso "todo
bien", que es peor que no medir. Hay un test que falla a propósito si alguien agrega un chequeo de
engagement sin agregar primero la captura.

Consecuencia real: **no se puede rankear por calidad.** No hay señal. Por eso el ranking por
autoridad es lo más que hay, y por eso el filtro de calidad es la hipótesis abierta más antigua.

---

## Verificado

2026-10-03, con `cf_clearance` del perfil real:

- `search`, `user`, `tweet` y `multi`: OK, headed y headless, **sin challenge de Cloudflare**.
- Anti-ban verificado: pausas de 6.1 s y 7.1 s entre 3 consultas consecutivas.
- `test-analyze.js`: 14/14 contra los 3 archivos raw de la ronda.
- El ranking por autoridad pone el anuncio oficial de `@tavus` en el top-5, donde el de keywords
  lo dejaba en el puesto 60 de 99.

2026-10-04 (escritura, **los cuatro caminos ejecutados contra X**):

| Acción | Cómo se verificó | Resultado |
|---|---|---|
| `whoami` | lee y compara | `Gbro` / `@gbroOCT` |
| `profile --bio` | relee el texto del perfil y compara | publicado |
| `avatar` | la URL deja de ser `sticky/default_profile_images` | `pbs.twimg.com/profile_images/2106829987479191552/r4BvLnB4_normal.png` (200, `image/png`, 16.283 B) |
| `post` | busca el tweet en el perfil y compara el **texto**, no el largo | `x.com/gbroOCT/status/2106849765644259547` |

- `test-analyze.js` 14/14, `test-smoke.js` 10/10, `test-account.js` **50/50**.
- `degraded()` verificado **contra X**: búsqueda con resultados → `ok` (`cargados: 7`); búsqueda de
  cadena sin sentido → `empty` (legítimo, `perfilAvatar: true`), no `degraded`.

**Comparar el texto, no el largo.** X cuenta los saltos de línea distinto: se mandaron 174
caracteres y sirvieron 172. Con tolerancia numérica, dos posts reales dieron `no_verificado`.
Normalizar espacios y comparar strings es lo que sobrevive.

**Sobre el costo real de la escritura:** las corridas de avatar hicieron 1.000-1.225 peticiones cada
una, y una terminó con 4 respuestas 429. Un cambio de avatar es ~6 veces más caro que toda una
ronda de búsqueda (~500 con `multi`). **Escribir en la cuenta es caro de verdad:** por eso la regla
de una acción por corrida y por eso los cooldowns entre acciones.

## Alcance

**Lectura por default. Escritura separada y explícita.**

| | |
|---|---|
| `scrape.js`, `analyze.js` | **Solo lectura.** No publican, no likean, no siguen, no borran |
| `account.js` | **Escribe**: cambia nombre, bio y avatar, y publica posts |

La línea se puso el 2026-10-04 a pedido del dueño de la cuenta, que pidió improving la cuenta y
publicar. Antes de tocar la skill, el skill docs decía que escribir requería hablarlo antes:
se habló, y esta es la versión acordada.

**Reglas de la escritura, que no son opcionales:**

1. **Una acción por invocación.** Menos arranques de x.com = menos riesgo de que X marque la
   cuenta. La sesión real es lo más valioso del setup: perderla mata también el scraping.
2. **Toda escritura exige `--yes`.** Sin el flag, sale con código 6 y no toca nada. Un `post`
   accidental no publica.
3. **En escritura, exito = SE VIO EL EFECTO.** Hay un estado aparte, `no_verificado` (código 3), para
   el caso "la sesión estaba sana pero el cambio no ocurrió". **Nunca se deriva `verificado` del
   estado de la sesión**: se relee el resultado y se compara. Para el avatar, el chequeo es que la
   URL deje de ser `sticky/default_profile_images`. Ver F-25, que es una falla real de este skill.
4. **Nada de ocultar que es automatizado.** No se falsifican cabeceras, no se camufla el tráfico.

**Sobre la transparencia de esta cuenta en concreto:** la bio de @gbroOCT **no** declara que la
escribe una IA. Fue una decisión explícita del dueño, que eligió texto solo de tema. Que conste
acá para que nadie lea estos docs y asuma lo contrario.

**Lo que esta skill sigue sin haciendo**, y sigue en la misma línea: nada concealment-oriented
(ocultar que sos automatizado, evadir detección de plataforma). Si alguna vez hace falta, es porque
la operación cambió de naturaleza y hay que hablarlo antes.

---

## Escribir en la cuenta

```powershell
$S = "$HOME\.agents\skills\x-scrape\scripts"

node $S\account.js whoami                      # LECTURA: handle, nombre, bio actuales
node $S\account.js profile --bio "..." --yes    # cambia nombre y/o bio
node $S\account.js avatar "ruta.png" --yes      # sube la foto de perfil
node $S\account.js post "texto" --yes           # publica (máx 280, corta si se pasa)
```

`account.js` reusa el mismo contexto de Brave, los mismos estados y las mismas reglas de red que
`scrape.js`. Antes de escribir chequea sesión y red: un 429 es peor acá, porque creería que publicó
y no publicó nada. Y corta apenas ve uno, en vez de seguir insistiendo (F-23).

**Los límites de X se validan antes de abrir el navegador:** nombre 50, bio 160. Si no, el editor
rechaza el guardado y el script reportaría un éxito que no ocurrió.

### El avatar es un script, no una imagen suelta

```powershell
node $S\make-avatar.js --out avatar.png [--bg "#0b1020" --fg "#f8fafc" --accent "#38bdf8"]
```

Se dibuja un SVG y se saca el PNG con el mismo Playwright del scraper. Sin ImageMagick, sin
`sharp`. Versioná el `.js`, no el `.png`: cambiar el color es cambiar un flag.

**Por qué geométrico y no una imagen de difusión:** un avatar se lee a **40px** en la barra
lateral. Un mark con contraste alto se sigue entendiendo; una imagen generada por modelo se
convierte en ruido a ese tamaño.

## Archivos

- `scripts/scrape.js` — extracción. Autodetecta `playwright-core` en el cache de npx. **Solo lectura.**
- `scripts/account.js` — perfil, avatar y publicaciones. **Escribe** (ver «Alcance»).
- `scripts/make-avatar.js` — genera el avatar como PNG desde un SVG. Sin dependencias extra.
- `scripts/analyze.js` — dedup difuso + ranking. Sin navegador.
- `scripts/test-analyze.js` — 14 tests contra datos reales.
- `scripts/validate.js` - informe de validación de un corpus. Offline. Detecta drift, nulos, duplicados y concentración de autor.
- `scripts/test-account.js` - 50 tests: escritura (--yes, límites, degraded) y los detectores de `validate.js`.
