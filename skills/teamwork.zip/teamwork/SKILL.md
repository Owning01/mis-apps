---
name: teamwork
description: Multi-agent teamwork and swarm orchestration loop replicating Antigravity's /teamwork-preview. Features two-phase execution (scoping interview + autonomous swarm), 3-tier architecture (Sentinel, Orchestrator, Explorers, Workers), adversarial verification gates (Critic, Challenger, Auditor, Success Auditor), integrity modes (development, demo, benchmark), exclusive file ownership, and milestone context renewal.
argument-hint: "[general|iterative|review|math] [descripción de la tarea]"
version: "2.0.0-antigravity"
license: MIT
---

# 🐝 Teamwork — Autonomous Agent Teams & Swarm Architecture (/teamwork-preview)

> **Axioma Fundamental de Teamwork**: **Un agente individual nunca debe asumir todos los roles de un proyecto.** Concentrar planificación, exploración, implementación y evaluación en un único contexto conduce a fatiga de atención, degradación de ventana de contexto y ceguera de verificación ("mis propios bugs me parecen correctos").
>
> Replicando la arquitectura oficial de **Google Antigravity (`/teamwork-preview`)**, este protocolo desacopla la ingeniería de software en **3 niveles de agentes**, introduce **puertas de verificación adversarial**, aplica **modos de integridad** y renueva el contexto entre hitos para garantizar código probado, verificado y sin fabricaciones.

---

## 📑 ÍNDICE DEL PROTOCOLO
1. [Arquitectura de Roles en 3 Niveles](#1-arquitectura-de-roles-en-3-niveles)
2. [Modos de Integridad (Integrity Modes)](#2-modos-de-integridad-integrity-modes)
3. [Flujo en 2 Fases (Two-Phase Workflow)](#3-flujo-en-2-fases-two-phase-workflow)
4. [Puertas de Verificación Adversarial](#4-puertas-de-verificación-adversarial)
5. [Aislamiento, Propiedad de Archivos y Mitigación de Degradación](#5-aislamiento-propiedad-de-archivos-y-mitigación-de-degradación)
6. [Protocolo de Comunicación y Artefactos Stigmérgicos](#6-protocolo-de-comunicación-y-artefactos-stigmérgicos)
7. [Rutas de Ejecución Especializadas](#7-rutas-de-ejecución-especializadas)
8. [Despliegue Rápido y Ejemplos de Invocación](#8-despliegue-rápido-y-ejemplos-de-invocación)

---

## 👥 1. ARQUITECTURA DE ROLES EN 3 NIVELES

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                               TIER 1: ORQUESTACIÓN Y VUELO                              │
│                                                                                        │
│   👑 SENTINEL (Coordinador Raíz)                                                      │
│      • Conduce la entrevista Fase 1 ("Especifica Qué, no Cómo").                       │
│      • Despacha al Project Orchestrator y publica actualizaciones periódicas.          │
│      • Spawnea al Success Auditor final antes de entregar el proyecto al usuario.      │
│                                                                                        │
│   🧭 PROJECT ORCHESTRATOR (Director de Hitos)                                          │
│      • Descompone el plan en hitos y rutas de trabajo no colisionantes.                │
│      • Asigna propiedad exclusiva de archivos a los Workers.                          │
│      • RENOVA CONTEXTO: entrega el relevo a un sucesor fresco entre hitos.             │
└───────────────────────────┬────────────────────────────────┬───────────────────────────┘
                            │                                │
            ┌───────────────┴────────────────┐               │
            ▼                                ▼               ▼
┌───────────────────────┐        ┌───────────────────────┐   │
│     TIER 2: EXPLORACIÓN│        │   TIER 2: CONSTRUCCIÓN│   │
│   🔍 EXPLORERS        │        │   🔨 WORKERS          │   │
│   • Solo lectura.     │        │   • Escritura activa. │   │
│   • Rastreo de cadenas│        │   • Diffs mínimos.    │   │
│     de llamada.       │        │   • Tests unitarios.  │   │
│   • Cero mutaciones.  │        │   • 1 Worker x archivo│   │
└───────────────────────┘        └───────────┬───────────┘   │
                                             │               │
                                             ▼               │
┌────────────────────────────────────────────────────────────┴───────────────────────────┐
│                      TIER 3: PUERTAS DE VERIFICACIÓN ADVERSARIAL                        │
│                                                                                        │
│   🧐 CRITIC: Audita elegancia, interfaces, contratos de tipos y estilo de código.      │
│   ⚔️ CHALLENGER: Diseña tests adversariales, inputs extremos y condiciones de carrera. │
│   📋 AUDITOR: Comprueba ejecución real en terminal (CERO tests mockeados o falsos).    │
│   🏆 SUCCESS AUDITOR: Verificación final E2E de aceptación previa a la entrega.       │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 🛡️ 2. MODOS DE INTEGRIDAD (INTEGRITY MODES)

Teamwork establece tres modos de rigor técnico acordados con el usuario antes de iniciar:

| Modo | Propósito | Reglas de Verificación del Auditor |
| :--- | :--- | :--- |
| **`development`** *(Default)* | Iteración rápida y prototipado. | Permite reutilización de librerías, dependencias y frameworks. **Prohíbe terminantemente salidas fabricadas o implementaciones fachada/placeholders.** |
| **`demo`** | Presentaciones y reproducibilidad. | Suma: prohibido copiar lógica central de código abierto, prohibido delegar el núcleo a herramientas externas, **prohibido leer el código del test para hacer trampas (reverse-engineering).** |
| **`benchmark`** | Máximo rigor, evaluación estricta. | **Cero dependencias externas (solo biblioteca estándar del lenguaje).** Implementación 100% desde cero. Salida real de comandos verificada contra oráculos de hardware/sistema. |

---

## 📋 3. FLUJO EN 2 FASES (TWO-PHASE WORKFLOW)

Para evitar interrupciones constantes y asegurar alineación quirúrgica, el trabajo se divide en dos fases:

### Fase 1: Entrevista de Alcance ("Especifica Qué, no Cómo")
Antes de despachar agentes o tocar archivos, el Sentinel valida los 5 pilares:
1. **Objetivo & Audiencia**: ¿Es producción, demo, benchmark o investigación?
2. **Bloques de Requerimientos**: Requisitos estrictos de lo que importa resolver.
3. **Mecanismo de Verificación Independiente**: Suite de tests objetiva, script de métricas o benchmark real.
4. **Criterios de Aceptación (DoD)**: Condiciones numéricas o lógicas para dar por cerrado el proyecto.
5. **Directorio Dedicado de Proyecto**: Carpeta de trabajo aislada (ej. `teamwork_projects/{PROJECT_NAME}/` o rama dedicada).

> **Salida de Fase 1**: Un artefacto de propuesta revisable (`teamwork_brief.md`). El usuario aprueba con una sola confirmación.

### Fase 2: Ejecución Autónoma con Handoffs Estructurados
Sentinel cede el control al **Project Orchestrator**, el cual coordina al equipo sin pedir confirmaciones paso a paso:
- Publica el estado en `teamwork_plan.md` y `teamwork_progress.md`.
- Despacha Explorers y Workers en pistas paralelas no conflictivas.
- Ejecuta las compuertas adversariales al término de cada hito.
- Invoca al **Success Auditor** para certificar el proyecto antes de avisar al usuario.

---

## ⚔️ 4. PUERTAS DE VERIFICACIÓN ADVERSARIAL

Ningún hito se aprueba porque el Worker diga "ya terminé". Debe superar el tribunal de 4 filtros:

1. **🧐 Critic (Revisión de Arquitectura y Estilo)**:
   - ¿Respeta las capas del sistema? ¿Introduce acoplamiento indebido? ¿Usa tipos estrictos?
2. **⚔️ Challenger (Pruebas de Esfuerzo y Caos)**:
   - Inyecta inputs nulos, arrays vacíos, strings de 10MB, cortes abruptos de red o errores `EPERM`.
   - Si el Challenger logra que el código lance un pánico no controlado, la tarea se **RECHAZA**.
3. **📋 Auditor (Integridad Empírica)**:
   - **Cero complacencia con tests mockeados:** Inspecciona la salida real del comando en la terminal (código de salida 0 y logs genuinos).
   - Verifica que el Worker no haya modificado los tests existentes para "hacerlos pasar".
4. **🏆 Success Auditor (Aceptación Final)**:
   - Despachado por el Sentinel al cierre del último hito. Ejecuta la suite completa de integración de punta a punta.

---

## 🔒 5. AISLAMIENTO, PROPIEDAD DE ARCHIVOS Y MITIGACIÓN DE DEGRADACIÓN

Para que un equipo multi-agente trabaje sin destruirse mutuamente:

1. **Propiedad Exclusiva de Archivos (Exclusive File Ownership)**:
   - El Orchestrator asigna archivos explícitos a cada Worker.
   - **Dos Workers NUNCA editan el mismo archivo al mismo tiempo.**
2. **Directorios Scratch por Agente**:
   - Cada subagente escribe sus scripts auxiliares y logs en su carpeta temporal propia (`scratch/agent-<id>/`), manteniendo limpia la raíz del proyecto.
3. **Relevo de Sucesores (Context Renewal)**:
   - Para evitar que la memoria del Orchestrator se degrade por acumulación de miles de tokens tras varios hitos, el Orchestrator sintetiza el estado actual en `teamwork_progress.md` y **transfiere el relevo a una nueva instancia fresca del Orchestrator para el siguiente hito.**

---

## 💬 6. PROTOCOLO DE COMUNICACIÓN Y ARTEFACTOS STIGMÉRGICOS

### Artefactos de Estado del Workspace:
- `.agents/teamwork_board.json`: Tablero de tareas en máquina (DAG, dependencias, estados).
- `.agents/teamwork_plan.md`: Hoja de ruta de hitos y tracks paralelos.
- `.agents/teamwork_progress.md`: Registro vivo de avances, reportes del Challenger y auditorías.

### Estructura de Mensajería Inter-Agente:

#### Despacho a Worker (`WORKER_DISPATCH`):
```json
{
  "type": "WORKER_DISPATCH",
  "milestoneId": "M1",
  "taskId": "T-102",
  "workerRole": "Worker-Storage",
  "integrityMode": "development",
  "exclusiveFiles": ["src/storage/engine.ts", "tests/storage/engine_test.ts"],
  "objective": "Implementar almacenamiento append-only con recuperación de fallos",
  "verificationCommand": "pnpm test tests/storage/engine_test.ts"
}
```

#### Notificación de Entrega (`WORKER_COMPLETE`):
```json
{
  "type": "WORKER_COMPLETE",
  "taskId": "T-102",
  "modifiedFiles": ["src/storage/engine.ts", "tests/storage/engine_test.ts"],
  "commandOutputSummary": "12 tests ejecutados, 12 exitosos. Salida 0.",
  "readyForAudit": true
}
```

#### Dictamen del Tribunal de Verificación (`GATE_VERDICT`):
```json
{
  "type": "GATE_VERDICT",
  "taskId": "T-102",
  "criticReview": "PASS - Estructura limpia y desacoplada",
  "challengerVerdict": "FAIL - Falla ante escritura concurrente en archivo bloqueado",
  "auditorVerdict": "PASS - Tests reales sin mocks",
  "finalDecision": "REJECTED",
  "remediationRequired": "Añadir manejo de bloqueo de archivos y test de concurrencia para Challenger"
}
```

---

## 🧭 7. NIVELES DE ESFUERZO Y RUTAS ESPECIALIZADAS (TEAMWORK TIERS)

Teamwork adapta automáticamente la composición y esfuerzo del equipo según la complejidad del encargo o el comando invocado:

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                          ESCALERA DE ESFUERZO TEAMWORK                                 │
├────────────────────────────────────────────────────────────────────────────────────────┤
│ 1. ⚡ MINI / LIGHT    ➔ 2 Agentes (Worker + Auditor)               | ~1-3m  | Cuota mín │
│ 2. ⚖️ STANDARD (Def)  ➔ 3-5 Agentes (Orch + 2 Workers + Challenger)| ~5-12m | Balanceado│
│ 3. 🚀 FULL / MAX      ➔ 8-15+ Agentes (Swarm Masivo + Victory Gate)| ~20-45m| MÁXIMO   │
│ 4. 🔍 REVIEW / AUDIT  ➔ Critics & Forensic Auditors                | ~3-8m  | Auditoría │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

| Nivel / Comando | Composición del Equipo | Entrevista y Burocracia | Cuándo Usarlo |
| :--- | :--- | :--- | :--- |
| **`teamwork mini`**<br>`/teamwork mini` | **2 Agentes**:<br>• 1 Worker (implementa)<br>• 1 Auditor (test real terminal) | **Cero burocracia**:<br>Sin entrevista ni brief. Va directo a la edición quirúrgica y su test. | Bug fixes puntuales, cambios en 1-2 archivos, scripts auxiliares. Ahorra 80% de tokens y evita agotar cuota (429). |
| **`teamwork`**<br>`teamwork standard` *(Default)* | **3 a 5 Agentes**:<br>• Orchestrator<br>• 1-2 Workers paralelos<br>• 1 Challenger adversarial<br>• Evaluador | **Alineación rápida**:<br>3 preguntas clave y ejecución directa con DAG de hitos. | Features medianas, integración de nuevas APIs, tests E2E y refactors modulares. |
| **`teamwork full`**<br>`teamwork max`<br>`/teamwork full` | **MÁXIMO ESFUERZO Y RIGOR**<br>**8 a 15+ Agentes**:<br>• Sentinel coordinador<br>• Project Orchestrator (con renovación de contexto)<br>• 3 Exploradores en paralelo<br>• Múltiples Workers especializados con propiedad exclusiva de archivos<br>• Tribunal de 4 jueces (Critic, 2 Challengers, Auditor)<br>• **Victory Auditor Independiente** bloqueante | **Auditoría completa de 9 pasos**:<br>Definición estricta de DoD, matriz de riesgos, multi-ronda de remediación adversarial y certificación de victoria. | Proyectos completos desde cero, suites de SO (ej. MCP de 48 tools), arquitecturas críticas donde **no se tolera ningún error**. |
| **`teamwork review`**<br>`/teamwork audit` | **Tribunal de Revisión**:<br>• Lead Critic<br>• Security Challenger<br>• Architecture Auditor | **Solo lectura**:<br>Sin mutaciones de código; genera informe de hallazgos y mitigaciones. | Auditorías de seguridad, revisión de PRs, inspección de código legacy o RFCs. |

---

## ⚡ 8. DESPLIEGUE RÁPIDO Y EJEMPLOS DE INVOCACIÓN

### 1. Invocación Nivel Mini (Ultra-rápido, económico):
```
teamwork mini Corrige la validación de regex de emails en auth/validator.ts y añade el test correspondiente.
```
*Directiva canónica inyectada:* `"This is a single self-contained change; keep it small and focused. Use a small, focused team."*

### 2. Invocación Nivel Standard (Balanceado):
```
teamwork Implementar soporte de paginación por cursor y filtros por fecha en el endpoint /api/v1/orders.
```

### 3. Invocación Nivel Full / Max (Máximo Esfuerzo y Rigor Absoluto):
```
teamwork full Diseñar e implementar desde cero el motor de replicación en clúster con pruebas de partición de red (Jepsen-style) y certificación formal.
```
*Directiva canónica inyectada:* `"Use a very large team of agents. Maximize exploration, parallel implementation, adversarial testing and forensic victory audit."*

---

## 🤖 9. COMPORTAMIENTO INMEDIATO DEL AGENTE PRINCIPAL

1. **Detectar el Modo**:
   - Si el usuario dice `teamwork mini` o `mini teamwork` ➔ **Ruta Mini**: sin entrevista, despachar Worker + Auditor directo.
   - Si el usuario dice `teamwork full` o `teamwork max` ➔ **Ruta Full**: máximo esfuerzo, activar Sentinel con exploración masiva y Victory Auditor.
   - Si no especifica ➔ **Ruta Standard**.
2. **Definir Modo de Integridad**: Acordar `development`, `demo` o `benchmark`.
3. **Lanzar Orquestación**: Desplegar el enjambre correspondiente y coordinar de forma asíncrona hasta la entrega validada.
