---
name: mi-entorno
description: Perfil de desarrollo personal de Octavio. Aplica al iniciar proyectos, configurar herramientas, dependencias, documentación, commits y despliegue.
---

# Perfil de Desarrollo — Octavio

Reglas mandatorias de entorno y desarrollo para cualquier tarea o proyecto.

## 1. Entorno & Almacenamiento (Regla Crítica)
* **Usuario / SO**: Octavio | Windows 11 (PowerShell 7+) | VPS Linux: `ssh -p5536 root@149.50.148.236`.
* **Disco de Trabajo**: **TODO en `G:\` (NUNCA en `C:\`)**. Proyectos (`G:\Proyectos\`), SDKs, Python (`G:\Python\`), Android (`G:\Android\`), tmp (`G:\tmp\`), Cargo, npm prefix.
* **Seguridad Zero-Leak**: Jamás hardcodear credenciales, API keys o tokens. Siempre en `.env` (incluido en `.gitignore`) o variables de entorno.

## 2. Stack & Gestores de Paquetes
* **Preferencia Backend-first**: 1. Go | 2. C# | 3. Rust | 4. TypeScript | 5. Flutter/Dart.
* **Arquitectura & APIs**: REST siempre (no GraphQL/gRPC salvo petición explícita) | DB principal: PostgreSQL (`pgxpool`).
* **Gestores Oficiales (Regla Estricta)**:
  * **Node/TS**: `pnpm` (PROHIBIDO `npm` o `yarn`).
  * **Go**: `go mod` (`go mod tidy`, `go get pkg@latest`).
  * **Rust**: `cargo` (`cargo add`).
  * **C#**: `dotnet` / NuGet.
  * **Python**: `uv` (`uv add`, `uv sync`).
  * **Flutter**: `dart pub` / `flutter pub`.
* **Versiones**: Usar siempre la última versión estable oficial (`@latest`). Nunca versiones obsoletas.

## 3. Arquitectura & Estilo de Código
* **Patrón**: Handler → Service → Repository.
* **DRY & Conciso**: Funciones cortas (<40 líneas), *guard clauses* y *early returns*. Cero código muerto o verbosidad innecesaria.
* **Singleton para Recursos**: Conexiones a DB, clientes HTTP y Firebase Admin deben ser singletons con connection pool (ej. `sync.Once` en Go, `Lazy<T>` en C#). Jamás abrir/cerrar conexiones por request.

## 4. Estructura de Documentación (`docs/`)
Todo proyecto nuevo debe estructurarse con documentación tipo tutorial paso a paso:
```
docs/
  ├── 01-setup.md          # Instalación, requisitos y comandos reales
  ├── 02-arquitectura.md   # Flujo modular con diagramas ASCII
  ├── 03-api.md            # Endpoints REST, contratos y payloads
  ├── 04-despliegue.md     # Guía de deploy a VPS / Docker / systemd
  └── dependencias.md      # Tabla con paquete, versión, propósito y link
```

## 5. Convención de Commits
* Formato: **Conventional Commits** (`feat`, `fix`, `docs`, `refactor`, `perf`, `test`, `chore`).
* Frecuencia: Commit **al completar cada feature** (no por archivo, no por tiempo).
* Mensaje: `<tipo>(<scope opcional>): <descripción>` explicando QUÉ y POR QUÉ.

## 6. Despliegue a VPS (Linux amd64)
Compilar para Linux, comprimir con UPX al máximo y desplegar por SSH (puerto 5536):
* **Go**: `$env:GOOS="linux"; $env:GOARCH="amd64"; go build -ldflags="-s -w" -o app . ; upx --best --ultra-brute app ; scp -P 5536 app root@149.50.148.236:/root/app ; ssh -p 5536 root@149.50.148.236 "mv /root/app /usr/local/bin/<app> && chmod +x /usr/local/bin/<app> && systemctl restart <app>"`
* **Rust**: `$env:TARGET="x86_64-unknown-linux-gnu"; cargo build --release ; upx --best --ultra-brute target/release/<app> ; scp -P 5536 target/release/<app> root@149.50.148.236:/root/app ; ssh -p 5536 root@149.50.148.236 "mv /root/app /usr/local/bin/<app> && chmod +x /usr/local/bin/<app> && systemctl restart <app>"`

## 7. Workflow al Iniciar Proyecto Nuevo
1. Inicializar paquete (`go mod init`, `pnpm init`, etc.).
2. Crear `.gitignore` acorde al stack (`.env`, binarios, dependencias).
3. Crear carpeta `docs/` con los 5 archivos base.
4. `git init` y primer commit: `feat(init): initial project scaffold`.
