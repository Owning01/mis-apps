# Plantilla de plan

Todo plan escrito por `improve-animations` sigue esta estructura. El ejecutor puede ser un modelo menos capaz, sin contexto y sin criterio propio: el plan debe contenerlo todo, exactamente. Sin referencias a "la auditoría de arriba" o "el easing que discutimos".

```markdown
# NNN — <Título imperativo corto>

- **Estado**: PENDIENTE
- **Commit**: <salida de `git rev-parse --short HEAD` cuando se escribió este plan>
- **Severidad**: ALTA | MEDIA | BAJA
- **Categoría**: <categoría de auditoría>
- **Alcance estimado**: <n archivos, tamaño aproximado>

## Problema

Qué está mal, dónde, y por qué importa para cómo se siente el producto. Cita
cada ubicación como `path/to/file.tsx:123` e incluye el código actual textual:

​```css
/* src/components/dropdown.css:14 — actual */
.dropdown { transition: all 400ms ease-in; }
​```

## Objetivo

El estado final exacto. Cada valor escrito: curvas, duraciones, configs de
resorte, media queries. Nunca "usa un easing más lindo":

​```css
/* objetivo */
.dropdown {
  transition: transform 200ms var(--ease-out), opacity 200ms var(--ease-out);
  transform-origin: var(--transform-origin);
}
​```

## Convenciones del repo a seguir

Cómo lo hace ya este codebase, con un ejemplar que el ejecutor debería
imitar (nombres de tokens, ubicación de archivos, patrones de props):

- Los tokens de easing viven en `src/styles/tokens.css`; agrega las curvas nuevas ahí, p. ej. `--ease-out: cubic-bezier(0.23, 1, 0.32, 1);`
- <file:line de un ejemplar que ya lo hace bien>

## Pasos

1. <Una edición concreta por paso: archivo, qué cambia, código resultante.>
2. …

## Límites

- NO toques <archivos/componentes fuera de alcance>.
- NO cambies markup/estructura: solo propiedades de movimiento (salvo que un paso diga otra cosa).
- NO agregues dependencias nuevas.
- Si un paso no coincide con el código que encontrás (deriva desde el sello del commit), DETENTE y reporta en vez de improvisar.

## Verificación

- **Mecánica**: <comandos exactos: typecheck, lint, build, con el resultado esperado>.
- **Verificación de sensación**: corre la UI, dispara <interacción> y confirma:
  - <verificable, p. ej. "el dropdown escala desde su disparador, no desde el centro">
  - <p. ej. "spamear el toggle nunca reinicia la animación desde cero">
  - En DevTools, pon el playback en 10% (panel Animations) y confirma <detalle>.
  - Activa `prefers-reduced-motion` (panel Rendering) y confirma que el movimiento desaparece pero el feedback de opacity permanece.
- **Terminado cuando**: <criterios de completación verificables por máquina o a ojo>.
```

## Notas para quien escribe el plan

- Un plan por hallazgo. Si dos hallazgos comparten todos los archivos y el mismo patrón de arreglo (p. ej. el mismo cambio de token de easing en varios componentes), pueden fusionarse en un solo plan.
- Toma todos los valores de [AUDIT.md](AUDIT.md): nunca los aproximes de memoria.
- La verificación de sensación no es opcional. El movimiento puede ser mecánicamente correcto y aun así sentirse mal; dale al ejecutor (o a la persona que revisa su diff) cosas concretas que observar en movimiento lento.
- Después de escribir los planes, crea o actualiza `plans/README.md` con: una tabla de planes (número, título, severidad, estado), el orden de ejecución recomendado y cualquier dependencia entre planes.
