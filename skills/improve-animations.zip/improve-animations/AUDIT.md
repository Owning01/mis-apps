# Playbook de auditoría de animaciones

Las ocho categorías de auditoría, qué buscar en cada una y los valores objetivo exactos que hay que citar en los hallazgos y los planes. Destilado de la filosofía de ingeniería de diseño de Emil Kowalski ([emilkowal.ski](https://emilkowal.ski/)). Nunca aproximes un valor que aparece aquí: cópialo.

## 1. Propósito y frecuencia

Toda animación debe responder "¿por qué se anima esto?": consistencia espacial, indicación de estado, feedback, explicación o evitar un cambio brusco. "Se ve genial" en un elemento que se ve seguido no es un propósito.

| Frecuencia | Decisión |
| --- | --- |
| 100+ veces/día (atajos de teclado, toggle del command palette) | Sin animación. Nunca. |
| Decenas de veces/día (efectos de hover, navegación de listas) | Quitar o reducir drásticamente |
| Ocasional (modales, cajones, toasts) | Animación estándar |
| Rara / primera vez (onboarding, feedback, celebraciones) | Puede añadir encanto |

Busca: animaciones en acciones iniciadas por teclado, command palettes con transiciones de apertura/cierre (Raycast no tiene ninguna — correcto), movimiento decorativo en ítems de lista o estados de hover que se golpean constantemente. El arreglo más fuerte suele ser **borrar la animación**.

## 2. Easing y duración

Orden de decisión para el easing:

- Entrando o saliendo → **`ease-out`** (empieza rápido, se siente responsive)
- Moviéndose o transformándose en pantalla → **`ease-in-out`**
- Hover o cambio de color → **`ease`**
- Movimiento constante (marquesina, progreso) → **`linear`**
- Por defecto → **`ease-out`**

**`ease-in` en UI siempre es un hallazgo**: empieza lento, retrasando justo el momento que el usuario está mirando. Los easings incluidos en CSS son demasiado débiles para movimiento deliberado; los planes deberían introducir curvas propias fuertes (como tokens, siguiendo las convenciones del repo):

```css
--ease-out: cubic-bezier(0.23, 1, 0.32, 1);        /* ease-out fuerte para UI */
--ease-in-out: cubic-bezier(0.77, 0, 0.175, 1);    /* ease-in-out fuerte para movimiento en pantalla */
--ease-drawer: cubic-bezier(0.32, 0.72, 0, 1);     /* curva de cajón al estilo iOS */
```

Presupuestos de duración — **las animaciones de UI se quedan bajo 300ms**:

| Elemento | Duración |
| --- | --- |
| Feedback de pulsación de botón | 100–160ms |
| Tooltips, popovers pequeños | 125–200ms |
| Dropdowns, selects | 150–250ms |
| Modales, cajones | 200–500ms |
| Marketing / explicativas | Pueden ser más largas |

Busca: `ease-in` en cualquier lado, `ease`/`linear` crudos en entradas, duraciones > 300ms en elementos de UI, delay + animación en cada tooltip de una barra de herramientas (después del primero deberían ser instantáneos).

## 3. Fisicalidad y origen

- **Nunca `scale(0)`** — nada en el mundo real aparece de la nada. Objetivo: `scale(0.9–0.97)` + `opacity: 0`.
- **Los popovers/dropdowns/tooltips escalan desde su disparador**, no desde el centro:
  ```css
  .popover { transform-origin: var(--transform-origin); } /* Base UI */
  ```
  **Los modales están exentos**: aparecen centrados; ahí `transform-origin: center` es correcto. No lo reportes.
- **Feedback de pulsación**: `transform: scale(0.97)` en `:active` con `transition: transform 160ms ease-out`. Mantenlo sutil (0.95–0.98).

Busca: `scale(0)`, entradas solo-fade sin transform inicial, `transform-origin: center` (o ninguno) en elementos anclados a su disparador, elementos pulsables sin feedback de pulsación.

## 4. Interrumpibilidad

Las **transiciones** de CSS recalculan el destino desde el estado actual a mitad de animación; los **fotogramas clave** reinician desde cero. Todo lo que se dispara rápido o es reversible a mitad de movimiento (toasts apilados, toggles, arrastres, expandir/contraer) debe usar transiciones o resortes.

- Entrada sin JS: `@starting-style` (fallback legado: un atributo `data-mounted` seteado en `useEffect`).
- El movimiento por gesto debería usar resortes: conservan la velocidad al interrumpirse.
- Configs de resorte al estilo Apple (recomendado): `{ type: "spring", duration: 0.5, bounce: 0.2 }`. Mantén el rebote sutil (0.1–0.3); reserva el rebote visible para el drag-to-dismiss y los momentos jugetones.
- **Timing asimétrico**: las fases deliberadas (pulsación, sostén, confirmación destructiva) animan más lento; la respuesta del sistema es inmediata. Timing simétrico en pulsar-y-soltar es un hallazgo.

Busca: `@keyframes` en toasts/toggles/UI disparada rápidamente, gesture handlers que hacen tween con fotogramas clave de duración fija, arrastres sin descarte basado en velocidad (descarta con `Math.abs(distance)/elapsedMs > ~0.11`, no solo con umbrales de distancia), topes secos en los límites del drag en vez de una fricción creciente.

## 5. Rendimiento

- **Anima solo `transform` y `opacity`.** `width`/`height`/`margin`/`padding`/`top`/`left` disparan layout + paint + composite.
- **`transition: all`** anima propiedades no deseadas fuera de la GPU: siempre es un hallazgo.
- **Los atajos `x`/`y`/`scale` de Framer Motion no tienen aceleración por hardware**: corren en el hilo principal y pierden frames bajo carga. Objetivo: el string completo de transform, `animate={{ transform: "translateX(100px)" }}`.
- **No muevas transforms de hijos mediante una variable CSS en el padre**: recalcula los estilos de todos los hijos. Setea `transform` directamente en el elemento.
- CSS (y WAAPI) le ganan al JS basado en rAF bajo carga: usa CSS para movimiento predeterminado, JS/resortes para movimiento dinámico y por gesto.
- Mantén el `filter: blur()` de transición por debajo de 20px: el blur pesado es caro, especialmente en Safari.

Busca: `transition: all`, propiedades de layout animadas, props abreviadas de Framer Motion en páginas con tráfico, `setProperty('--x', …)` moviendo transforms de hijos, loops de rAF haciendo lo que CSS podría hacer.

## 6. Accesibilidad

```css
@media (prefers-reduced-motion: reduce) {
  .element { animation: fade 0.2s ease; } /* conserva opacity/color, quita movimiento */
}
@media (hover: hover) and (pointer: fine) {
  .element:hover { transform: scale(1.05); } /* el touch dispara hovers falsos al tocar */
}
```

Movimiento reducido significa menos animaciones y más suaves, **no cero**: conserva las transiciones que ayudan a comprender, quita los cambios de posición. En JS: `useReducedMotion()` y bifurca los valores de transform.

Busca: movimiento sin manejo de `prefers-reduced-motion`, movimiento en `:hover` sin condiciones, implementaciones de movimiento reducido que eliminan todo el feedback.

## 7. Cohesión y tokens

- El movimiento debería coincidir con la personalidad del producto: lo jugetón puede rebotar más, un dashboard se mantiene nítido. Una personalidad despareja entre componentes es un hallazgo.
- Las curvas y duraciones deberían vivir como tokens compartidos. Cinco cubic-beziers escritos a mano que casi coinciden son un hallazgo de consolidación.
- Entradas de grupo todo-de-golpe-a-la-vez donde debería haber un **escalonado de 30–80ms**. El escalonado es decorativo: nunca debe bloquear la interacción.
- Un crossfade brusco que muestra dos estados superpuestos se puede enmascarar con un `filter: blur(2px)` sutil durante la transición.

Busca: easings/duraciones casi idénticos duplicados, un componente que rebota dentro de una app nítida, entradas de lista/grid sin escalonado, crossfades que visiblemente superponen doble.

## 8. Oportunidades perdidas

La categoría aditiva: lugares que no animan y deberían:

- Cambios de estado que se teletransportan (intercambios de contenido, saltos de layout) donde una transición breve evitaría un cambio brusco.
- UI conectada espacialmente (un panel que aparece desde un disparador) sin ningún movimiento que explique de dónde salió.
- Momentos raros y de alta carga emocional (primera ejecución, éxito, celebración) renderizados sin nada del presupuesto de encanto que se les permite.
- Porcentajes de `translate` (`translateY(100%)` = la altura del propio elemento) y revelados con `clip-path: inset()` como herramientas para esto: nada de offsets en píxeles hardcodeados.

Reporta como máximo unas cuantas, fundamentadas en costuras de UX reales que observaste: no es una lista de deseos.
