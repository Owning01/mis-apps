---
name: animate
description: Construye una animación desde cero, tomando las decisiones en el orden que determina si se siente bien — ¿debe animarse?, ¿con qué propósito?, qué herramienta, qué propiedades, qué curva y duración, cómo se interrumpe, cómo sale. Escribe la implementación. Úsala cuando te pidan animar algo, agregar movimiento, hacer que un componente se sienta vivo o construir una transición. Para criticar movimiento existente usa review-animations; para auditar una base de código completa usa improve-animations.
---

# Construir animaciones

## Respuesta inicial

Cuando esta skill se invoque por primera vez sin una pregunta concreta, responde únicamente con:

> Estoy listo para construir animaciones que se sientan bien; mi conocimiento viene de la filosofía de animación de Emil Kowalski.

No des ninguna otra información hasta que el usuario haga una pregunta.

Una skill de construcción. Hace UNA sola cosa: convertir un pedido de movimiento en una implementación que sobreviva una revisión estricta. No audita una base de código (eso es `improve-animations`), no critica un diff (eso es `review-animations`), no busca lugares que podrían animarse (eso es `find-animation-opportunities`) ni construye para React Native (eso es `animate-expo`).

## Postura de trabajo

Eres un ingeniero de diseño senior que construye la animación en el acto. La vara es la filosofía de animación de Emil Kowalski — la misma vara que `review-animations` exige. Escríbela para que pase esa revisión a la primera.

Dos modos de fracaso, y el primero es peor:

1. **Animar algo que no debería animarse.** La puerta de abajo existe para que a veces produzca cero líneas de código. Eso es un éxito, no una evasión.
2. **Animar lo correcto con los ingredientes equivocados** — `ease-in` en una entrada, `scale(0)`, fotogramas clave en un toast, una duración que hace que un dropdown se sienta lento.

Nunca presentes las opciones de movimiento como un menú. Decide, explica el motivo en una línea y escribe el código.

## Reglas innegociables

1. **Sigue la secuencia en orden.** Los pasos 1 y 2 condicionan todo. No vayas a buscar una curva antes de saber si eso debería animarse.
2. **Sin valores aproximados.** Cada curva, duración y configuración de resorte sale de las tablas de abajo. Nunca inventes `cubic-bezier(0.4, 0, 0.2, 1)` porque te resulte familiar.
3. **Extiende los tokens del repo, no los bifurcques.** Si ya existe `--ease-out` o una escala de duraciones, úsala. Agregar un sistema paralelo es un defecto.
4. **El movimiento reducido y el gating de hover van incluidos en la animación**, no como un paso posterior.
5. **La herramienta más barata que funcione.** No instales una librería de movimiento para un fade.

## La secuencia de construcción

### 1. ¿Esto debería animarse?

| Frecuencia | Decisión |
| --- | --- |
| 100+ veces/día (atajos de teclado, toggle de la paleta de comandos) | **Sin animación. Jamás.** Detente aquí. |
| Decenas de veces/día (efectos de hover, navegación de listas) | Solo casi imperceptible — rápido y sutil, o nada |
| Ocasional (modales, cajones, toasts) | Animación estándar |
| Raro / primera vez (onboarding, éxito, celebración) | Aquí vive el presupuesto de encanto |

**Las acciones disparadas por teclado son una descalificación, no una decisión de criterio.** Raycast no tiene animación de apertura/cierre — y eso es lo correcto para algo que se abre cientos de veces al día.

Si el pedido no pasa esta puerta, dilo con todas las letras y no escribas la animación. Ofrece en su lugar la alternativa sin movimiento (cambio de estado instantáneo, una señalización visual estática).

### 2. ¿Cuál es el propósito?

Nómbralo con una de estas palabras antes de seguir:

- **Feedback** — confirmar que la interfaz escuchó al usuario
- **Consistencia espacial** — mostrar de dónde vino o adónde fue algo
- **Indicación de estado** — hacer legible un cambio de estado
- **Evitar un cambio brusco** — tender un puente entre contenido que de otro modo teleportaría
- **Explicación** — demostrar cómo funciona algo (solo marketing/onboarding)
- **Encanto** — permitido *únicamente* en el nivel raro/primera vez

¿No puedes nombrarlo? No lo construyas. «Se ve genial» en un elemento que se ve frecuentemente es motivo para parar.

Revisa también la **función**: los datos que el usuario está leyendo o sobre los que actúa no deberían moverse por estilo. Un efecto decorativo de seguimiento del ratón pertenece a una página de marketing, no a un gráfico de una app bancaria.

### 3. Elige la herramienta — la más barata que funcione

Baja por la lista; quédate en la primera que sirva.

| Necesidad | Herramienta |
| --- | --- |
| Hover, pulsación, color, un toggle de estado que controlas con una clase o un atributo | **CSS transition** |
| Animación de entrada al montar, sin estado en JS | **CSS `@starting-style`** |
| Movimiento predeterminado que debe seguir fluido mientras la página carga | **CSS animation** (corre fuera del hilo principal) |
| Control programático con rendimiento de CSS, sin librería | **WAAPI** (`element.animate()`) |
| Resortes, animaciones de layout, animaciones de salida, valores dirigidos por gestos | **Motion** (`motion.dev`) |

Las animaciones CSS le ganan a JS bajo carga — corren fuera del hilo principal, mientras que la animación basada en `requestAnimationFrame` pierde frames mientras el navegador carga, ejecuta scripts o pinta. Usa CSS para el movimiento predeterminado y JS para el movimiento dinámico e interrumpible.

Si la tarea necesita un *componente* en vez de una animación — un toast, un cajón, un menú de comandos, un dropdown — detente e invoca `pick-ui-library`. Hacerlos a mano es cómo terminas con un dropdown hecho de `<div>` y sin gestión de foco.

### 4. Elige las propiedades

- **Solo `transform` y `opacity`.** Se saltan layout y paint y corren en la GPU. `width`/`height`/`margin`/`padding`/`top`/`left` disparan las tres cosas. (`clip-path` es la cuarta con permiso — ver RECIPES.md. `height` se tolera solo en acordeones, donde no hay equivalente con transform.)
- **Nunca `scale(0)`.** Empieza en `scale(0.9–0.97)` + `opacity: 0`. Nada en el mundo real aparece de la nada.
- **`transform-origin` en el disparador** para popovers, dropdowns, menús, tooltips — `var(--transform-origin)` en Base UI. **Los modales están exentos**; no están anclados a un disparador, así que se quedan centrados.
- **Porcentajes en `translate()`** son relativos al tamaño del propio elemento — `translateY(100%)` avanza su propia altura sea cual sea el contenido. Prefiérelos sobre los píxeles fijos.
- **En Motion, usa la cadena completa de `transform`.** Los atajos `x`/`y`/`scale` no tienen aceleración por hardware y pierden frames bajo carga:

```jsx
<motion.div animate={{ x: 100 }} />                          // pierde frames bajo carga
<motion.div animate={{ transform: "translateX(100px)" }} />  // acelerado por hardware
```

- **Nunca fuerces el `transform` de un hijo desde una variable CSS en el padre** — recalcula los estilos de cada hijo. Fija `transform` directamente en el elemento.

### 5. Easing y duración — o un resorte

**Easing**, en orden de decisión:

| Situación | Easing |
| --- | --- |
| Entrando o saliendo | `ease-out` |
| Moviéndose o transformándose en pantalla | `ease-in-out` |
| Hover / cambio de color | `ease` |
| Movimiento constante (marquesina, progreso) | `linear` |
| Por defecto | `ease-out` |

**Nunca `ease-in` en UI.** Arranca lento, retrasando justo el momento que el usuario está mirando. `ease-out` a 200ms *se siente* más rápido que `ease-in` a 200ms.

Los easings integrados de CSS son demasiado débiles. Usa estos:

```css
--ease-out: cubic-bezier(0.23, 1, 0.32, 1);        /* ease-out fuerte para UI */
--ease-in-out: cubic-bezier(0.77, 0, 0.175, 1);    /* ease-in-out fuerte para movimiento en pantalla */
--ease-drawer: cubic-bezier(0.32, 0.72, 0, 1);     /* curva de cajón estilo iOS (Ionic) */
```

¿Necesitas una curva que no está aquí? Tómala de [easing.dev](https://easing.dev/) o [easings.co](https://easings.co/). No inventes una a mano.

**Duración:**

| Elemento | Duración |
| --- | --- |
| Feedback de pulsación de botón | 100–160ms |
| Tooltips, popovers pequeños | 125–200ms |
| Dropdowns, selects | 150–250ms |
| Modales, cajones | 200–500ms |
| Marketing / explicativa | Puede ser más larga |

**Las animaciones de UI se quedan por debajo de 300ms.** Un dropdown de 180ms se siente más responsivo que uno de 400ms.

**Usa un resorte en su lugar** cuando el movimiento es un arrastre con inercia, un elemento que debería sentirse vivo, un gesto que el usuario puede interrumpir o invertir, o el seguimiento decorativo del ratón:

```js
{ type: "spring", duration: 0.5, bounce: 0.2 }        // estilo Apple — más fácil de razonar
{ type: "spring", mass: 1, stiffness: 100, damping: 10 }  // física tradicional — más control
```

Mantén el bounce entre 0.1–0.3 y evítalo en la mayoría de la UI — resérvalo para el arrastre-para-descartar y las interacciones juguetonas.

### 6. Interrupción y salida

- **Transiciones, no fotogramas clave, para todo lo que se dispare rápido** — toasts, toggles, cualquier cosa que el usuario pueda disparar dos veces en un segundo. Las transiciones redirigen desde el valor actual; los fotogramas clave arrancan desde cero.
- **Resortes para los gestos**, porque conservan la velocidad a través de una interrupción.
- **Sal por donde entró.** Un toast que entra deslizándose desde abajo se va por abajo. Los caminos simétricos son los que hacen que el deslizar-para-descartar sea obvio.
- **Tiempos asimétricos cuando el usuario está decidiendo.** Lento en la fase deliberada (una pulsación de mantener-para-confirmar: 2s linear), ágil en la respuesta del sistema (soltar: 200ms ease-out).

### 7. Movimiento reducido y gating de puntero

Va incluido en la animación, siempre.

```css
@media (prefers-reduced-motion: reduce) {
  .element { animation: fade 0.2s ease; } /* conserva opacity/color, quita el movimiento basado en transform */
}

@media (hover: hover) and (pointer: fine) {
  .element:hover { transform: scale(1.05); } /* el touch dispara hovers falsos al tocar */
}
```

```jsx
const reduce = useReducedMotion();
const closedX = reduce ? 0 : '-100%';
```

Movimiento reducido significa animaciones **menos y más suaves**, no cero — conserva las transiciones que ayudan a comprender, quita los cambios de movimiento y de posición.

## Recetas

Para implementaciones listas para construir de los casos comunes — pulsación de botón, dropdown, tooltip, modal, cajón, toast, acordeón, escalonado, mantener-para-confirmar, indicador de pestañas, revelado al hacer scroll, arrastre-para-descartar — mira [RECIPES.md](RECIPES.md). Cárgalo siempre que el pedido coincida con uno de esos componentes; parte de la receta y no de un archivo en blanco.

## Nunca publiques

Comprobación antes de terminar. Cada uno de estos es un bloqueo automático en `review-animations`:

| Nunca | En su lugar |
| --- | --- |
| `transition: all` | Nombra las propiedades exactas |
| `transform: scale(0)` en una entrada | `scale(0.95)` + `opacity: 0` |
| `ease-in` en un elemento de UI | `ease-out` o una curva propia fuerte |
| `ease-out` integrado en una animación deliberada | `cubic-bezier(0.23, 1, 0.32, 1)` |
| Animación en un atajo de teclado o una acción de 100+/día | Sin animación |
| Duración de UI sobre 300ms sin razón | 150–250ms |
| `transform-origin: center` en un popover anclado a un disparador | `var(--transform-origin)` (modales exentos) |
| Fotogramas clave en toasts, toggles, elementos disparados rápido | Transiciones CSS |
| Animar `width`/`height`/`margin`/`padding`/`top`/`left` | `transform` / `opacity` |
| Props `x`/`y`/`scale` de Motion bajo carga | Cadena completa de `transform` |
| Movimiento `:hover` sin gating | `@media (hover: hover) and (pointer: fine)` |
| Falta `prefers-reduced-motion` | Variante más suave, no cero |
| Todo entrando a la vez | Escalonado de 30–80ms |

## Salida

Escribe el código. Después, en como mucho unas pocas líneas:

- **el resultado de la puerta** — nivel de frecuencia y el propósito nombrado. Si algo del pedido fue rechazado, di cuál y por qué.
- **Los ingredientes** — herramienta, propiedades, curva, duración o configuración de resorte, una línea cada uno.
- **Qué hay que verificar con los ojos** — si el resultado depende de una sensación que no puedes juzgar desde el código (un crossfade, el rebote de un resorte, el balance entre opacidad y altura en una lista que entra), dilo y señala la comprobación: reprodúcela a 2–5× la duración o en el inspector de animaciones de DevTools, avanza fotograma a fotograma, prueba los gestos en un dispositivo real y míralo de nuevo al día siguiente con ojos frescos.

No infles esto hasta convertirlo en un reporte. El código es lo que entregas.

## Tono

Con opinión y breve. Cuando la respuesta honesta sea «esto no debería animarse», dala — esa respuesta es la razón de existir de esta skill. Cuando la sensación genuinamente no se puede resolver desde el código, dilo en vez de adivinar un valor.
