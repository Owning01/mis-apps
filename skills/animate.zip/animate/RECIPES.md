# Recetas de animación

Implementaciones listas para construir de los casos que más se repiten. Parte de la receta y después adapta — no reconstruyas desde cero.

Las curvas son los tokens `--ease-out`, `--ease-in-out` y `--ease-drawer` definidos en SKILL.md.

---

## Pulsación de botón

Cualquier elemento presionable. Feedback instantáneo de que la interfaz escuchó al usuario.

```css
.button {
  transition: transform 160ms var(--ease-out);
}

.button:active {
  transform: scale(0.97);
}
```

`scale()` escala también a los hijos — la etiqueta y los iconos vienen con él, y eso es lo que hace que se lea como una pulsación física.

Aquí no hace falta gating de hover: `:active` es una pulsación real en touch. Gatea por separado cualquier estilo `:hover`.

---

## Dropdown, popover, menú, select

Escala desde su disparador, no desde la nada.

```css
.popover {
  transform-origin: var(--transform-origin); /* Base UI provee esto */
  transition:
    opacity 200ms var(--ease-out),
    transform 200ms var(--ease-out);
}

.popover[data-starting-style],
.popover[data-ending-style] {
  opacity: 0;
  transform: scale(0.95);
}
```

El `transform-origin` es todo el punto — el panel debería verse como si saliera de aquello en lo que hiciste clic.

---

## Tooltip

La misma forma que un popover, más rápido, más el detalle que casi todas las implementaciones se saltan.

```css
.tooltip {
  transform-origin: var(--transform-origin);
  transition:
    transform 125ms var(--ease-out),
    opacity 125ms var(--ease-out);
}

.tooltip[data-starting-style],
.tooltip[data-ending-style] {
  opacity: 0;
  transform: scale(0.97);
}

/* Una vez que hay un tooltip abierto, los vecinos se abren al instante */
.tooltip[data-instant] {
  transition-duration: 0ms;
}
```

El retardo inicial evita la activación accidental. Después de eso, saltarte tanto el retardo como la animación hace que toda la barra se sienta más rápida.

---

## Modal

El único popover que se queda centrado.

```css
.modal {
  transform-origin: center; /* exento — no está anclado a un disparador */
  transition:
    opacity 250ms var(--ease-out),
    transform 250ms var(--ease-out);
}

.modal[data-starting-style],
.modal[data-ending-style] {
  opacity: 0;
  transform: scale(0.96);
}

.backdrop {
  transition: opacity 250ms var(--ease-out);
}
```

Anima la opacidad del fondo junto con él para que se lean como una sola superficie.

---

## Cajón / hoja

```css
.drawer {
  transform: translateY(0);
  transition: transform 500ms var(--ease-drawer);
}

.drawer[data-closed] {
  transform: translateY(100%);
}
```

Así es como Vaul oculta un cajón antes de animarlo hacia dentro.

Agrégale arrastre y se convierte en un problema de gestos — mira **Arrastre para descartar** más abajo.

---

## Toast

```css
.toast {
  opacity: 1;
  transform: translateY(0);
  transition:
    opacity 400ms ease,
    transform 400ms ease;

  @starting-style {
    opacity: 0;
    transform: translateY(100%);
  }
}
```

- `ease` en vez de `ease-out`, algo más lento que lo típico en UI: Sonner se lee como elegante en parte porque su movimiento está afinado a la personalidad del componente y no al presupuesto genérico de UI.
- Si `@starting-style` no está disponible, cae a la bandera de montaje:

```jsx
useEffect(() => { setMounted(true); }, []);
// <div data-mounted={mounted}>
```

Cuando los toasts se apilan y la lista se reacomoda, el cambio de opacidad tiene que trabajar contra el cambio de altura. No hay fórmula para ese par — ajústalo hasta que se sienta bien y después revísalo de nuevo al día siguiente.

---

## Acordeón / colapso

```css
.content {
  overflow: hidden;
  transition:
    height 200ms var(--ease-out),
    opacity 200ms var(--ease-out);
}
```

Mantenla corta — esta es una de las pocas animaciones que cuesta layout en cada fotograma, así que una duración larga es cara además de lenta. Mide la altura del contenido en JS (o usa una primitiva headless que la provea) en vez de animar hacia `auto`.

---

## Escalonar una entrada en grupo

Para una lista o grilla que el usuario ve ocasionalmente — no para una lista que desplace todo el día.

```css
.item {
  opacity: 0;
  transform: translateY(8px);
  animation: fadeIn 300ms var(--ease-out) forwards;
}

.item:nth-child(2) { animation-delay: 50ms; }
.item:nth-child(3) { animation-delay: 100ms; }
.item:nth-child(4) { animation-delay: 150ms; }

@keyframes fadeIn {
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
```

El escalonado es decorativo — nunca debe bloquear la interacción mientras corre.

---

## Mantener pulsado para confirmar

Para acciones destructivas donde un clic normal es demasiado fácil de disparar por accidente.

```css
.overlay {
  clip-path: inset(0 100% 0 0);
  transition: clip-path 200ms var(--ease-out); /* soltar: ágil */
}

.button:active .overlay {
  clip-path: inset(0 0 0 0);
  transition: clip-path 2s linear;             /* pulsar: lento y deliberado */
}

.button:active {
  transform: scale(0.97);
}
```

`linear` es lo correcto aquí — el relleno es un indicador de progreso, y el progreso no debería usar easing.

---

## Indicador de pestañas con transición de color

Ajustar los tiempos de las transiciones de color individuales a lo largo de una lista de pestañas nunca queda del todo bien. Recorta en su lugar.

Duplica la lista de pestañas. Estila la copia como el estado activo — fondo distinto, color de texto distinto. Recorta la copia para que solo se vea la pestaña activa, y anima el recorte al cambiar:

```css
.tabs-active-copy {
  clip-path: inset(0 60% 0 20%); /* lo maneja la posición de la pestaña activa */
  transition: clip-path 250ms var(--ease-in-out);
}
```

El texto y el fondo cambian juntos, perfectamente sincronizados, porque son un solo elemento que se revela y no dos colores que se interpolan.

---

## Revelado al hacer scroll

Solo superficies de marketing. No hagas esto en UI funcional que el usuario visita a diario.

```css
.reveal {
  clip-path: inset(0 0 100% 0);
  transition: clip-path 600ms var(--ease-in-out);
}

.reveal[data-visible] {
  clip-path: inset(0 0 0 0);
}
```

Disparalo con `IntersectionObserver`, o con el `useInView` de Motion y `{ once: true, margin: "-100px" }`. Dispara una sola vez — reanimar en cada scroll es una interfaz peleando con su lector.

---

## Arrastre para descartar

La receta de gestos. Resortes, no duraciones, porque el usuario puede invertir a mitad del movimiento.

```js
// Descartar con un flick, no solo por distancia
const timeTaken = Date.now() - dragStartTime.current;
const velocity = Math.abs(swipeAmount) / timeTaken;

if (Math.abs(swipeAmount) >= SWIPE_THRESHOLD || velocity > 0.11) {
  dismiss();
}
```

```js
// Fija transform directamente en el elemento arrastrado.
// Manejarlo por una variable CSS en el padre recalcula los estilos de cada hijo.
element.style.transform = `translateY(${distance}px)`;
```

Cuatro detalles que separan un buen arrastre de uno malo:

- **Captura del puntero** una vez que empieza el arrastre, para que continúe cuando el puntero sale de los límites del elemento.
- **Protección multitáctil** — `if (isDragging) return` en los nuevos puntos de contacto, o cambiar de dedo a mitad del arrastre hace que el elemento salte.
- **Amortiguación más allá de los límites** — arrastrar más allá de un borde natural mueve el elemento menos cuanto más se va. Las cosas reales frenan antes de detenerse.
- **Fricción, no un muro** — permite el sobrearrastre con resistencia creciente en vez de rechazarlo.

Asienta con un resorte para que un arrastre interrumpido conserve su velocidad:

```js
{ type: "spring", duration: 0.5, bounce: 0.2 }
```

---

## Enmascarar un crossfade que no se asienta

Cuando dos estados se superponen visiblemente durante una transición y ningún ajuste de easing o de duración lo resuelve, difumina la costura:

```css
.content {
  transition:
    filter 200ms ease,
    opacity 200ms ease;
}

.content.transitioning {
  filter: blur(2px);
  opacity: 0.7;
}
```

Sin blur, el ojo lee dos objetos distintos que se intercambian. El blur los funde en una sola transformación percibida. Mantenlo por debajo de 20px — un blur fuerte es caro, especialmente en Safari.

---

## Programático, sin librería

Cuando el movimiento necesita control desde JS pero no una dependencia, WAAPI te da rendimiento de nivel CSS:

```js
element.animate(
  [{ clipPath: 'inset(0 0 100% 0)' }, { clipPath: 'inset(0 0 0 0)' }],
  { duration: 1000, fill: 'forwards', easing: 'cubic-bezier(0.77, 0, 0.175, 1)' }
);
```

Acelerado por hardware, interrumpible, sin costo de bundle.
