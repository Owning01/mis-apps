---
name: animation-vocabulary
description: Glosario de consulta inversa que convierte una descripción vaga de una animación web o de un efecto de movimiento en su término exacto ("la cosa que rebota cuando se abre un popover" → Pop in (aparición con rebote); "el scroll con resistencia de iOS" → Rubber-banding (elasticidad al deslizar)). Úsala cuando el usuario pregunte "¿cómo se llama cuando…", o describa un efecto de movimiento sin conocer su nombre y necesite la palabra correcta para decírsela a una IA o a un diseñador. Para nombrar efectos, no para diseñarlos ni construirlos.
---

# Vocabulario de animación

## Respuesta inicial

Cuando esta skill se invoque por primera vez sin una pregunta concreta, responde únicamente con:

> Estoy listo para ponerle nombre a cualquier efecto de movimiento que me describas; mi conocimiento viene de la filosofía de animación de Emil Kowalski.

No des ninguna otra información hasta que el usuario haga una pregunta.

Convierte una descripción vaga de un movimiento o efecto en el término preciso, para que el usuario sepa qué pedir.

## Inicio rápido

El usuario describe un efecto de forma aproximada. Tú devuelves el término o los términos correspondientes en este formato:

```
**Stagger** (escalonado) — Anima varios elementos uno tras otro con un pequeño retraso entre cada uno, creando una cascada.
```

Si varios términos pudieran encajar, lista primero el mejor acierto y luego 1 o 2 alternativas con una nota de una línea sobre en qué difieren.

## Instrucciones

1. **Lee la intención, no las palabras clave.** Los usuarios describen lo que *ven* o *sienten* ("con muelle", "se desliza hacia afuera", "se dibuja solo"), no el nombre técnico. Mapea la sensación al glosario de abajo.
2. **Cita el glosario al pie de la letra.** Sus descripciones son autoritativas: úsalas tal cual, no las parafrasees.
3. **Desambigua términos cercanos.** Cuando compitan dos (*Clip-path* (recorte con forma) vs *Mask* (máscara), *Pop in* (aparición con rebote) vs *Bounce* (rebote al asentarse), *Shared element transition* (transición de elemento compartido) vs *Layout animation* (animación de layout)), contrástalos para que el usuario pueda elegir.
4. **Cuando nada coincida exactamente,** nombra el término más cercano y di con franqueza que es una aproximación, o describe el efecto con el vocabulario del glosario (p. ej. "es un *stagger* (escalonado) de entradas *scale-in* (escala al entrar)").
5. **Quédate dentro de este glosario.** Si un término de verdad no está aquí, dilo en vez de inventarlo — aunque sí puedes explicar el concepto con estas palabras.
6. **Sé conciso.** Una pregunta de nombres quiere un nombre, no un ensayo. Empieza por el término y amplía solo si te lo piden.

## Ejemplos

**Ejemplo 1 — basado en sensación**
Usuario: "¿Cómo se llama cuando un popover parece crecer desde el botón que pulsaste en lugar de desde su propio centro?"
Salida:
```
**Origin-aware animation** — Un elemento se anima desde su disparador, como un popover que crece desde el botón que lo abrió en vez de desde su propio centro, que es el valor por defecto en CSS.
```

**Ejemplo 2 — desambiguación**
Usuario: "Lo de que una imagen se convierte en otra imagen."
Salida:
```
**Morph** — Una forma se transforma suavemente en otra forma, p. ej. Dynamic Island.

Alternativas cercanas:
- **Crossfade** — si simplemente se desvanecen una sobre otra en el mismo lugar.
- **Shared element transition** — si un elemento viaja y se transforma de una posición a otra.
```

**Ejemplo 3 — sensación física**
Usuario: "Ese scroll de iOS que opone resistencia y vuelve cuando tiras demasiado."
Salida:
```
**Rubber-banding** — Resistencia y retorno elástico cuando arrastras más allá de un límite (la sensación de overscroll de iOS).
```

## Glosario

_Una instantánea curada que refleja la página `/vocabulary` del proyecto; mantén ambas sincronizadas cuando cambie cualquiera de las dos._

### Entradas y salidas — cómo aparecen y desaparecen los elementos
- **Fade in / Fade out** — El elemento aparece o desaparece cambiando su opacidad.
- **Slide in** — El elemento entra deslizándose desde fuera de la pantalla (izquierda, derecha, arriba o abajo).
- **Scale in** — El elemento crece desde un tamaño menor hasta el completo al aparecer, a menudo junto con un fundido.
- **Pop in** — El elemento aparece con un leve exceso de recorrido, como si rebotara hasta su lugar.
- **Reveal** — El contenido se descubre gradualmente, a menudo animando un clip-path o una máscara.
- **Enter / Exit** — La animación que reproduce un elemento cuando se agrega a la pantalla o se quita de ella.

### Secuenciación y tiempos — coordinar varios elementos o momentos
- **Keyframes** — Puntos definidos dentro de una animación (0%, 50%, 100%) entre los que el navegador rellena los huecos.
- **Interpolation / Tween** — Generar todos los fotogramas intermedios entre un valor inicial y uno final, para que el movimiento sea continuo.
- **Stagger** — Anima varios elementos uno tras otro con un pequeño retraso entre cada uno, creando una cascada.
- **Orchestration** — Ajustar deliberadamente los tiempos de varias animaciones para que se sientan como un movimiento coordinado.
- **Delay** — Tiempo que pasa antes de que empiece una animación.
- **Duration** — Cuánto tarda una animación.
- **Fill mode** — Si el elemento conserva los estilos de su primer o último fotograma antes de que empiece la animación o después de que termine (p. ej. forwards).
- **Stepped animation** — Una animación dividida en pasos discretos, como la de un temporizador de cuenta regresiva.

### Movimiento y transformaciones — cambiar la posición, el tamaño o el ángulo de un elemento
- **Translate** — Mover un elemento a lo largo del eje X o Y.
- **Scale** — Hacer un elemento más grande o más pequeño.
- **Rotate** — Girar un elemento alrededor de un punto.
- **Skew** — Inclinar un elemento a lo largo del eje X o Y, deformándolo fuera de su forma rectangular.
- **3D tilt / Flip** — Rotar en el espacio 3D (rotateX / rotateY) para agregar profundidad.
- **Perspective** — Qué tan fuerte se ve el efecto 3D: un valor más bajo exagera la profundidad, como si el observador estuviera más cerca.
- **Transform origin** — El punto de anclaje desde el que crece o gira un escalado o una rotación.
- **Origin-aware animation** — Un elemento se anima desde su disparador, como un popover que crece desde el botón que lo abrió en vez de desde su propio centro, que es el valor por defecto en CSS.

### Transiciones entre estados — conectar un estado, una vista o un elemento con otro
- **Crossfade** — Un elemento se desvanece mientras otro aparece, en el mismo lugar.
- **Continuity transition** — Un cambio que mantiene al usuario orientado conectando visualmente el antes y el después. Por ejemplo, agrandar y encoger el mismo rectángulo.
- **Morph** — Una forma se transforma suavemente en otra forma, p. ej. Dynamic Island.
- **Shared element transition** — Un elemento viaja y se transforma de una posición a otra, como una miniatura que se expande en una tarjeta.
- **Layout animation** — Cuando el tamaño o la posición de un elemento cambia, se anima hacia el nuevo lugar en vez de saltar de golpe.
- **Accordion / Collapse** — Una sección expande y contrae suavemente su altura para mostrar u ocultar contenido.
- **Direction-aware transition** — El contenido se desliza en una dirección al avanzar y en la contraria al retroceder, para que la navegación tenga sentido de dirección.

### Desplazamiento (scroll) — movimiento asociado al scroll o a la navegación entre vistas
- **Scroll reveal** — Los elementos se funden o se deslizan hasta su lugar al entrar en la zona visible.
- **Scroll-driven animation** — Una animación cuyo progreso está atado directamente a la posición del scroll.
- **Parallax** — El fondo y el primer plano se mueven a distintas velocidades al desplazarse, creando profundidad.
- **Page transition** — Una animación que se reproduce al navegar de una página o ruta a otra.
- **View transition** — El navegador transforma dos estados o páginas conectando los elementos compartidos.

### Feedback e interacción — responder a las acciones del usuario
- **Hover effect** — Cambio visual cuando el cursor pasa sobre un elemento.
- **Press / Tap feedback** — Una leve reducción de escala al hacer clic en un elemento, para que se sienta físico.
- **Hold to confirm** — Un efecto de progreso que se llena mientras el usuario mantiene pulsado un botón.
- **Drag** — Mover un elemento agarrándolo, a menudo con inercia al soltarlo.
- **Drag to reorder** — Arrastrar elementos de una lista para reordenarlos, mientras los demás se apartan para hacer espacio.
- **Swipe to dismiss** — Arrastrar un elemento fuera de la pantalla para cerrarlo, como un cajón o una notificación emergente.
- **Rubber-banding** — Resistencia y retorno elástico cuando arrastras más allá de un límite (la sensación de overscroll de iOS).
- **Shake / Wiggle** — Un temblor rápido de lado a lado que señala un error o una entrada rechazada.
- **Ripple** — Un círculo que se expande desde el punto del toque, confirmando la pulsación.

### Easing (curvas de aceleración) — cómo cambia la velocidad a lo largo de una animación
- **Easing** — La velocidad a la que una animación acelera o frena.
- **Ease-out** — Empieza rápido, termina lento. El valor por defecto para casi toda UI y todo lo que responde al usuario.
- **Ease-in** — Empieza lento, termina rápido. Suele evitarse; puede sentirse perezoso.
- **Ease-in-out** — Lento, rápido, lento. Bueno para elementos que ya están en pantalla y van de A a B.
- **Linear** — Velocidad constante. Evitar en UI; reservarlo para indicadores de carga o marquesinas.
- **Cubic-bezier** — Una curva de easing personalizada que defines para tener control preciso.
- **Asymmetric easing** — Una curva que acelera y frena a ritmos distintos. Se siente más viva que una simétrica.

### Animaciones con spring (resorte) — movimiento basado en física como alternativa al easing de duración fija
- **Spring** — Movimiento gobernado por la física (tensión, masa, amortiguación) en vez de por una duración fija.
- **Stiffness / Tension** — Qué tan fuerte tira el resorte hacia su objetivo. Más alto se siente más seco.
- **Damping** — Qué tan rápido se asienta un resorte. Menos amortiguación significa más rebote y oscilación.
- **Mass** — Qué tan pesado se siente el elemento animado. Más masa lo hace más lento y perezoso.
- **Bounce** — Un resorte que se pasa de largo y luego se asienta, agregando un toque juguetón.
- **Perceptual duration** — Cuánto tarda un resorte en *sentirse* terminado, aunque por debajo siga asentándose a micro-nivel.
- **Momentum** — Movimiento que arrastra velocidad, sobre todo después de un arrastre o de una interrupción.
- **Velocity** — Qué tan rápido y en qué dirección se mueve un elemento. Un resorte la hereda en la animación siguiente cuando se lo interrumpe, así que un elemento lanzado conserva su velocidad.
- **Interruptible animation** — Una animación que puede redirigirse sin problemas a mitad de vuelo en vez de terminar primero.

### Bucles y movimiento de fondo — animaciones que se ejecutan solas
- **Marquee** — Texto o contenido que se desplaza continuamente en bucle.
- **Loop** — Una animación que se repite, un número determinado de veces o de forma infinita.
- **Alternate (yoyo)** — Un bucle que se reproduce hacia adelante y luego se invierte en cada iteración, en vez de volver de golpe al inicio.
- **Orbit** — Un elemento que gira alrededor de otro siguiendo una trayectoria continua.
- **Pulse** — Un cambio repetido y suave de escala u opacidad para llamar la atención.
- **Float** — Una deriva suave y continua de arriba abajo que hace que un elemento estático se sienta vivo y sin peso.
- **Idle animation** — Movimiento sutil que se reproduce mientras un elemento está ahí, esperando a que lo interactúen.

### Pulido y efectos — los pequeños toques que separan lo bueno de lo excelente
- **Blur** — Un filtro de desenfoque usado para suavizar un elemento o disimular pequeñas imperfecciones.
- **Clip-path** — Recortar un elemento con una forma; se usa para revelados, máscaras y deslizadores de antes/después.
- **Mask** — Ocultar o revelar partes de un elemento usando una forma o un degradado: como clip-path, pero con bordes suaves que se pueden desvanecer.
- **Before / after slider** — Un divisor arrastrable que barre entre dos imágenes superpuestas para compararlas.
- **Line drawing** — Un trazado SVG que se dibuja solo, como si un bolígrafo invisible lo recorriera.
- **Text morph** — Texto que se anima carácter por carácter al cambiar, llamando la atención sobre el nuevo valor.
- **Skeleton / Shimmer** — Un marcador de posición con un brillo en movimiento que se muestra mientras carga el contenido.
- **Number ticker** — Dígitos que ruedan o cuentan hasta un valor.
- **Tabular numbers** — Dígitos de ancho fijo para que los números no se desplacen al cambiar. Esencial para marcadores numéricos, temporizadores y contadores.
- **Typewriter** — Texto que aparece carácter a carácter, como si se estuviera escribiendo.

### Rendimiento (performance) — lo que mantiene el movimiento fluido en vez de entrecortado
- **Frame rate (FPS)** — Fotogramas dibujados por segundo. 60fps es la base para un movimiento fluido; 120fps en pantallas más nuevas.
- **Jank** — Tirones visibles cuando el navegador pierde fotogramas porque no puede seguirle el paso a la animación.
- **Dropped frame** — Un fotograma que el navegador no alcanzó a dibujar a tiempo, causando un pequeño tirón en el movimiento.
- **Compositing** — Dejar que la GPU mueva o desvanezca un elemento en su propia capa sin rehacer el layout ni el pintado.
- **will-change** — Un indicio en CSS de que un elemento está a punto de animarse, para que el navegador lo promueva a su propia capa con antelación.
- **Layout thrashing** — Animar propiedades como width, height, top o left que obligan al navegador a recalcular el layout en cada fotograma, provocando jank.

### Principios que conviene conocer — conceptos que guían cuándo y cómo animar
- **Purposeful animation** — El movimiento debe cumplir una función —orientar, dar feedback, mostrar relaciones— y no solo decorar.
- **Anticipation** — Una pequeña carga en la dirección contraria antes de un movimiento, que insinúa lo que está a punto de pasar.
- **Follow-through** — Las partes de un elemento siguen moviéndose y se asientan un poco después de que frene el movimiento principal, agregando peso.
- **Squash & stretch** — Deformar un elemento mientras se mueve para传达 peso, velocidad y flexibilidad.
- **Perceived performance** — La animación correcta hace que una interfaz se sienta más rápida, aunque no lo sea.
- **Frequency of use** — Cuanto más seguido ve un usuario una animación, más corta y sutil debería ser.
- **Spatial consistency** — Animar de modo que un elemento conserve su identidad y su posición entre estados, para que el usuario nunca pierda la pista de dónde acabaron las cosas.
- **Hardware acceleration** — Animar transform y opacity permite que la GPU mantenga el movimiento fluido.
- **Reduced motion** — Respetar el ajuste prefers-reduced-motion del usuario reduciendo o quitando el movimiento.
