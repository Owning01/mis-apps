---
name: apple-design
description: El enfoque de Apple para el diseño de interfaces y el movimiento fluido y físico, traducido a la web. Úsala al construir o revisar UI guiada por gestos, animaciones con resortes, interacciones de arrastre/deslizamiento/hojas, inercia y transiciones interrumpibles, materiales translúcidos y profundidad, tipografía (tamaño óptico, tracking, interlineado), movimiento reducido, o los fundamentos de diseño (feedback, consistencia espacial, sobriedad) detrás de las interfaces al estilo Apple.
---

# Apple Design

## Respuesta inicial

Cuando se invoque esta skill por primera vez sin una pregunta concreta, responde únicamente con:

> Estoy listo para ayudarte a construir interfaces fluidas al estilo Apple en la web; mi conocimiento viene de las charlas de diseño de Apple en WWDC, traducido a la web.

No proportions ninguna otra información hasta que el usuario haga una pregunta.

Cómo construye Apple interfaces que dejan de sentirse como una computadora y empiezan a sentirse como una extensión de ti. Este conocimiento viene de las charlas de diseño de Apple en WWDC — principalmente *Designing Fluid Interfaces* (WWDC 2018) — destilado y traducido a la plataforma web (CSS, Pointer Events, `requestAnimationFrame`, librerías de resortes como Motion/Framer Motion).

La idea que atraviesa todo: **una interfaz se siente viva cuando el movimiento parte del valor actual en pantalla, hereda la velocidad del usuario, proyecta la inercia hacia adelante y puede agarrarse y revertirse en cualquier instante.** Los resortes son la herramienta que hace natural todo esto, porque son inherentemente interrumpibles y conscientes de la velocidad.

## La idea central

> "Cuando alineamos la interfaz con la forma en que pensamos y nos movemos, ocurre algo mágico: deja de sentirse como una computadora y empieza a sentirse como una extensión continua de nosotros."

Una interfaz es fluida cuando se comporta como el mundo físico: las cosas responden al instante, se mueven de forma continua, conservan inercia, resisten en los límites y pueden redirigirse a mitad del movimiento. Todo lo que sigue es una forma de acercarse a eso.

Apple plantea el diseño como servir cuatro necesidades humanas: **seguridad/previsibilidad, comprensión, logro y alegría.** Cada regla de aquí sirve a alguna de ellas.

## 1. Respuesta — elimina la latencia

En el momento en que aparece el retardo, la sensación de inmediatez se "desploma". La respuesta es la base sobre la que se construye todo lo demás.

- **Responde en pointer-down, no en la liberación.** Resalta un botón en el instante en que se pulsa. Esperar al `click`/touch-up para mostrar feedback se siente muerto.
- **Vigila cada latencia.** Audita los *debounces*, temporizadores artificiales, esperas de transición y el retraso de toque de ~300ms. Todo lo que esté en la ruta de entrada y no sea esencial es una regresión.
- **El feedback debe ser continuo *durante* la interacción, no solo al final.** En un arrastre, un slider o un cajón, actualiza la UI 1:1 con el puntero durante todo el trayecto: nunca animes solo cuando el gesto se completa.

```css
/* El feedback vive en la pulsación, y es instantáneo */
.button:active {
  transform: scale(0.97);
  transition: transform 100ms ease-out;
}
```

## 2. Manipulación directa — tracking 1:1

> "El toque y el contenido deben moverse juntos."

Cuando el usuario arrastra algo, debe quedar pegado al dedo — y respetar el desplazamiento respecto a *donde lo agarró*. Saltar al centro del elemento al agarrarlo rompe la ilusión de inmediato.

- Usa Pointer Events con `setPointerCapture` para que el tracking continúe incluso cuando el puntero sale de los límites del elemento.
- Registra un breve **historial de velocidad/posición** (los últimos eventos `pointermove`), no solo el punto actual: necesitarás la velocidad al soltar.

```js
el.addEventListener('pointerdown', (e) => {
  el.setPointerCapture(e.pointerId);
  const grabOffset = e.clientY - el.getBoundingClientRect().top; // respeta dónde lo agarró
  // ...registra posición + marcas de tiempo para la velocidad
});
```

## 3. Interrumpibilidad — el principio más importante

> "El pensamiento y el gesto ocurren en paralelo."

Toda animación debe ser interrumpible y redirigible en cualquier momento. El usuario debe poder agarrar un elemento en movimiento a medio vuelo y revertirlo sin esperar a que la animación termine. Un modal que se está cerrando y que el usuario vuelve a agarrar debe seguir al dedo, no terminar de cerrarse primero y luego reabrirse.

- **Nunca bloquees la entrada durante una transición.**
- **Anima siempre desde el valor de *presentación* (actual), nunca desde el valor objetivo.** Al interrumpir, lee el transform vivo del elemento en pantalla y arranca la nueva animación desde ahí. Arrancar desde el valor lógico/objetivo provoca un salto visible.
- **Evita las transiciones CSS y los `@keyframes` para todo lo guiado por gestos**: no se pueden agarrar ni revertir con suavidad a medio vuelo. Los resortes animan desde el valor actual por defecto, que es justo lo que la interrupción necesita.
- **Cuando un gesto se revierte, mezcla la velocidad: no la cortes en seco.** Reemplazar una animación por otra en una reversión crea una discontinuidad de velocidad, un "muro de ladrillo". Las librerías de resortes que arrastran la velocidad a través de un nuevo objetivo la evitan. (Esto es lo que hacen de forma nativa las *animaciones aditivas* de iOS; en la web, elige una librería de resortes que reapunte desde la velocidad actual.)
- **Descompón el movimiento 2D en resortes X e Y independientes.** Un solo resorte sobre una distancia 2D se desincroniza cuando X e Y tienen velocidades distintas.

## 4. Comportamiento antes que animación — usa resortes

> "Piensa en la animación como una conversación entre tú y el objeto, no como algo prescrito por la interfaz."

Una animación preescrita de duración fija no puede responder a nueva entrada. Un resorte sí: la nueva entrada solo cambia el objetivo y el movimiento sigue siendo continuo. Recurre a los resortes para todo lo que el usuario pueda tocar.

Apple reemplazó deliberadamente el triplete físico (masa/rigidez/amortiguación) por dos parámetros amigables para el diseño. Piensa en estos términos:

- **Razón de amortiguación** — controla el sobrepaso. `1.0` = amortiguación crítica, sin rebote, asentamiento suave. `< 1.0` = sobrepasa y oscila. Menor = más rebotante.
- **Response** — con qué rapidez el valor alcanza el objetivo, en segundos. Menor = más ágil. **Esto no es "duration"**: un resorte no tiene duración fija; su tiempo de asentamiento surge de los parámetros.

**Valores por defecto:**
- Inicia la mayoría de la UI con **amortiguación `1.0`** (amortiguación crítica): elegante y sin distraer.
- Agrega rebote (**amortiguación ~`0.8`**) **solo cuando el gesto en sí cargó inercia** (un flick, un lanzamiento, la liberación de un arrastre). El sobrepaso en un menú que simplemente se desvanció hacia dentro se siente mal; el sobrepaso en una tarjeta que flickeaste se siente bien.

**Valores concretos que usa Apple:**

| Interacción | Amortiguación | Response |
| --- | --- | --- |
| Mover / reposicionar (p. ej. PiP) | `1.0` | `0.4` |
| Rotación | `0.8` | `0.4` |
| Cajón / hoja | `0.8` | `0.3` |

**Mapeo web (Motion / Framer Motion):** la API de resortes `bounce` + `duration` mapea muy bien a la amortiguación + response de Apple. Un estilo de casa seguro es usar resortes con `damping: 1.0` por defecto en todas partes; reserva el rebote para interacciones físicas impulsadas por la inercia.

```js
import { animate } from 'motion';

// Amortiguación crítica por defecto (sin sobrepaso)
animate(el, { y: 0 }, { type: 'spring', bounce: 0, duration: 0.4 });

// Interacción con inercia: un poco de rebote, solo porque la precedió un flick
animate(el, { y: target }, { type: 'spring', bounce: 0.2, duration: 0.4 });
```

## 5. Entrega de velocidad — la costura entre arrastre y animación

Cuando un gesto termina, la animación debe **continuar a la velocidad exacta del dedo**, para que no haya una costura visible entre arrastrar y animar. Este es el detalle que más separa "fluido" de "correcto".

Pasa la velocidad de liberación del puntero como velocidad inicial del resorte. Algunas APIs de resorte quieren velocidad **relativa**: normalízala por la distancia restante hasta el objetivo:

```
relativeVelocity = gestureVelocity / (targetValue − currentValue)
```

Ejemplo: elemento en `y=50`, objetivo `y=150` (faltan 100px), dedo moviéndose a 50px/s → velocidad inicial del resorte = `50 / 100 = 0.5`. Framer Motion / Motion aceptan directamente la velocidad absoluta en px/s (opción `velocity`), así que normalmente le pasas el valor crudo.

## 6. Proyección de inercia — anima hacia donde el gesto *va*

> "Toma una entrada pequeña y produce una salida grande."

No saltes al límite más cercano desde el *punto de liberación*. Usa la velocidad para **proyectar la posición de reposo** — exactamente como la deceleración del scroll — y luego ajusta al objetivo más cercano a ese punto proyectado. Esto es lo que hace que un flick se sienta como si lanzara el elemento.

La función exacta de proyección de Apple (del código de muestra de *Designing Fluid Interfaces*):

```js
// decelerationRate ≈ 0.998 para una sensación de scroll normal; 0.99 para más ágil
function project(initialVelocity /* px/s */, decelerationRate = 0.998) {
  return (initialVelocity / 1000) * decelerationRate / (1 - decelerationRate);
}

const projectedEndpoint = currentPosition + project(releaseVelocity);
const target = nearestSnapPoint(projectedEndpoint);   // elige el objetivo a partir de la proyección
animateSpringTo(target, { velocity: releaseVelocity }); // luego entrega la velocidad (§5)
```

Nota: el `v²/(2·decel)` de los libros de física *no* es lo que usa Apple: usa la forma de decaimiento exponencial de arriba. Este es el comportamiento estándar en buenas hojas inferiores y carruseles (Vaul, Embla).

## 7. Consistencia espacial — trayectorias simétricas, orígenes anclados

> "Si algo desaparece de una forma, esperamos que emerja de donde vino."

- **Entra y sale por el mismo camino.** Un panel que se desliza desde la derecha debe cerrarse hacia la derecha. Entrar por la derecha / salir por abajo se siente desconectado y confuso.
- **Ancla las interacciones a su origen.** Un menú, popover u hoja debería originarse en el elemento que lo disparó: define `transform-origin` en el disparador, para que la relación espacial entre el botón y el contenido sea obvia. (Este es el mismo punto de conciencia del origen que hace que los popover escalen desde su disparador y no desde su centro.)
- **Refleja la curva de aceleración en las transiciones reversibles** para que el camino de ida coincida con el de vuelta (usa puntos de control cubic-bézier inversos para las dos direcciones).

## 8. Insinuar en la dirección del gesto

Los humanos predecimos un estado final a partir de una trayectoria. El movimiento intermedio debe anticipar hacia dónde van las cosas: los módulos del Control Center "crecen hacia arriba y hacia fuera, hacia tu dedo". Haz que los fotogramas intermedios apunten al resultado, no que solo interpolen ciegamente hacia él.

## 9. Rubber-banding — límites blandos

En un borde, resiste progresivamente en lugar de detenerte en seco. Una parada brusca se lee como "congelado"; una resistencia continua se lee como "responde, pero aquí no hay nada más". Aplica una amortiguación que crezca cuanto más se pase el límite el usuario.

```js
// Cuanto más se pase el límite, menos sigue el elemento: las cosas reales frenan antes de parar
function rubberband(overshoot, dimension, constant = 0.55) {
  return (overshoot * dimension * constant) / (dimension + constant * Math.abs(overshoot));
}
```

## 10. Detalles de diseño de gestos (la lista de "sensación")

- **Toque:** resalta en touch-*down* (instantáneo), confirma en touch-*up*. Agrega ~10px de histéresis/margen de acierto alrededor del objetivo, y permite cancelar arrastrando fuera y de vuelta.
- **Arrastre/deslizamiento:** exige un umbral pequeño de movimiento (histéresis, ~10px) antes de comprometerte con una dirección, y luego sigue 1:1.
- **Detecta todos los gestos plausibles en paralelo desde el primer movimiento**, y luego cancela con confianza a los perdedores una vez que la intención es clara. Evita reconocedores que solo reportan un estado *final* (eventos tipo `swipeleft`): descartan el tracking continuo que necesitas para el feedback.
- **Minimiza los retrasos de desambiguación.** La detección de doble toque inevitablemente retrasa los toques simples; paga ese costo solo donde el doble toque exista de verdad.

## 11. Suavidad a nivel de fotograma

La suavidad depende de *qué hay en los fotogramas*, no solo de la tasa de fotogramas.

- Mantén el cambio posicional por fotograma por debajo del umbral de percepción para evitar el efecto estroboscópico.
- Para movimiento muy rápido, un sutil **desenfoque de movimiento / estiramiento** codifica la velocidad y se lee mejor que una estela nítida y abrupta.
- `requestAnimationFrame` es el reloj de la web sincronizado con la pantalla (Apple usa `CADisplayLink`). Anima solo propiedades amigables con el compositor — `transform` y `opacity` — y avisa con `will-change` donde el movimiento sea inminente.

## 12. Materiales y profundidad — la translucidez comunica jerarquía

Apple usa materiales translúcidos como una capa funcional flotante que aporta estructura sin robar el foco. En la web, aproxímalo con `backdrop-filter`.

- **Construye nav/barras/hojas como capas translúcidas** (`backdrop-filter: blur()` + un fondo semitransparente) con el contenido desplazándose por debajo, no como barras opacas que consumen una franja fija.
- **El peso del material codifica la jerarquía:** los materiales más oscuros/pesados separan regiones estructurales (barras laterales); los más ligeros dirigen la atención a los elementos interactivos (botones). **Nunca apiles una superficie translúcida clara sobre otra**: la legibilidad se desploma.
- **Las superficies más grandes deben leerse como más gruesas:** más blur + una sombra más profunda que los chips pequeños. Considera sombras conscientes del contexto: más pesadas sobre contenido cargado o textual para separar, más ligeras sobre fondos planos.
- **Atenúa para enfocar, separa para mantener el flujo.** Una tarea modal empareja la superficie con un scrim de atenuación y empuja el fondo hacia atrás/abajo. Un panel paralelo y no bloqueante usa translucidez y desplazamiento *sin* scrim para que el flujo no se rompa. Para hojas apiladas, atenúa y empuja atrás progresivamente cada capa padre.
- **La vibrancia mantiene el texto legible sobre fondos cambiantes.** Sobre superficies con blur/translúcidas, no uses texto gris plano: usa mayor contraste, un peso ligeramente más pesado y un pequeño aumento del letter-spacing. Pon el color en una capa sólida, no en el primer plano translúcido.
- **Efectos en el borde del scroll, no divisores duros.** En lugar de un borde de 1px bajo un encabezado fijo, desvanece una pequeña máscara de blur/degradado donde el contenido se encuentra con el cromo flotante, solo donde la UI flotante realmente se superpone al contenido.
- **Materializa, no solo desvanezcas.** Para superficies de vidrio/blur, anima el radio de blur y la escala juntos al entrar/salir, para que la superficie se lea como un material real que llega y no como un simple fundido de opacidad.

```css
.toolbar {
  background: rgba(255, 255, 255, 0.6);
  backdrop-filter: blur(20px) saturate(180%);
  border-top: 1px solid rgba(255, 255, 255, 0.4); /* borde superior claro = la luz que golpea el material */
}
```

## 13. Feedback multimodal — movimiento + sonido + háptica

Tres reglas para combinar sentidos (de *Designing Audio-Haptic Experiences*):

1. **Causalidad**: debe ser obvio qué causó el feedback. Dispara el feedback en el evento causal real (el toggle que cambia, el elemento que vuelve a su sitio) y haz coincidir su carácter con la fisicalidad de la acción.
2. **Armonía**: lo visual, el sonido y la háptica deben dispararse en el **mismo fotograma**. La latencia entre ellos destruye la ilusión. No dejes que una transición CSS se quede atrás del audio o de la háptica (Vibration API).
3. **Utilidad**: agrega feedback solo donde se gane su lugar. Reserva háptica y sonido para momentos significativos (éxito, error, confirmación, ajuste). El exceso de feedback entrena a los usuarios a ignorarlo todo.

## 14. Movimiento reducido y accesibilidad

El movimiento reducido no significa *ningún* feedback: significa un equivalente más suave y no vestibular. Responde a tres señales independientes e incorpóralas en tus componentes:

- **`prefers-reduced-motion: reduce`** — reemplaza deslizamientos/resortes/parallaje por **fundidos cruzados o transiciones estáticas** cortos de opacidad. Elimina lo elástico y el sobrepaso. Conserva los cambios de opacidad/color que ayuden a la comprensión.
- **`prefers-reduced-transparency: reduce`** — vuelve más opacas/sólidas las superficies translúcidas: sube la opacidad del fondo y quita el blur.
- **`prefers-contrast: more`** — fondos casi sólidos con un borde definido y contrastado.

También: evita fondos móviles que ocupen toda la ventana, oscilaciones lentas en bucle (cerca de 0.2 Hz / un ciclo cada 5s) y saltos bruscos de brillo (suaviza los cambios de tema oscuro↔claro). Haz semitransparentes los objetos grandes en movimiento mientras se desplazan, y desvanece las superficies grandes durante un reposicionamiento amplio y vuelve a fundirlas cuando se asienten.

```css
@media (prefers-reduced-motion: reduce) {
  .sheet { transition: opacity 200ms ease; transform: none !important; }
}
@media (prefers-reduced-transparency: reduce) {
  .toolbar { background: white; backdrop-filter: none; }
}
```

## 15. Tipografía — tamaño óptico, tracking, interlineado

Apple diseña la tipografía para que cambie de forma con el tamaño; la misma disciplina aplica en la web. (De *The Details of UI Typography*, WWDC 2020.)

- **El tracking (letter-spacing) es específico del tamaño: nunca un solo valor para todos los tamaños.** El texto grande de display quiere tracking *negativo* (las letras se leen demasiado separadas al crecer); el texto pequeño quiere tracking ligeramente *positivo* para la legibilidad. Un `letter-spacing` fijo está mal en algún lado. Aprieta los títulos y deja el cuerpo cerca de `0`.
- **El interlineado (line-height) acompaña al tamaño de forma inversa.** Ajustado en títulos grandes, más suelto en texto de cuerpo. Auméntalo para scripts con ascendentes/descendentes altos; apriétalo para UI densa y rica en información.
- **Construye la jerarquía a partir de peso + tamaño + interlineado como un conjunto,** no solo del tamaño. Enfatiza con peso: aporta presencia sin ocupar más espacio.
- **Respeta el ajuste de tamaño de texto del usuario** (Dynamic Type). Escala el layout *con* el texto: espaciado en `rem`/`em`, no px fijos, para que una fuente más grande no rompa el layout.
- **Apóyate por defecto en la fuente de sistema de la plataforma** antes que en una cara personalizada: ya incluye tamaño óptico, tablas de tracking y ajuste de legibilidad. Sobreescríbela solo con una razón.

```css
:root { font: 100%/1.5 system-ui, sans-serif; } /* cuerpo: fuente de sistema, interlineado cómodo */

.display {
  font-size: clamp(2rem, 5vw, 4rem);
  line-height: 1.05;        /* interlineado ajustado para texto grande */
  letter-spacing: -0.02em;  /* tracking negativo al crecer */
  font-optical-sizing: auto;
}
```

## 16. Fundamentos de diseño — los ocho principios

El movimiento y el oficio de arriba sirven a los ocho principios de diseño de Apple (*Principles of Great Design*, WWDC 2026). Úsalos como los nombres con los que razonas:

1. **Propósito.** Crea con intención; decide qué *no* construir. Cada funcionalidad pide el tiempo, la atención y la confianza del usuario: gasta ese presupuesto solo donde rinde.
2. **Autonomía.** Mantén a la gente al mando: ofrece opciones, no fuerces un único camino. Respalda eso con perdón: deshacer fácil para los errores, un diálogo de confirmación solo para acciones genuinamente destructivas e irreversibles (úsalo con moderación; abusar de él entrena a la gente a hacer clic sin leer).
3. **Responsabilidad.** Actúa en interés del usuario. Privacidad: pregunta en el momento justo, solo por lo necesario, de forma transparente. Seguridad: anticipa el mal uso y el daño, especialmente con IA (una app de recetas consciente de alergias no debe sugerir un ingrediente dañino). Agrega vistas previas, confirmaciones, avisos; elimina una funcionalidad cuyo riesgo supere su valor.
4. **Familiaridad.** Construye sobre lo que la gente ya conoce. Usa metáforas que no sean ni demasiado literales ni demasiado abstractas (un bote de basura significa eliminar) y respeta su física. Sé consistente: lo que se ve igual debe comportarse igual y vivir en el mismo lugar (cerrar siempre arriba a la izquierda en macOS) para que la gente pueda predecir qué pasa después. Solo rompe un patrón familiar si puedes demostrar que es mejor, y entonces pruébalo, no lo asumas.
5. **Flexibilidad.** Diseña para distintos contextos, dispositivos y todo el espectro de capacidades. Adáptate a la plataforma (iPhone = toque rápido; escritorio = flujos profundos con control preciso del puntero) y a la situación. Diseña de forma inclusiva (edad, idioma, experiencia, accesibilidad). Cuando ningún layout le sirve a todos, deja que la gente personalice: reordena controles, oculta lo que no usa.
6. **Simplicidad, no minimalismo.** Quita lo innecesario para que el propósito central resplandezca; enterrarlo todo en un solo lugar se ve minimalista pero no es simple. Sé conciso (lenguaje llano, sin jerga, menos pasos) y claro (usa jerarquía: orden, espaciado, contraste) para que lo más importante sea lo más obvio. Cada elemento se gana su lugar; a veces *añadir* contexto simplifica (una barra de reproducción de video que muestra el tiempo restante). Muestra primero el camino común y las opciones avanzadas un nivel más adentro.
7. **Oficio.** La atención al detalle sin concesiones construye confianza. Tipografía hermosa, colores que se adaptan a claro/oscuro, iconografía clara y animaciones responsivas que dan feedback inmediato y natural. Nada es aleatorio: cada valor de espaciado, tiempo y alineación es una decisión deliberada que puedes defender. El scroll tembloroso, los iconos desalineados y los layouts que se rompen al rotar se leen como descuido. El oficio necesita iteración y longevidad: sigue evolucionando el diseño a medida que cambian las funcionalidades y el hardware.
8. **Encanto.** Es el resultado de acertar con los otros siete, no confeti pegado encima. Decide la emoción que quieres que la gente sienta (calma, confianza, emoción) y refuérzala en cada decisión.

Reglas tácticas que sirven a estos principios:

- **El feedback viene en cuatro clases:** estado, finalización, advertencia, error. Confirma las acciones significativas, expone el estado en curso, advierte antes de los problemas, valida en línea (no al enviar).
- **Orientación.** Cada pantalla debería responder: ¿dónde estoy? ¿a dónde puedo ir? ¿qué hay aquí? ¿cómo salgo? Nunca atrapes al usuario.
- **Agrupación y correspondencia.** La proximidad implica relación: coloca un control cerca de lo que afecta y ordena los controles de forma que refleje lo que cambian. Si necesitas una etiqueta para explicar un control, la correspondencia es débil.
- **Las etiquetas directas y específicas vencen a las genéricas y seguras.** Nombra los elementos de navegación por su contenido ("Progreso", "Biblioteca"), no por paraguas vagos ("Inicio"). La especificidad genera previsibilidad.

## 17. Proceso

- **Prototipa de forma interactiva: una demo interactiva vale "un millón de diseños estáticos".** Descubres la interfaz construyéndola y jugando con ella; un prototipo funcional además fija una vara concreta que evita una implementación final mediocre.
- **Diseña la interacción y lo visual juntos.** "No deberías poder decir dónde termina una y empieza la otra." El movimiento no es una capa que se agrega después de los píxeles.
- **Prueba con personas reales en contexto real**, y revisa el movimiento con ojos frescos: reprodúcelo en cámara lenta, fotograma a fotograma, para atrapar lo que es invisible a velocidad completa.

## Referencia rápida

| Necesidad | Técnica | Valor concreto |
| --- | --- | --- |
| Resorte de UI por defecto | Amortiguación crítica, sin sobrepaso | `damping 1.0`, `response 0.3–0.4` |
| Resorte de inercia / flick | Subamortiguado, rebote slighto | `damping ~0.8`, `response 0.3–0.4` |
| Velocidad de gesto → resorte | Entrega la velocidad de liberación | `gestureVelocity / (target − current)` si está normalizada |
| Punto de aterrizaje del flick | Proyecta la inercia | `current + (v/1000)·d/(1−d)`, `d ≈ 0.998` |
| Interrumpir limpiamente | Parte del valor de presentación (vivo) | lee el transform en pantalla |
| Evitar el "muro de ladrillo" al revertir | Conserva la velocidad al reapuntar | resorte que mezcle la velocidad |
| Transición reversible | Refleja la curva de aceleración | cubic-bézier inversa |
| Decide reversión vs. confirmación | Usa el **signo** de la velocidad, no la posición | al soltar |
| Arrastre 1:1 | Pointer Events + captura | respeta el desplazamiento de agarre |
| Feedback | En pointer-down, continuo | nunca solo al final |
| Límite | Banda elástica, no frenado brusco | resistencia progresiva |
| Cromo translúcido | Capa con `backdrop-filter` | el contenido se desplaza debajo |
| Tracking tipográfico | Específico por tamaño, nunca fijo | aprieta el texto grande (`-0.02em`), cuerpo cerca de `0` |
| Movimiento reducido | Fundido cruzado, no deslizamiento/resorte | `@media (prefers-reduced-motion)` |
