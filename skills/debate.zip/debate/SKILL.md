﻿---
name: debate
description: Debate deliberativo multi-perspectiva entre especialistas con roles opuestos y síntesis arbitral central. Úsalo para evaluar alternativas técnicas, arquitecturas o trade-offs sin invalidar caché de contexto ni abrir sub-sesiones costosas.
argument-hint: "[single-context|swarm] \"<dilema, arquitectura o decisión técnica>\""
version: "2.0.0-opencode"
license: MIT
---

# ⚖️ Debate — Deliberación Técnica Multi-Perspectiva (Zero Cache Invalidation)

> **Axioma del Debate**: **La mejor decisión técnica surge de la tensión dialéctica entre perspectivas opuestas.**
> En OpenCode / Claude / Gemini, **abrir sub-sesiones o sub-agentes para cada turno invalida el Prompt Cache del LLM**, disparando costos y latencia. 
> Por ello, la skill `debate` opera de forma predeterminada en **MODO MONOLÍTICO DE CONTEXTO ÚNICO (In-Context Multi-Persona)**: un único turno o proceso fluido que reutiliza el 100% de la caché de prefijo.

---

## 🚀 1. MODOS DE EJECUCIÓN: CACHE-FRIENDLY VS SWARM

| Modo | Cuándo usar | Impacto en Caché / Sesiones | Mecánica |
| :--- | :--- | :--- | :--- |
| **`in-context`** *(Default en OpenCode)* | **Siempre por defecto.** Evaluación de librerías, arquitecturas, diseño de API, refactorings. | **0 sub-sesiones.** Preserva el Prompt Cache (costo mínimo, velocidad instantánea). | El modelo asume secuencialmente los 4 roles en bloques dialécticos dentro del mismo hilo. |
| **`swarm`** *(Opcional explícito)* | Solo si se pide explícitamente auditar código en paralelo con herramientas pesadas. | Abre subagentes aislados (más tokens, reescritura de caché). | Despacha subagentes independientes con archivo `.agents/debates/` como bus. |

---

## 👥 2. LOS 4 ROLES COGNITIVOS EN CONTEXTO

El agente adopta 4 arquetipos con mandatos estrictamente opuestos:

1. 🏗️ **Architect**: Máxima modularidad, contratos de tipos estrictos, desacoplamiento de capas, escalabilidad a futuro y prevención de deuda técnica.
2. ⚡ **Pragmatist**: Simplicidad radical (YAGNI), cero dependencias superfluas, biblioteca estándar, solución mínima que funciona y máxima velocidad de entrega.
3. ⚔️ **Adversary (Red Team / Chaos)**: Dónde y cómo se rompe: condiciones de carrera, fallos de red a mitad de ACK, saturación de memoria, locks de archivos, excepciones no capturadas y casos borde extremos.
4. ⚖️ **Lead Arbiter (Juez y Síntesis)**: Modera, evalúa trade-offs reales (costo vs beneficio), descarta falacias y emite el dictamen final vinculante.

---

## 🔄 3. PROTOCOLO DIALÉCTICO EN 3 RONDAS (IN-CONTEXT)

Cuando el usuario invoque `debate "<tema>"`, el agente ejecuta la deliberación en un único flujo estructurado:

```markdown
### 🥊 RONDA 1: PROPUESTAS Y TESIS INICIALES
- **🏗️ Architect**: [Propuesta estructural, tipos y capas]
- **⚡ Pragmatist**: [Propuesta minimalista, YAGNI, código plano]
- **⚔️ Adversary**: [Vectores de falla, bordes destructivos y riesgos ignorados]

---

### ⚔️ RONDA 2: FUEGO CRUZADO Y CONCESIONES (RÉPLICAS)
- **Pragmatist vs Architect**: Ataca la sobre-ingeniería innecesaria.
- **Pragmatist ante Adversary**: Reconoce qué fallos reales obligan a ceder y adoptar robustez.
- **Architect ante Adversary**: Incorpora las salvaguardas mínimas en la arquitectura sin romper el desacoplamiento.
- **Adversary (Límites del Ring)**: Fija los candados que no son negociables en código.

---

### ⚖️ RONDA 3: DICTAMEN FINAL DEL LEAD ARBITER
1. **Veredicto Ejecutivo**: Enfoque ganador justificado.
2. **Matriz de Trade-offs**: Qué se aceptó y qué se descartó de cada especialista.
3. **Salvaguardas Obligatorias**: Candados del Adversary que van al código sí o sí.
4. **Plan de Acción Inmediato**: Pasos quirúrgicos a implementar.
```

---

## 💡 4. VENTAJAS DE ESTE ENFOQUE EN OPENCODE
- **Cero reescritura de caché de prefijo**: La conversación fluye linealmente, aprovechando el KV-cache de Anthropic/OpenAI/Gemini.
- **Sin subsesiones huérfanas**: No deja procesos ni sub-turnos flotando en el cliente de OpenCode.
- **Inmediatez**: Respuesta completa con debate genuino en una fracción de segundo, sin esperas asíncronas ni polling.
