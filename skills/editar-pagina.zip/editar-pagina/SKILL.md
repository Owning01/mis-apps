---
name: editar-pagina
description: Cambiar CÓMO SE VE O SE COMPORTA una página web abierta en el navegador (ocultar, mover, borrar o agregar elementos; tocar CSS o HTML del sitio). Usalo cuando el usuario diga "cambiá esto en la página", "ocultá este banner", "sacá este popup", "arreglá el estilo de esta web", "quiero que se vea distinto", "editá esta página", "modificá esta página". El cambio se aplica sobre el DOM vivo que entrega Chrome, nunca sobre archivos del disco.
---

# Editar una página en el navegador

## Regla de oro

La fuente de verdad es la **página viva**: el HTML, el CSS y el JS que Chrome ya
tiene cargados. Los lees y los cambias por el DOM, con los tools del navegador.

**Nunca** busques el archivo fuente del sitio en el disco. **Nunca** edites el
repo del usuario pensando que ahí vive la página. Si el usuario dice "cambiá
esto" mientras mira una pestaña, el cambio va en esa pestaña.

Señales de que te equivocaste: aparecen pasos como "busco el componente",
"¿dónde está el archivo de esa página?", un `grep` en `G:\Proyectos`, o un
`edit` sobre un `.tsx`/`.html` del repo. Pará y volvé al DOM.

## Qué tools usar (no confundir)

Hay dos familias de tools de navegador y **no son la misma cosa**:

| Familia | Qué maneja | Cuándo usarla |
|---|---|---|
| **`browser-control`** (25 tools) | Tu **Chrome/Brave real**, el que estás mirando | Siempre, para editar tu página |
| **`browser.*`** (45 tools) | El navegador interno del app de escritorio de OpenCode (panel Review) | Sólo si el usuario habla de ese panel |

Señal de que estás en la familia equivocada: `browser.tabs.list()` devuelve
`{ tabs: [], focusedTabID: null }`. La página del usuario **no está ahí**. Volvé a
`browser-control`.

## Elegir la pestaña

1. `browser-control.session_adopt({})` — adopta la única pestaña que el usuario compartió.
2. `browser-control.session_adopt({ targetUrl: "ejemplo.com" })` — cuando hay varias, elegís por un trozo de URL.
3. Si no hay ninguna compartida, pedile al usuario que apriete **Share tab** en el panel lateral (botón con un `+` chico, arriba del composer). Sin eso el agente no ve su página. No abras una pestaña nueva: tiene su propia sesión, sin sus logins.

Cuando el usuario comparte la pestaña, `session_adopt({})` la toma. Verificá con
`session_current` que `pageUrl` sea la URL que el usuario mencionó, no
`about:blank`.

## Leer antes de tocar

```js
return await snapshot()
```

`snapshot()` devuelve un árbol semántico compacto. Para el HTML crudo:

```js
return await page.evaluate(() => document.documentElement.outerHTML.slice(0, 20000))
```

Para saber qué estilos aplican a un elemento:

```js
return await page.evaluate(() => {
  const el = document.querySelector("SELECTOR")
  if (!el) return null
  const cs = getComputedStyle(el)
  return { tag: el.tagName, display: cs.display, position: cs.position, width: cs.width }
})
```

## Aplicar el cambio (temporal)

El cambio dura hasta que la página se recargue. Es el modo por defecto.

**CSS** — inyectá un `<style>` con un id propio, para poder quitarlo después:

```js
return await page.evaluate(() => {
  const id = "opencode-edit-css"
  document.getElementById(id)?.remove()
  const s = document.createElement("style")
  s.id = id
  s.textContent = "SELECTOR { display: none !important; }"
  document.head.append(s)
  return "ok"
})
```

**HTML** — mové, borrá o agregá nodos:

```js
return await page.evaluate(() => {
  const el = document.querySelector("SELECTOR")
  if (!el) return "no encontrado"
  el.remove()
  // el.style.color = "red"
  // el.insertAdjacentHTML("afterend", "<p>hola</p>")
  return "ok"
})
```

**Comportamiento** — si el usuario pide algo que actúa y no sólo se ve, usá
`el.addEventListener(...)` dentro de `page.evaluate`. Ojo: ese listener muere al
recargar, y para conservarlo el camino es un site script.

## Conservar el cambio

Si el usuario quiere el cambio **cada vez** que entra al sitio, eso es un **site
script**. Ahí aparece el botón para decidir si se conservan los cambios: el panel
le muestra el código y el usuario aprueba.

```js
code: `// ==UserScript==
// @name        Ocultar banner de ejemplo.com
// @match       https://ejemplo.com/*
// @run-at      document_end
// ==/UserScript==
const s = document.createElement("style")
s.textContent = "#banner { display: none !important; }"
document.head.append(s)
`,
matches: ["https://ejemplo.com/*"],
```

Se llama con `tools.site_scripts.install`. Después: `site_scripts.list` para
verlos, `site_scripts.set_enabled` para prenderlos o apagarlos por sitio,
`site_scripts.remove` para borrarlos.

Preguntá siempre lo mismo: **"¿lo querés sólo ahora, o cada vez que entres?"**.

## Verificar

Nunca digas que quedó bien porque el código corrió. Mirá el resultado:

```js
return await page.evaluate(() => {
  const el = document.querySelector("SELECTOR")
  if (!el) return { presente: false }
  const cs = getComputedStyle(el)
  return { presente: true, display: cs.display, visibility: cs.visibility }
})
```

Cuando el aspecto importa, devolvé la imagen:
`return await screenshotWithLabels({ page })`.

## Trampas

- El elemento puede estar en un `<iframe>`. Verificá con `page.frames().map((f) => f.url())` y usá `frame.locator(...)`.
- `document.querySelector` no atraviesa shadow roots **cerrados**. Los abiertos sí. Si el elemento no aparece, buscá el host y entrá por `.shadowRoot`.
- El sitio puede repintar y borrar tu cambio. En un site script volvé a aplicar, o usá `MutationObserver` y `@run-at document_end`.
- Si `execute` falla con "Execution context was destroyed" o aparece `target/cross-extension-page`, el gestor de contraseñas abrió un menú propio de la extensión. Pedile al usuario que lo cierre y reintentá. No resetees la pestaña.
- No uses `page.goto()` para "recargar y ver": si la página tiene estado sin guardar, lo perdés. Preferí `reload()` sólo si el usuario lo pide.
