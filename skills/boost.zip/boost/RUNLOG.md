# RUNLOG — skill boost (máx 25 líneas, rotar)

- 2026-09-03 | editor-lag | FileEditor modal → LiteEditor; Tab colapsado inserta indent; collectWords lazy. tsc 0, vitest 118, build 0. Commit 12ffd329.
- 2026-09-03 | editor-monaco-6 | undo/redo propio, curline, Ctrl+Shift+O, paste-reindent, Ln/Col, hl adaptativo. tsc 0, vitest 72, build 0. Commit c53cc319.
- 2026-09-11 | dsh-switch | Boost+deep-investigator: integracion DeepSeek Harness como motor alterno. Opcion D (plugin openher-bridge + perfil, 4.30) > E hibrido ACP (4.10) > B (3.95). Corrige research-multi-harness (dsh NO es OpenAI-compat). Informe en docs/research-dsh-integration.md. 0 codigo.
