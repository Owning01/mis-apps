# Recetas de animación en Expo

Implementaciones listas para construir para los casos que más se repiten en una app React Native. Parte de la receta y después adáptala.

---

## Configuración que asumen las recetas

```bash
npx expo install react-native-reanimated react-native-worklets react-native-gesture-handler expo-haptics
```

(`react-native-keyboard-controller` solo para la receta del teclado.) `expo install`, no `npm install` — resuelve las versiones que corresponden al SDK. El plugin de Babel de worklets lo configura `babel-preset-expo` automáticamente.

`GestureHandlerRootView` envuelve la app una sola vez — en Expo Router, el `_layout` raíz:

```jsx
import { GestureHandlerRootView } from 'react-native-gesture-handler';

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <Stack />
    </GestureHandlerRootView>
  );
}
```

Imports y constantes que comparten todas las recetas siguientes:

```js
import { useState, useEffect, useMemo } from 'react';
import Animated, {
  useSharedValue, useAnimatedStyle, useAnimatedScrollHandler, useAnimatedReaction,
  withSpring, withTiming, interpolate, Extrapolation, Easing,
  FadeInDown, FadeOutDown, LinearTransition,
} from 'react-native-reanimated';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import { scheduleOnRN } from 'react-native-worklets';
import * as Haptics from 'expo-haptics';

const EASE_OUT = Easing.bezier(0.23, 1, 0.32, 1);      // ease-out fuerte para UI
const EASE_IN_OUT = Easing.bezier(0.77, 0, 0.175, 1);  // movimiento en pantalla
const EASE_SHEET = Easing.bezier(0.32, 0.72, 0, 1);    // curva de hoja de iOS
```

Tres convenciones, explicadas una sola vez acá en lugar de en cada receta:

- **Los shared values se leen y se escriben con `.get()` / `.set()`**, la forma que recomienda la documentación de Reanimated para soportar React Compiler. `.value` sigue funcionando, pero el compilador no puede atravesarlo.
- **`scheduleOnRN(fn, ...args)` reemplaza al deprecado `runOnJS(fn)(...args)`** para llamar de vuelta al runtime de React Native desde un worklet.
- **Los gestos se envuelven en `useMemo`.** Reconstruir un gesto en cada render reconecta el recognizer y puede cortar un arrastre que está en pleno vuelo.

**Gesture Handler v3:** Expo instala v2, y las recetas usan su builder `Gesture.Pan()`. Si el proyecto ya está en v3, el builder es legacy — cada gesto es un hook que toma un objeto de configuración, con `onStart` → `onActivate`, `onEnd` → `onDeactivate`, y el flag `success` reemplazado por `event.canceled` (invertido). El hook gestiona su propia identidad, así que saca el `useMemo`:

```jsx
const pan = usePanGesture({
  activeOffsetY: [-10, 10],
  onActivate: () => { context.set(translateY.get()); },
  onUpdate: (e) => { translateY.set(context.get() + e.translationY); },
  onDeactivate: (e) => { /* asienta con withSpring como abajo */ },
});
```

---

## Dos worklets que vas a necesitar en todas partes

La proyección de inercia decide *hacia dónde iba un flick*, así que un swipe rápido y corto se confirma y uno lento y largo no. El rubber-banding hace que un límite resista en lugar de frenar en seco.

```js
// Dónde quedaría el dedo en reposo si siguiera frenando.
// La forma de decaimiento exponencial de Apple — no el v²/2a de la clase de física.
function project(velocity, decelerationRate = 0.998) {
  'worklet';
  return ((velocity / 1000) * decelerationRate) / (1 - decelerationRate);
}

// Cuanto más pasa del borde, menos sigue el elemento.
function rubberband(overshoot, dimension, constant = 0.55) {
  'worklet';
  return (overshoot * dimension * constant) / (dimension + constant * Math.abs(overshoot));
}
```

---

## Feedback de pulsación

Todos los pulsables de la app. Esto pasa la puerta de frecuencia solo porque es casi imperceptible: 120ms y un scale del 3% es el techo para algo que se toca tan a menudo — cualquier cosa más larga o más grande pertenece a momentos más raros, según el paso 1 de SKILL.md. Sin gesto, sin shared value — una transición CSS es toda la implementación.

```jsx
import Animated from 'react-native-reanimated';
import { Pressable, StyleSheet } from 'react-native';

function PressableScale({ onPress, children }) {
  const [pressed, setPressed] = useState(false);
  return (
    <Pressable
      onPress={onPress}
      onPressIn={() => setPressed(true)}
      onPressOut={() => setPressed(false)}
      hitSlop={12}
      pressRetentionOffset={16}
    >
      <Animated.View style={[styles.box, pressed && styles.pressed]}>{children}</Animated.View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  box: {
    transform: [{ scale: 1 }],
    transitionProperty: 'transform',
    transitionDuration: '120ms',
    transitionTimingFunction: 'cubic-bezier(0.23, 1, 0.32, 1)',
  },
  pressed: { transform: [{ scale: 0.97 }] },
});
```

`setState` está bien acá — se dispara dos veces por pulsación, no por cuadro. `hitSlop` lleva un icono pequeño hasta el objetivo de 44pt sin agrandarlo; `pressRetentionOffset` evita que una leve desviación del dedo cancele la pulsación.

---

## Hoja inferior que se descarta arrastrando

Antes de escribir esto: si la hoja es su propio destino, usa `presentation: 'formSheet'` (mira **Transiciones de pantalla**) y obtén gratis la hoja real de la plataforma. Construye esto solo cuando la hoja tenga que vivir dentro de una pantalla existente.

```jsx
const translateY = useSharedValue(0);
const context = useSharedValue(0);

const pan = useMemo(() => Gesture.Pan()
  .activeOffsetY([-10, 10])   // deja ganar al swipe horizontal; exige intención antes de confirmar
  .onStart(() => {
    context.set(translateY.get());   // parte del valor actual en pantalla, no de 0
  })
  .onUpdate((e) => {
    const next = context.get() + e.translationY;
    // hacia abajo es libre; hacia arriba más allá del tope resiste
    translateY.set(next >= 0 ? next : rubberband(next, HEIGHT));
  })
  .onEnd((e) => {
    const projected = translateY.get() + project(e.velocityY);
    if (projected > HEIGHT * 0.4) {
      translateY.set(withSpring(HEIGHT, {
        duration: 300, dampingRatio: 1, velocity: e.velocityY, overshootClamping: true,
      }, (finished) => { if (finished) scheduleOnRN(onClose); }));
    } else {
      translateY.set(withSpring(0, { duration: 300, dampingRatio: 0.8, velocity: e.velocityY }));
      scheduleOnRN(Haptics.impactAsync, Haptics.ImpactFeedbackStyle.Light);   // volvió a su sitio
    }
  }), [onClose]);

const sheetStyle = useAnimatedStyle(() => ({ transform: [{ translateY: translateY.get() }] }));
```

Los cuatro detalles que separan esto de un mal arrastre:

- **`onStart` captura el valor actual.** Sin eso, tomar una hoja en pleno recorrido la teletransporta — la animación debe continuar desde donde el ojo la vio por última vez.
- **Decide la velocidad, no la distancia.** `project()` hace que un flick rápido descarte la hoja con solo unos píxeles de desplazamiento. Exigir 40% de recorrido hace que la hoja se sienta pesada.
- **La velocidad se pasa al resorte**, así que no hay costura entre el dedo soltándose y la animación continuando. Este es el único detalle que más separa "fluido" de "correcto".
- **`overshootClamping` al descartar** — si no, la hoja rebota más allá del fondo de la pantalla y deja ver un hueco.

El fondo se deriva del mismo valor, así que siempre está sincronizado y no cuesta nada:

```jsx
const backdropStyle = useAnimatedStyle(() => ({
  opacity: interpolate(translateY.get(), [0, HEIGHT], [1, 0], Extrapolation.CLAMP),
}));
```

---

## Swipe para borrar una fila

Antes de escribir esto: gesture-handler incluye [`ReanimatedSwipeable`](https://docs.swmansion.com/react-native-gesture-handler/docs/components/reanimated_swipeable/), que ya hace swipe-to-reveal de acciones — umbrales, sobreimpulso, métodos de apertura/cierre — en el hilo de UI. Recúrrele cuando la fila revele botones de acción. Construye el gesto tú mismo solo cuando la interacción sea de otra naturaleza: swipe para confirmar con proyección de inercia, como esta.

```jsx
const x = useSharedValue(0);
const context = useSharedValue(0);

const pan = useMemo(() => Gesture.Pan()
  .activeOffsetX([-10, 10])   // debe declarar el eje, o pelea con el scroll vertical
  .onStart(() => { context.set(x.get()); })   // tomar en pleno resorte continúa desde donde está la fila, no desde 0
  .onUpdate((e) => { x.set(Math.min(0, context.get() + e.translationX)); })
  .onEnd((e) => {
    const projected = x.get() + project(e.velocityX);
    if (projected < -SWIPE_THRESHOLD) {
      x.set(withTiming(-WIDTH, { duration: 200, easing: EASE_OUT }, (f) => {
        if (f) scheduleOnRN(onDelete, id);
      }));
    } else {
      x.set(withSpring(0, { duration: 300, dampingRatio: 1, velocity: e.velocityX }));
    }
  }), [onDelete, id]);
```

Cerrar el hueco que dejó la fila borrada es trabajo de la lista, no de la fila:

```jsx
const ROW_CLOSE = LinearTransition.duration(200);   // ámbito de módulo — los builders recreados en el render cuestan en cada re-render

<Animated.FlatList data={items} itemLayoutAnimation={ROW_CLOSE} ... />
```

`activeOffsetX` es la parte propia de mobile. Un pan handler dentro de un scroll view sin eje declarado se apropia de los scrolls verticales, y la lista se siente rota de una forma que parece un bug de scroll y no de gesto.

---

## Header que colapsa con el scroll

```jsx
const scrollY = useSharedValue(0);
const onScroll = useAnimatedScrollHandler((e) => { scrollY.set(e.contentOffset.y); });

const titleStyle = useAnimatedStyle(() => ({
  opacity: interpolate(scrollY.get(), [0, 60], [1, 0], Extrapolation.CLAMP),
  transform: [{ translateY: interpolate(scrollY.get(), [0, 60], [0, -12], Extrapolation.CLAMP) }],
}));

<Animated.ScrollView onScroll={onScroll} scrollEventThrottle={16}>
```

**Nunca animes el `height` del header para hacerlo colapsar.** Eso corre una pasada de layout sobre el header y todo lo que está debajo en cada cuadro de scroll — la única animación que garantiza tirones, porque compite con el propio scroll. Dale al contenedor una altura fija y traslada el contenido dentro, recortando con `overflow: 'hidden'`.

`Extrapolation.CLAMP` no es opcional: sin él, seguir desplazándose más allá de 60 sigue llevando la opacidad a valores negativos y el header reaparece invertido al final de una lista larga.

---

## Entradas de listas

```jsx
// Los docs de Reanimated recomiendan construir las animaciones de layout fuera de los
// componentes, o en useMemo — una cadena inline en JSX reconstruye el builder en cada render.
// Un delay por índice no puede vivir en el ámbito de módulo, así que la fila memoriza el suyo:
function Row({ item, index }) {
  const entering = useMemo(() => FadeInDown.duration(250).delay(index * 40), [index]);
  return <Animated.View entering={entering}>{/* ... */}</Animated.View>;
}

{items.map((item, i) => <Row key={item.id} item={item} index={i} />)}
```

Escalonado de 30–80ms. Más largo se siente lento, más corto se lee como simultáneo.

**Nunca pongas `entering` en una fila dentro de `FlatList`, `FlashList` o cualquier lista virtualizada.** Las filas se reciclan, así que la animación se vuelve a disparar cada vez que una reaparece en pantalla — la lista parece parpadear mientras el usuario se desplaza. Anima el contenedor de la lista una vez al montar, o usa `itemLayoutAnimation` solo para el reflujo.

Las animaciones de entrada son para el contenido que el usuario pidió y está esperando. Una lista que el usuario recorre todo el día debería ya estar ahí.

---

## UI sincronizada con el teclado

Necesita su propio módulo y un provider de una vez ([guía de teclado de Expo](https://docs.expo.dev/guides/keyboard-handling/)):

```bash
npx expo install react-native-keyboard-controller
```

```jsx
import { KeyboardProvider } from 'react-native-keyboard-controller';

// _layout raíz, junto a GestureHandlerRootView — los hooks de abajo no hacen nada sin esto.
<KeyboardProvider>
  <Stack />
</KeyboardProvider>
```

```jsx
import { useReanimatedKeyboardAnimation } from 'react-native-keyboard-controller';

const { height } = useReanimatedKeyboardAnimation();   // 0 → -keyboardHeight, en el hilo de UI
const footerStyle = useAnimatedStyle(() => ({ transform: [{ translateY: height.get() }] }));
```

Nunca construyas esto con `Keyboard.addListener` más una animación de timing. El teclado viaja sobre una curva privada del sistema, el evento llega al hilo de JS después de que el teclado ya empezó a moverse, y cualquier duración que elijas se va a ver rezagada o adelantada. La UI debe ser conducida por la posición real del teclado, cuadro a cuadro.

---

## Indicador de pestañas / control segmentado

Mide una vez, después anima transforms.

```jsx
const [layouts, setLayouts] = useState({});   // medido con onLayout, no por cuadro
const x = useSharedValue(0);
const w = useSharedValue(0);

useEffect(() => {
  const l = layouts[active];
  if (!l) return;
  x.set(withTiming(l.x, { duration: 250, easing: EASE_IN_OUT }));
  w.set(withTiming(l.width, { duration: 250, easing: EASE_IN_OUT }));
}, [active, layouts]);

const pillStyle = useAnimatedStyle(() => ({
  transform: [{ translateX: x.get() }],
  width: w.get(),
}));
```

Esta es la animación de `width` sancionada: la píldora está en posicionamiento absoluto y sin hijos, así que nada más recalcula layout, y su radio de esquina sobrevive — `scaleX` deformaría las esquinas en óvalos.

`ease-in-out`, porque la píldora se mueve cruzando la pantalla en vez de entrar o salir de ella. Dispara `Haptics.selectionAsync()` en la pulsación, no cuando la píldora se posa.

---

## Transiciones de pantalla (Expo Router)

Configura la pila nativa. Nunca reconstruyas una transición de pantalla en JS: la nativa corre del lado de la plataforma, conserva el gesto interactivo de retroceso y coincide con cualquier otra app del dispositivo.

```jsx
<Stack screenOptions={{ animation: reduced ? 'fade' : 'default' }}>
  <Stack.Screen name="settings" options={{ animation: 'slide_from_right', animationMatchesGesture: true }} />
  <Stack.Screen name="compose" options={{ presentation: 'modal' }} />
  <Stack.Screen name="filter" options={{
    presentation: 'formSheet',
    sheetAllowedDetents: 'fitToContents',
    sheetGrabberVisible: true,
  }} />
</Stack>
```

| Navegación | Opción |
| --- | --- |
| Más adentro en una jerarquía | `animation: 'default'` — el push de la plataforma, sin modificar |
| Una tarea autocontenida que el usuario puede abandonar | `presentation: 'modal'` |
| Una interrupción breve: picker, filtro, compartir | `presentation: 'formSheet'` con detents |
| Entre pestañas | `animation: 'none'` |
| Movimiento reducido | `animation: 'fade'` |

`animationMatchesGesture: true` hace que el swipe de retroceso de iOS ejecute tu transición al revés bajo el dedo, en lugar del push por defecto. Actívalo siempre que pongas un `animation` propio, o arrastrar hacia atrás se verá como una app distinta de la que aparece al avanzar.

`formSheet` es nativo en ambas plataformas, pero no igual en ambas — los [docs de modales de Expo](https://docs.expo.dev/router/advanced/modals/#form-sheet-presentation) tienen la lista completa:

- **Android limita los detents a tres.** Un array `sheetAllowedDetents` más largo funciona en iOS y se trunca en silencio en Android — diseña para tres.
- **`sheetGrabberVisible` es solo de iOS.** Android no muestra grabber; no dependas de él como única afordancia de "esto se arrastra".
- **Las form sheets de Android no pueden alojar headers nativos ni pilas anidadas.** Mantén el contenido de la hoja en una sola pantalla; si necesita su propia navegación, usa `presentation: 'modal'` en su lugar.
- **`fitToContents` necesita contenido con tamaño explícito.** Una raíz con `flex: 1` no tiene altura intrínseca que ajustar — dale tamaño al contenido, o el detent queda mal.

---

## Toast

```jsx
// Ámbito de módulo — los builders de animación de layout viven fuera del componente.
const TOAST_ENTER = FadeInDown.duration(300).easing(EASE_OUT);
const TOAST_EXIT = FadeOutDown.duration(250).easing(EASE_OUT);

<Animated.View
  entering={TOAST_ENTER}
  exiting={TOAST_EXIT}
  style={{ position: 'absolute', bottom: insets.bottom + 16, left: 16, right: 16 }}
/>
```

- **El techo de 300ms también aplica acá.** Un toast no es la excepción — es no solicitado, así que debería ser más rápido y más discreto que el movimiento que el usuario pidió, si algo.
- **Sale de la misma manera en que entró.** Entrar desde abajo y salir hacia el lado se lee como dos elementos sin relación.
- **Sale ~20% más rápido que como entra.** El usuario ya terminó de leer; la llegada merece el tiempo, la salida no.
- **Insets de área segura, siempre.** Un toast en `bottom: 16` queda debajo del indicador de inicio en todos los iPhone modernos.

Si los toasts se apilan y la lista se refluye, agrega `itemLayoutAnimation` y espera tener que ajustar la opacidad contra el reflujo a ojo — no hay fórmula para esa pareja. Míralo de nuevo al día siguiente.

---

## Disparar algo una sola vez en un umbral

Cuando un punto de cruce importa — un detent, un snap, la activación de un pull-to-refresh — no lo sondees desde JS ni hagas `scheduleOnRN` en cada cuadro.

```jsx
const armed = useSharedValue(false);

useAnimatedReaction(
  () => pullDistance.get() > REFRESH_THRESHOLD,
  (isArmed, wasArmed) => {
    if (isArmed !== wasArmed) {
      armed.set(isArmed);
      scheduleOnRN(Haptics.impactAsync, Haptics.ImpactFeedbackStyle.Light);
    }
  }
);
```

La comparación corre en el hilo de UI en cada cuadro; la llamada a JS ocurre dos veces por arrastre. Ese es el patrón para cada "haz algo cuando la animación llegue a X".
